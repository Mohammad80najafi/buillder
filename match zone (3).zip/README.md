
  # match zone

  This is a code bundle for match zone. The original project is available at https://www.figma.com/design/oXJttuVhZxVIc92AjqfV52/match-zone.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  