/**
 * League System Components Export
 * اکسپورت کامپوننت‌های سیستم لیگ
 */

export { ProfessionalLeagueSystem } from './ProfessionalLeagueSystem';