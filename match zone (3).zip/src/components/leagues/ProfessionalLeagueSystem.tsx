/**
 * Professional League System - Advanced competitive ranking system
 * مرحله 5: سیستم لیگ حرفه‌ای پیشرفته
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  Trophy, 
  Crown, 
  Zap, 
  TrendingUp, 
  Users, 
  Calendar,
  Star,
  Award,
  Target,
  Flame,
  Shield,
  Sword,
  ChevronUp,
  ChevronDown
} from 'lucide-react';

interface LeagueTier {
  id: string;
  name: string;
  nameEn: string;
  icon: React.ReactNode;
  color: string;
  bgColor: string;
  minRating: number;
  maxRating: number;
  benefits: string[];
  seasonRewards: {
    coins: number;
    gems: number;
    exclusive: string[];
  };
}

interface PlayerRanking {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  currentRating: number;
  peakRating: number;
  tier: string;
  rank: number;
  winRate: number;
  totalGames: number;
  recentForm: boolean[];
  isRising: boolean;
  isStreaming?: boolean;
}

interface SeasonInfo {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  totalPlayers: number;
  averageRating: number;
}

const LEAGUE_TIERS: LeagueTier[] = [
  {
    id: 'bronze',
    name: 'برنز',
    nameEn: 'Bronze',
    icon: <Shield className="w-5 h-5" />,
    color: 'text-orange-600',
    bgColor: 'bg-orange-100 dark:bg-orange-900/20',
    minRating: 0,
    maxRating: 1199,
    benefits: ['دسترسی به لابی‌های عمومی', 'پاداش روزانه پایه'],
    seasonRewards: { coins: 1000, gems: 50, exclusive: ['آواتار ویژه برنز'] }
  },
  {
    id: 'silver',
    name: 'نقره',
    nameEn: 'Silver',
    icon: <Star className="w-5 h-5" />,
    color: 'text-gray-600',
    bgColor: 'bg-gray-100 dark:bg-gray-900/20',
    minRating: 1200,
    maxRating: 1699,
    benefits: ['دسترسی به تورنومنت‌های نقره‌ای', 'پاداش روزانه +25%'],
    seasonRewards: { coins: 2500, gems: 100, exclusive: ['آواتار ویژه نقره', 'فریم پروفایل'] }
  },
  {
    id: 'gold',
    name: 'طلا',
    nameEn: 'Gold',
    icon: <Award className="w-5 h-5" />,
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-100 dark:bg-yellow-900/20',
    minRating: 1700,
    maxRating: 2199,
    benefits: ['دسترسی به تورنومنت‌های طلایی', 'پاداش روزانه +50%', 'ساخت کلن ویژه'],
    seasonRewards: { coins: 5000, gems: 250, exclusive: ['آواتار ویژه طلا', 'فریم ویژه', 'اموجی اختصاصی'] }
  },
  {
    id: 'platinum',
    name: 'پلاتین',
    nameEn: 'Platinum',
    icon: <Target className="w-5 h-5" />,
    color: 'text-cyan-600',
    bgColor: 'bg-cyan-100 dark:bg-cyan-900/20',
    minRating: 2200,
    maxRating: 2699,
    benefits: ['دسترسی به لیگ حرفه‌ای', 'پاداش روزانه +75%', 'مربیگری رسمی'],
    seasonRewards: { coins: 10000, gems: 500, exclusive: ['آواتار ویژه پلاتین', 'عنوان اختصاصی'] }
  },
  {
    id: 'diamond',
    name: 'الماس',
    nameEn: 'Diamond',
    icon: <Zap className="w-5 h-5" />,
    color: 'text-blue-600',
    bgColor: 'bg-blue-100 dark:bg-blue-900/20',
    minRating: 2700,
    maxRating: 3199,
    benefits: ['دسترسی به مسابقات الماسی', 'پاداش روزانه +100%', 'استریم رسمی'],
    seasonRewards: { coins: 20000, gems: 1000, exclusive: ['آواتار ویژه الماس', 'استریم بج'] }
  },
  {
    id: 'master',
    name: 'استاد',
    nameEn: 'Master',
    icon: <Crown className="w-5 h-5" />,
    color: 'text-purple-600',
    bgColor: 'bg-purple-100 dark:bg-purple-900/20',
    minRating: 3200,
    maxRating: 3999,
    benefits: ['دعوت به تیم‌های حرفه‌ای', 'اسپانسر رسمی', 'مشارکت در رویدادها'],
    seasonRewards: { coins: 50000, gems: 2500, exclusive: ['عنوان استاد', 'کلید ویژه'] }
  },
  {
    id: 'grandmaster',
    name: 'استاد بزرگ',
    nameEn: 'Grandmaster',
    icon: <Trophy className="w-5 h-5" />,
    color: 'text-red-600',
    bgColor: 'bg-red-100 dark:bg-red-900/20',
    minRating: 4000,
    maxRating: 9999,
    benefits: ['شرکت در جام قهرمانان', 'درآمد از اسپانسرها', 'نماینده رسمی Matchzone'],
    seasonRewards: { coins: 100000, gems: 5000, exclusive: ['تاج استاد بزرگ', 'دسترسی VIP'] }
  }
];

const mockSeasonData: SeasonInfo = {
  id: 'season-5',
  name: 'فصل پنجم: قهرمانان آسمان',
  startDate: '1403/06/01',
  endDate: '1403/09/30',
  isActive: true,
  totalPlayers: 125847,
  averageRating: 1650
};

const mockLeaderboard: PlayerRanking[] = [
  {
    id: '1',
    username: 'persian_legend',
    displayName: 'افسانه پارس',
    avatar: '/avatars/legend.png',
    currentRating: 4250,
    peakRating: 4350,
    tier: 'grandmaster',
    rank: 1,
    winRate: 87.5,
    totalGames: 1250,
    recentForm: [true, true, true, true, false],
    isRising: true,
    isStreaming: true
  },
  {
    id: '2',
    username: 'shadow_master',
    displayName: 'استاد سایه',
    avatar: '/avatars/shadow.png',
    currentRating: 4180,
    peakRating: 4200,
    tier: 'grandmaster',
    rank: 2,
    winRate: 84.2,
    totalGames: 980,
    recentForm: [true, true, false, true, true],
    isRising: false
  },
  {
    id: '3',
    username: 'fire_phoenix',
    displayName: 'ققنوس آتشین',
    avatar: '/avatars/phoenix.png',
    currentRating: 4050,
    peakRating: 4120,
    tier: 'grandmaster',
    rank: 3,
    winRate: 82.1,
    totalGames: 1150,
    recentForm: [true, false, true, true, true],
    isRising: true
  }
];

export function ProfessionalLeagueSystem() {
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [currentPlayerRating] = useState(2350);
  const [seasonTimeLeft] = useState({ days: 45, hours: 12, minutes: 30 });

  const getCurrentTier = (rating: number): LeagueTier => {
    return LEAGUE_TIERS.find(tier => 
      rating >= tier.minRating && rating <= tier.maxRating
    ) || LEAGUE_TIERS[0];
  };

  const currentTier = getCurrentTier(currentPlayerRating);
  const nextTier = LEAGUE_TIERS.find(tier => tier.minRating > currentPlayerRating);
  const progressToNext = nextTier 
    ? ((currentPlayerRating - currentTier.minRating) / (nextTier.minRating - currentTier.minRating)) * 100
    : 100;

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto" dir="rtl">
      {/* Season Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center gap-3">
          <Trophy className="w-8 h-8 text-yellow-500" />
          <h1 className="text-3xl font-bold">لیگ حرفه‌ای Matchzone</h1>
        </div>
        
        <Card className="border-2 border-yellow-500/20 bg-gradient-to-r from-yellow-500/10 to-orange-500/10">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-yellow-400">{mockSeasonData.name}</h2>
                <p className="text-sm text-muted-foreground">
                  {mockSeasonData.totalPlayers.toLocaleString()} بازیکن ��عال
                </p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-yellow-400">
                  {seasonTimeLeft.days} روز
                </p>
                <p className="text-sm text-muted-foreground">باقی مانده از فصل</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Current Player Status */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className={`border-2 ${currentTier.bgColor} border-opacity-50`}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-3 rounded-full ${currentTier.bgColor}`}>
                  {currentTier.icon}
                </div>
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <span className={currentTier.color}>رتبه {currentTier.name}</span>
                    <Badge variant="secondary">{currentPlayerRating} امتیاز</Badge>
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    رتبه شما در این فصل
                  </p>
                </div>
              </div>
              {nextTier && (
                <div className="text-left">
                  <p className="text-sm text-muted-foreground">تا رتبه بعدی:</p>
                  <p className="font-semibold">
                    {nextTier.minRating - currentPlayerRating} امتیاز
                  </p>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {nextTier && (
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">پیشرفت تا {nextTier.name}:</span>
                  <span className="text-sm font-medium">{Math.round(progressToNext)}%</span>
                </div>
                <Progress value={progressToNext} className="h-2" />
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* League Tiers Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Tabs defaultValue="tiers" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tiers">رتبه‌بندی‌ها</TabsTrigger>
            <TabsTrigger value="leaderboard">جدول امتیازات</TabsTrigger>
            <TabsTrigger value="rewards">پاداش‌ها</TabsTrigger>
          </TabsList>

          <TabsContent value="tiers" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {LEAGUE_TIERS.slice().reverse().map((tier, index) => (
                <motion.div
                  key={tier.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className={`transition-all hover:scale-105 ${
                    tier.id === currentTier.id 
                      ? `ring-2 ring-${tier.color.split('-')[1]}-500 ${tier.bgColor}` 
                      : 'hover:shadow-lg'
                  }`}>
                    <CardHeader className="text-center pb-3">
                      <div className={`mx-auto p-3 rounded-full w-fit ${tier.bgColor}`}>
                        {tier.icon}
                      </div>
                      <CardTitle className={`text-lg ${tier.color}`}>
                        {tier.name}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {tier.minRating} - {tier.maxRating === 9999 ? '+' : tier.maxRating} امتیاز
                      </p>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-1">
                        {tier.benefits.map((benefit, idx) => (
                          <p key={idx} className="text-xs flex items-start gap-1">
                            <span className="text-green-500 mt-0.5">•</span>
                            {benefit}
                          </p>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="leaderboard" className="space-y-4">
            <div className="space-y-3">
              {mockLeaderboard.map((player, index) => (
                <motion.div
                  key={player.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className={`${index < 3 ? 'bg-gradient-to-r from-yellow-500/5 to-orange-500/5 border-yellow-500/20' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-2">
                            <span className={`text-2xl font-bold ${
                              index === 0 ? 'text-yellow-500' :
                              index === 1 ? 'text-gray-400' :
                              index === 2 ? 'text-orange-600' :
                              'text-muted-foreground'
                            }`}>
                              #{player.rank}
                            </span>
                            {index < 3 && (
                              <Trophy className={`w-5 h-5 ${
                                index === 0 ? 'text-yellow-500' :
                                index === 1 ? 'text-gray-400' :
                                'text-orange-600'
                              }`} />
                            )}
                          </div>
                          
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={player.avatar} alt={player.displayName} />
                            <AvatarFallback>{player.displayName.charAt(0)}</AvatarFallback>
                          </Avatar>
                          
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{player.displayName}</h3>
                              {player.isStreaming && (
                                <Badge variant="destructive" className="text-xs">
                                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-1" />
                                  لایو
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">@{player.username}</p>
                          </div>
                        </div>

                        <div className="text-left space-y-1">
                          <div className="flex items-center gap-2">
                            <Badge className={getCurrentTier(player.currentRating).color}>
                              {player.currentRating} امتیاز
                            </Badge>
                            {player.isRising ? (
                              <ChevronUp className="w-4 h-4 text-green-500" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-red-500" />
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {player.winRate}% برد | {player.totalGames} بازی
                          </p>
                          <div className="flex gap-1">
                            {player.recentForm.map((win, idx) => (
                              <div
                                key={idx}
                                className={`w-2 h-2 rounded-full ${
                                  win ? 'bg-green-500' : 'bg-red-500'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="rewards" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {LEAGUE_TIERS.slice().reverse().map((tier, index) => (
                <motion.div
                  key={tier.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full">
                    <CardHeader className="text-center">
                      <div className={`mx-auto p-3 rounded-full w-fit ${tier.bgColor}`}>
                        {tier.icon}
                      </div>
                      <CardTitle className={`${tier.color}`}>{tier.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">پاداش‌های فصل</p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex justify-between items-center p-2 bg-muted rounded-lg">
                        <span className="text-sm">سکه:</span>
                        <span className="font-semibold text-yellow-600">
                          {tier.seasonRewards.coins.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-muted rounded-lg">
                        <span className="text-sm">جواهر:</span>
                        <span className="font-semibold text-blue-600">
                          {tier.seasonRewards.gems.toLocaleString()}
                        </span>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">موارد ویژه:</p>
                        {tier.seasonRewards.exclusive.map((item, idx) => (
                          <p key={idx} className="text-xs flex items-start gap-1">
                            <Star className="w-3 h-3 text-yellow-500 mt-0.5" />
                            {item}
                          </p>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}