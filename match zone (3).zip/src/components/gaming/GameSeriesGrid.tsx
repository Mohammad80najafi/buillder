/**
 * Game Series Grid Component
 * نمایش شبکه‌ای از سری بازی‌ها
 */

import React, { useState, useMemo, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Search, Filter, Grid, List, Star, TrendingUp, 
  Clock, Users, PlayCircle, Crown, ChevronLeft, ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useMobile } from '../ui/use-mobile';
import { GameSeriesCard, GameSeries } from './GameSeriesCard';

interface GameSeriesGridProps {
  title?: string;
  description?: string;
  series: GameSeries[];
  onEpisodeSelect?: (episodeId: string) => void;
  onSeriesSelect?: (seriesId: string) => void;
  showSearch?: boolean;
  showFilters?: boolean;
  showCategories?: boolean;
  viewType?: 'grid' | 'list';
  itemsPerPage?: number;
  compact?: boolean;
}

export function GameSeriesGrid({ 
  title = "مجموعه بازی‌ها",
  description = "سری‌های بازی محبوب و جدید",
  series,
  onEpisodeSelect, 
  onSeriesSelect,
  showSearch = true,
  showFilters = true,
  showCategories = true,
  viewType = 'grid',
  itemsPerPage = 6,
  compact = false
}: GameSeriesGridProps) {
  const isMobile = useMobile();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('همه');
  const [sortBy, setSortBy] = useState('جدیدترین');
  const [currentPage, setCurrentPage] = useState(0);
  const [displayViewType, setDisplayViewType] = useState<'grid' | 'list'>(viewType);

  // استخراج دسته‌بندی‌ها
  const categories = useMemo(() => 
    ['همه', ...Array.from(new Set(series.map(s => s.category)))],
    [series]
  );

  // فیلتر کردن سری‌ها
  const filteredSeries = useMemo(() => 
    series.filter(s => {
      const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           s.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'همه' || s.category === selectedCategory;
      return matchesSearch && matchesCategory;
    }),
    [series, searchQuery, selectedCategory]
  );

  // مرتب‌سازی
  const sortedSeries = useMemo(() => {
    const sorted = [...filteredSeries];
    switch (sortBy) {
      case 'محبوب‌ترین':
        return sorted.sort((a, b) => b.stats.totalViews - a.stats.totalViews);
      case 'بهترین امتیاز':
        return sorted.sort((a, b) => b.rating - a.rating);
      case 'بیشترین شرکت‌کننده':
        return sorted.sort((a, b) => b.stats.totalParticipants - a.stats.totalParticipants);
      case 'جدیدترین':
      default:
        return sorted; // فرض می‌کنیم که لیست از قبل مرتب است
    }
  }, [filteredSeries, sortBy]);

  // صفحه‌بندی
  const totalPages = useMemo(() => 
    Math.ceil(sortedSeries.length / itemsPerPage),
    [sortedSeries.length, itemsPerPage]
  );
  
  const paginatedSeries = useMemo(() => 
    sortedSeries.slice(
      currentPage * itemsPerPage,
      (currentPage + 1) * itemsPerPage
    ),
    [sortedSeries, currentPage, itemsPerPage]
  );

  const handleNextPage = useCallback(() => {
    if (currentPage < totalPages - 1) {
      setCurrentPage(prev => prev + 1);
    }
  }, [currentPage, totalPages]);

  const handlePrevPage = useCallback(() => {
    if (currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    }
  }, [currentPage]);

  const handleCategoryChange = useCallback((category: string) => {
    setSelectedCategory(category);
    setCurrentPage(0);
  }, []);

  const getGridColumns = useCallback(() => {
    if (compact) {
      return isMobile ? 'grid-cols-2' : 'grid-cols-4';
    }
    return isMobile ? 'grid-cols-1' : 'grid-cols-2';
  }, [compact, isMobile]);

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-bold">{title}</h2>
          <p className="text-muted-foreground">{description}</p>
        </div>

        {/* Search and Filters */}
        {(showSearch || showFilters) && (
          <div className="flex flex-col gap-4">
            {/* Search */}
            {showSearch && (
              <div className="relative max-w-md">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجو در سری بازی‌ها..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10"
                />
              </div>
            )}

            {/* Filters */}
            {showFilters && (
              <div className="flex flex-wrap items-center gap-4">
                {/* View Type Toggle */}
                <div className="flex rounded-lg border p-1">
                  <Button
                    size="sm"
                    variant={displayViewType === 'grid' ? 'default' : 'ghost'}
                    onClick={() => setDisplayViewType('grid')}
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant={displayViewType === 'list' ? 'default' : 'ghost'}
                    onClick={() => setDisplayViewType('list')}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>

                {/* Sort Dropdown */}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">مرتب‌سازی:</span>
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="bg-background border rounded px-3 py-1 text-sm"
                  >
                    <option value="جدیدترین">جدیدترین</option>
                    <option value="محبوب‌ترین">محبوب‌ترین</option>
                    <option value="بهترین امتیاز">بهترین امتیاز</option>
                    <option value="بیشترین شرکت‌کننده">بیشترین شرکت‌کننده</option>
                  </select>
                </div>

                {/* Results Count */}
                <span className="text-sm text-muted-foreground">
                  {sortedSeries.length} سری بازی
                </span>
              </div>
            )}
          </div>
        )}

        {/* Categories */}
        {showCategories && (
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                size="sm"
                variant={selectedCategory === category ? 'default' : 'outline'}
                onClick={() => handleCategoryChange(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        )}
      </div>

      {/* Series Grid/List */}
      <AnimatePresence mode="wait">
        <motion.div
          key={`${selectedCategory}-${sortBy}-${currentPage}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {paginatedSeries.length === 0 ? (
            <Card className="p-8 text-center">
              <div className="space-y-4">
                <PlayCircle className="h-16 w-16 mx-auto text-muted-foreground" />
                <div>
                  <h3 className="font-semibold">سری بازی‌ای یافت نشد</h3>
                  <p className="text-muted-foreground">لطفاً جستجوی خود را تغییر دهید</p>
                </div>
              </div>
            </Card>
          ) : displayViewType === 'grid' ? (
            <div className={`grid ${getGridColumns()} gap-6`}>
              {paginatedSeries.map((serie) => (
                <motion.div
                  key={serie.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <GameSeriesCard
                    series={serie}
                    onEpisodeSelect={onEpisodeSelect}
                    onSeriesSelect={onSeriesSelect}
                    compact={compact}
                    showEpisodes={!compact}
                  />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {paginatedSeries.map((serie) => (
                <motion.div
                  key={serie.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="p-4 hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => onSeriesSelect?.(serie.id)}>
                    <div className="flex gap-4">
                      <div className="w-32 h-20 relative overflow-hidden rounded-lg flex-shrink-0">
                        <img 
                          src={serie.coverImage} 
                          alt={serie.title}
                          className="w-full h-full object-cover"
                        />
                        {serie.isPremium && (
                          <Badge className="absolute top-1 right-1 bg-yellow-500 text-white text-xs">
                            <Crown className="h-3 w-3" />
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex-1 space-y-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-semibold line-clamp-1">{serie.title}</h3>
                            <p className="text-sm text-muted-foreground line-clamp-2">{serie.description}</p>
                          </div>
                          <div className="flex items-center gap-1 text-sm">
                            <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                            {serie.rating}
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <PlayCircle className="h-4 w-4" />
                            {serie.totalEpisodes} قسمت
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            {serie.stats.totalParticipants.toLocaleString('fa-IR')}
                          </div>
                          <Badge variant="secondary">{serie.category}</Badge>
                        </div>

                        {serie.completedEpisodes > 0 && (
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs text-muted-foreground">
                              <span>پیشرفت: {serie.completedEpisodes} از {serie.totalEpisodes}</span>
                              <span>{Math.round((serie.completedEpisodes / serie.totalEpisodes) * 100)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-primary h-2 rounded-full transition-all duration-300"
                                style={{ width: `${(serie.completedEpisodes / serie.totalEpisodes) * 100}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-4">
          <Button 
            variant="outline"
            onClick={handlePrevPage}
            disabled={currentPage === 0}
          >
            <ChevronRight className="h-4 w-4 ml-1" />
            قبلی
          </Button>
          
          <div className="flex items-center gap-2">
            {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
              const pageNumber = currentPage < 3 ? i : 
                               currentPage >= totalPages - 3 ? totalPages - 5 + i :
                               currentPage - 2 + i;
              
              if (pageNumber >= 0 && pageNumber < totalPages) {
                return (
                  <Button
                    key={pageNumber}
                    size="sm"
                    variant={currentPage === pageNumber ? 'default' : 'outline'}
                    onClick={() => setCurrentPage(pageNumber)}
                    className="w-8 h-8 p-0"
                  >
                    {pageNumber + 1}
                  </Button>
                );
              }
              return null;
            })}
          </div>
          
          <Button 
            variant="outline"
            onClick={handleNextPage}
            disabled={currentPage >= totalPages - 1}
          >
            بعدی
            <ChevronLeft className="h-4 w-4 mr-1" />
          </Button>
        </div>
      )}
    </div>
  );
}

export default GameSeriesGrid;