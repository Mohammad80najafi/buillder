/**
 * Lobby Chat System
 * سیستم چت مخصوص لابی - فقط برای اعضای پذیرفته شده
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { ScrollArea } from '../ui/scroll-area';
import { Separator } from '../ui/separator';
import { 
  MessageCircle, 
  Send, 
  Shield, 
  Crown, 
  User,
  Lock,
  Settings,
  MoreVertical,
  AlertTriangle,
  Flag,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Clock,
  Check,
  CheckCheck
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface ChatMessage {
  id: string;
  user: {
    id: string;
    username: string;
    avatar: string;
    role: 'owner' | 'admin' | 'member';
    isOnline: boolean;
  };
  content: string;
  timestamp: Date;
  type: 'message' | 'system' | 'voice' | 'join' | 'leave';
  isRead?: boolean;
  reactions?: { emoji: string; users: string[]; }[];
}

interface LobbyChatSystemProps {
  lobbyId: string;
  currentUser: {
    id: string;
    username: string;
    avatar: string;
    role: 'owner' | 'admin' | 'member';
  };
  membershipStatus: 'none' | 'pending' | 'approved' | 'rejected';
  members: Array<{
    id: string;
    username: string;
    avatar: string;
    role: 'owner' | 'admin' | 'member';
    isOnline: boolean;
  }>;
  onSendMessage?: (message: string) => void;
  disabled?: boolean;
}

export function LobbyChatSystem({ 
  lobbyId, 
  currentUser, 
  membershipStatus, 
  members, 
  onSendMessage,
  disabled = false 
}: LobbyChatSystemProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      user: {
        id: '1',
        username: 'کاپیتان_پرو',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
        role: 'owner',
        isOnline: true
      },
      content: 'سلام به همه! لابی آماده است 🎮',
      timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
      type: 'message',
      isRead: true
    },
    {
      id: '2',
      user: {
        id: 'system',
        username: 'سیستم',
        avatar: '',
        role: 'admin',
        isOnline: true
      },
      content: 'اسنایپر_پرو به لابی پیوست',
      timestamp: new Date(Date.now() - 25 * 60 * 1000), // 25 minutes ago
      type: 'join',
      isRead: true
    },
    {
      id: '3',
      user: {
        id: '2',
        username: 'اسنایپر_پرو',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
        role: 'member',
        isOnline: true
      },
      content: 'سلام! آماده‌ام برای بازی 💪',
      timestamp: new Date(Date.now() - 24 * 60 * 1000), // 24 minutes ago
      type: 'message',
      isRead: true
    },
    {
      id: '4',
      user: {
        id: '1',
        username: 'کاپیتان_پرو',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
        role: 'owner',
        isOnline: true
      },
      content: 'عالی! منتظر باقی اعضا هستیم. مپ Dust2 رو انتخاب کردم',
      timestamp: new Date(Date.now() - 20 * 60 * 1000), // 20 minutes ago
      type: 'message',
      isRead: true
    },
    {
      id: '5',
      user: {
        id: '3',
        username: 'گیمر_فوری',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
        role: 'member',
        isOnline: true
      },
      content: 'Dust2 عالیه! میتونیم استراتژی رو بحث کنیم؟',
      timestamp: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
      type: 'message',
      isRead: true
    },
    {
      id: '6',
      user: {
        id: 'system',
        username: 'سیستم',
        avatar: '',
        role: 'admin',
        isOnline: true
      },
      content: '⏰ 10 دقیقه تا شروع خودکار لابی باقی مانده',
      timestamp: new Date(Date.now() - 2 * 60 * 1000), // 2 minutes ago
      type: 'system',
      isRead: false
    }
  ]);

  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Simulate typing indicator
  useEffect(() => {
    if (newMessage.length > 0) {
      setIsTyping(true);
      const timeout = setTimeout(() => setIsTyping(false), 1000);
      return () => clearTimeout(timeout);
    }
  }, [newMessage]);

  const handleSendMessage = () => {
    if (!newMessage.trim() || membershipStatus !== 'approved') return;

    const message: ChatMessage = {
      id: Date.now().toString(),
      user: currentUser,
      content: newMessage.trim(),
      timestamp: new Date(),
      type: 'message',
      isRead: false
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');
    
    if (onSendMessage) {
      onSendMessage(newMessage.trim());
    }

    // Simulate message delivery
    setTimeout(() => {
      setMessages(prev => 
        prev.map(msg => 
          msg.id === message.id 
            ? { ...msg, isRead: true }
            : msg
        )
      );
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatMessageTime = (timestamp: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - timestamp.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'الآن';
    if (diffMins < 60) return `${diffMins} دقیقه پیش`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} ساعت پیش`;
    
    return timestamp.toLocaleDateString('fa-IR');
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner':
        return <Crown className="w-3 h-3 text-yellow-400" />;
      case 'admin':
        return <Shield className="w-3 h-3 text-blue-400" />;
      default:
        return <User className="w-3 h-3 text-slate-400" />;
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'owner':
        return <Badge variant="outline" className="text-xs text-yellow-400 border-yellow-400/20">میزبان</Badge>;
      case 'admin':
        return <Badge variant="outline" className="text-xs text-blue-400 border-blue-400/20">ادمین</Badge>;
      default:
        return null;
    }
  };

  const canUseChat = membershipStatus === 'approved';

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-blue-400" />
            <span>چت لابی</span>
            <Badge variant="secondary" className="text-xs">
              {messages.filter(m => m.type === 'message').length} پیام
            </Badge>
          </div>
          
          {!canUseChat && (
            <div className="flex items-center gap-1">
              <Lock className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-amber-400">قفل شده</span>
            </div>
          )}
        </CardTitle>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        {/* Access Warning */}
        {!canUseChat && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-4 mb-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20"
          >
            <div className="flex items-center gap-2 text-amber-400 mb-2">
              <Lock className="w-4 h-4" />
              <span className="font-medium text-sm">دسترسی محدود</span>
            </div>
            <p className="text-xs text-amber-300/80">
              {membershipStatus === 'none' && 'برای مشاهده و ارسال پیام، ابتدا درخواست عضویت دهید'}
              {membershipStatus === 'pending' && 'در انتظار تایید میزبان برای دسترسی به چت'}
              {membershipStatus === 'rejected' && 'درخواست عضویت شما رد شده است'}
            </p>
          </motion.div>
        )}

        {/* Messages Area */}
        <ScrollArea className="flex-1 px-4 gaming-scroll">
          <div className="space-y-4 pb-4">
            <AnimatePresence>
              {messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: canUseChat ? 1 : 0.3, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: index * 0.05 }}
                  className={`flex gap-3 ${message.type === 'system' || message.type === 'join' || message.type === 'leave' ? 'justify-center' : ''}`}
                >
                  {message.type === 'system' || message.type === 'join' || message.type === 'leave' ? (
                    // System messages
                    <div className="text-center">
                      <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-700/50 text-xs text-slate-300">
                        {message.type === 'system' && <AlertTriangle className="w-3 h-3" />}
                        {message.type === 'join' && <User className="w-3 h-3 text-green-400" />}
                        {message.type === 'leave' && <User className="w-3 h-3 text-red-400" />}
                        <span>{message.content}</span>
                        <span className="text-slate-400">•</span>
                        <span className="text-slate-400">{formatMessageTime(message.timestamp)}</span>
                      </div>
                    </div>
                  ) : (
                    // Regular messages
                    <>
                      <Avatar className="w-8 h-8 flex-shrink-0">
                        <AvatarImage src={message.user.avatar} />
                        <AvatarFallback>{message.user.username[0]}</AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="flex items-center gap-1">
                            {getRoleIcon(message.user.role)}
                            <span className="font-medium text-sm">{message.user.username}</span>
                          </div>
                          {getRoleBadge(message.user.role)}
                          <span className="text-xs text-slate-400">{formatMessageTime(message.timestamp)}</span>
                          
                          {message.user.id === currentUser.id && (
                            <div className="flex items-center gap-1 mr-auto">
                              {message.isRead ? (
                                <CheckCheck className="w-3 h-3 text-blue-400" />
                              ) : (
                                <Check className="w-3 h-3 text-slate-400" />
                              )}
                            </div>
                          )}
                        </div>
                        
                        <div className="bg-slate-700/30 rounded-lg px-3 py-2 text-sm break-words">
                          {message.content}
                        </div>
                        
                        {message.reactions && message.reactions.length > 0 && (
                          <div className="flex gap-1 mt-2">
                            {message.reactions.map((reaction, idx) => (
                              <button
                                key={idx}
                                className="flex items-center gap-1 px-2 py-1 rounded-full bg-slate-600/50 text-xs hover:bg-slate-600/70 transition-colors"
                              >
                                <span>{reaction.emoji}</span>
                                <span className="text-slate-300">{reaction.users.length}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            
            {/* Typing indicator */}
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 text-slate-400 text-xs"
              >
                <div className="flex gap-1">
                  <div className="w-1 h-1 bg-slate-400 rounded-full animate-pulse" />
                  <div className="w-1 h-1 bg-slate-400 rounded-full animate-pulse delay-75" />
                  <div className="w-1 h-1 bg-slate-400 rounded-full animate-pulse delay-150" />
                </div>
                <span>در حال تایپ...</span>
              </motion.div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        <Separator />

        {/* Message Input */}
        <div className="p-4">
          {canUseChat ? (
            <div className="flex items-center gap-2">
              <div className="flex-1 relative">
                <Input
                  ref={inputRef}
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="پیام خود را بنویسید..."
                  className="pr-12"
                  disabled={disabled}
                  maxLength={500}
                />
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400">
                  {newMessage.length}/500
                </div>
              </div>
              
              <Button
                onClick={handleSendMessage}
                disabled={!newMessage.trim() || disabled}
                size="sm"
                className="px-3"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <div className="text-center py-4 text-slate-400 text-sm">
              <Lock className="w-6 h-6 mx-auto mb-2 opacity-50" />
              <p>برای استفاده از چت باید عضو تایید شده باشید</p>
            </div>
          )}
        </div>

        {/* Online Members */}
        {canUseChat && (
          <div className="px-4 pb-4">
            <div className="text-xs text-slate-400 mb-2">
              اعضای آنل��ین ({members.filter(m => m.isOnline).length})
            </div>
            <div className="flex gap-1 flex-wrap">
              {members.filter(m => m.isOnline).map(member => (
                <div
                  key={member.id}
                  className="flex items-center gap-1 px-2 py-1 rounded-full bg-slate-700/30 text-xs"
                >
                  <div className="w-2 h-2 bg-green-400 rounded-full" />
                  <span>{member.username}</span>
                  {getRoleIcon(member.role)}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default LobbyChatSystem;