/**
 * Join by Code Dialog Component
 * Allows users to join a lobby using a 6-character lobby code
 */

import React, { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { 
  QrCode,
  Search,
  Users,
  CheckCircle,
  XCircle,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useLobby } from './LobbyContext';

interface JoinByCodeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onLobbyFound?: (lobbyId: string) => void;
}

export function JoinByCodeDialog({
  open,
  onOpenChange,
  onLobbyFound
}: JoinByCodeDialogProps) {
  const [code, setCode] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [foundLobby, setFoundLobby] = useState<any>(null);
  
  const { findLobbyByCode, requestMembership } = useLobby();

  // Simulate lobby data - in real app, fetch from API
  const mockLobbies: Record<string, any> = {
    'ABC123': {
      id: 'lobby-abc123',
      name: 'تیم Elite CS2',
      game: 'Counter-Strike 2',
      currentPlayers: 6,
      maxPlayers: 10,
      status: 'open',
      owner: 'کاپیتان_پرو'
    },
    'XYZ789': {
      id: 'lobby-xyz789', 
      name: 'Valorant Pro Match',
      game: 'Valorant',
      currentPlayers: 4,
      maxPlayers: 5,
      status: 'open',
      owner: 'گیمر_پرو'
    }
  };

  const handleSearch = async () => {
    if (code.length !== 6) {
      toast.error('کد لابی باید ۶ کاراکتر باشد');
      return;
    }

    setIsSearching(true);
    
    // Simulate API call
    setTimeout(() => {
      const lobby = mockLobbies[code.toUpperCase()];
      if (lobby) {
        setFoundLobby(lobby);
        toast.success('لابی پیدا شد!');
      } else {
        setFoundLobby(null);
        toast.error('لابی با این کد پیدا نشد', {
          description: 'کد را بررسی کرده و دوباره تلاش کنید'
        });
      }
      setIsSearching(false);
    }, 1000);
  };

  const handleJoin = () => {
    if (foundLobby) {
      requestMembership(foundLobby.id);
      onLobbyFound?.(foundLobby.id);
      toast.success('درخواست پیوستن ارسال شد!');
      onOpenChange(false);
      reset();
    }
  };

  const reset = () => {
    setCode('');
    setFoundLobby(null);
    setIsSearching(false);
  };

  const handleClose = () => {
    onOpenChange(false);
    reset();
  };

  const formatCode = (value: string) => {
    // Only allow alphanumeric characters and limit to 6
    const cleaned = value.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    return cleaned.slice(0, 6);
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCode(e.target.value);
    setCode(formatted);
    if (foundLobby) {
      setFoundLobby(null); // Clear previous search results
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5 text-primary" />
            پیوستن با کد لابی
          </DialogTitle>
          <DialogDescription>
            کد ۶ کاراکتری لابی را وارد کنید
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Code Input */}
          <div className="space-y-2">
            <label className="text-sm font-medium">کد لابی</label>
            <div className="flex gap-2">
              <Input
                value={code}
                onChange={handleCodeChange}
                placeholder="ABC123"
                className="text-center font-mono text-lg tracking-widest uppercase"
                maxLength={6}
                autoComplete="off"
              />
              <Button 
                onClick={handleSearch}
                disabled={code.length !== 6 || isSearching}
                size="sm"
                className="px-3"
              >
                {isSearching ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Search className="h-4 w-4" />
                )}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              {code.length}/6 کاراکتر
            </p>
          </div>

          {/* Found Lobby */}
          {foundLobby && (
            <div className="p-4 border rounded-lg bg-muted/30">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    {foundLobby.name}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {foundLobby.game}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    میزبان: {foundLobby.owner}
                  </p>
                </div>
                <Badge 
                  variant={foundLobby.status === 'open' ? 'secondary' : 'destructive'}
                  className="text-xs"
                >
                  {foundLobby.status === 'open' ? 'باز' : 'بسته'}
                </Badge>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  <span>{foundLobby.currentPlayers}/{foundLobby.maxPlayers} نفر</span>
                </div>
                <Badge variant="outline" className="text-xs">
                  {foundLobby.maxPlayers - foundLobby.currentPlayers} جا خالی
                </Badge>
              </div>
            </div>
          )}

          {/* No Lobby Found */}
          {code.length === 6 && !foundLobby && !isSearching && (
            <div className="p-4 border rounded-lg bg-destructive/5 border-destructive/20">
              <div className="flex items-center gap-2 text-destructive">
                <XCircle className="h-4 w-4" />
                <span className="text-sm">لابی با این کد پیدا نشد</span>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleClose}>
            انصراف
          </Button>
          {foundLobby && (
            <Button 
              onClick={handleJoin}
              disabled={foundLobby.status !== 'open'}
            >
              درخواست پیوستن
            </Button>
          )}
        </DialogFooter>

        {/* Example Codes */}
        <div className="text-center">
          <p className="text-xs text-muted-foreground mb-2">
            کدهای نمونه برای تست:
          </p>
          <div className="flex justify-center gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-auto p-1 text-xs font-mono"
              onClick={() => setCode('ABC123')}
            >
              ABC123
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-auto p-1 text-xs font-mono"
              onClick={() => setCode('XYZ789')}
            >
              XYZ789
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}