import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardFooter, CardHeader } from '../ui/card';
import { GameButton } from '../ui/game-button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Users, Calendar, Trophy, Coins, Smartphone, Monitor, Crown, Gem } from 'lucide-react';
import { CountdownTimer } from './CountdownTimer';
import { useGames } from '../providers/GameProvider';
import { useUser } from '../providers/UserProvider';

export interface Tournament {
  id: string;
  title: string;
  gameId: string; // Use gameId instead of game string
  organizer: {
    name: string;
    avatar?: string;
    level: 'player' | 'host' | 'manager';
  };
  entryFee: number;
  prizePool: number;
  maxParticipants: number;
  currentParticipants: number;
  format: 'single-elimination' | 'double-elimination' | 'round-robin';
  status: 'registration' | 'starting' | 'in-progress' | 'finished';
  startDate: Date;
  registrationDeadline: Date;
  estimatedDuration: number;
  minLevel?: number;
  description?: string;
  // New fields
  gameMode?: string;
  requiresHostLevel?: boolean;
}

interface TournamentCardProps {
  tournament: Tournament;
  onRegister?: () => void;
  onUnregister?: () => void;
  onView?: () => void;
  isRegistered?: boolean;
  className?: string;
}

const formatLabels = {
  'single-elimination': 'حذفی تک',
  'double-elimination': 'حذفی دوتایی',
  'round-robin': 'دور رفت و برگشت',
};

const statusConfig = {
  registration: { label: 'ثبت‌نام', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20' },
  starting: { label: 'شروع', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20' },
  'in-progress': { label: 'در حال برگزاری', color: 'bg-green-100 text-green-800 dark:bg-green-900/20' },
  finished: { label: 'تمام شده', color: 'bg-gray-100 text-gray-800 dark:bg-gray-900/20' },
};

export const TournamentCard: React.FC<TournamentCardProps> = ({
  tournament,
  onRegister,
  onUnregister,
  onView,
  isRegistered = false,
  className,
}) => {
  const { getGame } = useGames();
  const { user, canCreateTournaments } = useUser();
  
  const game = getGame(tournament.gameId);
  const canRegister = 
    tournament.status === 'registration' && 
    tournament.currentParticipants < tournament.maxParticipants && 
    !isRegistered &&
    new Date() < tournament.registrationDeadline &&
    (!tournament.requiresHostLevel || canCreateTournaments) &&
    (!tournament.minLevel || Math.floor(user.xp / 100) >= tournament.minLevel);

  const canUnregister = isRegistered && tournament.status === 'registration';
  const isFull = tournament.currentParticipants >= tournament.maxParticipants;
  const registrationClosed = new Date() >= tournament.registrationDeadline;
  
  const levelIcons = {
    player: Users,
    host: Crown,
    manager: Gem
  };
  const OrganizerLevelIcon = levelIcons[tournament.organizer.level];

  return (
    <Card className={cn('relative transition-all duration-200 hover:shadow-lg', className)}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-medium text-foreground">{tournament.title}</h3>
              {tournament.requiresHostLevel && (
                <Badge variant="outline" className="text-xs text-yellow-400 border-yellow-400">
                  <Crown className="w-3 h-3 mr-1" />
                  VIP
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              {game?.platform === 'desktop' ? (
                <Monitor className="w-4 h-4" />
              ) : (
                <Smartphone className="w-4 h-4" />
              )}
              <span>{game?.name || tournament.gameId}</span>
              <span>•</span>
              <span>{formatLabels[tournament.format]}</span>
              {tournament.gameMode && (
                <>
                  <span>•</span>
                  <span>{tournament.gameMode}</span>
                </>
              )}
            </div>
          </div>
          <Badge className={statusConfig[tournament.status].color}>
            {statusConfig[tournament.status].label}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="py-3">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={tournament.organizer.avatar} alt={tournament.organizer.name} />
              <AvatarFallback className="text-xs">{tournament.organizer.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <span className="text-sm text-muted-foreground">
              برگزارکننده: {tournament.organizer.name}
            </span>
            <OrganizerLevelIcon className="w-4 h-4 text-yellow-400" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Coins className="w-4 h-4 text-muted-foreground" />
                <span>ورودی: {tournament.entryFee.toLocaleString('fa-IR')} سکه</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Trophy className="w-4 h-4 text-muted-foreground" />
                <span className="text-yellow-600 font-medium">
                  جایزه: {tournament.prizePool.toLocaleString('fa-IR')} سکه
                </span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span className={isFull ? 'text-destructive' : ''}>
                  {tournament.currentParticipants}/{tournament.maxParticipants}
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Calendar className="w-4 h-4" />
                <span>{tournament.estimatedDuration} ساعت</span>
              </div>
            </div>
          </div>

          {tournament.status === 'registration' && (
            <div className="p-3 rounded-lg bg-muted/50">
              <div className="text-sm font-medium mb-1">زمان باقی‌مانده تا شروع:</div>
              <CountdownTimer 
                targetDate={tournament.startDate} 
                onComplete={() => {}} 
              />
            </div>
          )}

          {tournament.minLevel && (
            <div className="text-sm text-muted-foreground">
              حداقل سطح مورد نیاز: {tournament.minLevel}
            </div>
          )}
        </div>
      </CardContent>

      <CardFooter className="pt-3">
        <div className="flex gap-2 w-full">
          {canRegister && (
            <GameButton onClick={onRegister} className="flex-1" variant="primary">
              ثبت‌نام ({tournament.entryFee.toLocaleString('fa-IR')} سکه)
            </GameButton>
          )}
          
          {canUnregister && (
            <GameButton onClick={onUnregister} className="flex-1" variant="danger">
              لغو ثبت‌نام
            </GameButton>
          )}
          
          {!canRegister && !canUnregister && (
            <GameButton onClick={onView} className="flex-1" variant="secondary">
              {isFull ? 'پر شده' : registrationClosed ? 'مهلت تمام' : 'مشاهده'}
            </GameButton>
          )}
        </div>
      </CardFooter>
    </Card>
  );
};