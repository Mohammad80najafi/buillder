/**
 * Lobby Countdown Timer Component
 * Shows countdown to lobby start time with notifications
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { 
  Timer, 
  Clock, 
  Play, 
  Bell, 
  AlertTriangle,
  CheckCircle,
  Users,
  Calendar
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface LobbyCountdownTimerProps {
  startTime: Date; // When the lobby should start
  duration: number; // Lobby duration in hours
  autoStart?: boolean;
  notifyBeforeStart?: boolean;
  notificationTime?: number; // in minutes
  onStart?: () => void;
  onTimeUp?: () => void;
  className?: string;
}

interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  total: number;
}

export function LobbyCountdownTimer({
  startTime,
  duration,
  autoStart = true,
  notifyBeforeStart = true,
  notificationTime = 5,
  onStart,
  onTimeUp,
  className
}: LobbyCountdownTimerProps) {
  const [timeRemaining, setTimeRemaining] = useState<TimeRemaining>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    total: 0
  });
  const [hasNotified, setHasNotified] = useState(false);
  const [isStarted, setIsStarted] = useState(false);

  // Calculate time remaining
  useEffect(() => {
    const updateTimer = () => {
      const now = new Date().getTime();
      const startTimeMs = new Date(startTime).getTime();
      const difference = startTimeMs - now;

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        setTimeRemaining({
          days,
          hours,
          minutes,
          seconds,
          total: difference
        });

        // Check for notification
        if (notifyBeforeStart && !hasNotified) {
          const minutesRemaining = Math.floor(difference / (1000 * 60));
          if (minutesRemaining <= notificationTime && minutesRemaining > 0) {
            setHasNotified(true);
            toast.warning(`بازی ${minutesRemaining} دقیقه دیگر شروع می‌شود!`, {
              description: 'آماده شوید و اطمینان حاصل کنید که برای بازی حاضر هستید',
              icon: <Bell className="w-4 h-4" />,
              duration: 8000,
              action: {
                label: 'فهمیدم',
                onClick: () => {}
              }
            });
          }
        }
      } else {
        // Timer has ended
        setTimeRemaining({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
          total: 0
        });

        if (!isStarted) {
          setIsStarted(true);
          if (autoStart) {
            toast.success('بازی شروع شد! 🎮', {
              description: 'لابی به حالت بازی تغییر کرد',
              icon: <Play className="w-4 h-4" />,
              duration: 10000,
              action: {
                label: 'ورود به بازی',
                onClick: () => {
                  if (onStart) onStart();
                }
              }
            });
            if (onStart) onStart();
          }
          if (onTimeUp) onTimeUp();
        }
      }
    };

    const interval = setInterval(updateTimer, 1000);
    updateTimer(); // Initial call

    return () => clearInterval(interval);
  }, [startTime, notifyBeforeStart, notificationTime, hasNotified, autoStart, isStarted, onStart, onTimeUp]);

  const formatTimeUnit = (value: number, unit: string) => {
    return (
      <div className="flex flex-col items-center">
        <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
          <span className="text-lg sm:text-2xl font-bold text-white">
            {value.toString().padStart(2, '0')}
          </span>
        </div>
        <span className="text-xs sm:text-sm text-slate-400 mt-1">{unit}</span>
      </div>
    );
  };

  const getTimerStatus = () => {
    if (timeRemaining.total <= 0) {
      return {
        status: 'started',
        color: 'text-green-400',
        bgColor: 'bg-green-500/10',
        borderColor: 'border-green-500/20',
        text: 'بازی شروع شده'
      };
    } else if (timeRemaining.total <= notificationTime * 60 * 1000) {
      return {
        status: 'warning',
        color: 'text-yellow-400',
        bgColor: 'bg-yellow-500/10',
        borderColor: 'border-yellow-500/20',
        text: 'آماده باش!'
      };
    } else {
      return {
        status: 'waiting',
        color: 'text-blue-400',
        bgColor: 'bg-blue-500/10',
        borderColor: 'border-blue-500/20',
        text: 'در انتظار شروع'
      };
    }
  };

  const timerStatus = getTimerStatus();

  return (
    <Card className={`p-4 sm:p-6 ${timerStatus.bgColor} border ${timerStatus.borderColor} ${className}`}>
      <div className="text-center space-y-4">
        {/* Header */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="relative">
            {timerStatus.status === 'started' ? (
              <CheckCircle className={`w-5 h-5 sm:w-6 sm:h-6 ${timerStatus.color}`} />
            ) : timerStatus.status === 'warning' ? (
              <AlertTriangle className={`w-5 h-5 sm:w-6 sm:h-6 ${timerStatus.color}`} />
            ) : (
              <Timer className={`w-5 h-5 sm:w-6 sm:h-6 ${timerStatus.color}`} />
            )}
          </div>
          <h3 className={`font-semibold text-base sm:text-lg ${timerStatus.color}`}>
            {timerStatus.text}
          </h3>
        </div>

        <AnimatePresence mode="wait">
          {timeRemaining.total > 0 ? (
            <motion.div
              key="countdown"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-4"
            >
              {/* Countdown Display */}
              <div className="flex items-center justify-center gap-3 sm:gap-4">
                {timeRemaining.days > 0 && formatTimeUnit(timeRemaining.days, 'روز')}
                {(timeRemaining.days > 0 || timeRemaining.hours > 0) && formatTimeUnit(timeRemaining.hours, 'ساعت')}
                {formatTimeUnit(timeRemaining.minutes, 'دقیقه')}
                {timeRemaining.days === 0 && formatTimeUnit(timeRemaining.seconds, 'ثانیه')}
              </div>

              {/* Additional Info */}
              <div className="flex items-center justify-center gap-4 text-xs sm:text-sm text-slate-400">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span>شروع: {new Date(startTime).toLocaleTimeString('fa-IR')}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span>مدت: {duration} ساعت</span>
                </div>
              </div>

              {/* Notification Info */}
              {notifyBeforeStart && timeRemaining.total > notificationTime * 60 * 1000 && (
                <div className="flex items-center justify-center gap-2 p-2 sm:p-3 rounded-lg bg-slate-700/30">
                  <Bell className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400" />
                  <span className="text-xs sm:text-sm text-slate-300">
                    {notificationTime} دقیقه قبل از شروع به شما اطلاع داده می‌شود
                  </span>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="started"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-4"
            >
              {/* Game Started */}
              <div className="p-4 sm:p-6 rounded-xl bg-gradient-to-r from-green-500/20 to-blue-500/20 border border-green-500/30">
                <div className="flex items-center justify-center gap-3 mb-3">
                  <Play className="w-6 h-6 sm:w-8 sm:h-8 text-green-400" />
                  <span className="text-lg sm:text-xl font-bold text-green-400">بازی شروع شد!</span>
                </div>
                <p className="text-sm sm:text-base text-slate-300 mb-4">
                  لابی به حالت بازی تغییر کرد. همه اعضا می‌توانند وارد بازی شوند.
                </p>
                
                {autoStart && onStart && (
                  <Button 
                    onClick={onStart}
                    className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    ورود به بازی
                  </Button>
                )}
              </div>

              {/* Game Duration Info */}
              <div className="text-xs sm:text-sm text-slate-400 text-center">
                مدت زمان بازی: {duration} ساعت
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Card>
  );
}

export default LobbyCountdownTimer;