/**
 * Lobby Detail Demo - Test for Team-based Player Display and Fixed Chat
 */

import React from 'react';
import { LobbyDetailPageAdvanced } from './LobbyDetailPageAdvanced';
import { useNavigation } from '../navigation/NavigationProvider';
import { useLobby } from './LobbyContext';

export function LobbyDetailDemo() {
  const { navigate } = useNavigation();
  const { selectedLobbyId } = useLobby();
  
  const handleBack = () => {
    if (navigate) {
      navigate('lobbies');
    } else {
      console.log('Back button clicked - navigation not available');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <LobbyDetailPageAdvanced 
        lobbyId={selectedLobbyId || "demo-lobby-1"} 
        onBack={handleBack}
      />
    </div>
  );
}

export default LobbyDetailDemo;