/**
 * Lobby Context
 * Manages selected lobby state for navigation between lobby list and detail pages
 */

import React, { createContext, useContext, useState, ReactNode } from 'react';
import { getLobbyCodeFromId } from '../../utils/lobbyCodeGenerator';
import { useUser } from '../providers/UserProvider';

type MembershipStatus = 'none' | 'pending' | 'approved' | 'rejected';

interface LobbyMembership {
  status: MembershipStatus;
  requestedAt?: Date;
  approvedAt?: Date;
}

interface LobbyTeam {
  id: string;
  name: string;
  members: string[]; // user IDs
  maxMembers: number;
}

interface LobbyTeams {
  [lobbyId: string]: LobbyTeam[];
}

interface LobbyMember {
  id: string;
  username: string;
  avatar?: string;
  role: 'owner' | 'admin' | 'member';
  joinedAt: Date;
}

interface LobbyMembers {
  [lobbyId: string]: LobbyMember[];
}

interface LobbyContextType {
  selectedLobbyId: string | null;
  setSelectedLobbyId: (id: string | null) => void;
  joinedLobbies: string[];
  joinLobby: (lobbyId: string) => void;
  leaveLobby: (lobbyId: string) => void;
  // Membership management
  lobbyMemberships: Record<string, LobbyMembership>;
  requestMembership: (lobbyId: string) => void;
  approveMembership: (lobbyId: string, userId?: string, username?: string) => void;
  rejectMembership: (lobbyId: string) => void;
  getMembershipStatus: (lobbyId: string) => MembershipStatus;
  // Members management
  lobbyMembers: LobbyMembers;
  addMemberToLobby: (lobbyId: string, member: LobbyMember) => void;
  removeMemberFromLobby: (lobbyId: string, userId: string) => void;
  getLobbyMembers: (lobbyId: string) => LobbyMember[];
  // Team management
  lobbyTeams: LobbyTeams;
  initializeLobbyTeams: (lobbyId: string, teamCount?: number, maxMembersPerTeam?: number) => void;
  addUserToTeam: (lobbyId: string, teamId: string, userId: string) => void;
  removeUserFromTeam: (lobbyId: string, teamId: string, userId: string) => void;
  moveUserBetweenTeams: (lobbyId: string, userId: string, fromTeamId: string, toTeamId: string) => void;
  autoAssignUserToTeam: (lobbyId: string, userId: string) => string | null;
  getLobbyTeams: (lobbyId: string) => LobbyTeam[];
  getUserTeam: (lobbyId: string, userId: string) => LobbyTeam | null;
  // Lobby code utilities
  getLobbyCode: (lobbyId: string) => string;
  findLobbyByCode: (code: string) => string | null;
}

const LobbyContext = createContext<LobbyContextType | undefined>(undefined);

export function LobbyProvider({ children }: { children: ReactNode }) {
  const { currentUser } = useUser(); // Get current user
  const [selectedLobbyId, setSelectedLobbyId] = useState<string | null>(null);
  const [joinedLobbies, setJoinedLobbies] = useState<string[]>([]);
  const [lobbyMemberships, setLobbyMemberships] = useState<Record<string, LobbyMembership>>({});
  const [lobbyMembers, setLobbyMembers] = useState<LobbyMembers>({});
  const [lobbyTeams, setLobbyTeams] = useState<LobbyTeams>({});

  const joinLobby = (lobbyId: string) => {
    setJoinedLobbies(prev => {
      if (prev.includes(lobbyId)) return prev;
      return [...prev, lobbyId];
    });
  };

  const leaveLobby = (lobbyId: string) => {
    setJoinedLobbies(prev => prev.filter(id => id !== lobbyId));
  };

  const requestMembership = (lobbyId: string) => {
    setLobbyMemberships(prev => ({
      ...prev,
      [lobbyId]: {
        status: 'pending',
        requestedAt: new Date()
      }
    }));
  };

  const approveMembership = (lobbyId: string, userId?: string, username?: string) => {
    // Use provided userId or fallback to currentUser
    const finalUserId = userId || currentUser?.id;
    const finalUsername = username || currentUser?.username || 'کاربر MatchZone';
    
    console.log('✅ Approving membership:', { 
      lobbyId, 
      userId, 
      finalUserId, 
      finalUsername,
      currentUser 
    });
    
    if (!finalUserId) {
      console.error('❌ Both userId and currentUser.id are undefined in approveMembership');
      return;
    }

    // Create member object
    const member: LobbyMember = {
      id: finalUserId,
      username: finalUsername,
      avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      role: 'member',
      joinedAt: new Date()
    };

    // Perform all updates in the correct order using React's batch updates
    // Update membership status
    setLobbyMemberships(prev => ({
      ...prev,
      [lobbyId]: {
        ...prev[lobbyId],
        status: 'approved',
        approvedAt: new Date()
      }
    }));
    
    // Auto-join user to lobby when approved
    setJoinedLobbies(prev => {
      if (prev.includes(lobbyId)) return prev;
      return [...prev, lobbyId];
    });
    
    // Add user as member to the lobby immediately
    setLobbyMembers(prev => {
      const currentMembers = prev[lobbyId] || [];
      // Check if member already exists
      if (currentMembers.some(m => m.id === member.id)) {
        console.log('⚠️ Member already exists:', member.id);
        return prev;
      }
      const newMembers = [...currentMembers, member];
      console.log('✅ Member added successfully in approveMembership:', { 
        id: member.id, 
        username: member.username,
        lobbyId,
        totalMembersAfterAdd: newMembers.length 
      });
      
      return {
        ...prev,
        [lobbyId]: newMembers
      };
    });
    
    // Handle team assignment after a short delay to ensure state is updated
    setTimeout(() => {
      const currentTeams = lobbyTeams[lobbyId];
      if (!currentTeams || currentTeams.length === 0) {
        console.log('🏗️ No teams exist, initializing teams and then assigning user');
        // Initialize teams first
        setLobbyTeams(prev => {
          const teams: LobbyTeam[] = [];
          for (let i = 0; i < 2; i++) {
            teams.push({
              id: `team-${i + 1}`,
              name: `تیم ${i + 1}`,
              members: [],
              maxMembers: 2
            });
          }
          
          const newState = {
            ...prev,
            [lobbyId]: teams
          };
          
          // Auto-assign user to team after teams are created
          setTimeout(() => {
            setLobbyTeams(teamsPrev => {
              const currentTeamsAfterInit = teamsPrev[lobbyId] || [];
              const availableTeam = currentTeamsAfterInit
                .filter(team => team.members.length < team.maxMembers)
                .sort((a, b) => a.members.length - b.members.length)[0];
              
              if (availableTeam) {
                console.log('🎯 Auto-assigning user to team after initialization:', { 
                  userId: finalUserId, 
                  teamId: availableTeam.id, 
                  teamName: availableTeam.name 
                });
                
                const updatedTeams = currentTeamsAfterInit.map(team => {
                  if (team.id === availableTeam.id && !team.members.includes(finalUserId)) {
                    return {
                      ...team,
                      members: [...team.members, finalUserId]
                    };
                  }
                  return team;
                });
                
                return {
                  ...teamsPrev,
                  [lobbyId]: updatedTeams
                };
              }
              
              return teamsPrev;
            });
          }, 100);
          
          return newState;
        });
      } else {
        // Teams exist, just assign user to a team
        autoAssignUserToTeam(lobbyId, finalUserId);
      }
    }, 100);
  };

  const rejectMembership = (lobbyId: string) => {
    setLobbyMemberships(prev => ({
      ...prev,
      [lobbyId]: {
        ...prev[lobbyId],
        status: 'rejected'
      }
    }));
  };

  const getMembershipStatus = (lobbyId: string): MembershipStatus => {
    return lobbyMemberships[lobbyId]?.status || 'none';
  };

  const getLobbyCode = (lobbyId: string): string => {
    return getLobbyCodeFromId(lobbyId);
  };

  const findLobbyByCode = (code: string): string | null => {
    // In real app, this would query the database
    // For demo, we'll simulate finding a lobby
    return `lobby-${code.toLowerCase()}`;
  };

  // Members management functions
  const addMemberToLobby = (lobbyId: string, member: LobbyMember) => {
    setLobbyMembers(prev => {
      const currentMembers = prev[lobbyId] || [];
      // Check if member already exists
      if (currentMembers.some(m => m.id === member.id)) {
        console.log('⚠️ Member already exists:', member.id);
        return prev;
      }
      const newMembers = [...currentMembers, member];
      console.log('✅ Member added successfully:', { 
        id: member.id, 
        username: member.username,
        lobbyId,
        totalMembersAfterAdd: newMembers.length 
      });
      
      const newState = {
        ...prev,
        [lobbyId]: newMembers
      };
      
      // Force a re-render by logging the new state
      console.log('📊 Updated lobby members state:', {
        lobbyId,
        members: newMembers.map(m => ({ id: m.id, username: m.username }))
      });
      
      return newState;
    });
  };

  const removeMemberFromLobby = (lobbyId: string, userId: string) => {
    setLobbyMembers(prev => ({
      ...prev,
      [lobbyId]: (prev[lobbyId] || []).filter(member => member.id !== userId)
    }));
  };

  const getLobbyMembers = (lobbyId: string): LobbyMember[] => {
    return lobbyMembers[lobbyId] || [];
  };

  // Team management functions
  const initializeLobbyTeams = (lobbyId: string, teamCount: number = 2, maxMembersPerTeam: number = 2) => {
    const teams: LobbyTeam[] = [];
    for (let i = 0; i < teamCount; i++) {
      teams.push({
        id: `team-${i + 1}`,
        name: `تیم ${i + 1}`,
        members: [],
        maxMembers: maxMembersPerTeam
      });
    }
    
    console.log('🏗️ Initializing lobby teams:', { lobbyId, teamCount, maxMembersPerTeam, teams });
    
    setLobbyTeams(prev => {
      const newState = {
        ...prev,
        [lobbyId]: teams
      };
      console.log('📊 Teams state after initialization:', newState);
      return newState;
    });
  };

  const addUserToTeam = (lobbyId: string, teamId: string, userId: string) => {
    setLobbyTeams(prev => {
      const currentTeams = prev[lobbyId] || [];
      const updatedTeams = currentTeams.map(team => {
        if (team.id === teamId) {
          // Check if team has space and user is not already in team
          if (team.members.length < team.maxMembers && !team.members.includes(userId)) {
            return {
              ...team,
              members: [...team.members, userId]
            };
          }
        }
        return team;
      });
      
      return {
        ...prev,
        [lobbyId]: updatedTeams
      };
    });
  };

  const removeUserFromTeam = (lobbyId: string, teamId: string, userId: string) => {
    setLobbyTeams(prev => {
      const currentTeams = prev[lobbyId] || [];
      const updatedTeams = currentTeams.map(team => {
        if (team.id === teamId) {
          return {
            ...team,
            members: team.members.filter(id => id !== userId)
          };
        }
        return team;
      });
      
      return {
        ...prev,
        [lobbyId]: updatedTeams
      };
    });
  };

  const moveUserBetweenTeams = (lobbyId: string, userId: string, fromTeamId: string, toTeamId: string) => {
    const currentTeams = lobbyTeams[lobbyId] || [];
    const toTeam = currentTeams.find(t => t.id === toTeamId);
    
    // Check if destination team has space
    if (toTeam && toTeam.members.length >= toTeam.maxMembers) {
      return; // Can't move, team is full
    }
    
    // Remove from old team and add to new team
    removeUserFromTeam(lobbyId, fromTeamId, userId);
    setTimeout(() => {
      addUserToTeam(lobbyId, toTeamId, userId);
    }, 0);
  };

  const autoAssignUserToTeam = (lobbyId: string, userId: string): string | null => {
    const currentTeams = lobbyTeams[lobbyId];
    console.log('🎯 Auto-assigning user to team:', { lobbyId, userId, teamsAvailable: currentTeams?.length || 0 });
    
    if (!currentTeams || currentTeams.length === 0) {
      console.log('⚠️ No teams exist, initializing default teams first');
      // Initialize default teams if none exist
      initializeLobbyTeams(lobbyId);
      return null;
    }
    
    // Check if user is already in a team
    const existingTeam = currentTeams.find(team => team.members.includes(userId));
    if (existingTeam) {
      console.log('✅ User already in team:', { userId, teamId: existingTeam.id, teamName: existingTeam.name });
      return existingTeam.id;
    }
    
    // Find team with least members
    const availableTeam = currentTeams
      .filter(team => team.members.length < team.maxMembers)
      .sort((a, b) => a.members.length - b.members.length)[0];
    
    if (availableTeam) {
      console.log('🎯 Assigning user to team:', { userId, teamId: availableTeam.id, teamName: availableTeam.name });
      addUserToTeam(lobbyId, availableTeam.id, userId);
      return availableTeam.id;
    }
    
    console.log('❌ No team space available for user:', userId);
    return null; // No space available
  };

  const getLobbyTeams = (lobbyId: string): LobbyTeam[] => {
    return lobbyTeams[lobbyId] || [];
  };

  const getUserTeam = (lobbyId: string, userId: string): LobbyTeam | null => {
    const teams = lobbyTeams[lobbyId] || [];
    return teams.find(team => team.members.includes(userId)) || null;
  };

  return (
    <LobbyContext.Provider value={{ 
      selectedLobbyId, 
      setSelectedLobbyId, 
      joinedLobbies, 
      joinLobby, 
      leaveLobby,
      lobbyMemberships,
      requestMembership,
      approveMembership,
      rejectMembership,
      getMembershipStatus,
      lobbyMembers,
      addMemberToLobby,
      removeMemberFromLobby,
      getLobbyMembers,
      lobbyTeams,
      initializeLobbyTeams,
      addUserToTeam,
      removeUserFromTeam,
      moveUserBetweenTeams,
      autoAssignUserToTeam,
      getLobbyTeams,
      getUserTeam,
      getLobbyCode,
      findLobbyByCode
    }}>
      {children}
    </LobbyContext.Provider>
  );
}

export function useLobby() {
  const context = useContext(LobbyContext);
  if (context === undefined) {
    throw new Error('useLobby must be used within a LobbyProvider');
  }
  return context;
}

export default LobbyProvider;