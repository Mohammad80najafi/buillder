/**
 * Friends Invite Section Component
 * Displays friends list for direct lobby invitations
 */

import React, { useState } from 'react';
import { Avatar, AvatarImage, AvatarFallback } from '../ui/avatar';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Users, 
  Send, 
  Check, 
  Clock, 
  Eye,
  Gamepad2,
  MessageCircle,
  Instagram,
  Phone
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { useFriends } from '../../hooks/useFriends';
import { Friend, FriendInviteStatus } from '../../types/friends';
import { toast } from 'sonner@2.0.3';
import { BulkFriendInvite } from './BulkFriendInvite';

interface FriendsInviteSectionProps {
  lobbyName: string;
  lobbyCode: string;
  lobbyUrl: string;
  game: string;
}

function FriendCard({ 
  friend, 
  inviteStatus, 
  onInvite 
}: { 
  friend: Friend; 
  inviteStatus?: FriendInviteStatus;
  onInvite: (friendId: string) => void;
}) {
  const getStatusColor = () => {
    switch (friend.status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = () => {
    if (friend.isOnline && friend.currentGame) {
      return `در حال بازی ${friend.currentGame}`;
    }
    
    switch (friend.status) {
      case 'online': return 'آنلاین';
      case 'away': return 'دور از دسترس';
      case 'busy': return 'مشغول';
      case 'offline': 
        if (friend.lastSeen) {
          const now = new Date();
          const diff = now.getTime() - friend.lastSeen.getTime();
          const minutes = Math.floor(diff / 60000);
          const hours = Math.floor(minutes / 60);
          const days = Math.floor(hours / 24);
          
          if (minutes < 60) return `${minutes} دقیقه پیش`;
          if (hours < 24) return `${hours} ساعت پیش`;
          return `${days} روز پیش`;
        }
        return 'آفلاین';
      default: return 'نامشخص';
    }
  };

  const getPlatformIcon = () => {
    switch (friend.platform) {
      case 'matchzone': return <Gamepad2 className="w-3 h-3" />;
      case 'discord': return <MessageCircle className="w-3 h-3" />;
      case 'telegram': return <Send className="w-3 h-3" />;
      case 'instagram': return <Instagram className="w-3 h-3" />;
      default: return <Phone className="w-3 h-3" />;
    }
  };

  const getInviteButtonContent = () => {
    if (!inviteStatus) {
      return (
        <>
          <Send className="w-4 h-4 ml-2" />
          دعوت
        </>
      );
    }

    switch (inviteStatus.status) {
      case 'sent':
        return (
          <>
            <Clock className="w-4 h-4 ml-2 animate-pulse" />
            ارسال شد
          </>
        );
      case 'delivered':
        return (
          <>
            <Check className="w-4 h-4 ml-2 text-blue-500" />
            تحویل شد
          </>
        );
      case 'seen':
        return (
          <>
            <Eye className="w-4 h-4 ml-2 text-green-500" />
            دیده شد
          </>
        );
      case 'joined':
        return (
          <>
            <Check className="w-4 h-4 ml-2 text-green-500" />
            پیوست
          </>
        );
      case 'declined':
        return (
          <>
            <span className="w-4 h-4 ml-2 text-red-500">✕</span>
            رد کرد
          </>
        );
      default:
        return (
          <>
            <Send className="w-4 h-4 ml-2" />
            دعوت
          </>
        );
    }
  };

  return (
    <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
      <div className="relative">
        <Avatar className="w-10 h-10">
          <AvatarImage src={friend.avatar} alt={friend.displayName} />
          <AvatarFallback>{friend.displayName.charAt(0)}</AvatarFallback>
        </Avatar>
        <div className={cn(
          "absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-background",
          getStatusColor()
        )} />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <p className="font-medium text-sm truncate">{friend.displayName}</p>
          <Badge variant="outline" className="text-xs px-1.5 py-0.5">
            {getPlatformIcon()}
          </Badge>
        </div>
        <p className="text-xs text-text-secondary truncate">
          {getStatusText()}
        </p>
        {friend.socialHandle && (
          <p className="text-xs text-text-tertiary truncate">
            {friend.socialHandle}
          </p>
        )}
      </div>
      
      <Button
        size="sm"
        variant={inviteStatus ? "secondary" : "default"}
        onClick={() => onInvite(friend.id)}
        disabled={!!inviteStatus}
        className="px-3 py-1.5 h-auto text-xs"
      >
        {getInviteButtonContent()}
      </Button>
    </div>
  );
}

export function FriendsInviteSection({ 
  lobbyName, 
  lobbyCode, 
  lobbyUrl, 
  game 
}: FriendsInviteSectionProps) {
  const { onlineFriends, offlineFriends, inviteStatuses, loading, sendLobbyInvite } = useFriends();
  const [showOffline, setShowOffline] = useState(false);

  const handleInvite = async (friendId: string) => {
    const friend = onlineFriends.find(f => f.id === friendId) || 
                  offlineFriends.find(f => f.id === friendId);
    
    if (!friend) return;

    await sendLobbyInvite(friendId, {
      lobbyName,
      lobbyCode,
      lobbyUrl,
      game
    });

    toast.success(`دعوت ارسال شد!`, {
      description: `دعوت لابی برای ${friend.displayName} ارسال شد`,
      duration: 3000
    });
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          <h3 className="font-medium">دوستان</h3>
        </div>
        <div className="space-y-2">
          {[1, 2, 3].map(i => (
            <div key={i} className="flex items-center gap-3 p-3">
              <div className="w-10 h-10 bg-muted rounded-full animate-pulse" />
              <div className="flex-1 space-y-1">
                <div className="w-20 h-4 bg-muted rounded animate-pulse" />
                <div className="w-16 h-3 bg-muted rounded animate-pulse" />
              </div>
              <div className="w-16 h-8 bg-muted rounded animate-pulse" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          <h3 className="font-medium">دوستان</h3>
          {onlineFriends.length > 0 && (
            <Badge 
              variant="secondary" 
              className="text-xs animate-pulse bg-green-500/10 text-green-400 border-green-500/20"
            >
              <div className="w-2 h-2 bg-green-500 rounded-full mr-1.5 animate-ping" />
              {onlineFriends.length} آنلاین
            </Badge>
          )}
        </div>
      </div>

      {/* Bulk Invite Button */}
      {onlineFriends.length > 1 && (
        <BulkFriendInvite
          lobbyName={lobbyName}
          lobbyCode={lobbyCode}
          lobbyUrl={lobbyUrl}
          game={game}
        />
      )}

      <ScrollArea className="max-h-64">
        <div className="space-y-1">
          {/* Online Friends */}
          {onlineFriends.length > 0 && (
            <div className="space-y-1">
              {onlineFriends.map(friend => (
                <FriendCard
                  key={friend.id}
                  friend={friend}
                  inviteStatus={inviteStatuses.get(friend.id)}
                  onInvite={handleInvite}
                />
              ))}
            </div>
          )}

          {/* Offline Friends Toggle */}
          {offlineFriends.length > 0 && (
            <>
              {onlineFriends.length > 0 && <Separator className="my-2" />}
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowOffline(!showOffline)}
                className="w-full justify-between text-xs h-8"
              >
                <span>دوستان آفلاین ({offlineFriends.length})</span>
                <span className={cn(
                  "transition-transform duration-200",
                  showOffline && "rotate-180"
                )}>
                  ▼
                </span>
              </Button>

              {/* Offline Friends */}
              {showOffline && (
                <div className="space-y-1 pt-2">
                  {offlineFriends.slice(0, 10).map(friend => (
                    <FriendCard
                      key={friend.id}
                      friend={friend}
                      inviteStatus={inviteStatuses.get(friend.id)}
                      onInvite={handleInvite}
                    />
                  ))}
                  {offlineFriends.length > 10 && (
                    <p className="text-xs text-text-tertiary text-center py-2">
                      و {offlineFriends.length - 10} دوست دیگر...
                    </p>
                  )}
                </div>
              )}
            </>
          )}

          {/* Empty State */}
          {onlineFriends.length === 0 && offlineFriends.length === 0 && (
            <div className="text-center py-8 text-text-secondary">
              <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">دوستی یافت نشد</p>
              <p className="text-xs text-text-tertiary mt-1">
                دوستان خود را از تنظیمات اضافه کنید
              </p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}