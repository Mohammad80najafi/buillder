import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardFooter, CardHeader } from '../ui/card';
import { GameButton } from '../ui/game-button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Users, Clock, Trophy, MapPin, Smartphone, Monitor, DollarSign, Crown, Gem } from 'lucide-react';
import { useNavigation } from '../navigation/NavigationProvider';

export interface Lobby {
  id: string;
  name: string;
  game: string;
  gameImage?: string;
  host: {
    name: string;
    avatar?: string;
    level: 'player' | 'host' | 'manager';
  };
  currentPlayers: number;
  maxPlayers: number;
  status: 'waiting' | 'starting' | 'in-progress' | 'finished';
  gameMode: string;
  isPrivate: boolean;
  isPaidLobby?: boolean;
  entryFee?: number;
  platform: 'desktop' | 'mobile';
  isTournamentGame?: boolean;
  requiredLevel?: number;
  estimatedDuration?: number;
  region?: string;
  ageRestriction?: string;
  genderRestriction?: string;
  createdAt: Date;
}

interface LobbyCardProps {
  lobby: Lobby;
  onJoin?: () => void;
  onLeave?: () => void;
  onView?: () => void;
  isJoined?: boolean;
  className?: string;
}

const statusConfig = {
  waiting: { label: 'در انتظار', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300' },
  starting: { label: 'در حال شروع', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300' },
  'in-progress': { label: 'در حال بازی', color: 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300' },
  finished: { label: 'تمام شده', color: 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300' },
};

export const LobbyCard: React.FC<LobbyCardProps> = ({
  lobby,
  onJoin,
  onLeave,
  onView,
  isJoined = false,
  className,
}) => {
  const { navigateToLobby } = useNavigation();
  const canJoin = lobby.status === 'waiting' && lobby.currentPlayers < lobby.maxPlayers && !isJoined;
  const canLeave = isJoined && lobby.status === 'waiting';
  const isFull = lobby.currentPlayers >= lobby.maxPlayers;

  const handleCardClick = () => {
    navigateToLobby(lobby.id);
  };

  return (
    <Card 
      className={cn('relative transition-all duration-200 hover:shadow-lg cursor-pointer', className)}
      onClick={handleCardClick}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-medium text-foreground">{lobby.name}</h3>
              {lobby.isPrivate && (
                <Badge variant="secondary" className="text-xs">
                  خصوصی
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>{lobby.game}</span>
              <span>•</span>
              <span>{lobby.gameMode}</span>
            </div>
          </div>
          <Badge className={statusConfig[lobby.status].color}>
            {statusConfig[lobby.status].label}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="py-3">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={lobby.host.avatar} alt={lobby.host.name} />
                <AvatarFallback className="text-xs">{lobby.host.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <span className="text-sm text-muted-foreground">
                میزبان: {lobby.host.name}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Users className="w-4 h-4" />
              <span className={isFull ? 'text-destructive' : ''}>
                {lobby.currentPlayers}/{lobby.maxPlayers}
              </span>
            </div>
            
            {lobby.estimatedDuration && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>{lobby.estimatedDuration} دقیقه</span>
              </div>
            )}
            
            {lobby.requiredLevel && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Trophy className="w-4 h-4" />
                <span>سطح {lobby.requiredLevel}+</span>
              </div>
            )}
            
            {lobby.region && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>{lobby.region}</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>

      <CardFooter className="pt-3">
        <div className="flex gap-2 w-full">
          {canJoin && (
            <GameButton 
              onClick={(e) => {
                e.stopPropagation();
                onJoin?.();
              }} 
              className="flex-1" 
              variant="primary"
            >
              پیوستن
            </GameButton>
          )}
          
          {canLeave && (
            <GameButton 
              onClick={(e) => {
                e.stopPropagation();
                onLeave?.();
              }} 
              className="flex-1" 
              variant="danger"
            >
              ترک کردن
            </GameButton>
          )}
          
          {!canJoin && !canLeave && (
            <GameButton 
              onClick={(e) => {
                e.stopPropagation();
                onView?.();
              }} 
              className="flex-1" 
              variant="secondary"
            >
              {lobby.status === 'waiting' ? 'پر شده' : 'مشاهده'}
            </GameButton>
          )}
        </div>
      </CardFooter>
    </Card>
  );
};