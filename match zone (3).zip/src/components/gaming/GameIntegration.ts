/**
 * Matchzone Game Integration System
 * Handles launching and joining different games based on platform capabilities
 */

export interface GameLaunchConfig {
  gameId: string;
  gameName: string;
  platforms: ('pc' | 'android' | 'ios')[];
  launchMethods: {
    steam?: {
      appId: string;
      connectCommand?: string;
      supportsDirectJoin: boolean;
    };
    battlenet?: {
      gameId: string;
      connectCommand?: string;
    };
    android?: {
      packageName: string;
      intentUrl: string;
      supportsDirectJoin: boolean;
    };
    ios?: {
      appStoreId: string;
      urlScheme?: string;
      supportsDirectJoin: boolean;
    };
  };
  serverSupport: {
    dedicatedServers: boolean;
    customLobbies: boolean;
    officialServers: boolean;
  };
  joinMethods: ('one_click' | 'manual_room' | 'invite_code' | 'server_browser')[];
}

export const SUPPORTED_GAMES: Record<string, GameLaunchConfig> = {
  'cs2': {
    gameId: 'cs2',
    gameName: 'Counter-Strike 2',
    platforms: ['pc'],
    launchMethods: {
      steam: {
        appId: '730',
        connectCommand: 'steam://run/730// +connect {serverIp}:{serverPort} +password {password}',
        supportsDirectJoin: true
      }
    },
    serverSupport: {
      dedicatedServers: true,
      customLobbies: false,
      officialServers: false
    },
    joinMethods: ['one_click']
  },
  
  'dota2': {
    gameId: 'dota2',
    gameName: 'Dota 2',
    platforms: ['pc'],
    launchMethods: {
      steam: {
        appId: '570',
        connectCommand: 'steam://run/570',
        supportsDirectJoin: false
      }
    },
    serverSupport: {
      dedicatedServers: false,
      customLobbies: true,
      officialServers: true
    },
    joinMethods: ['manual_room']
  },

  'cod_warzone': {
    gameId: 'cod_warzone',
    gameName: 'Call of Duty: Warzone',
    platforms: ['pc'],
    launchMethods: {
      steam: {
        appId: '1962663',
        connectCommand: 'steam://run/1962663',
        supportsDirectJoin: false
      },
      battlenet: {
        gameId: 'CODMW',
        connectCommand: 'battlenet://CODMW'
      }
    },
    serverSupport: {
      dedicatedServers: false,
      customLobbies: true,
      officialServers: true
    },
    joinMethods: ['manual_room', 'invite_code']
  },

  'mlbb': {
    gameId: 'mlbb',
    gameName: 'Mobile Legends: Bang Bang',
    platforms: ['android', 'ios'],
    launchMethods: {
      android: {
        packageName: 'com.mobile.legends',
        intentUrl: 'intent://launch/#Intent;package=com.mobile.legends;end',
        supportsDirectJoin: false
      },
      ios: {
        appStoreId: '1160056295',
        supportsDirectJoin: false
      }
    },
    serverSupport: {
      dedicatedServers: false,
      customLobbies: true,
      officialServers: true
    },
    joinMethods: ['manual_room']
  },

  'pubg_mobile': {
    gameId: 'pubg_mobile',
    gameName: 'PUBG Mobile',
    platforms: ['android', 'ios'],
    launchMethods: {
      android: {
        packageName: 'com.tencent.ig',
        intentUrl: 'intent://launch/#Intent;package=com.tencent.ig;end',
        supportsDirectJoin: false
      },
      ios: {
        appStoreId: '1097344660',
        supportsDirectJoin: false
      }
    },
    serverSupport: {
      dedicatedServers: false,
      customLobbies: true,
      officialServers: true
    },
    joinMethods: ['manual_room']
  },

  'cod_mobile': {
    gameId: 'cod_mobile',
    gameName: 'Call of Duty: Mobile',
    platforms: ['android', 'ios'],
    launchMethods: {
      android: {
        packageName: 'com.activision.callofduty.shooter',
        intentUrl: 'intent://launch/#Intent;package=com.activision.callofduty.shooter;end',
        supportsDirectJoin: false
      },
      ios: {
        appStoreId: '1287282214',
        supportsDirectJoin: false
      }
    },
    serverSupport: {
      dedicatedServers: false,
      customLobbies: true,
      officialServers: true
    },
    joinMethods: ['manual_room', 'invite_code']
  },

  'among_us': {
    gameId: 'among_us',
    gameName: 'Among Us',
    platforms: ['pc', 'android', 'ios'],
    launchMethods: {
      steam: {
        appId: '945360',
        connectCommand: 'steam://run/945360',
        supportsDirectJoin: false
      },
      android: {
        packageName: 'com.innersloth.spacemafia',
        intentUrl: 'intent://launch/#Intent;package=com.innersloth.spacemafia;end',
        supportsDirectJoin: false
      },
      ios: {
        appStoreId: '1351168404',
        supportsDirectJoin: false
      }
    },
    serverSupport: {
      dedicatedServers: false,
      customLobbies: true,
      officialServers: true
    },
    joinMethods: ['invite_code']
  }
};

export interface JoinLobbyOptions {
  lobbyId: string;
  gameId: string;
  serverIp?: string;
  serverPort?: number;
  password?: string;
  roomCode?: string;
  inviteCode?: string;
  platform?: 'pc' | 'android' | 'ios';
}

export class GameLauncher {
  static async joinLobby(options: JoinLobbyOptions): Promise<{ success: boolean; method: string; instructions?: string }> {
    const game = SUPPORTED_GAMES[options.gameId];
    if (!game) {
      return { success: false, method: 'unsupported' };
    }

    const platform = options.platform || this.detectPlatform();
    const launchMethod = game.launchMethods[platform];
    
    if (!launchMethod) {
      return { 
        success: false, 
        method: 'platform_not_supported',
        instructions: `این بازی روی ${platform} پشتیبانی نمی‌شود`
      };
    }

    try {
      switch (options.gameId) {
        case 'cs2':
          return this.joinCS2(options, launchMethod.steam!);
        
        case 'dota2':
        case 'cod_warzone':
          return this.launchGameManually(game.gameName, launchMethod, platform);
        
        case 'mlbb':
        case 'pubg_mobile':
        case 'cod_mobile':
          return this.launchMobileGame(game.gameName, launchMethod, platform, options.roomCode);
        
        case 'among_us':
          return this.launchWithCode(game.gameName, launchMethod, platform, options.inviteCode);
        
        default:
          return { success: false, method: 'not_implemented' };
      }
    } catch (error) {
      return { 
        success: false, 
        method: 'error',
        instructions: 'خطا در راه‌اندازی بازی. لطفاً دوباره تلاش کنید.'
      };
    }
  }

  private static async joinCS2(options: JoinLobbyOptions, steamConfig: any): Promise<any> {
    if (!options.serverIp || !options.serverPort) {
      return { success: false, method: 'missing_server_info' };
    }

    const connectUrl = steamConfig.connectCommand
      .replace('{serverIp}', options.serverIp)
      .replace('{serverPort}', options.serverPort.toString())
      .replace('{password}', options.password || '');

    // Try to launch Steam URL
    try {
      window.location.href = connectUrl;
      return { 
        success: true, 
        method: 'steam_direct',
        instructions: 'در حال اتصال به سرور از طریق Steam...'
      };
    } catch (error) {
      return { 
        success: false, 
        method: 'steam_failed',
        instructions: 'Steam نصب نیست یا در دسترس نیست. لطفاً Steam را باز کنید و دوباره تلاش کنید.'
      };
    }
  }

  private static async launchGameManually(gameName: string, launchMethod: any, platform: string): Promise<any> {
    if (platform === 'pc' && launchMethod.steam) {
      try {
        window.location.href = launchMethod.steam.connectCommand;
        return { 
          success: true, 
          method: 'steam_launch',
          instructions: `${gameName} در حال باز شدن... پس از ورود به بازی، از منوی داخلی لابی پیوستن کنید.`
        };
      } catch (error) {
        return { 
          success: false, 
          method: 'steam_failed',
          instructions: 'Steam نصب نیست. لطفاً Steam را نصب کنید و دوباره تلاش کنید.'
        };
      }
    }

    if (platform === 'pc' && launchMethod.battlenet) {
      try {
        window.location.href = launchMethod.battlenet.connectCommand;
        return { 
          success: true, 
          method: 'battlenet_launch',
          instructions: `${gameName} در حال باز شدن از Battle.net... پس از ورود به بازی، از منوی داخلی لابی پیوستن کنید.`
        };
      } catch (error) {
        return { 
          success: false, 
          method: 'battlenet_failed',
          instructions: 'Battle.net نصب نیست. لطفاً Battle.net را نصب کنید و دوباره تلاش کنید.'
        };
      }
    }

    return { success: false, method: 'unsupported_platform' };
  }

  private static async launchMobileGame(gameName: string, launchMethod: any, platform: string, roomCode?: string): Promise<any> {
    if (platform === 'android' && launchMethod.android) {
      try {
        window.location.href = launchMethod.android.intentUrl;
        return { 
          success: true, 
          method: 'android_intent',
          instructions: roomCode 
            ? `${gameName} در حال باز شدن... کد اتاق: ${roomCode}`
            : `${gameName} در حال باز شدن... از منوی داخلی لابی پیوستن کنید.`
        };
      } catch (error) {
        return { 
          success: false, 
          method: 'android_failed',
          instructions: `${gameName} نصب نیست. لطفاً از Google Play نصب کنید.`
        };
      }
    }

    if (platform === 'ios') {
      return { 
        success: true, 
        method: 'ios_manual',
        instructions: roomCode 
          ? `لطفاً ${gameName} را باز کنید و کد اتاق ${roomCode} را وارد کنید.`
          : `لطفاً ${gameName} را باز کنید و از منوی داخلی لابی پیوستن کنید.`
      };
    }

    return { success: false, method: 'unsupported_platform' };
  }

  private static async launchWithCode(gameName: string, launchMethod: any, platform: string, inviteCode?: string): Promise<any> {
    const launchResult = await this.launchGameManually(gameName, launchMethod, platform);
    
    if (launchResult.success && inviteCode) {
      launchResult.instructions += ` کد دعوت: ${inviteCode}`;
    }

    return launchResult;
  }

  private static detectPlatform(): 'pc' | 'android' | 'ios' {
    const userAgent = navigator.userAgent.toLowerCase();
    
    if (/android/.test(userAgent)) {
      return 'android';
    } else if (/iphone|ipad|ipod/.test(userAgent)) {
      return 'ios';
    } else {
      return 'pc';
    }
  }

  static getJoinButtonText(gameId: string): string {
    const game = SUPPORTED_GAMES[gameId];
    if (!game) return 'پیوستن';

    const platform = this.detectPlatform();
    
    if (game.joinMethods.includes('one_click')) {
      return '🚀 پیوستن یک‌کلیک';
    } else if (game.joinMethods.includes('manual_room')) {
      return platform === 'pc' ? '🎮 راه‌اندازی بازی' : '📱 باز کردن بازی';
    } else if (game.joinMethods.includes('invite_code')) {
      return '🔗 دریافت کد';
    } else {
      return 'پیوستن';
    }
  }

  static getJoinMethodIcon(gameId: string): string {
    const game = SUPPORTED_GAMES[gameId];
    if (!game) return '🎮';

    if (game.joinMethods.includes('one_click')) {
      return '⚡';
    } else if (game.joinMethods.includes('manual_room')) {
      return '🎯';
    } else if (game.joinMethods.includes('invite_code')) {
      return '🔗';
    } else {
      return '🎮';
    }
  }
}

export default GameLauncher;