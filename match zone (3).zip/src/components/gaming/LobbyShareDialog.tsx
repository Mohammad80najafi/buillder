/**
 * Lobby Share Dialog Component
 * Provides comprehensive sharing options for lobbies including code, URL, and social media
 */

import React, { useState } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from '../ui/dialog';
import { 
  AlertDialog,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogCancel
} from '../ui/alert-dialog';
import { Separator } from '../ui/separator';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { 
  Copy, 
  Share2, 
  MessageCircle, 
  Instagram,
  Send,
  QrCode,
  Link,
  Users,
  Check,
  ExternalLink
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { 
  getLobbyCodeFromId, 
  generateLobbyUrl, 
  generateShareText,
  shareViaWebAPI 
} from '../../utils/lobbyCodeGenerator';
import { QuickCopyButton } from './QuickCopyButton';
import { CopyableField } from '../ui/copyable-field';
import { FriendsInviteSection } from './FriendsInviteSection';

interface LobbyShareDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lobbyId: string;
  lobbyName: string;
  gameTitle: string;
  currentPlayers: number;
  maxPlayers: number;
}

export function LobbyShareDialog({
  open,
  onOpenChange,
  lobbyId,
  lobbyName,
  gameTitle,
  currentPlayers,
  maxPlayers
}: LobbyShareDialogProps) {
  const [copiedItem, setCopiedItem] = useState<string | null>(null);
  const [showManualCopy, setShowManualCopy] = useState<{ text: string; name: string } | null>(null);
  
  const lobbyCode = getLobbyCodeFromId(lobbyId);
  const lobbyUrl = generateLobbyUrl(lobbyId);
  const shareText = generateShareText(lobbyName, lobbyCode, gameTitle);

  const handleCopy = async (text: string, itemName: string) => {
    const result = await copyToClipboard(text);
    
    if (result.success) {
      setCopiedItem(itemName);
      toast.success(`${itemName} کپی شد!`, {
        description: `روش: ${result.method === 'clipboard-api' ? 'مدرن' : 
                      result.method === 'execCommand' ? 'سنتی' : 
                      result.method === 'selection-api' ? 'انتخاب متن' : 'نامشخص'}`,
        duration: 2000
      });
      setTimeout(() => setCopiedItem(null), 2000);
    } else if (result.method === 'manual') {
      // Show manual copy dialog
      setShowManualCopy({ text, name: itemName });
      toast.warning('کپی دستی', {
        description: result.error || 'لطفاً به صورت دستی کپی کنید',
        duration: 4000
      });
    } else {
      toast.error('خطا در کپی کردن', {
        description: result.error || 'لطفاً دوباره تلاش کنید',
        duration: 3000
      });
    }
  };

  const handleWebShare = async () => {
    const success = await shareViaWebAPI({
      title: `لابی ${lobbyName} - Matchzone`,
      text: shareText,
      url: lobbyUrl
    });
    
    if (!success) {
      // Fallback to copying URL
      await handleCopy(lobbyUrl, 'لینک');
    } else {
      toast.success('اشتراک‌گذاری شد!', {
        description: 'از طریق سیستم اشتراک‌گذاری دستگاه',
        duration: 2000
      });
    }
  };

  const shareViaWhatsApp = () => {
    const url = `https://wa.me/?text=${encodeURIComponent(shareText + '\n' + lobbyUrl)}`;
    window.open(url, '_blank');
  };

  const shareViaTelegram = () => {
    const url = `https://t.me/share/url?url=${encodeURIComponent(lobbyUrl)}&text=${encodeURIComponent(shareText)}`;
    window.open(url, '_blank');
  };

  const shareViaInstagram = () => {
    // Instagram doesn't support direct sharing, copy to clipboard instead
    handleCopy(shareText + '\n' + lobbyUrl, 'متن برای اینستاگرام');
    toast.info('برای اینستاگرام', {
      description: 'متن کپی شد، در استوری یا پست خودتان بچسبانید',
      duration: 4000
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className="sm:max-w-lg max-h-[85vh] overflow-y-auto" 
        dir="rtl"
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5 text-primary" />
            اشتراک‌گذاری لابی
          </DialogTitle>
          <DialogDescription>
            لابی خود را با دوستان به اشتراک بگذارید
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Lobby Info */}
          <div className="text-center p-4 bg-muted/30 rounded-lg">
            <h3 className="font-semibold text-lg mb-1">{lobbyName}</h3>
            <p className="text-sm text-muted-foreground mb-2">{gameTitle}</p>
            <div className="flex items-center justify-center gap-2">
              <Users className="h-4 w-4" />
              <span className="text-sm">{currentPlayers}/{maxPlayers} نفر</span>
              <Badge variant="secondary" className="text-xs">
                {maxPlayers - currentPlayers} جا خالی
              </Badge>
            </div>
          </div>

          {/* Lobby Code */}
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <QrCode className="h-4 w-4" />
              کد لابی
            </label>
            <div className="flex gap-2">
              <Input 
                value={lobbyCode} 
                readOnly 
                className="text-center font-mono text-lg tracking-widest"
              />
              <QuickCopyButton
                text={lobbyCode}
                successMessage="کد لابی کپی شد!"
                errorMessage="خطا در کپی کد"
              />
            </div>
            <p className="text-xs text-muted-foreground">
              دوستان می‌توانند با این کد به لابی بپیوندند
            </p>
          </div>

          {/* Lobby URL */}
          <div className="space-y-2">
            <label className="text-sm font-medium flex items-center gap-2">
              <Link className="h-4 w-4" />
              لینک مستقیم
            </label>
            <div className="flex gap-2">
              <Input 
                value={lobbyUrl} 
                readOnly 
                className="text-sm"
              />
              <QuickCopyButton
                text={lobbyUrl}
                successMessage="لینک کپی شد!"
                errorMessage="خطا در کپی لینک"
              />
            </div>
          </div>

          {/* Friends Invite Section */}
          <FriendsInviteSection
            lobbyName={lobbyName}
            lobbyCode={lobbyCode}
            lobbyUrl={lobbyUrl}
            game={gameTitle}
          />

          <Separator />

          {/* Share Options */}
          <div className="space-y-3">
            <label className="text-sm font-medium">اشتراک‌گذاری در:</label>
            
            <div className="grid grid-cols-2 gap-3">
              {/* WhatsApp */}
              <Button 
                variant="outline" 
                onClick={shareViaWhatsApp}
                className="h-auto py-3 flex flex-col gap-1"
              >
                <MessageCircle className="h-5 w-5 text-green-600" />
                <span className="text-xs">واتس‌اپ</span>
              </Button>

              {/* Telegram */}
              <Button 
                variant="outline" 
                onClick={shareViaTelegram}
                className="h-auto py-3 flex flex-col gap-1"
              >
                <Send className="h-5 w-5 text-blue-500" />
                <span className="text-xs">تلگرام</span>
              </Button>

              {/* Instagram */}
              <Button 
                variant="outline" 
                onClick={shareViaInstagram}
                className="h-auto py-3 flex flex-col gap-1"
              >
                <Instagram className="h-5 w-5 text-pink-500" />
                <span className="text-xs">اینستاگرام</span>
              </Button>

              {/* Native Share */}
              <Button 
                variant="outline" 
                onClick={handleWebShare}
                className="h-auto py-3 flex flex-col gap-1"
              >
                <ExternalLink className="h-5 w-5 text-primary" />
                <span className="text-xs">سایر</span>
              </Button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex gap-2">
            <QuickCopyButton
              text={shareText}
              label="کپی متن کامل"
              variant="secondary"
              className="flex-1"
              showLabel={true}
              successMessage="متن کامل کپی شد!"
              errorMessage="خطا در کپی متن"
            />
            <Button onClick={() => onOpenChange(false)} variant="outline">
              بستن
            </Button>
          </div>
        </div>
      </DialogContent>

      {/* Manual Copy Alert Dialog */}
      <AlertDialog open={!!showManualCopy} onOpenChange={() => setShowManualCopy(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Copy className="h-5 w-5 text-yellow-500" />
              کپی دستی
            </AlertDialogTitle>
            <AlertDialogDescription>
              خودکار کپی کردن امکان‌پذیر نیست. لطفاً متن زیر را انتخاب کرده و کپی کنید:
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          {showManualCopy && (
            <div className="p-4 bg-muted rounded-lg">
              <label className="text-sm font-medium mb-2 block">
                {showManualCopy.name}
              </label>
              <Input
                value={showManualCopy.text}
                readOnly
                className="font-mono text-sm"
                onClick={(e) => (e.target as HTMLInputElement).select()}
                onFocus={(e) => (e.target as HTMLInputElement).select()}
              />
              <p className="text-xs text-muted-foreground mt-2">
                روی فیلد بالا کلیک کنید و Ctrl+C (یا Cmd+C) بزنید
              </p>
            </div>
          )}
          
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowManualCopy(null)}>
              متوجه شدم
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  );
}