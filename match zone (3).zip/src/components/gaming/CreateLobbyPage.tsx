/**
 * Create Lobby Page - Enhanced Multi-Game Support
 * Comprehensive lobby creation interface with user levels, platform separation and tournaments
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Switch } from '../ui/switch';
import { Separator } from '../ui/separator';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Users, 
  MapPin, 
  Clock, 
  Lock, 
  Server, 
  Shield, 
  Gamepad2, 
  Trophy,
  Target,
  Sword,
  Zap,
  Eye,
  Settings,
  ChevronRight,
  Play,
  Copy,
  Check,
  Calendar,
  UserCheck,
  Smartphone,
  Monitor,
  Crown,
  Star,
  Gem,
  DollarSign,
  Timer,
  Bell,
  AlertTriangle
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useUser } from '../providers/UserProvider';
import { useNavigation } from '../navigation/NavigationProvider';
import { useClipboard } from '../../hooks/useClipboard';
import { CopyableField } from '../ui/copyable-field';
import { LobbyCountdownTimer } from './LobbyCountdownTimer';

// Types
interface LobbySettings {
  game: string;
  name: string;
  gameMode: string;
  teamSize: string;
  map: string;
  maxRounds: number;
  roundTime: number;
  password: string;
  isPrivate: boolean;
  serverType: string;
  description: string;
  maxPlayers: number;
  ageRestriction: string;
  genderRestriction: string;
  isPaidLobby: boolean;
  entryFee: number;
  // Timer settings
  enableTimer: boolean;
  lobbyDuration: number; // in hours
  autoStart: boolean;
  notifyBeforeStart: boolean;
  notificationTime: number; // in minutes (default 5)
}

// Import user level types from provider
import { UserLevel } from '../providers/UserProvider';

// Available Games - Separated by Platform
const DESKTOP_GAMES = {
  cs2: {
    name: 'Counter-Strike 2',
    description: 'بازی تیمی تاکتیکی FPS',
    icon: Target,
    color: 'text-orange-400',
    bgColor: 'bg-orange-400/10',
    emoji: '🔫',
    platform: 'desktop',
    isTournamentGame: true
  },
  valorant: {
    name: 'Valorant',
    description: 'بازی تیمی تاکتیکی با قابلیت‌های خاص',
    icon: Zap,
    color: 'text-red-400',
    bgColor: 'bg-red-400/10',
    emoji: '⚡',
    platform: 'desktop',
    isTournamentGame: false
  },
  lol: {
    name: 'League of Legends',
    description: 'بازی MOBA استراتژیک',
    icon: Sword,
    color: 'text-purple-400',
    bgColor: 'bg-purple-400/10',
    emoji: '⚔️',
    platform: 'desktop',
    isTournamentGame: false
  },
  rocket_league: {
    name: 'Rocket League',
    description: 'فوتبال با ماشین‌های پرنده',
    icon: Users,
    color: 'text-green-400',
    bgColor: 'bg-green-400/10',
    emoji: '🚗',
    platform: 'desktop',
    isTournamentGame: false
  }
};

const MOBILE_GAMES = {
  pubg_mobile: {
    name: 'PUBG Mobile',
    description: 'بازی بتل رویال موبایل',
    icon: Target,
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-400/10',
    emoji: '📱',
    platform: 'mobile',
    isTournamentGame: true
  },
  cod_mobile: {
    name: 'Call of Duty Mobile',
    description: 'بازی FPS موبایل',
    icon: Target,
    color: 'text-red-400',
    bgColor: 'bg-red-400/10',
    emoji: '🎯',
    platform: 'mobile',
    isTournamentGame: true
  },
  fifa_mobile: {
    name: 'FIFA Mobile',
    description: 'فوتبال موبایل',
    icon: Trophy,
    color: 'text-green-400',
    bgColor: 'bg-green-400/10',
    emoji: '⚽',
    platform: 'mobile',
    isTournamentGame: true
  },
  fortnite: {
    name: 'Fortnite Mobile',
    description: 'بازی بتل رویال موبایل',
    icon: Trophy,
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10',
    emoji: '🏆',
    platform: 'mobile',
    isTournamentGame: false
  }
};

// Combined games object for backward compatibility
const GAMES = { ...DESKTOP_GAMES, ...MOBILE_GAMES };

// Game modes for different games
const GAME_MODES = {
  cs2: {
    competitive: {
      name: 'رقابتی',
      description: 'فرمت استاندارد جهانی Esports',
      icon: Trophy,
      teamSize: '5v5',
      maxRounds: 24,
      roundTime: 115,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10',
      players: 10
    },
    wingman: {
      name: 'وینگمن',
      description: 'سریع و محبوب برای کلن‌های کوچک',
      icon: Target,
      teamSize: '2v2',
      maxRounds: 16,
      roundTime: 90,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
      players: 4
    }
  },
  valorant: {
    unrated: {
      name: 'Unrated',
      description: 'حالت عادی و تمرینی',
      icon: Users,
      teamSize: '5v5',
      maxRounds: 24,
      roundTime: 100,
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
      players: 10
    }
  },
  pubg_mobile: {
    squad: {
      name: 'Squad',
      description: 'تیم 4 نفره',
      icon: Users,
      teamSize: '4-Squad',
      maxRounds: 1,
      roundTime: 1500,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
      players: 4
    }
  },
  cod_mobile: {
    battle_royale: {
      name: 'Battle Royale',
      description: 'حالت بتل رویال',
      icon: Target,
      teamSize: '4-Squad',
      maxRounds: 1,
      roundTime: 1200,
      color: 'text-red-400',
      bgColor: 'bg-red-400/10',
      players: 4
    }
  },
  fifa_mobile: {
    quick_match: {
      name: 'مسابقه سریع',
      description: 'بازی 11 در برابر 11',
      icon: Trophy,
      teamSize: '1v1',
      maxRounds: 1,
      roundTime: 600,
      color: 'text-green-400',
      bgColor: 'bg-green-400/10',
      players: 2
    }
  }
};

// Age restriction options
const AGE_RESTRICTIONS = {
  all: { name: 'همه سنین', description: 'بدون محدودیت سنی' },
  '12-18': { name: '12 تا 18 سال', description: 'مخصوص نوجوانان' },
  '18-35': { name: '18 تا 35 سال', description: 'مخصوص جوانان' },
  '35+': { name: '35 به بعد', description: 'مخصوص بزرگسالان' }
};

// Gender restriction options
const GENDER_RESTRICTIONS = {
  all: { name: 'همه', description: 'همه جنسیت‌ها' },
  male: { name: 'فقط آقایان', description: 'مخصوص آقایان' },
  female: { name: 'فقط خانم‌ها', description: 'مخصوص خانم‌ها' }
};

// Maps categorized by game and mode
const MAPS = {
  cs2: {
    competitive: [
      { id: 'de_mirage', name: 'Mirage', description: 'پرمحبوب‌ترین، همیشه در لیست', emoji: '🏜️' },
      { id: 'de_inferno', name: 'Inferno', description: 'خیلی بالانس و کلاسیک', emoji: '🔥' },
      { id: 'de_nuke', name: 'Nuke', description: 'برای تیم‌های حرفه‌ای', emoji: '☢️' }
    ],
    wingman: [
      { id: 'de_shortdust', name: 'Short Dust', description: 'نسخه کوچک Dust2', emoji: '🏜️' },
      { id: 'de_inferno_2v2', name: 'Inferno (2v2)', description: 'نسخه کوچک Inferno', emoji: '🔥' }
    ]
  },
  valorant: {
    unrated: [
      { id: 'bind', name: 'Bind', description: 'مپ کلاسیک Valorant', emoji: '🌊' },
      { id: 'haven', name: 'Haven', description: 'مپ 3 site', emoji: '🏛️' }
    ]
  },
  pubg_mobile: {
    squad: [
      { id: 'erangel', name: 'Erangel', description: 'مپ کلاسیک PUBG', emoji: '🏝️' }
    ]
  },
  cod_mobile: {
    battle_royale: [
      { id: 'blackout', name: 'Blackout', description: 'مپ اصلی COD Mobile', emoji: '🗺️' }
    ]
  },
  fifa_mobile: {
    quick_match: [
      { id: 'camp_nou', name: 'Camp Nou', description: 'ورزشگاه بارسلونا', emoji: '🏟️' }
    ]
  }
};

export function CreateLobbyPage({ onNavigateToLobbies }: { onNavigateToLobbies?: () => void }) {
  const { user, currentLevelInfo, canCreatePaidLobbies } = useUser();
  const { navigate } = useNavigation();
  
  const [settings, setSettings] = useState<LobbySettings>({
    game: '',
    name: '',
    gameMode: '',
    teamSize: '',
    map: '',
    maxRounds: 24,
    roundTime: 115,
    password: '',
    isPrivate: false,
    serverType: 'dedicated',
    description: '',
    maxPlayers: 10,
    ageRestriction: 'all',
    genderRestriction: 'all',
    isPaidLobby: false,
    entryFee: 0,
    // Timer settings
    enableTimer: true,
    lobbyDuration: 2,
    autoStart: true,
    notifyBeforeStart: true,
    notificationTime: 5
  });

  const [step, setStep] = useState(1);
  const [isCreating, setIsCreating] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  // Clipboard functionality
  const { copy: copyToClipboard, copied: copiedPassword } = useClipboard({
    timeout: 2000,
    onSuccess: (method) => {
      toast.success('رمز با موفقیت کپی شد!', {
        description: `روش: ${method === 'clipboard-api' ? 'مدرن' : method === 'execCommand' ? 'کلاسیک' : 'سنتی'}`
      });
    },
    onError: (error) => {
      toast.error('خطا در کپی کردن', {
        description: error,
        action: {
          label: 'نمایش رمز',
          onClick: () => {
            alert(`رمز لابی: ${settings.password}`);
          }
        }
      });
    }
  });

  const currentGame = settings.game && GAMES[settings.game as keyof typeof GAMES] ? GAMES[settings.game as keyof typeof GAMES] : null;
  const availableGameModes = settings.game && GAME_MODES[settings.game as keyof typeof GAME_MODES] ? GAME_MODES[settings.game as keyof typeof GAME_MODES] : {};
  const currentGameMode = settings.gameMode && settings.game && GAME_MODES[settings.game as keyof typeof GAME_MODES] ? 
    GAME_MODES[settings.game as keyof typeof GAME_MODES][settings.gameMode as keyof typeof GAME_MODES[keyof typeof GAME_MODES]] : null;
  const availableMaps = settings.gameMode && settings.game && MAPS[settings.game as keyof typeof MAPS] && MAPS[settings.game as keyof typeof MAPS][settings.gameMode as keyof typeof MAPS[keyof typeof MAPS]] ? 
    MAPS[settings.game as keyof typeof MAPS][settings.gameMode as keyof typeof MAPS[keyof typeof MAPS]] : [];

  const handleGameChange = (game: string) => {
    setSettings(prev => ({
      ...prev,
      game,
      gameMode: '',
      map: '',
      teamSize: '',
      maxRounds: 24,
      roundTime: 115,
      maxPlayers: 10
    }));
  };

  const handleGameModeChange = (mode: string) => {
    if (!settings.game) return;
    const gameModeConfig = GAME_MODES[settings.game as keyof typeof GAME_MODES]?.[mode as keyof typeof GAME_MODES[keyof typeof GAME_MODES]];
    if (gameModeConfig) {
      setSettings(prev => ({
        ...prev,
        gameMode: mode,
        teamSize: gameModeConfig.teamSize,
        maxRounds: gameModeConfig.maxRounds,
        roundTime: gameModeConfig.roundTime,
        maxPlayers: gameModeConfig.players,
        map: '' // Reset map selection
      }));
    }
  };

  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHIJKLMNPQRSTUVWXYZ123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setSettings(prev => ({ ...prev, password: result }));
  };

  const copyPassword = async () => {
    if (!settings.password) {
      toast.error('ابتدا رمز را تولید کنید!');
      return;
    }

    await copyToClipboard(settings.password);
  };

  const handleCreateLobby = async () => {
    setIsCreating(true);
    
    // Simulate lobby creation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    toast.success(`لابی "${settings.name}" با موفقیت ایجاد شد!`);
    setIsCreating(false);
    setShowPreview(false);
    
    // Reset form
    setSettings({
      game: '',
      name: '',
      gameMode: '',
      teamSize: '',
      map: '',
      maxRounds: 24,
      roundTime: 115,
      password: '',
      isPrivate: false,
      serverType: 'dedicated',
      description: '',
      maxPlayers: 10,
      ageRestriction: 'all',
      genderRestriction: 'all',
      isPaidLobby: false,
      entryFee: 0,
      enableTimer: true,
      lobbyDuration: 2,
      autoStart: true,
      notifyBeforeStart: true,
      notificationTime: 5
    });
    setStep(1);
    
    // Navigate back to lobbies page
    setTimeout(() => {
      if (onNavigateToLobbies) {
        onNavigateToLobbies();
      } else {
        navigate('lobbies');
        toast.success('به صفحه لابی‌ها بازگشتید', {
          action: {
            label: 'مشاهده',
            onClick: () => navigate('lobbies')
          }
        });
      }
    }, 500);
  };

  const isFormValid = () => {
    return settings.game && settings.name && settings.gameMode && settings.map && 
           (!settings.isPrivate || settings.password) &&
           (!settings.isPaidLobby || settings.entryFee > 0);
  };

  const currentUserLevel = currentLevelInfo;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900 p-2 sm:p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-4 sm:mb-8"
        >
          <div className="flex items-center justify-center gap-2 sm:gap-3 mb-3 sm:mb-4">
            <div className="relative">
              <div className="absolute -inset-1 sm:-inset-2 bg-gradient-to-r from-blue-500 to-green-500 rounded-full blur opacity-75"></div>
              <div className="relative bg-slate-800 p-2 sm:p-3 rounded-xl">
                <Gamepad2 className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400" />
              </div>
            </div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent">
              ایجاد لابی جدید
            </h1>
          </div>
          <p className="text-slate-400 text-sm sm:text-base">
            {currentGame ? `${currentGame.name} Lobby` : 'انتخاب بازی و ایجاد لابی'}
          </p>
        </motion.div>

        {/* Progress Steps - Mobile Optimized */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex justify-center mb-4 sm:mb-8"
        >
          <div className="flex items-center gap-2 sm:gap-4 overflow-x-auto w-full justify-center">
            {[1, 2, 3, 4, 5].map((stepNum) => (
              <div key={stepNum} className="flex items-center flex-shrink-0">
                <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center border-2 transition-colors text-sm sm:text-base ${
                  step >= stepNum 
                    ? 'bg-blue-500 border-blue-500 text-white' 
                    : 'border-slate-600 text-slate-400'
                }`}>
                  {stepNum}
                </div>
                {stepNum < 5 && (
                  <div className={`w-8 sm:w-16 h-0.5 mx-1 sm:mx-2 ${
                    step > stepNum ? 'bg-blue-500' : 'bg-slate-600'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Step 1: Game Selection */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <Card className="p-3 sm:p-6 bg-slate-800/50 border-slate-700">
                <h2 className="text-lg sm:text-xl font-semibold mb-4 sm:mb-6 flex items-center gap-2">
                  <Gamepad2 className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                  انتخاب بازی
                </h2>

                <div className="space-y-4 sm:space-y-6">
                  {/* User Level Display */}
                  <div className="p-3 sm:p-4 rounded-xl bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <div className={`p-1.5 sm:p-2 rounded-lg ${currentUserLevel.bgColor}`}>
                        <currentUserLevel.icon className={`w-4 h-4 sm:w-5 sm:h-5 ${currentUserLevel.color}`} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm sm:text-base">{currentUserLevel.name}</h3>
                        <p className="text-xs sm:text-sm text-slate-400">{currentUserLevel.description}</p>
                      </div>
                    </div>
                  </div>

                  {/* Game Selection with Platform Tabs */}
                  <div>
                    <Label className="text-sm sm:text-base">انتخاب بازی</Label>
                    <Tabs defaultValue="desktop" className="mt-2 sm:mt-3">
                      <TabsList className="grid w-full grid-cols-2 h-9 sm:h-10">
                        <TabsTrigger value="desktop" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm">
                          <Monitor className="w-3 h-3 sm:w-4 sm:h-4" />
                          <span className="hidden sm:inline">بازی‌های کامپیوتر</span>
                          <span className="sm:hidden">کامپیوتر</span>
                        </TabsTrigger>
                        <TabsTrigger value="mobile" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm">
                          <Smartphone className="w-3 h-3 sm:w-4 sm:h-4" />
                          <span className="hidden sm:inline">بازی‌های موبایل</span>
                          <span className="sm:hidden">موبایل</span>
                        </TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="desktop" className="mt-3 sm:mt-4">
                        <div className="grid grid-cols-1 gap-3 sm:gap-4">
                          {Object.entries(DESKTOP_GAMES).map(([key, game]) => (
                            <motion.div
                              key={key}
                              whileHover={{ scale: 1.01 }}
                              whileTap={{ scale: 0.99 }}
                              onClick={() => handleGameChange(key)}
                              className={`p-3 sm:p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                settings.game === key
                                  ? 'border-blue-500 bg-blue-500/10'
                                  : 'border-slate-600 hover:border-slate-500'
                              }`}
                            >
                              <div className="flex items-center gap-2 sm:gap-3">
                                <div className={`p-2 sm:p-3 rounded-lg ${game.bgColor} relative flex-shrink-0`}>
                                  <span className="text-lg sm:text-2xl">{game.emoji}</span>
                                  {game.isTournamentGame && (
                                    <Trophy className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-yellow-400 absolute -top-0.5 -right-0.5 sm:-top-1 sm:-right-1" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h3 className="font-semibold text-sm sm:text-base">{game.name}</h3>
                                  <p className="text-xs sm:text-sm text-slate-400 mt-0.5 sm:mt-1 line-clamp-2">{game.description}</p>
                                  {game.isTournamentGame && (
                                    <Badge variant="outline" className="text-xs mt-1 sm:mt-2">
                                      مسابقه‌ای
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="mobile" className="mt-3 sm:mt-4">
                        <div className="grid grid-cols-1 gap-3 sm:gap-4">
                          {Object.entries(MOBILE_GAMES).map(([key, game]) => (
                            <motion.div
                              key={key}
                              whileHover={{ scale: 1.01 }}
                              whileTap={{ scale: 0.99 }}
                              onClick={() => handleGameChange(key)}
                              className={`p-3 sm:p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                settings.game === key
                                  ? 'border-blue-500 bg-blue-500/10'
                                  : 'border-slate-600 hover:border-slate-500'
                              }`}
                            >
                              <div className="flex items-center gap-2 sm:gap-3">
                                <div className={`p-2 sm:p-3 rounded-lg ${game.bgColor} relative flex-shrink-0`}>
                                  <span className="text-lg sm:text-2xl">{game.emoji}</span>
                                  {game.isTournamentGame && (
                                    <Trophy className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-yellow-400 absolute -top-0.5 -right-0.5 sm:-top-1 sm:-right-1" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h3 className="font-semibold text-sm sm:text-base">{game.name}</h3>
                                  <p className="text-xs sm:text-sm text-slate-400 mt-0.5 sm:mt-1 line-clamp-2">{game.description}</p>
                                  {game.isTournamentGame && (
                                    <Badge variant="outline" className="text-xs mt-1 sm:mt-2">
                                      مسابقه‌ای
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </TabsContent>
                    </Tabs>
                  </div>
                </div>
              </Card>

              <div className="flex justify-end pt-2">
                <Button
                  onClick={() => setStep(2)}
                  disabled={!settings.game}
                  className="flex items-center gap-2 h-9 sm:h-10 text-sm sm:text-base px-4 sm:px-6"
                >
                  ادامه
                  <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Basic Settings */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <Card className="p-3 sm:p-6 bg-slate-800/50 border-slate-700">
                <h2 className="text-lg sm:text-xl font-semibold mb-4 sm:mb-6 flex items-center gap-2">
                  <Settings className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
                  تنظیمات اصلی
                </h2>

                <div className="space-y-4 sm:space-y-6">
                  {/* Lobby Name */}
                  <div>
                    <Label htmlFor="lobbyName" className="text-sm sm:text-base">نام لابی</Label>
                    <Input
                      id="lobbyName"
                      value={settings.name}
                      onChange={(e) => setSettings(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="نام لابی خود را وارد کنید..."
                      className="mt-1.5 sm:mt-2 h-9 sm:h-10 text-sm sm:text-base"
                    />
                  </div>

                  {/* Paid Lobby Toggle (Only for Host+ levels) */}
                  {canCreatePaidLobbies && (
                    <div className="p-3 sm:p-4 rounded-xl bg-gradient-to-r from-yellow-500/10 to-green-500/10 border border-yellow-500/20">
                      <div className="flex items-center justify-between mb-3 sm:mb-4">
                        <div>
                          <h3 className="font-semibold flex items-center gap-1.5 sm:gap-2 text-sm sm:text-base">
                            <DollarSign className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-400" />
                            لابی پولی
                          </h3>
                          <p className="text-xs sm:text-sm text-slate-400 mt-0.5 sm:mt-1">ورودیه برای شرکت در لابی</p>
                        </div>
                        <Switch
                          checked={settings.isPaidLobby}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, isPaidLobby: checked }))}
                        />
                      </div>
                      
                      <AnimatePresence>
                        {settings.isPaidLobby && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                          >
                            <Label htmlFor="entryFee" className="text-sm sm:text-base">مبلغ ورودیه (تومان)</Label>
                            <Input
                              id="entryFee"
                              type="number"
                              value={settings.entryFee}
                              onChange={(e) => setSettings(prev => ({ ...prev, entryFee: parseInt(e.target.value) || 0 }))}
                              placeholder="مبلغ ورودیه..."
                              className="mt-1.5 sm:mt-2 h-9 sm:h-10 text-sm sm:text-base"
                            />
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  )}

                  {/* Game Mode Selection */}
                  <div>
                    <Label className="text-sm sm:text-base">نوع بازی</Label>
                    <div className="grid grid-cols-1 gap-3 sm:gap-4 mt-2 sm:mt-3">
                      {availableGameModes && Object.entries(availableGameModes).map(([key, mode]) => {
                        if (!mode) return null;
                        const Icon = mode.icon;
                        return (
                          <motion.div
                            key={key}
                            whileHover={{ scale: 1.01 }}
                            whileTap={{ scale: 0.99 }}
                            onClick={() => handleGameModeChange(key)}
                            className={`p-3 sm:p-4 rounded-xl border-2 cursor-pointer transition-all ${
                              settings.gameMode === key
                                ? 'border-green-500 bg-green-500/10'
                                : 'border-slate-600 hover:border-slate-500'
                            }`}
                          >
                            <div className="flex items-center gap-2 sm:gap-3">
                              <div className={`p-1.5 sm:p-2 rounded-lg ${mode.bgColor} flex-shrink-0`}>
                                <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${mode.color}`} />
                              </div>
                              <div className="flex-1 min-w-0">
                                <h3 className="font-semibold text-sm sm:text-base">{mode.name}</h3>
                                <p className="text-xs sm:text-sm text-slate-400 mt-0.5 sm:mt-1 line-clamp-2">{mode.description}</p>
                                <div className="flex items-center gap-2 sm:gap-4 mt-1.5 sm:mt-2">
                                  <Badge variant="secondary" className="text-xs">
                                    {mode.teamSize}
                                  </Badge>
                                  <span className="text-xs text-slate-500">
                                    {mode.players} بازیکن
                                  </span>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        );
                      })}
                      {(!availableGameModes || Object.keys(availableGameModes).length === 0) && (
                        <div className="col-span-full text-center py-6 sm:py-8 text-slate-400 text-sm sm:text-base">
                          ابتدا یک بازی انتخاب کنید
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <Label htmlFor="description" className="text-sm sm:text-base">توضیحات (اختیاری)</Label>
                    <Input
                      id="description"
                      value={settings.description}
                      onChange={(e) => setSettings(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="توضیحی درباره لابی..."
                      className="mt-1.5 sm:mt-2 h-9 sm:h-10 text-sm sm:text-base"
                    />
                  </div>
                </div>
              </Card>

              <div className="flex justify-between pt-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep(1)}
                  className="flex items-center gap-1.5 sm:gap-2 h-9 sm:h-10 text-sm sm:text-base px-3 sm:px-4"
                >
                  <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4 rotate-180" />
                  قبلی
                </Button>
                <Button
                  onClick={() => setStep(3)}
                  disabled={!settings.name || !settings.gameMode || (settings.isPaidLobby && settings.entryFee <= 0)}
                  className="flex items-center gap-1.5 sm:gap-2 h-9 sm:h-10 text-sm sm:text-base px-3 sm:px-4"
                >
                  ادامه
                  <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Map & Restrictions */}
          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <Card className="p-3 sm:p-6 bg-slate-800/50 border-slate-700">
                <h2 className="text-lg sm:text-xl font-semibold mb-4 sm:mb-6 flex items-center gap-2">
                  <MapPin className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
                  انتخاب مپ و محدودیت‌ها
                </h2>

                <div className="space-y-4 sm:space-y-6">
                  {/* Map Selection */}
                  <div>
                    <Label className="text-sm sm:text-base">انتخاب مپ</Label>
                    <div className="grid grid-cols-1 gap-3 mt-2 sm:mt-3">
                      {availableMaps && availableMaps.length > 0 ? (
                        availableMaps.map((map) => (
                          <motion.div
                            key={map.id}
                            whileHover={{ scale: 1.01 }}
                            whileTap={{ scale: 0.99 }}
                            onClick={() => setSettings(prev => ({ ...prev, map: map.id }))}
                            className={`p-3 sm:p-4 rounded-xl border-2 cursor-pointer transition-all ${
                              settings.map === map.id
                                ? 'border-purple-500 bg-purple-500/10'
                                : 'border-slate-600 hover:border-slate-500'
                            }`}
                          >
                            <div className="flex items-center gap-2 sm:gap-3">
                              <span className="text-lg sm:text-2xl flex-shrink-0">{map.emoji}</span>
                              <div className="min-w-0">
                                <h3 className="font-semibold text-sm sm:text-base">{map.name}</h3>
                                <p className="text-xs sm:text-sm text-slate-400 line-clamp-2">{map.description}</p>
                              </div>
                            </div>
                          </motion.div>
                        ))
                      ) : (
                        <div className="col-span-full text-center py-6 sm:py-8 text-slate-400 text-sm sm:text-base">
                          ابتدا یک نوع بازی انتخاب کنید
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator />

                  {/* Restrictions Section */}
                  <div className="space-y-4 sm:space-y-6">
                    <h3 className="text-base sm:text-lg font-semibold flex items-center gap-2">
                      <UserCheck className="w-4 h-4 sm:w-5 sm:h-5 text-orange-400" />
                      محدودیت‌های لابی
                    </h3>

                    {/* Age Restriction */}
                    <div>
                      <Label className="text-sm sm:text-base">محدودیت سنی</Label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2 sm:mt-3">
                        {Object.entries(AGE_RESTRICTIONS).map(([key, restriction]) => (
                          <motion.div
                            key={key}
                            whileHover={{ scale: 1.01 }}
                            whileTap={{ scale: 0.99 }}
                            onClick={() => setSettings(prev => ({ ...prev, ageRestriction: key }))}
                            className={`p-3 sm:p-4 rounded-xl border-2 cursor-pointer transition-all ${
                              settings.ageRestriction === key
                                ? 'border-orange-500 bg-orange-500/10'
                                : 'border-slate-600 hover:border-slate-500'
                            }`}
                          >
                            <div className="flex items-center gap-2 sm:gap-3">
                              <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-orange-400 flex-shrink-0" />
                              <div className="min-w-0">
                                <h4 className="font-semibold text-sm sm:text-base">{restriction.name}</h4>
                                <p className="text-xs sm:text-sm text-slate-400 line-clamp-2">{restriction.description}</p>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    {/* Gender Restriction */}
                    <div>
                      <Label className="text-sm sm:text-base">محدودیت جنسیت</Label>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-2 sm:mt-3">
                        {Object.entries(GENDER_RESTRICTIONS).map(([key, restriction]) => (
                          <motion.div
                            key={key}
                            whileHover={{ scale: 1.01 }}
                            whileTap={{ scale: 0.99 }}
                            onClick={() => setSettings(prev => ({ ...prev, genderRestriction: key }))}
                            className={`p-3 sm:p-4 rounded-xl border-2 cursor-pointer transition-all ${
                              settings.genderRestriction === key
                                ? 'border-pink-500 bg-pink-500/10'
                                : 'border-slate-600 hover:border-slate-500'
                            }`}
                          >
                            <div className="flex items-center gap-2 sm:gap-3">
                              <Users className="w-4 h-4 sm:w-5 sm:h-5 text-pink-400 flex-shrink-0" />
                              <div className="min-w-0">
                                <h4 className="font-semibold text-sm sm:text-base">{restriction.name}</h4>
                                <p className="text-xs sm:text-sm text-slate-400 line-clamp-2">{restriction.description}</p>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              <div className="flex justify-between pt-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep(2)}
                  className="flex items-center gap-1.5 sm:gap-2 h-9 sm:h-10 text-sm sm:text-base px-3 sm:px-4"
                >
                  <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4 rotate-180" />
                  قبلی
                </Button>
                <Button
                  onClick={() => setStep(4)}
                  disabled={!settings.map}
                  className="flex items-center gap-1.5 sm:gap-2 h-9 sm:h-10 text-sm sm:text-base px-3 sm:px-4"
                >
                  ادامه
                  <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 4: Timer Settings */}
          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <Card className="p-3 sm:p-6 bg-slate-800/50 border-slate-700">
                <h2 className="text-lg sm:text-xl font-semibold mb-4 sm:mb-6 flex items-center gap-2">
                  <Timer className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                  تنظیمات تایمر و شروع بازی
                </h2>

                <div className="space-y-4 sm:space-y-6">
                  {/* Enable Timer Toggle */}
                  <div className="flex items-center justify-between p-3 sm:p-4 rounded-xl bg-slate-700/30 gap-3">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-semibold text-sm sm:text-base">فعال‌سازی تایمر</h3>
                      <p className="text-xs sm:text-sm text-slate-400 mt-0.5 sm:mt-1 line-clamp-2">
                        تایمر مشخص می‌کند لابی چه زمانی برای بازی شروع شود
                      </p>
                    </div>
                    <Switch
                      checked={settings.enableTimer}
                      onCheckedChange={(checked) => setSettings(prev => ({ ...prev, enableTimer: checked }))}
                    />
                  </div>

                  <AnimatePresence>
                    {settings.enableTimer && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-4 sm:space-y-6"
                      >
                        {/* Lobby Duration */}
                        <div>
                          <Label className="text-sm sm:text-base">مدت زمان باز بودن لابی</Label>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-2 sm:mt-3">
                            {[
                              { value: 0.5, label: '30 دقیقه', description: 'سریع' },
                              { value: 1, label: '1 ساعت', description: 'متوسط' },
                              { value: 2, label: '2 ساعت', description: 'معمول' },
                              { value: 4, label: '4 ساعت', description: 'طولانی' },
                              { value: 8, label: '8 ساعت', description: 'خیلی طولانی' },
                              { value: 24, label: '24 ساعت', description: 'روزانه' },
                              { value: 48, label: '48 ساعت', description: 'دو روزه' },
                              { value: 168, label: '1 هفته', description: 'هفتگی' }
                            ].map((duration) => (
                              <motion.div
                                key={duration.value}
                                whileHover={{ scale: 1.01 }}
                                whileTap={{ scale: 0.99 }}
                                onClick={() => setSettings(prev => ({ ...prev, lobbyDuration: duration.value }))}
                                className={`p-3 sm:p-4 rounded-xl border-2 cursor-pointer transition-all text-center ${
                                  settings.lobbyDuration === duration.value
                                    ? 'border-blue-500 bg-blue-500/10'
                                    : 'border-slate-600 hover:border-slate-500'
                                }`}
                              >
                                <div className="flex flex-col items-center gap-1">
                                  <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                                  <h4 className="font-semibold text-xs sm:text-sm">{duration.label}</h4>
                                  <p className="text-xs text-slate-400">{duration.description}</p>
                                </div>
                              </motion.div>
                            ))}
                          </div>
                        </div>

                        {/* Auto Start Toggle */}
                        <div className="flex items-center justify-between p-3 sm:p-4 rounded-xl bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/20 gap-3">
                          <div className="min-w-0 flex-1">
                            <h3 className="font-semibold text-sm sm:text-base flex items-center gap-2">
                              <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-green-400" />
                              شروع خودکار بازی
                            </h3>
                            <p className="text-xs sm:text-sm text-slate-400 mt-0.5 sm:mt-1 line-clamp-2">
                              بعد از تمام شدن تایمر، بازی به طور خودکار شروع می‌شود
                            </p>
                          </div>
                          <Switch
                            checked={settings.autoStart}
                            onCheckedChange={(checked) => setSettings(prev => ({ ...prev, autoStart: checked }))}
                          />
                        </div>

                        {/* Notification Settings */}
                        <div className="flex items-center justify-between p-3 sm:p-4 rounded-xl bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 gap-3">
                          <div className="min-w-0 flex-1">
                            <h3 className="font-semibold text-sm sm:text-base flex items-center gap-2">
                              <Bell className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-400" />
                              اعلان قبل از شروع
                            </h3>
                            <p className="text-xs sm:text-sm text-slate-400 mt-0.5 sm:mt-1 line-clamp-2">
                              به اعضا قبل از شروع بازی اطلاع داده شود
                            </p>
                          </div>
                          <Switch
                            checked={settings.notifyBeforeStart}
                            onCheckedChange={(checked) => setSettings(prev => ({ ...prev, notifyBeforeStart: checked }))}
                          />
                        </div>

                        <AnimatePresence>
                          {settings.notifyBeforeStart && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                            >
                              <Label className="text-sm sm:text-base">زمان اعلان (دقیقه قبل از شروع)</Label>
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-2 sm:mt-3">
                                {[1, 3, 5, 10, 15, 30].map((minutes) => (
                                  <motion.div
                                    key={minutes}
                                    whileHover={{ scale: 1.01 }}
                                    whileTap={{ scale: 0.99 }}
                                    onClick={() => setSettings(prev => ({ ...prev, notificationTime: minutes }))}
                                    className={`p-3 rounded-lg border-2 cursor-pointer transition-all text-center ${
                                      settings.notificationTime === minutes
                                        ? 'border-yellow-500 bg-yellow-500/10'
                                        : 'border-slate-600 hover:border-slate-500'
                                    }`}
                                  >
                                    <div className="flex flex-col items-center gap-1">
                                      <AlertTriangle className="w-4 h-4 text-yellow-400" />
                                      <span className="text-xs sm:text-sm font-medium">{minutes} دقیقه</span>
                                    </div>
                                  </motion.div>
                                ))}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>

                        {/* Timer Summary */}
                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="p-3 sm:p-4 rounded-xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20"
                        >
                          <h3 className="font-semibold mb-2 sm:mb-3 flex items-center gap-2 text-sm sm:text-base">
                            <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            خلاصه تایمر
                          </h3>
                          <div className="grid grid-cols-1 gap-2 text-xs sm:text-sm">
                            <div>
                              <span className="text-slate-400">مدت زمان لابی:</span>
                              <span className="mr-2 font-medium text-blue-400">
                                {settings.lobbyDuration < 1 
                                  ? `${settings.lobbyDuration * 60} دقیقه`
                                  : settings.lobbyDuration < 24
                                    ? `${settings.lobbyDuration} ساعت`
                                    : `${settings.lobbyDuration / 24} روز`
                                }
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400">شروع خودکار:</span>
                              <Badge variant={settings.autoStart ? "default" : "secondary"} className="mr-2 text-xs">
                                {settings.autoStart ? 'فعال' : 'غیرفعال'}
                              </Badge>
                            </div>
                            {settings.notifyBeforeStart && (
                              <div>
                                <span className="text-slate-400">اعلان:</span>
                                <span className="mr-2 font-medium text-yellow-400">
                                  {settings.notificationTime} دقیقه قبل از شروع
                                </span>
                              </div>
                            )}
                          </div>
                        </motion.div>

                        {/* Timer Preview */}
                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="mt-6"
                        >
                          <h4 className="font-semibold mb-3 flex items-center gap-2 text-sm sm:text-base">
                            <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                            پیش‌نمایش تایمر
                          </h4>
                          <LobbyCountdownTimer
                            startTime={new Date(Date.now() + settings.lobbyDuration * 60 * 60 * 1000)}
                            duration={settings.lobbyDuration}
                            autoStart={settings.autoStart}
                            notifyBeforeStart={settings.notifyBeforeStart}
                            notificationTime={settings.notificationTime}
                            className="opacity-75"
                          />
                        </motion.div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </Card>

              <div className="flex justify-between pt-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep(3)}
                  className="flex items-center gap-1.5 sm:gap-2 h-9 sm:h-10 text-sm sm:text-base px-3 sm:px-4"
                >
                  <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4 rotate-180" />
                  قبلی
                </Button>
                <Button
                  onClick={() => setStep(5)}
                  className="flex items-center gap-1.5 sm:gap-2 h-9 sm:h-10 text-sm sm:text-base px-3 sm:px-4"
                >
                  ادامه
                  <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 5: Privacy & Final Review */}
          {step === 5 && (
            <motion.div
              key="step5"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <Card className="p-3 sm:p-6 bg-slate-800/50 border-slate-700">
                <h2 className="text-lg sm:text-xl font-semibold mb-4 sm:mb-6 flex items-center gap-2">
                  <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400" />
                  امنیت و بررسی نهایی
                </h2>

                <div className="space-y-4 sm:space-y-6">
                  {/* Private Lobby Toggle */}
                  <div className="flex items-center justify-between p-3 sm:p-4 rounded-xl bg-slate-700/30 gap-3">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-semibold text-sm sm:text-base">لابی خصوصی</h3>
                      <p className="text-xs sm:text-sm text-slate-400 mt-0.5 sm:mt-1 line-clamp-2">فقط افراد دارای رمز می‌توانند بپیوندند</p>
                    </div>
                    <Switch
                      checked={settings.isPrivate}
                      onCheckedChange={(checked) => setSettings(prev => ({ ...prev, isPrivate: checked }))}
                    />
                  </div>

                  {/* Password Settings */}
                  <AnimatePresence>
                    {settings.isPrivate && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-3 sm:space-y-4"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1.5 sm:mb-2">
                            <Label htmlFor="password" className="text-sm sm:text-base">رمز لابی</Label>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={generateRandomPassword}
                              className="flex items-center gap-1 sm:gap-2 h-7 sm:h-8 px-2 sm:px-3 text-xs sm:text-sm"
                            >
                              <Zap className="w-3 h-3 sm:w-4 sm:h-4" />
                              <span className="hidden sm:inline">تولید</span>
                              <span className="sm:hidden">تولید</span>
                            </Button>
                          </div>
                          
                          <CopyableField
                            value={settings.password}
                            placeholder="رمز 6 رقمی وارد کنید..."
                            variant="separated"
                            readonly={false}
                            successMessage="رمز لابی کپی شد!"
                            errorMessage="خطا در کپی رمز"
                            inputClassName="h-9 sm:h-10 text-sm sm:text-base"
                            showCopyButton={!!settings.password}
                            onChange={(e) => 
                              setSettings(prev => ({ ...prev, password: e.target.value }))
                            }
                          />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Final Review */}
                  {currentGameMode && settings.map && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 sm:p-4 rounded-xl bg-gradient-to-r from-blue-500/10 to-green-500/10 border border-blue-500/20"
                    >
                      <h3 className="font-semibold mb-2 sm:mb-3 flex items-center gap-2 text-sm sm:text-base">
                        <Eye className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                        خلاصه لابی
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4 text-xs sm:text-sm">
                        <div>
                          <span className="text-slate-400">بازی:</span>
                          <span className="mr-2 font-medium">{currentGame?.name}</span>
                        </div>
                        <div>
                          <span className="text-slate-400">نام:</span>
                          <span className="mr-2 font-medium">{settings.name}</span>
                        </div>
                        <div>
                          <span className="text-slate-400">نوع:</span>
                          <span className="mr-2 font-medium">{currentGameMode.name}</span>
                        </div>
                        <div>
                          <span className="text-slate-400">مپ:</span>
                          <span className="mr-2 font-medium">
                            {availableMaps?.find(m => m.id === settings.map)?.name || 'مپ انتخاب نشده'}
                          </span>
                        </div>
                        {settings.isPaidLobby && (
                          <div className="col-span-1 sm:col-span-2">
                            <span className="text-slate-400">ورودیه:</span>
                            <Badge variant="outline" className="mr-2 text-yellow-400 text-xs">
                              {settings.entryFee.toLocaleString()} تومان
                            </Badge>
                          </div>
                        )}
                        <div className="col-span-1 sm:col-span-2">
                          <span className="text-slate-400">وضعیت:</span>
                          <Badge variant={settings.isPrivate ? "secondary" : "default"} className="mr-2 text-xs">
                            {settings.isPrivate ? 'خصوصی' : 'عمومی'}
                          </Badge>
                          {settings.isPaidLobby && (
                            <Badge variant="outline" className="mr-2 text-yellow-400 text-xs">
                              پولی
                            </Badge>
                          )}
                        </div>
                        {settings.enableTimer && (
                          <>
                            <div>
                              <span className="text-slate-400">مدت زمان:</span>
                              <span className="mr-2 font-medium text-blue-400">
                                {settings.lobbyDuration < 1 
                                  ? `${settings.lobbyDuration * 60} دقیقه`
                                  : settings.lobbyDuration < 24
                                    ? `${settings.lobbyDuration} ساعت`
                                    : `${settings.lobbyDuration / 24} روز`
                                }
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400">شروع خودکار:</span>
                              <Badge variant={settings.autoStart ? "default" : "secondary"} className="mr-2 text-xs">
                                {settings.autoStart ? 'فعال' : 'غیرفعال'}
                              </Badge>
                            </div>
                          </>
                        )}
                      </div>
                    </motion.div>
                  )}
                </div>
              </Card>

              <div className="flex justify-between pt-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep(4)}
                  className="flex items-center gap-1.5 sm:gap-2 h-9 sm:h-10 text-sm sm:text-base px-3 sm:px-4"
                >
                  <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4 rotate-180" />
                  قبلی
                </Button>
                <Button
                  onClick={() => setShowPreview(true)}
                  disabled={!isFormValid()}
                  className="flex items-center gap-1.5 sm:gap-2 bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 h-9 sm:h-10 text-sm sm:text-base px-3 sm:px-6"
                >
                  <Play className="w-3 h-3 sm:w-4 sm:h-4" />
                  ایجاد لابی
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Create Lobby Confirmation Modal - Mobile Optimized */}
        <AnimatePresence>
          {showPreview && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 flex items-center justify-center p-3 sm:p-4 z-50"
              onClick={() => setShowPreview(false)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-slate-800 rounded-2xl p-4 sm:p-6 max-w-md w-full border border-slate-700 max-h-[90vh] overflow-y-auto"
              >
                <h3 className="text-lg sm:text-xl font-semibold mb-3 sm:mb-4 text-center">تایید ایجاد لابی</h3>
                
                <div className="space-y-2 sm:space-y-3 mb-4 sm:mb-6">
                  <div className="flex justify-between items-start gap-2">
                    <span className="text-slate-400 text-sm sm:text-base flex-shrink-0">بازی:</span>
                    <span className="font-medium text-sm sm:text-base text-left">{currentGame?.name}</span>
                  </div>
                  <div className="flex justify-between items-start gap-2">
                    <span className="text-slate-400 text-sm sm:text-base flex-shrink-0">نام لابی:</span>
                    <span className="font-medium text-sm sm:text-base text-left break-words">{settings.name}</span>
                  </div>
                  {settings.isPaidLobby && (
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-slate-400 text-sm sm:text-base flex-shrink-0">ورودیه:</span>
                      <span className="font-medium text-yellow-400 text-sm sm:text-base text-left">{settings.entryFee.toLocaleString()} تومان</span>
                    </div>
                  )}
                  {settings.isPrivate && (
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-slate-400 text-sm sm:text-base flex-shrink-0">رمز:</span>
                      <code className="bg-slate-700 px-2 py-1 rounded text-xs sm:text-sm font-mono">
                        {settings.password}
                      </code>
                    </div>
                  )}
                  {settings.enableTimer && (
                    <>
                      <div className="flex justify-between items-start gap-2">
                        <span className="text-slate-400 text-sm sm:text-base flex-shrink-0">مدت زمان لابی:</span>
                        <span className="font-medium text-blue-400 text-sm sm:text-base text-left">
                          {settings.lobbyDuration < 1 
                            ? `${settings.lobbyDuration * 60} دقیقه`
                            : settings.lobbyDuration < 24
                              ? `${settings.lobbyDuration} ساعت`
                              : `${settings.lobbyDuration / 24} روز`
                          }
                        </span>
                      </div>
                      {settings.autoStart && (
                        <div className="flex justify-between items-start gap-2">
                          <span className="text-slate-400 text-sm sm:text-base flex-shrink-0">شروع خودکار:</span>
                          <Badge variant="default" className="text-xs">
                            فعال
                          </Badge>
                        </div>
                      )}
                      {settings.notifyBeforeStart && (
                        <div className="flex justify-between items-start gap-2">
                          <span className="text-slate-400 text-sm sm:text-base flex-shrink-0">اعلان:</span>
                          <span className="font-medium text-yellow-400 text-sm sm:text-base text-left">
                            {settings.notificationTime} دقیقه قبل
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </div>

                <div className="flex gap-2 sm:gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setShowPreview(false)}
                    className="flex-1 h-9 sm:h-10 text-sm sm:text-base"
                    disabled={isCreating}
                  >
                    انصراف
                  </Button>
                  <Button
                    onClick={handleCreateLobby}
                    className="flex-1 bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600 h-9 sm:h-10 text-sm sm:text-base"
                    disabled={isCreating}
                  >
                    {isCreating ? (
                      <div className="flex items-center gap-1 sm:gap-2">
                        <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        <span className="text-xs sm:text-sm">در حال ایجاد...</span>
                      </div>
                    ) : (
                      'ایجاد لابی'
                    )}
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}