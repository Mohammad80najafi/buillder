/**
 * Matchzone Gaming Platform
 * Enhanced Lobby Card - کارت بهبود یافته لابی با پشتیبانی از زمان‌بندی
 */

import React from 'react';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  Users, 
  Clock, 
  Calendar,
  MapPin,
  Star,
  Trophy,
  Shield,
  Eye,
  Play,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { useLobby } from './LobbyContext';
import { cn } from '../../lib/utils';
import { format } from 'date-fns';
import { formatPersianTime, formatPersianDate } from '../../utils/dateHelpers';
import { getLobbyCodeFromId } from '../../utils/lobbyCodeGenerator';
import { silentCopy } from '../../utils/clipboardUtils';


interface EnhancedLobbyCardProps {
  // Basic Info
  id: string;
  title: string;
  game: string;
  platform: 'mobile' | 'desktop';
  
  // Player Info
  currentPlayers: number;
  maxPlayers: number;
  
  // Owner Info
  owner?: {
    id: string;
    username: string;
    avatar?: string;
    trustLevel: 'low' | 'mid' | 'high';
    isVerified?: boolean;
  };
  
  // Status & Visibility
  status: 'open' | 'nearfull' | 'full' | 'closed' | 'starting' | 'active';
  visibility: 'public' | 'private';
  
  // Entry Requirements
  entryFee?: number;
  skillLevel?: 'beginner' | 'intermediate' | 'advanced' | 'pro';
  
  // Schedule Info (New)
  startTime?: Date;
  endTime?: Date;
  duration?: number; // in minutes
  
  // Additional Info
  description?: string;
  rules?: string;
  tags?: string[];
  region?: string;
  
  // Event Handlers
  onJoin?: () => void;
  onView?: () => void;
  onClick?: () => void;
  
  className?: string;
}

// Helper function to get platform emoji
const getPlatformEmoji = (platform: 'mobile' | 'desktop'): string => {
  return platform === 'mobile' ? '📱' : '💻';
};

// Helper function to get game emoji
const getGameEmoji = (game: string): string => {
  if (!game || typeof game !== 'string') {
    return '🎮';
  }
  
  const gameEmojis: { [key: string]: string } = {
    'fifa-mobile': '⚽',
    'pubg-mobile': '🔫',
    'cod-mobile': '🎯',
    'cs2': '🔫',
    'valorant': '🎮',
    'apex-legends': '🎮'
  };
  return gameEmojis[game.toLowerCase()] || '🎮';
};

// Status badge component
const StatusBadge: React.FC<{ 
  status: EnhancedLobbyCardProps['status']; 
  currentPlayers: number; 
  maxPlayers: number;
  startTime?: Date;
}> = ({ status, currentPlayers, maxPlayers, startTime }) => {
  // Fallback functions since Schedule context has been removed
  const isSlotActive = () => false;
  const isSlotUpcoming = () => false;
  const getTimeUntilStart = () => '';
  
  if (startTime) {
    const mockSlot = {
      id: '',
      startTime,
      endTime: startTime,
      lobbyId: '',
      userId: '',
      gameType: '',
      platform: 'mobile' as const,
      status: 'scheduled' as const,
      participants: [],
      maxParticipants: maxPlayers
    };
    
    if (isSlotActive(mockSlot)) {
      return (
        <Badge className="bg-state-success text-state-success-foreground">
          <Play className="w-3 h-3 mr-1" />
          در حال اجرا
        </Badge>
      );
    }
    
    if (isSlotUpcoming(mockSlot)) {
      return (
        <Badge className="bg-brand-primary text-primary-foreground">
          <Clock className="w-3 h-3 mr-1" />
          {getTimeUntilStart(mockSlot)} مانده
        </Badge>
      );
    }
  }

  switch (status) {
    case 'open':
      return (
        <Badge className="bg-state-success text-state-success-foreground">
          <CheckCircle className="w-3 h-3 mr-1" />
          باز
        </Badge>
      );
    case 'nearfull':
      return (
        <Badge className="bg-state-warning text-state-warning-foreground">
          <AlertCircle className="w-3 h-3 mr-1" />
          تقریباً پر
        </Badge>
      );
    case 'full':
      return (
        <Badge variant="secondary">
          <Users className="w-3 h-3 mr-1" />
          پر شده
        </Badge>
      );
    case 'closed':
      return (
        <Badge variant="destructive">
          بسته
        </Badge>
      );
    case 'starting':
      return (
        <Badge className="bg-brand-accent text-accent-foreground animate-pulse">
          <Play className="w-3 h-3 mr-1" />
          در حال شروع
        </Badge>
      );
    case 'active':
      return (
        <Badge className="bg-state-success text-state-success-foreground animate-pulse">
          <Play className="w-3 h-3 mr-1" />
          فعال
        </Badge>
      );
    default:
      return null;
  }
};

// Trust level component
const TrustBadge: React.FC<{ level: 'low' | 'mid' | 'high'; isVerified?: boolean }> = ({ 
  level, 
  isVerified 
}) => {
  const getTrustColor = () => {
    switch (level) {
      case 'high':
        return 'text-state-success';
      case 'mid':
        return 'text-state-warning';
      case 'low':
        return 'text-text-tertiary';
      default:
        return 'text-text-tertiary';
    }
  };

  const getTrustStars = () => {
    switch (level) {
      case 'high':
        return 5;
      case 'mid':
        return 3;
      case 'low':
        return 1;
      default:
        return 1;
    }
  };

  return (
    <div className="flex items-center gap-1">
      {isVerified && (
        <Shield className={cn("w-3 h-3", getTrustColor())} />
      )}
      {[...Array(getTrustStars())].map((_, i) => (
        <Star key={i} className={cn("w-3 h-3 fill-current", getTrustColor())} />
      ))}
    </div>
  );
};

export const EnhancedLobbyCard: React.FC<EnhancedLobbyCardProps> = ({
  id,
  title,
  game = '',
  platform = 'mobile',
  currentPlayers = 0,
  maxPlayers = 4,
  owner,
  status = 'open',
  visibility = 'public',
  entryFee,
  skillLevel,
  startTime,
  endTime,
  duration,
  description,
  rules,
  tags,
  region,
  onJoin,
  onView,
  onClick,
  className
}) => {
  // Lobby membership state
  const { getMembershipStatus, requestMembership, joinedLobbies } = useLobby();
  const membershipStatus = getMembershipStatus(id);
  const isJoinedLobby = joinedLobbies.includes(id);
  
  // Use fallback formatting functions directly
  const formatTime = formatPersianTime;
  const formatDate = formatPersianDate;

  const isFullyBooked = currentPlayers >= maxPlayers;
  const isNearFull = currentPlayers >= maxPlayers * 0.8;
  const canJoin = !isFullyBooked && (status === 'open' || status === 'nearfull');

  // Calculate fill percentage for progress indication
  const fillPercentage = (currentPlayers / maxPlayers) * 100;

  const handleCardClick = () => {
    if (onClick) {
      onClick();
    } else if (canJoin && onJoin) {
      onJoin();
    } else if (onView) {
      onView();
    }
  };

  return (
    <Card 
      className={cn(
        "group cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1 border-border-primary",
        "bg-gradient-to-br from-surface-primary to-surface-secondary",
        status === 'active' && "ring-2 ring-state-success ring-offset-2 ring-offset-background",
        status === 'starting' && "ring-2 ring-brand-accent ring-offset-2 ring-offset-background animate-pulse",
        isFullyBooked && "opacity-60",
        className
      )}
      onClick={handleCardClick}
    >
      <CardContent className="p-6 space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <div className="text-2xl flex-shrink-0">
              {getPlatformEmoji(platform)}
              {getGameEmoji(game)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-lg leading-tight truncate">{title}</h3>
                <Badge 
                  variant="outline" 
                  className="text-xs font-mono cursor-pointer hover:bg-muted/50 transition-colors"
                  title="کلیک برای کپی کد"
                  onClick={(e) => {
                    e.stopPropagation();
                    const code = getLobbyCodeFromId(id);
                    silentCopy(code);
                  }}
                >
                  {getLobbyCodeFromId(id)}
                </Badge>
              </div>
              <p className="text-sm text-text-secondary truncate">{game}</p>
              
              {/* Schedule Info */}
              {startTime && (
                <div className="flex items-center gap-4 mt-2 text-xs text-text-secondary">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{startTime ? formatDate(startTime) : ''}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>
                      {startTime ? formatTime(startTime) : ''}
                      {endTime && ` - ${formatTime(endTime)}`}
                      {!endTime && duration && ` (${duration}م)`}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex flex-col items-end gap-2">
            <StatusBadge 
              status={status} 
              currentPlayers={currentPlayers} 
              maxPlayers={maxPlayers}
              startTime={startTime}
            />
            {visibility === 'private' && (
              <Badge variant="outline" className="text-xs">
                خصوصی
              </Badge>
            )}
          </div>
        </div>

        {/* Player Count & Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-1 text-text-secondary">
              <Users className="w-4 h-4" />
              <span>{currentPlayers}/{maxPlayers} نفر</span>
            </div>
            {entryFee !== undefined && (
              <div className="text-brand-accent font-medium">
                {entryFee === 0 ? 'رایگان' : `${entryFee.toLocaleString()} تومان`}
              </div>
            )}
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-surface-tertiary rounded-full h-2 overflow-hidden">
            <div 
              className={cn(
                "h-full transition-all duration-300 rounded-full",
                fillPercentage < 50 ? "bg-state-success" : 
                fillPercentage < 80 ? "bg-state-warning" : "bg-state-danger"
              )}
              style={{ width: `${fillPercentage}%` }}
            />
          </div>
        </div>

        {/* Owner Info */}
        {owner && (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Avatar className="w-6 h-6">
                <AvatarImage src={owner.avatar} />
                <AvatarFallback className="text-xs">
                  {owner.username?.charAt(0).toUpperCase() || 'U'}
                </AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium truncate max-w-24">{owner.username || 'کاربر ناشناس'}</span>
              <TrustBadge level={owner.trustLevel || 'low'} isVerified={owner.isVerified} />
            </div>
            
            {region && (
              <div className="flex items-center gap-1 text-xs text-text-tertiary">
                <MapPin className="w-3 h-3" />
                <span>{region}</span>
              </div>
            )}
          </div>
        )}

        {/* Tags */}
        {tags && tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {tags.slice(0, 3).map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs px-2 py-0">
                {tag}
              </Badge>
            ))}
            {tags.length > 3 && (
              <Badge variant="outline" className="text-xs px-2 py-0">
                +{tags.length - 3}
              </Badge>
            )}
          </div>
        )}

        {/* Description */}
        {description && (
          <p className="text-sm text-text-secondary line-clamp-2">{description}</p>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2 pt-2">
          {isFullyBooked ? (
            <Button 
              variant="outline" 
              className="flex-1" 
              size="sm"
              disabled
            >
              <Users className="w-4 h-4 ml-1" />
              پر شده
            </Button>
          ) : membershipStatus === 'pending' ? (
            <Button 
              variant="outline" 
              className="flex-1" 
              size="sm"
              disabled
            >
              <Clock className="w-4 h-4 ml-1" />
              در انتظار تایید برگذارکننده
            </Button>
          ) : membershipStatus === 'approved' || isJoinedLobby ? (
            <Button 
              onClick={(e) => {
                e.stopPropagation();
                onView?.();
              }}
              className="flex-1"
              size="sm"
              variant={isJoinedLobby ? "default" : "outline"}
            >
              <CheckCircle className="w-4 h-4 ml-1" />
              {isJoinedLobby ? 'عضو لابی • ورود' : 'تایید شده • ورود'}
            </Button>
          ) : membershipStatus === 'rejected' ? (
            <Button 
              onClick={(e) => {
                e.stopPropagation();
                requestMembership(id);
              }}
              variant="outline"
              className="flex-1"
              size="sm"
            >
              <AlertCircle className="w-4 h-4 ml-1" />
              درخواست مجدد
            </Button>
          ) : canJoin ? (
            <Button 
              onClick={(e) => {
                e.stopPropagation();
                requestMembership(id);
              }}
              className="flex-1"
              size="sm"
            >
              <Play className="w-4 h-4 ml-1" />
              درخواست پیوستن
            </Button>
          ) : (
            <Button 
              variant="outline" 
              className="flex-1" 
              size="sm"
              disabled
            >
              غیرقابل دسترس
            </Button>
          )}
          
          {onView && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onView();
              }}
            >
              <Eye className="w-4 h-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};