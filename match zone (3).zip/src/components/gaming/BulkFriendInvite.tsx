/**
 * Bulk Friend Invite Component
 * Quick invite all online friends feature
 */

import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  Users, 
  Send, 
  Loader2,
  CheckCircle
} from 'lucide-react';
import { useFriends } from '../../hooks/useFriends';
import { toast } from 'sonner@2.0.3';

interface BulkFriendInviteProps {
  lobbyName: string;
  lobbyCode: string;
  lobbyUrl: string;
  game: string;
}

export function BulkFriendInvite({ 
  lobbyName, 
  lobbyCode, 
  lobbyUrl, 
  game 
}: BulkFriendInviteProps) {
  const { onlineFriends, sendLobbyInvite, inviteStatuses } = useFriends();
  const [isSending, setIsSending] = useState(false);
  const [sentCount, setSentCount] = useState(0);

  // Filter out friends who already received invites
  const uninvitedOnlineFriends = onlineFriends.filter(
    friend => !inviteStatuses.has(friend.id)
  );

  const handleBulkInvite = async () => {
    if (uninvitedOnlineFriends.length === 0) return;

    setIsSending(true);
    setSentCount(0);

    try {
      for (let i = 0; i < uninvitedOnlineFriends.length; i++) {
        const friend = uninvitedOnlineFriends[i];
        
        await sendLobbyInvite(friend.id, {
          lobbyName,
          lobbyCode,
          lobbyUrl,
          game
        });

        setSentCount(i + 1);
        
        // Add delay between invites to feel more natural
        if (i < uninvitedOnlineFriends.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 300));
        }
      }

      toast.success('دعوت‌ها ارسال شد!', {
        description: `دعوت لابی برای ${uninvitedOnlineFriends.length} دوست ارسال شد`,
        duration: 4000
      });

    } catch (error) {
      toast.error('خطا در ارسال دعوت‌ها', {
        description: 'لطفاً دوباره تلاش کنید',
        duration: 3000
      });
    } finally {
      setIsSending(false);
      setSentCount(0);
    }
  };

  if (uninvitedOnlineFriends.length === 0) {
    return null;
  }

  return (
    <Button
      onClick={handleBulkInvite}
      disabled={isSending}
      variant="secondary"
      className="w-full relative overflow-hidden"
    >
      <div className="flex items-center justify-center gap-2">
        {isSending ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            در حال ارسال... ({sentCount}/{uninvitedOnlineFriends.length})
          </>
        ) : sentCount > 0 ? (
          <>
            <CheckCircle className="w-4 h-4 text-green-500" />
            ارسال شد!
          </>
        ) : (
          <>
            <Send className="w-4 h-4" />
            دعوت همه آنلاین‌ها
            <Badge variant="outline" className="ml-2 text-xs">
              {uninvitedOnlineFriends.length}
            </Badge>
          </>
        )}
      </div>
      
      {/* Progress bar */}
      {isSending && (
        <div 
          className="absolute bottom-0 left-0 h-1 bg-primary transition-all duration-300"
          style={{ 
            width: `${(sentCount / uninvitedOnlineFriends.length) * 100}%` 
          }}
        />
      )}
    </Button>
  );
}