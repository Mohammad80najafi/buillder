/**
 * Chat Notification Badge
 * نمایش badge برای پیام‌های خوانده نشده چت
 */

import React from 'react';
import { Badge } from '../ui/badge';
import { MessageCircle } from 'lucide-react';

interface ChatNotificationBadgeProps {
  count: number;
  className?: string;
}

export function ChatNotificationBadge({ count, className = '' }: ChatNotificationBadgeProps) {
  if (count === 0) return null;

  return (
    <div className={`relative inline-flex ${className}`}>
      <Badge 
        variant="destructive" 
        className="absolute -top-2 -right-2 h-5 w-5 p-0 text-xs flex items-center justify-center rounded-full animate-pulse"
      >
        {count > 99 ? '99+' : count}
      </Badge>
      <MessageCircle className="w-4 h-4" />
    </div>
  );
}

export default ChatNotificationBadge;