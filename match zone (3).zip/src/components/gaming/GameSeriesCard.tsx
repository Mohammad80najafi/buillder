/**
 * Game Series Card Component
 * نمایش سری بازی‌ها (مثل "آخرین بازمانده" با چند قسمت)
 */

import React, { useState, useMemo, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { 
  Play, Clock, Users, Eye, ChevronLeft, ChevronRight, 
  Calendar, Star, Download, Share2, BookOpen, Lock,
  CheckCircle, PlayCircle, Crown, Flame
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useMobile } from '../ui/use-mobile';

export interface GameEpisode {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  duration: string;
  releaseDate: string;
  isNew?: boolean;
  isWatched?: boolean;
  isLocked?: boolean;
  views: number;
  likes: number;
  difficulty?: 'آسان' | 'متوسط' | 'سخت' | 'خیلی سخت';
  participants?: number;
}

export interface GameSeries {
  id: string;
  title: string;
  description: string;
  coverImage: string;
  totalEpisodes: number;
  completedEpisodes: number;
  category: string;
  rating: number;
  isPremium?: boolean;
  episodes: GameEpisode[];
  creator: {
    name: string;
    avatar: string;
    verified: boolean;
  };
  stats: {
    totalViews: number;
    totalParticipants: number;
    averageRating: number;
  };
}

interface GameSeriesCardProps {
  series: GameSeries;
  onEpisodeSelect?: (episodeId: string) => void;
  onSeriesSelect?: (seriesId: string) => void;
  showEpisodes?: boolean;
  compact?: boolean;
}

export function GameSeriesCard({ 
  series, 
  onEpisodeSelect, 
  onSeriesSelect,
  showEpisodes = true,
  compact = false 
}: GameSeriesCardProps) {
  const isMobile = useMobile();
  const [currentEpisodePage, setCurrentEpisodePage] = useState(0);
  const [isExpanded, setIsExpanded] = useState(false);
  
  const episodesPerPage = useMemo(() => isMobile ? 2 : 3, [isMobile]);

  const progressPercentage = useMemo(() => 
    (series.completedEpisodes / series.totalEpisodes) * 100,
    [series.completedEpisodes, series.totalEpisodes]
  );
  
  const paginatedEpisodes = useMemo(() => 
    series.episodes.slice(
      currentEpisodePage * episodesPerPage,
      (currentEpisodePage + 1) * episodesPerPage
    ),
    [series.episodes, currentEpisodePage, episodesPerPage]
  );

  const totalPages = useMemo(() => 
    Math.ceil(series.episodes.length / episodesPerPage),
    [series.episodes.length, episodesPerPage]
  );

  const getDifficultyColor = useCallback((difficulty?: string) => {
    switch (difficulty) {
      case 'آسان': return 'bg-green-500';
      case 'متوسط': return 'bg-yellow-500';
      case 'سخت': return 'bg-orange-500';
      case 'خیلی سخت': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  }, []);

  const handleNextPage = useCallback(() => {
    if (currentEpisodePage < totalPages - 1) {
      setCurrentEpisodePage(prev => prev + 1);
    }
  }, [currentEpisodePage, totalPages]);

  const handlePrevPage = useCallback(() => {
    if (currentEpisodePage > 0) {
      setCurrentEpisodePage(prev => prev - 1);
    }
  }, [currentEpisodePage]);

  const handleSeriesClick = useCallback(() => {
    onSeriesSelect?.(series.id);
  }, [onSeriesSelect, series.id]);

  const handleEpisodeClick = useCallback((episodeId: string) => {
    onEpisodeSelect?.(episodeId);
  }, [onEpisodeSelect]);

  const getGridColumns = useMemo(() => 
    isMobile ? 'grid-cols-1' : 'grid-cols-3',
    [isMobile]
  );

  if (compact) {
    return (
      <Card className="group hover:shadow-lg transition-all duration-300 cursor-pointer relative overflow-hidden"
            onClick={handleSeriesClick}>
        <div className="aspect-video relative overflow-hidden">
          <img 
            src={series.coverImage} 
            alt={series.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          <div className="absolute top-2 right-2 flex gap-2">
            {series.isPremium && (
              <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                <Crown className="h-3 w-3 ml-1" />
                پریمیوم
              </Badge>
            )}
            <Badge variant="secondary" className="bg-black/50 text-white">
              {series.totalEpisodes} قسمت
            </Badge>
          </div>
          <div className="absolute bottom-2 right-2">
            <Button size="sm" className="rounded-full bg-primary/80 hover:bg-primary">
              <Play className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <CardContent className="p-4">
          <div className="space-y-2">
            <h3 className="font-semibold text-sm line-clamp-2">{series.title}</h3>
            <p className="text-xs text-muted-foreground line-clamp-2">{series.description}</p>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Eye className="h-3 w-3" />
                {series.stats.totalViews.toLocaleString('fa-IR')}
              </div>
              <div className="flex items-center gap-1">
                <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                <span className="text-xs">{series.rating}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="group hover:shadow-lg transition-all duration-300 relative overflow-hidden">
      {/* Series Header */}
      <div className={`${isMobile ? 'aspect-[16/10]' : 'aspect-[21/9]'} relative overflow-hidden cursor-pointer`}
           onClick={handleSeriesClick}>
        <img 
          src={series.coverImage} 
          alt={series.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        {/* Premium Badge */}
        {series.isPremium && (
          <div className="absolute top-4 right-4">
            <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
              <Crown className="h-4 w-4 ml-1" />
              پریمیوم
            </Badge>
          </div>
        )}

        {/* Play Button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Button size="lg" className="rounded-full bg-primary/80 hover:bg-primary backdrop-blur-sm">
            <Play className="h-6 w-6 ml-2" />
            شروع تماشا
          </Button>
        </div>

        {/* Series Info Overlay */}
        <div className="absolute bottom-4 right-4 left-4">
          <div className="space-y-2">
            <h2 className="text-white text-xl font-bold">{series.title}</h2>
            <p className="text-white/80 text-sm line-clamp-2">{series.description}</p>
            
            {/* Stats */}
            <div className="flex items-center gap-4 text-white/70 text-sm">
              <div className="flex items-center gap-1">
                <BookOpen className="h-4 w-4" />
                {series.totalEpisodes} قسمت
              </div>
              <div className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                {series.stats.totalViews.toLocaleString('fa-IR')} بازدید
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                {series.stats.totalParticipants.toLocaleString('fa-IR')} شرکت‌کننده
              </div>
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                {series.rating}
              </div>
            </div>

            {/* Progress */}
            {series.completedEpisodes > 0 && (
              <div className="space-y-1">
                <div className="flex justify-between text-white/70 text-xs">
                  <span>پیشرفت شما</span>
                  <span>{series.completedEpisodes} از {series.totalEpisodes}</span>
                </div>
                <Progress value={progressPercentage} className="h-2 bg-white/20" />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Creator Info */}
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={series.creator.avatar} alt={series.creator.name} />
              <AvatarFallback>{series.creator.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-1">
                <h4 className="font-semibold text-sm">{series.creator.name}</h4>
                {series.creator.verified && (
                  <CheckCircle className="h-4 w-4 text-blue-500" />
                )}
              </div>
              <p className="text-xs text-muted-foreground">{series.category}</p>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button size="sm" variant="outline">
              <Share2 className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline">
              <Download className="h-4 w-4" />
            </Button>
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? 'بستن' : 'نمایش قسمت‌ها'}
            </Button>
          </div>
        </div>
      </CardHeader>

      {/* Episodes List */}
      <AnimatePresence>
        {(showEpisodes && isExpanded) && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <CardContent className="pt-0">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">قسمت‌ها</h3>
                  <div className="flex items-center gap-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={handlePrevPage}
                      disabled={currentEpisodePage === 0}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    <span className="text-sm text-muted-foreground">
                      {currentEpisodePage + 1} از {totalPages}
                    </span>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={handleNextPage}
                      disabled={currentEpisodePage >= totalPages - 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className={`grid ${getGridColumns} gap-4`}>
                  {paginatedEpisodes.map((episode) => (
                    <Card 
                      key={episode.id} 
                      className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                        episode.isLocked ? 'opacity-60' : 'hover:scale-[1.02]'
                      }`}
                      onClick={() => !episode.isLocked && handleEpisodeClick(episode.id)}
                    >
                      <div className="aspect-video relative overflow-hidden">
                        <img 
                          src={episode.thumbnail} 
                          alt={episode.title}
                          className="w-full h-full object-cover"
                        />
                        
                        {/* Episode Status Overlays */}
                        <div className="absolute inset-0 flex items-center justify-center">
                          {episode.isLocked ? (
                            <div className="bg-black/70 rounded-full p-3">
                              <Lock className="h-6 w-6 text-white" />
                            </div>
                          ) : episode.isWatched ? (
                            <div className="bg-green-500/80 rounded-full p-2">
                              <CheckCircle className="h-5 w-5 text-white" />
                            </div>
                          ) : (
                            <div className="bg-primary/80 rounded-full p-3 opacity-0 group-hover:opacity-100 transition-opacity">
                              <PlayCircle className="h-6 w-6 text-white" />
                            </div>
                          )}
                        </div>

                        {/* Episode Badges */}
                        <div className="absolute top-2 right-2 flex gap-1">
                          {episode.isNew && (
                            <Badge className="bg-red-500 text-white">
                              <Flame className="h-3 w-3 ml-1" />
                              جدید
                            </Badge>
                          )}
                          {episode.difficulty && (
                            <Badge className={`${getDifficultyColor(episode.difficulty)} text-white`}>
                              {episode.difficulty}
                            </Badge>
                          )}
                        </div>

                        <div className="absolute bottom-2 left-2">
                          <Badge variant="secondary" className="bg-black/70 text-white text-xs">
                            {episode.duration}
                          </Badge>
                        </div>
                      </div>

                      <CardContent className="p-3">
                        <div className="space-y-2">
                          <h4 className="font-semibold text-sm line-clamp-1">{episode.title}</h4>
                          <p className="text-xs text-muted-foreground line-clamp-2">{episode.description}</p>
                          
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              {episode.views.toLocaleString('fa-IR')}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {episode.releaseDate}
                            </div>
                          </div>

                          {episode.participants && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Users className="h-3 w-3" />
                              {episode.participants.toLocaleString('fa-IR')} شرکت‌کننده
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

export default GameSeriesCard;