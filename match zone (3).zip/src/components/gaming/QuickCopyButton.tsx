/**
 * Quick Copy Button Component
 * Enhanced copy button with multiple fallback methods and visual feedback
 */

import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Copy, Check, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useClipboard } from '../../hooks/useClipboard';
import { cn } from '../../lib/utils';

interface QuickCopyButtonProps {
  text: string;
  label?: string;
  variant?: 'default' | 'outline' | 'ghost' | 'link' | 'destructive' | 'secondary';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
  showLabel?: boolean;
  successMessage?: string;
  errorMessage?: string;
}

export function QuickCopyButton({
  text,
  label,
  variant = 'outline',
  size = 'sm',
  className,
  showLabel = false,
  successMessage,
  errorMessage
}: QuickCopyButtonProps) {
  const [status, setStatus] = useState<'idle' | 'copying' | 'success' | 'error'>('idle');

  const { copy: copyToClipboard } = useClipboard({
    onSuccess: (method) => {
      setStatus('success');
      toast.success(successMessage || 'کپی شد!', {
        description: `روش: ${method === 'clipboard-api' ? 'مدرن' : 
                      method === 'execCommand' ? 'سنتی' : 
                      method === 'selection-api' ? 'انتخاب متن' : 'نامشخص'}`,
        duration: 1500
      });
      setTimeout(() => setStatus('idle'), 2000);
    },
    onError: (error) => {
      setStatus('error');
      
      // Create temporary input for manual copy as fallback
      const tempInput = document.createElement('input');
      tempInput.value = text;
      tempInput.style.position = 'absolute';
      tempInput.style.left = '50%';
      tempInput.style.top = '50%';
      tempInput.style.transform = 'translate(-50%, -50%)';
      tempInput.style.zIndex = '10000';
      tempInput.style.padding = '8px';
      tempInput.style.border = '2px solid #3B82F6';
      tempInput.style.borderRadius = '8px';
      tempInput.style.backgroundColor = '#1A1D24';
      tempInput.style.color = '#E5E7EB';
      tempInput.readOnly = true;
      
      document.body.appendChild(tempInput);
      tempInput.focus();
      tempInput.select();
      
      toast.warning('کپی دستی', {
        description: 'فیلد بالا را انتخاب کرده و Ctrl+C بزنید',
        action: {
          label: 'بستن',
          onClick: () => {
            if (document.body.contains(tempInput)) {
              document.body.removeChild(tempInput);
            }
          }
        },
        duration: 5000
      });
      
      setTimeout(() => {
        if (document.body.contains(tempInput)) {
          document.body.removeChild(tempInput);
        }
        setStatus('idle');
      }, 5000);
    }
  });

  const handleCopy = async () => {
    setStatus('copying');
    await copyToClipboard(text);
  };

  const getIcon = () => {
    switch (status) {
      case 'copying':
        return <div className="animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full" />;
      case 'success':
        return <Check className="w-4 h-4 text-green-500" />;
      case 'error':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default:
        return <Copy className="w-4 h-4" />;
    }
  };

  const getButtonText = () => {
    if (!showLabel) return null;
    
    switch (status) {
      case 'copying':
        return 'در حال کپی...';
      case 'success':
        return 'کپی شد!';
      case 'error':
        return 'خطا';
      default:
        return label || 'کپی';
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleCopy}
      disabled={status === 'copying'}
      className={cn(
        'transition-all duration-200',
        status === 'success' && 'border-green-500/50 bg-green-500/10',
        status === 'error' && 'border-yellow-500/50 bg-yellow-500/10',
        className
      )}
    >
      {getIcon()}
      {showLabel && getButtonText() && (
        <span className="mr-2">{getButtonText()}</span>
      )}
    </Button>
  );
}