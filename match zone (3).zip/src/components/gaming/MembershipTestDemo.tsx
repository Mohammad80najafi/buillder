/**
 * Membership Test Demo
 * Shows the complete flow of lobby membership with team management
 */

import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { useLobby } from './LobbyContext';
import { useUser } from '../providers/UserProvider';
import { Clock, CheckCircle, AlertCircle, Users } from 'lucide-react';

const mockLobbyId = 'test-lobby-1';

export function MembershipTestDemo() {
  const { 
    getMembershipStatus, 
    requestMembership, 
    approveMembership, 
    rejectMembership,
    joinedLobbies,
    getLobbyTeams,
    getLobbyMembers,
    initializeLobbyTeams
  } = useLobby();
  
  const { currentUser } = useUser();
  const [simulateHost, setSimulateHost] = useState(false);
  
  const membershipStatus = getMembershipStatus(mockLobbyId);
  const isJoined = joinedLobbies.includes(mockLobbyId);
  const teams = getLobbyTeams(mockLobbyId);
  const members = getLobbyMembers(mockLobbyId);
  
  const previousMembersCount = useRef(members.length);
  
  // Debug: Log when members change
  useEffect(() => {
    console.log('🧪 Members state update:', {
      previousCount: previousMembersCount.current,
      newCount: members.length,
      members: members.map(m => ({ id: m.id, username: m.username })),
      timestamp: new Date().toISOString()
    });
    previousMembersCount.current = members.length;
  }, [members]);

  // Initialize teams if they don't exist
  const handleInitializeTeams = () => {
    initializeLobbyTeams(mockLobbyId, 2, 2);
  };

  const getStatusBadge = () => {
    switch (membershipStatus) {
      case 'pending':
        return <Badge variant="outline" className="text-yellow-400 border-yellow-400">در انتظار تایید</Badge>;
      case 'approved':
        return <Badge variant="outline" className="text-green-400 border-green-400">تایید شده</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="text-red-400 border-red-400">رد شده</Badge>;
      default:
        return <Badge variant="outline">بدون درخواست</Badge>;
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto p-6">
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-bold">تست سیستم عضویت و تیم‌بندی</h1>
        <p className="text-muted-foreground">
          این صفحه برای تست عملکرد درست سیستم عضویت و تیم‌بندی لابی است
        </p>
      </div>

      {/* User Info */}
      <Card>
        <CardHeader>
          <CardTitle>اطلاعات کاربر</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p><strong>شناسه:</strong> {currentUser?.id}</p>
              <p><strong>نام کاربری:</strong> {currentUser?.username}</p>
              <p><strong>سطح:</strong> {currentUser?.level}</p>
            </div>
            <div className="flex items-center gap-2">
              <label>شبیه‌سازی برگذارکننده:</label>
              <Button
                variant={simulateHost ? "default" : "outline"}
                size="sm"
                onClick={() => setSimulateHost(!simulateHost)}
              >
                {simulateHost ? 'فعال' : 'غیرفعال'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lobby Status */}
      <Card>
        <CardHeader>
          <CardTitle>وضعیت لابی تست</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-muted-foreground mb-1">وضعیت عضویت</p>
              {getStatusBadge()}
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">عضویت در لابی</p>
              <Badge variant={isJoined ? "default" : "outline"}>
                {isJoined ? 'عضو هستم' : 'عضو نیستم'}
              </Badge>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">تعداد تیم‌ها</p>
              <Badge variant="outline">{teams.length} تیم</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <Card>
        <CardHeader>
          <CardTitle>عملیات</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Member Actions */}
            <div className="space-y-2">
              <h4 className="font-medium text-sm">عملیات عضو:</h4>
              <Button
                onClick={() => requestMembership(mockLobbyId)}
                disabled={membershipStatus !== 'none' && membershipStatus !== 'rejected'}
                size="sm"
                className="w-full"
              >
                <Clock className="w-4 h-4 ml-1" />
                درخواست عضویت
              </Button>
            </div>

            {/* Host Actions */}
            <div className="space-y-2">
              <h4 className="font-medium text-sm">عملیات برگذارکننده:</h4>
              {simulateHost && (
                <>
                  <Button
                    onClick={() => {
                      console.log('🔍 Approving membership for user:', currentUser);
                      const userId = currentUser?.id || 'current-user-1'; // fallback
                      console.log('🔍 Using userId:', userId);
                      approveMembership(mockLobbyId, userId);
                    }}
                    disabled={membershipStatus !== 'pending'}
                    size="sm"
                    className="w-full"
                    variant="default"
                  >
                    <CheckCircle className="w-4 h-4 ml-1" />
                    تایید عضویت
                  </Button>
                  <Button
                    onClick={() => rejectMembership(mockLobbyId)}
                    disabled={membershipStatus !== 'pending'}
                    size="sm"
                    className="w-full"
                    variant="destructive"
                  >
                    <AlertCircle className="w-4 h-4 ml-1" />
                    رد عضویت
                  </Button>
                </>
              )}
            </div>

            {/* Team Actions */}
            <div className="space-y-2">
              <h4 className="font-medium text-sm">عملیات تیم:</h4>
              <Button
                onClick={handleInitializeTeams}
                size="sm"
                className="w-full"
                variant="outline"
              >
                <Users className="w-4 h-4 ml-1" />
                ایجاد تیم‌ها
              </Button>
            </div>

            {/* Test Actions */}
            <div className="space-y-2">
              <h4 className="font-medium text-sm">تست:</h4>
              <Button
                onClick={() => {
                  // Add a test user
                  const testUserId = `test-user-${Date.now()}`;
                  const testUsername = `تست یوزر ${Math.floor(Math.random() * 1000)}`;
                  
                  console.log('🧪 Creating test user:', { id: testUserId, username: testUsername });
                  
                  // Directly approve membership with custom username
                  approveMembership(mockLobbyId, testUserId, testUsername);
                }}
                size="sm"
                className="w-full"
                variant="outline"
              >
                اضافه کردن تست یوزر
              </Button>
              <Button
                onClick={() => window.location.reload()}
                size="sm"
                className="w-full"
                variant="outline"
              >
                ریست همه
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Members Display */}
      {members.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>اعضای لابی</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {members.map(member => (
                <div key={member.id} className="flex items-center justify-between p-3 border rounded-lg bg-surface-secondary">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-sm">
                      {member.username.charAt(0)}
                    </div>
                    <div>
                      <p className="font-medium">{member.username}</p>
                      <p className="text-sm text-muted-foreground">
                        {member.id === currentUser?.id ? 'من' : member.id}
                      </p>
                    </div>
                  </div>
                  <Badge variant={member.role === 'owner' ? 'default' : 'outline'}>
                    {member.role === 'owner' ? 'برگذارکننده' : 'عضو'}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Teams Display */}
      {teams.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>تیم‌های موجود</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {teams.map(team => (
                <div key={team.id} className="p-4 border rounded-lg bg-surface-secondary">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{team.name}</h4>
                    <Badge variant="outline">
                      {team.members.length}/{team.maxMembers}
                    </Badge>
                  </div>
                  {team.members.length > 0 ? (
                    <div className="space-y-1">
                      {team.members.map(memberId => {
                        const member = members.find(m => m.id === memberId);
                        return (
                          <div key={memberId} className="text-sm text-muted-foreground">
                            {member ? member.username : memberId} {memberId === currentUser?.id ? '(من)' : ''}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">تیم خالی</p>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Test Steps */}
      <Card>
        <CardHeader>
          <CardTitle>مراحل تست</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="space-y-1">
            <p className="font-medium">1. تست عضویت پایه:</p>
            <p className="text-muted-foreground">• درخواست عضویت ارسال کنید</p>
            <p className="text-muted-foreground">• حالت برگذارکننده را فعال کنید</p>
            <p className="text-muted-foreground">• عضویت را تایید کنید</p>
            <p className="text-muted-foreground">• باید وضعیت به "عضو هستم" تغییر کند</p>
          </div>
          
          <div className="space-y-1">
            <p className="font-medium">2. تست تیم‌بندی:</p>
            <p className="text-muted-foreground">• تیم‌ها را ایجاد کنید</p>
            <p className="text-muted-foreground">• پس از تایید عضویت، باید خودکار به تیمی اضافه شوید</p>
            <p className="text-muted-foreground">• نام شما باید در لیست اعضای لابی ظاهر شود</p>
          </div>
          
          <div className="space-y-1">
            <p className="font-medium">3. تست کامل سیستم:</p>
            <p className="text-muted-foreground">• وضعیت باید از "بدون درخواست" به "در انتظار تایید" تغییر کند</p>
            <p className="text-muted-foreground">• بعد از تایید، باید "عضو هستم" نشان دهد</p>
            <p className="text-muted-foreground">• نام در بخش "اعضای لابی" ظاهر شود</p>
            <p className="text-muted-foreground">• در صورت وجود تیم، خودکار به تیمی تخصیص یابد</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}