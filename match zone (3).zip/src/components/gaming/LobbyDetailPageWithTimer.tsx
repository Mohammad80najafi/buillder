import React, { useState, useEffect } from 'react';
import { useLobby } from './LobbyContext';
import { 
  ArrowRight, Users, Settings, MessageCircle, Trophy, Crown, Shield, 
  UserMinus, UserPlus, Copy, Share2, Flag, MoreVertical, Mic, MicOff,
  Volume2, VolumeX, Play, Pause, MapPin, Clock, Star, Heart, Send,
  Edit3, Save, X, Check, AlertTriangle, Gamepad2, Headphones, Timer,
  Bell
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Separator } from '../ui/separator';
import { Input } from '../ui/input';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../ui/alert-dialog';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/dialog';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { LobbyShareDialog } from './LobbyShareDialog';
import { LobbyChatSystem } from './LobbyChatSystem';

interface LobbyMember {
  id: string;
  username: string;
  avatar: string;
  role: 'owner' | 'admin' | 'member';
  isReady: boolean;
  isOnline: boolean;
  joinedAt: string;
  stats: {
    level: number;
    wins: number;
    kd: number;
  };
  voiceStatus: 'muted' | 'talking' | 'silent';
  team?: 1 | 2; // For CS2
}

interface ChatMessage {
  id: string;
  user: {
    username: string;
    avatar: string;
    role: 'owner' | 'admin' | 'member';
  };
  content: string;
  timestamp: string;
  type: 'message' | 'system' | 'voice';
}

interface LobbyDetailPageWithTimerProps {
  lobbyId: string;
  onBack: () => void;
}

type MembershipStatus = 'none' | 'pending' | 'approved' | 'rejected';

export function LobbyDetailPageWithTimer({ lobbyId, onBack }: LobbyDetailPageWithTimerProps) {
  // Lobby membership state
  const { getMembershipStatus, requestMembership, approveMembership, rejectMembership } = useLobby();
  const membershipStatus = getMembershipStatus(lobbyId);
  
  const [activeTab, setActiveTab] = useState('overview');
  const [isReady, setIsReady] = useState(false);
  const [micEnabled, setMicEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [newMessage, setNewMessage] = useState('');
  const [showReadyCheck, setShowReadyCheck] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [currentUser] = useState({ role: 'member' }); // Mock current user

  // Timer states
  const [lobbyTimeRemaining, setLobbyTimeRemaining] = useState(2 * 60 * 60); // 2 hours in seconds
  const [gameStartsIn, setGameStartsIn] = useState(0);
  const [lobbyStatus, setLobbyStatus] = useState<'waiting' | 'starting' | 'playing'>('waiting');

  // Mock lobby data - in real app, fetch based on lobbyId
  const lobby = {
    id: lobbyId,
    name: 'تیم Elite CS2',
    game: 'Counter-Strike 2',
    gameIcon: 'https://images.unsplash.com/photo-1555864326-5cf22ef123cf?w=100&h=100&fit=crop',
    description: 'لابی حرفه‌ای برای بازیکنان مجرب CS2. فقط رنک Supreme به بالا',
    owner: {
      id: '1',
      username: 'کاپیتان_پرو',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
    },
    settings: {
      maxMembers: 10,
      currentMembers: 6,
      isPrivate: false,
      requiresApproval: true,
      minLevel: 50,
      gameMode: '5v5 Competitive',
      map: 'Dust2',
      server: 'Iran',
      voiceChatEnabled: true,
      autoStart: true,
      duration: 2 * 60 * 60, // 2 hours
      scheduledStart: new Date(Date.now() + 10 * 60 * 1000) // 10 minutes from now
    },
    status: lobbyStatus,
    createdAt: '2 ساعت پیش',
    tags: ['رنک بالا', 'جدی', 'تیم ورک', 'مایک']
  };

  const members: LobbyMember[] = [
    {
      id: '1',
      username: 'کاپیتان_پرو',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      role: 'owner',
      isReady: true,
      isOnline: true,
      joinedAt: '2 ساعت پیش',
      stats: { level: 87, wins: 245, kd: 2.8 },
      voiceStatus: 'talking',
      team: 1
    },
    {
      id: '2',
      username: 'اسنایپر_پرو',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      role: 'member',
      isReady: true,
      isOnline: true,
      joinedAt: '1 ساعت پیش',
      stats: { level: 72, wins: 189, kd: 3.2 },
      voiceStatus: 'silent',
      team: 1
    },
    {
      id: '3',
      username: 'گیمر_فوری',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      role: 'member',
      isReady: false,
      isOnline: true,
      joinedAt: '30 دقیقه پیش',
      stats: { level: 65, wins: 156, kd: 2.1 },
      voiceStatus: 'muted',
      team: 1
    },
    {
      id: '4',
      username: 'تکتیک_استاد',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      role: 'member',
      isReady: true,
      isOnline: true,
      joinedAt: '45 دقیقه پیش',
      stats: { level: 78, wins: 201, kd: 2.4 },
      voiceStatus: 'talking',
      team: 2
    },
    {
      id: '5',
      username: 'شارپ_شوتر',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      role: 'member',
      isReady: true,
      isOnline: true,
      joinedAt: '25 دقیقه پیش',
      stats: { level: 69, wins: 178, kd: 2.6 },
      voiceStatus: 'silent',
      team: 2
    },
    {
      id: '6',
      username: 'استراتژی_کینگ',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      role: 'member',
      isReady: false,
      isOnline: true,
      joinedAt: '15 دقیقه پیش',
      stats: { level: 73, wins: 192, kd: 2.2 },
      voiceStatus: 'muted',
      team: 2
    }
  ];

  // Timer effects
  useEffect(() => {
    const timer = setInterval(() => {
      setLobbyTimeRemaining(prev => {
        if (prev <= 0) {
          setLobbyStatus('starting');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (lobbyTimeRemaining <= 300 && lobbyTimeRemaining > 0 && membershipStatus === 'approved') { // 5 minutes remaining
      setShowReadyCheck(true);
    }
  }, [lobbyTimeRemaining, membershipStatus]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const team1Members = members.filter(m => m.team === 1);
  const team2Members = members.filter(m => m.team === 2);
  const team1Full = team1Members.length >= 5;
  const team2Full = team2Members.length >= 5;

  const canStartLobby = currentUser.role === 'owner' || members.find(m => m.id === 'current-user')?.role === 'owner';

  const handleStartGame = () => {
    if (canStartLobby) {
      setLobbyStatus('starting');
      setGameStartsIn(10); // 10 second countdown
      
      const countdown = setInterval(() => {
        setGameStartsIn(prev => {
          if (prev <= 1) {
            setLobbyStatus('playing');
            clearInterval(countdown);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} className="mb-4">
          <ArrowRight className="h-4 w-4 ml-2" />
          بازگشت
        </Button>
        
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowShareDialog(true)}
          >
            <Share2 className="h-4 w-4 ml-2" />
            اشتراک‌گذاری
          </Button>
        </div>
      </div>

      {/* Ready Check Modal */}
      {showReadyCheck && (
        <Dialog open={showReadyCheck} onOpenChange={setShowReadyCheck}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-yellow-500" />
                آمادگی برای شروع
              </DialogTitle>
              <DialogDescription>
                ۵ دقیقه تا شروع لابی باقی مانده. آیا آماده هستید؟
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowReadyCheck(false)}>
                هنوز آماده نیستم
              </Button>
              <Button onClick={() => { setIsReady(true); setShowReadyCheck(false); }}>
                آماد�� هستم!
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Lobby Timer */}
      <Card className="border-yellow-500/20 bg-yellow-500/5">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Timer className="h-5 w-5 text-yellow-500" />
              <div>
                <h3 className="font-medium">زمان باقی‌مانده لابی</h3>
                <p className="text-sm text-text-secondary">
                  لابی {formatTime(lobbyTimeRemaining)} دیگر خودکار شروع می‌شود
                </p>
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-500">
                {formatTime(lobbyTimeRemaining)}
              </div>
              {lobbyTimeRemaining <= 300 && (
                <Badge variant="destructive" className="animate-pulse">
                  آماده باش!
                </Badge>
              )}
            </div>
          </div>
          
          <Progress 
            value={((lobby.settings.duration - lobbyTimeRemaining) / lobby.settings.duration) * 100} 
            className="mt-3"
          />
        </CardContent>
      </Card>

      {/* Lobby Header */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-4" dir="rtl">
              <div className="relative">
                <ImageWithFallback
                  src={lobby.gameIcon}
                  alt={lobby.game}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="absolute -bottom-1 -left-1 bg-background rounded-full p-1">
                  <Gamepad2 className="h-4 w-4 text-primary" />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center space-x-2" dir="rtl">
                  <h1 className="text-2xl font-bold">{lobby.name}</h1>
                  <Badge variant="outline">{lobby.game}</Badge>
                </div>
                
                <div className="flex items-center space-x-4 text-sm text-muted-foreground" dir="rtl">
                  <div className="flex items-center space-x-1" dir="rtl">
                    <Users className="h-4 w-4" />
                    <span>{lobby.settings.currentMembers}/{lobby.settings.maxMembers}</span>
                  </div>
                  <div className="flex items-center space-x-1" dir="rtl">
                    <Clock className="h-4 w-4" />
                    <span>{lobby.createdAt}</span>
                  </div>
                  <div className="flex items-center space-x-1" dir="rtl">
                    <MapPin className="h-4 w-4" />
                    <span>{lobby.settings.server}</span>
                  </div>
                </div>
                
                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {lobby.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            {/* Status */}
            <div className="text-center">
              <Badge 
                variant={lobbyStatus === 'playing' ? 'destructive' : lobbyStatus === 'starting' ? 'default' : 'outline'} 
                className="mb-2"
              >
                {lobbyStatus === 'waiting' ? 'در انتظار' : 
                 lobbyStatus === 'starting' ? 'در حال شروع' : 'در حال بازی'}
              </Badge>
              
              {lobbyStatus === 'waiting' && (
                <div className="text-sm text-muted-foreground">
                  آماده شدن: {members.filter(m => m.isReady).length}/{members.length}
                  {membershipStatus === 'approved' && (
                    <div className="text-xs text-green-500 mt-1">
                      شما عضو لابی هستید
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          <p className="text-muted-foreground mb-4">{lobby.description}</p>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 gap-2">
            {membershipStatus === 'none' ? (
              <Button onClick={() => requestMembership(lobbyId)} className="flex-1">
                <UserPlus className="h-4 w-4 ml-2" />
                درخواست پیوستن
              </Button>
            ) : membershipStatus === 'pending' ? (
              <div className="flex-1 space-y-2">
                <Button disabled className="w-full" variant="outline">
                  <Clock className="h-4 w-4 ml-2" />
                  در انتظار تایید برگذارکننده
                </Button>
                <p className="text-xs text-center text-muted-foreground">
                  درخواست شما ارسال شد و منتظر تایید میزبان است
                </p>
                {/* Mock approval button for demo - در واقعیت فقط میزبان دسترسی دارد */}
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => approveMembership(lobbyId)}
                    className="flex-1 text-xs"
                  >
                    [دمو] تایید
                  </Button>
                  <Button 
                    size="sm" 
                    variant="destructive" 
                    onClick={() => rejectMembership(lobbyId)}
                    className="flex-1 text-xs"
                  >
                    [دمو] رد
                  </Button>
                </div>
              </div>
            ) : membershipStatus === 'approved' ? (
              <>
                <Button 
                  onClick={() => setIsReady(!isReady)}
                  variant={isReady ? 'destructive' : 'default'}
                  className="flex-1"
                >
                  <Check className="h-4 w-4 ml-2" />
                  {isReady ? 'لغو آمادگی' : 'آماده هستم'}
                </Button>
                
                {currentUser.role === 'owner' && lobbyStatus === 'waiting' && (
                  <Button onClick={() => {}} variant="secondary">
                    <Play className="h-4 w-4 ml-2" />
                    شروع بازی
                  </Button>
                )}
              </>
            ) : membershipStatus === 'rejected' ? (
              <div className="flex-1 space-y-2">
                <Button disabled className="w-full" variant="destructive">
                  <X className="h-4 w-4 ml-2" />
                  درخواست رد شد
                </Button>
                <p className="text-xs text-center text-muted-foreground">
                  میزبان درخواست پیوستن شما را رد کرده است
                </p>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => requestMembership(lobbyId)}
                  className="w-full text-xs"
                >
                  درخواست مجدد
                </Button>
              </div>
            ) : null}
          </div>
        </CardContent>
      </Card>

      {/* Lobby Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">اطلاعات</TabsTrigger>
          <TabsTrigger value="teams">تیم‌ها</TabsTrigger>
          <TabsTrigger value="chat" className="relative">
            چت
            {membershipStatus === 'approved' && (
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-400 rounded-full" />
            )}
          </TabsTrigger>
          <TabsTrigger value="settings">تنظیمات</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>اطلاعات لابی</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-3 rounded-lg bg-slate-700/30">
                  <div className="text-lg font-semibold text-blue-400">{lobby.settings.currentMembers}</div>
                  <div className="text-xs text-slate-400">اعضا</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-slate-700/30">
                  <div className="text-lg font-semibold text-green-400">{lobby.settings.gameMode}</div>
                  <div className="text-xs text-slate-400">حالت بازی</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-slate-700/30">
                  <div className="text-lg font-semibold text-purple-400">{lobby.settings.map}</div>
                  <div className="text-xs text-slate-400">مپ</div>
                </div>
                <div className="text-center p-3 rounded-lg bg-slate-700/30">
                  <div className="text-lg font-semibold text-yellow-400">{lobby.settings.server}</div>
                  <div className="text-xs text-slate-400">سرور</div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="font-medium">اعضای لابی</h4>
                {members.map(member => (
                  <div key={member.id} className="flex items-center gap-3 p-2 rounded-lg bg-slate-700/20">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>{member.username[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{member.username}</span>
                        {member.role === 'owner' && <Crown className="w-3 h-3 text-yellow-400" />}
                        {member.role === 'admin' && <Shield className="w-3 h-3 text-blue-400" />}
                        {member.isOnline && <div className="w-2 h-2 bg-green-400 rounded-full" />}
                      </div>
                      <div className="text-xs text-slate-400">
                        سطح {member.stats.level} • {member.stats.wins} برد • K/D {member.stats.kd}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {member.isReady && <Badge variant="outline" className="text-xs">آماده</Badge>}
                      {member.voiceStatus === 'talking' && <Mic className="w-3 h-3 text-green-400" />}
                      {member.voiceStatus === 'muted' && <MicOff className="w-3 h-3 text-red-400" />}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Teams Tab */}
        <TabsContent value="teams" className="space-y-4">
          {/* CS2 Teams */}
          {lobby.game === 'Counter-Strike 2' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Team 1 */}
          <Card className="border-blue-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-blue-500">
                <div className="w-3 h-3 bg-blue-500 rounded-full" />
                تیم ۱ ({team1Members.length}/5)
                {team1Full && <Badge variant="outline" className="text-blue-500">پرشد</Badge>}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {team1Members.map(member => (
                <div key={member.id} className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={member.avatar} />
                    <AvatarFallback>{member.username[0]}</AvatarFallback>
                  </Avatar>
                  <span className="flex-1">{member.username}</span>
                  {member.isReady && <Badge variant="outline" className="text-xs">آماده</Badge>}
                </div>
              ))}
              {!team1Full && (
                <div className="flex items-center gap-3 text-muted-foreground">
                  <UserPlus className="h-8 w-8 p-2 border-2 border-dashed rounded-full" />
                  <span>اسلات خالی</span>
                  {membershipStatus === 'approved' ? (
                    <Button size="sm" variant="outline" className="mr-auto">
                      پیوستن به تیم ۱
                    </Button>
                  ) : membershipStatus === 'pending' ? (
                    <Button size="sm" variant="outline" className="mr-auto" disabled>
                      <Clock className="h-3 w-3 ml-1" />
                      در انتظار تایید
                    </Button>
                  ) : (
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="mr-auto" 
                      onClick={() => setMembershipStatus('pending')}
                    >
                      درخواست پیوستن
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Team 2 */}
          <Card className="border-red-500/20">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-red-500">
                <div className="w-3 h-3 bg-red-500 rounded-full" />
                تیم ۲ ({team2Members.length}/5)
                {team2Full && <Badge variant="outline" className="text-red-500">پرشد</Badge>}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {team2Members.map(member => (
                <div key={member.id} className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={member.avatar} />
                    <AvatarFallback>{member.username[0]}</AvatarFallback>
                  </Avatar>
                  <span className="flex-1">{member.username}</span>
                  {member.isReady && <Badge variant="outline" className="text-xs">آماده</Badge>}
                </div>
              ))}
              {!team2Full && (
                <div className="flex items-center gap-3 text-muted-foreground">
                  <UserPlus className="h-8 w-8 p-2 border-2 border-dashed rounded-full" />
                  <span>اسلات خالی</span>
                  {membershipStatus === 'approved' ? (
                    <Button size="sm" variant="outline" className="mr-auto">
                      پیوستن به تیم ۲
                    </Button>
                  ) : membershipStatus === 'pending' ? (
                    <Button size="sm" variant="outline" className="mr-auto" disabled>
                      <Clock className="h-3 w-3 ml-1" />
                      در انتظار تایید
                    </Button>
                  ) : (
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="mr-auto" 
                      onClick={() => setMembershipStatus('pending')}
                    >
                      درخواست پیوستن
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
          )}
          
          {/* Non-team based games */}
          {lobby.game !== 'Counter-Strike 2' && (
            <Card>
              <CardHeader>
                <CardTitle>اعضای لابی</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {members.map(member => (
                    <div key={member.id} className="flex items-center gap-3 p-3 rounded-lg bg-slate-700/20">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={member.avatar} />
                        <AvatarFallback>{member.username[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{member.username}</span>
                          {member.role === 'owner' && <Crown className="w-4 h-4 text-yellow-400" />}
                          {member.role === 'admin' && <Shield className="w-4 h-4 text-blue-400" />}
                          {member.isOnline && <div className="w-2 h-2 bg-green-400 rounded-full" />}
                        </div>
                        <div className="text-sm text-slate-400">
                          سطح {member.stats.level} • {member.stats.wins} برد • K/D {member.stats.kd}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {member.isReady && <Badge variant="outline">آماده</Badge>}
                        {member.voiceStatus === 'talking' && <Mic className="w-4 h-4 text-green-400" />}
                        {member.voiceStatus === 'muted' && <MicOff className="w-4 h-4 text-red-400" />}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Chat Tab */}
        <TabsContent value="chat" className="space-y-4">
          <div className="h-96">
            <LobbyChatSystem
              lobbyId={lobbyId}
              currentUser={{
                id: 'current-user',
                username: 'کاربر فعلی',
                avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face',
                role: 'member'
              }}
              membershipStatus={membershipStatus}
              members={members.map(member => ({
                id: member.id,
                username: member.username,
                avatar: member.avatar,
                role: member.role,
                isOnline: member.isOnline
              }))}
              onSendMessage={(message) => {
                console.log('Message sent:', message);
                // In real app, send to server
              }}
            />
          </div>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات لابی</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-medium">تنظیمات بازی</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-slate-400">حداکثر اعضا:</span>
                      <span>{lobby.settings.maxMembers}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">حد اقل سطح:</span>
                      <span>{lobby.settings.minLevel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">نیاز به تایید:</span>
                      <span>{lobby.settings.requiresApproval ? 'بله' : 'خیر'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">شروع خودکار:</span>
                      <span>{lobby.settings.autoStart ? 'فعال' : 'غیرفعال'}</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-medium">تنظیمات صوتی</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-2 rounded-lg bg-slate-700/20">
                      <span className="text-sm">چت صوتی:</span>
                      <Badge variant={lobby.settings.voiceChatEnabled ? "default" : "secondary"}>
                        {lobby.settings.voiceChatEnabled ? 'فعال' : 'غیرفعال'}
                      </Badge>
                    </div>
                    
                    {membershipStatus === 'approved' && (
                      <div className="space-y-2 pt-2 border-t border-slate-700">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">میکروفن:</span>
                          <Button
                            variant={micEnabled ? "default" : "secondary"}
                            size="sm"
                            onClick={() => setMicEnabled(!micEnabled)}
                          >
                            {micEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                          </Button>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-sm">بلندگو:</span>
                          <Button
                            variant={audioEnabled ? "default" : "secondary"}
                            size="sm"
                            onClick={() => setAudioEnabled(!audioEnabled)}
                          >
                            {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              {/* Action buttons for lobby owner */}
              {currentUser.role === 'owner' && (
                <div className="pt-4 border-t border-slate-700">
                  <div className="space-y-3">
                    <h4 className="font-medium text-red-400">عملیات میزبان</h4>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit3 className="w-4 h-4 ml-2" />
                        ویرایش تنظیمات
                      </Button>
                      <Button variant="destructive" size="sm">
                        <X className="w-4 h-4 ml-2" />
                        حذف لابی
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Game Starting Countdown */}
      {lobbyStatus === 'starting' && gameStartsIn > 0 && (
        <Card className="border-green-500/20 bg-green-500/5">
          <CardContent className="p-6 text-center">
            <div className="space-y-4">
              <div className="text-3xl font-bold text-green-500">
                {gameStartsIn}
              </div>
              <p className="text-lg">بازی در حال شروع...</p>
              <div className="animate-spin mx-auto w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Share Dialog */}
      <LobbyShareDialog
        open={showShareDialog}
        onOpenChange={setShowShareDialog}
        lobbyId={lobbyId}
        lobbyName={lobby.name}
        gameTitle={lobby.game}
        currentPlayers={lobby.settings.currentMembers}
        maxPlayers={lobby.settings.maxMembers}
      />
    </div>
  );
}