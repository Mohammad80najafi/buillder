import React, { useState } from 'react';
import { 
  ArrowRight, Users, Settings, MessageCircle, Trophy, Crown, Shield, 
  UserMinus, UserPlus, Copy, Share2, Flag, MoreVertical, Mic, MicOff,
  Volume2, VolumeX, Play, Pause, MapPin, Clock, Star, Heart, Send,
  Edit3, Save, X, Check, AlertTriangle, Gamepad2, Headphones
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Separator } from '../ui/separator';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Switch } from '../ui/switch';
import { Slider } from '../ui/slider';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../ui/alert-dialog';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { TeamManagement } from './TeamManagement';
import { useLobby } from './LobbyContext';
import { useUser } from '../providers/UserProvider';

interface LobbyMember {
  id: string;
  username: string;
  avatar: string;
  role: 'owner' | 'admin' | 'member';
  isReady: boolean;
  isOnline: boolean;
  joinedAt: string;
  stats: {
    level: number;
    wins: number;
    kd: number;
  };
  voiceStatus: 'muted' | 'talking' | 'silent';
}

interface ChatMessage {
  id: string;
  user: {
    username: string;
    avatar: string;
    role: 'owner' | 'admin' | 'member';
  };
  content: string;
  timestamp: string;
  type: 'message' | 'system' | 'voice';
}

interface LobbyDetailPageProps {
  lobbyId: string;
  onBack: () => void;
}

export function LobbyDetailPage({ lobbyId, onBack }: LobbyDetailPageProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isJoined, setIsJoined] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const [micEnabled, setMicEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [newMessage, setNewMessage] = useState('');
  const [isEditingLobby, setIsEditingLobby] = useState(false);
  
  // Lobby context and user
  const { joinedLobbies, getMembershipStatus, getLobbyMembers, addMemberToLobby } = useLobby();
  const { currentUser } = useUser();
  
  // Check if user is part of this lobby
  const membershipStatus = getMembershipStatus(lobbyId);
  const isLobbyMember = joinedLobbies.includes(lobbyId) || membershipStatus === 'approved';
  const isOwner = lobby.owner.id === currentUser?.id;

  // Mock lobby data - in real app, fetch based on lobbyId
  const lobby = {
    id: lobbyId,
    name: 'تیم Elite PUBG',
    game: 'PUBG Mobile',
    gameIcon: 'https://images.unsplash.com/photo-1555864326-5cf22ef123cf?w=100&h=100&fit=crop',
    description: 'لابی حرفه‌ای برای بازیکنان مجرب PUBG Mobile. فقط رنک دایموند به بالا',
    owner: {
      id: currentUser?.id || 'current-user-1',
      username: currentUser?.username || 'کاپیتان_پرو',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
    },
    settings: {
      maxMembers: 4,
      currentMembers: 3,
      isPrivate: false,
      requiresApproval: true,
      minLevel: 50,
      gameMode: 'Squad',
      map: 'Erangel',
      server: 'Asia',
      voiceChatEnabled: true,
      autoStart: false
    },
    status: 'waiting' as 'waiting' | 'playing' | 'finished',
    createdAt: '2 ساعت پیش',
    tags: ['رنک بالا', 'جدی', 'تیم ورک', 'مایک']
  };

  // Get real members from context
  const realMembers = getLobbyMembers(lobbyId);
  
  // Debug: Log current state
  console.log('🔍 LobbyDetailPage Debug:', {
    lobbyId,
    currentUserId: currentUser?.id,
    membershipStatus: getMembershipStatus(lobbyId),
    realMembersCount: realMembers.length,
    realMembers: realMembers.map(m => ({ id: m.id, username: m.username })),
    joinedLobbies: joinedLobbies.includes(lobbyId)
  });
  
  // Check if current user is a member (from membership system)
  const membershipStatus = getMembershipStatus(lobbyId);
  const isCurrentUserMember = membershipStatus === 'approved' || joinedLobbies.includes(lobbyId);
  
  // Effect to add current user when they become a member
  React.useEffect(() => {
    if (isCurrentUserMember && currentUser && !realMembers.some(m => m.id === currentUser.id)) {
      console.log('🔄 Auto-adding current user to lobby members');
      const currentUserMember = {
        id: currentUser.id,
        username: currentUser.username,
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
        role: 'member' as const,
        joinedAt: new Date()
      };
      addMemberToLobby(lobbyId, currentUserMember);
    }
  }, [isCurrentUserMember, currentUser?.id, lobbyId, realMembers.length]);
  
  // Mock members (for demo purposes) - don't include current user if they're a real member
  const mockMembers: LobbyMember[] = [];
  
  // Add owner (always mock for demo)
  if (!isCurrentUserMember) {
    mockMembers.push({
      id: currentUser?.id || 'current-user-1',
      username: currentUser?.username || 'کاپیتان_پرو',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      role: 'owner',
      isReady: true,
      isOnline: true,
      joinedAt: '2 ساعت پیش',
      stats: { level: 87, wins: 245, kd: 2.8 },
      voiceStatus: 'talking'
    });
  }
  
  // Add other mock members
  mockMembers.push(
    {
      id: '2',
      username: 'اسنایپر_پرو',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      role: 'member',
      isReady: true,
      isOnline: true,
      joinedAt: '1 ساعت پیش',
      stats: { level: 72, wins: 189, kd: 3.2 },
      voiceStatus: 'silent'
    },
    {
      id: '3',
      username: 'گیمر_فوری',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      role: 'member',
      isReady: false,
      isOnline: true,
      joinedAt: '30 دقیقه پیش',
      stats: { level: 65, wins: 156, kd: 2.1 },
      voiceStatus: 'muted'
    }
  );
  


  // Combine real members with mock members and remove duplicates
  const members: LobbyMember[] = [];
  
  // Add real members first (they have priority)
  realMembers.forEach(realMember => {
    const displayMember: LobbyMember = {
      id: realMember.id,
      username: realMember.username,
      avatar: realMember.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      role: realMember.role,
      isReady: realMember.id === currentUser?.id, // Current user is ready
      isOnline: true,
      joinedAt: realMember.id === currentUser?.id ? 'همین الان' : 'همین الان',
      stats: { level: 50, wins: 25, kd: 1.5 },
      voiceStatus: 'silent'
    };
    members.push(displayMember);
  });
  
  // Add mock members that aren't already in real members
  mockMembers.forEach(mockMember => {
    if (!realMembers.some(m => m.id === mockMember.id)) {
      members.push(mockMember);
    }
  });

  const chatMessages: ChatMessage[] = [
    {
      id: '1',
      user: {
        username: 'کاپیتان_پرو',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
        role: 'owner'
      },
      content: 'سلام بچه‌ها، آماده برای بازی؟',
      timestamp: '10:30',
      type: 'message'
    },
    {
      id: '2',
      user: {
        username: 'اسنایپر_پرو',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
        role: 'member'
      },
      content: 'آماده هستم کاپیتان! 🎮',
      timestamp: '10:32',
      type: 'message'
    },
    {
      id: '3',
      user: {
        username: 'System',
        avatar: '',
        role: 'member'
      },
      content: 'گیمر_فوری به لابی پیوست',
      timestamp: '10:35',
      type: 'system'
    }
  ];

  const getRoleIcon = (role: 'owner' | 'admin' | 'member') => {
    switch (role) {
      case 'owner':
        return Crown;
      case 'admin':
        return Shield;
      default:
        return null;
    }
  };

  const getRoleColor = (role: 'owner' | 'admin' | 'member') => {
    switch (role) {
      case 'owner':
        return 'text-gaming-warning';
      case 'admin':
        return 'text-gaming-primary';
      default:
        return 'text-foreground';
    }
  };

  const getVoiceIcon = (status: 'muted' | 'talking' | 'silent') => {
    switch (status) {
      case 'muted':
        return MicOff;
      case 'talking':
        return Mic;
      default:
        return Mic;
    }
  };

  const handleJoinLobby = () => {
    setIsJoined(true);
    
    // Add current user to lobby members and approve membership automatically
    if (currentUser) {
      // Add to members if not already added
      if (!realMembers.some(m => m.id === currentUser.id)) {
        const newMember = {
          id: currentUser.id,
          username: currentUser.username,
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
          role: 'member' as const,
          joinedAt: new Date()
        };
        addMemberToLobby(lobbyId, newMember);
      }
    }
  };

  const handleLeaveLobby = () => {
    setIsJoined(false);
    setIsReady(false);
  };

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // Add message logic here
      setNewMessage('');
    }
  };

  const handleReadyToggle = () => {
    setIsReady(!isReady);
  };

  const renderMemberCard = (member: LobbyMember) => {
    const RoleIcon = getRoleIcon(member.role);
    const VoiceIcon = getVoiceIcon(member.voiceStatus);
    
    return (
      <Card key={member.id} className="relative">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3" dir="rtl">
            <div className="relative">
              <Avatar className="h-12 w-12">
                <AvatarImage src={member.avatar} alt={member.username} />
                <AvatarFallback>{member.username[0]}</AvatarFallback>
              </Avatar>
              
              {/* Online indicator */}
              <div className={`absolute bottom-0 left-0 h-3 w-3 rounded-full border-2 border-background ${
                member.isOnline ? 'bg-gaming-success' : 'bg-muted-foreground'
              }`} />
              
              {/* Voice status */}
              {lobby.settings.voiceChatEnabled && (
                <div className={`absolute -top-1 -right-1 h-6 w-6 rounded-full flex items-center justify-center ${
                  member.voiceStatus === 'talking' ? 'bg-gaming-success animate-pulse' : 
                  member.voiceStatus === 'muted' ? 'bg-gaming-error' : 'bg-muted'
                }`}>
                  <VoiceIcon className="h-3 w-3 text-white" />
                </div>
              )}
            </div>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2" dir="rtl">
                <h4 className={`font-medium ${getRoleColor(member.role)}`}>
                  {member.username}
                </h4>
                
                {RoleIcon && (
                  <RoleIcon className={`h-4 w-4 ${getRoleColor(member.role)}`} />
                )}
                
                {member.isReady && (
                  <Badge variant="outline" className="bg-gaming-success/20 text-gaming-success border-gaming-success/50">
                    آماده
                  </Badge>
                )}
              </div>
              
              <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-1" dir="rtl">
                <span>سطح {member.stats.level}</span>
                <span>•</span>
                <span>{member.stats.wins} برد</span>
                <span>•</span>
                <span>K/D: {member.stats.kd}</span>
              </div>
              
              <p className="text-xs text-muted-foreground mt-1">
                پیوست {member.joinedAt}
              </p>
            </div>
            
            <div className="flex flex-col space-y-1">
              {member.role !== 'owner' && isJoined && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>مشاهده پروفایل</DropdownMenuItem>
                    <DropdownMenuItem>پیام خصوصی</DropdownMenuItem>
                    <DropdownMenuItem>دعوت به دوستی</DropdownMenuItem>
                    <Separator />
                    <DropdownMenuItem className="text-destructive">
                      حذف از لابی
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderChatMessage = (message: ChatMessage) => {
    if (message.type === 'system') {
      return (
        <div key={message.id} className="text-center">
          <span className="text-sm text-muted-foreground bg-muted px-3 py-1 rounded-full">
            {message.content}
          </span>
        </div>
      );
    }

    return (
      <div key={message.id} className="flex items-start space-x-3" dir="rtl">
        <Avatar className="h-8 w-8">
          <AvatarImage src={message.user.avatar} alt={message.user.username} />
          <AvatarFallback>{message.user.username[0]}</AvatarFallback>
        </Avatar>
        
        <div className="flex-1">
          <div className="flex items-center space-x-2" dir="rtl">
            <span className={`text-sm font-medium ${getRoleColor(message.user.role)}`}>
              {message.user.username}
            </span>
            <span className="text-xs text-muted-foreground">{message.timestamp}</span>
          </div>
          <p className="text-sm mt-1">{message.content}</p>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" onClick={onBack} className="mb-4">
          <ArrowRight className="h-4 w-4 ml-2" />
          بازگشت
        </Button>
        
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Share2 className="h-4 w-4 ml-2" />
            اشتراک‌گذاری
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Copy className="h-4 w-4 ml-2" />
                کپی لینک
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Flag className="h-4 w-4 ml-2" />
                گزارش لابی
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Lobby Header */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-4" dir="rtl">
              <div className="relative">
                <ImageWithFallback
                  src={lobby.gameIcon}
                  alt={lobby.game}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="absolute -bottom-1 -left-1 bg-background rounded-full p-1">
                  <Gamepad2 className="h-4 w-4 text-primary" />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center space-x-2" dir="rtl">
                  <h1 className="text-2xl font-bold">{lobby.name}</h1>
                  <Badge variant="outline">{lobby.game}</Badge>
                </div>
                
                <div className="flex items-center space-x-4 text-sm text-muted-foreground" dir="rtl">
                  <div className="flex items-center space-x-1" dir="rtl">
                    <Users className="h-4 w-4" />
                    <span>{lobby.settings.currentMembers}/{lobby.settings.maxMembers}</span>
                  </div>
                  <div className="flex items-center space-x-1" dir="rtl">
                    <Clock className="h-4 w-4" />
                    <span>{lobby.createdAt}</span>
                  </div>
                  <div className="flex items-center space-x-1" dir="rtl">
                    <MapPin className="h-4 w-4" />
                    <span>{lobby.settings.server}</span>
                  </div>
                </div>
                
                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {lobby.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            {/* Status */}
            <div className="text-center">
              <Badge 
                variant={lobby.status === 'playing' ? 'destructive' : 'default'} 
                className="mb-2"
              >
                {lobby.status === 'waiting' ? 'در انتظار' : 
                 lobby.status === 'playing' ? 'در حال بازی' : 'تمام شده'}
              </Badge>
              
              {lobby.status === 'waiting' && (
                <div className="text-sm text-muted-foreground">
                  آماده شدن: {members.filter(m => m.isReady).length}/{members.length}
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          <p className="text-muted-foreground mb-4">{lobby.description}</p>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 mb-4">
            {!isJoined ? (
              <Button onClick={handleJoinLobby} className="flex-1">
                <UserPlus className="h-4 w-4 ml-2" />
                پیوستن به لابی
              </Button>
            ) : (
              <>
                <Button 
                  onClick={handleReadyToggle}
                  variant={isReady ? 'destructive' : 'default'}
                  className="flex-1"
                >
                  <Check className="h-4 w-4 ml-2" />
                  {isReady ? 'لغو آمادگی' : 'آماده هستم'}
                </Button>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline">
                      <UserMinus className="h-4 w-4 ml-2" />
                      ترک لابی
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>ترک لابی</AlertDialogTitle>
                      <AlertDialogDescription>
                        آیا مطمئن هستید که می‌خواهید از این لابی خارج شوید؟
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>انصراف</AlertDialogCancel>
                      <AlertDialogAction onClick={handleLeaveLobby}>
                        ترک لابی
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </>
            )}
          </div>

          {/* Voice Controls (if joined) */}
          {isJoined && lobby.settings.voiceChatEnabled && (
            <div className="flex items-center justify-center space-x-4 p-3 bg-card rounded-lg">
              <Button
                variant={micEnabled ? "default" : "destructive"}
                size="sm"
                onClick={() => setMicEnabled(!micEnabled)}
              >
                {micEnabled ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
              </Button>
              
              <Button
                variant={audioEnabled ? "default" : "destructive"}
                size="sm"
                onClick={() => setAudioEnabled(!audioEnabled)}
              >
                {audioEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
              </Button>
              
              <span className="text-sm text-muted-foreground">
                {micEnabled ? 'میکروفون روشن' : 'میکروفون خاموش'} • {audioEnabled ? 'صدا روشن' : 'صدا خاموش'}
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">اعضا</TabsTrigger>
          <TabsTrigger value="teams">تیم‌ها</TabsTrigger>
          <TabsTrigger value="chat">چت</TabsTrigger>
          <TabsTrigger value="settings">تنظیمات</TabsTrigger>
          <TabsTrigger value="stats">آمار</TabsTrigger>
        </TabsList>

        {/* Members Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4">
            {members.map(renderMemberCard)}
            
            {/* Empty slots */}
            {Array.from({ length: lobby.settings.maxMembers - lobby.settings.currentMembers }).map((_, index) => (
              <Card key={`empty-${index}`} className="border-dashed">
                <CardContent className="p-4 text-center">
                  <div className="flex flex-col items-center space-y-2 text-muted-foreground">
                    <UserPlus className="h-8 w-8" />
                    <span>اسلات خالی</span>
                    {lobby.settings.requiresApproval && (
                      <Badge variant="outline" className="text-xs">
                        نیاز به تایید
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Teams Tab */}
        <TabsContent value="teams" className="space-y-4">
          <TeamManagement
            lobbyId={lobbyId}
            members={members.map(member => ({
              ...member,
              role: member.role as 'owner' | 'admin' | 'member'
            }))}
            isOwner={isOwner}
          />
        </TabsContent>

        {/* Chat Tab */}
        <TabsContent value="chat" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageCircle className="h-5 w-5" />
                <span>چت لابی</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Chat Messages */}
              <div className="space-y-4 max-h-64 overflow-y-auto mb-4">
                {chatMessages.map(renderChatMessage)}
              </div>
              
              {/* Message Input */}
              {isJoined && (
                <div className="flex space-x-2" dir="rtl">
                  <Input
                    placeholder="پیام خود را بنویسید..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="text-right"
                    dir="rtl"
                  />
                  <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              )}
              
              {!isJoined && (
                <div className="text-center py-4 text-muted-foreground">
                  برای چت کردن ابتدا به لابی بپیوندید
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات لابی</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>حد اکثر اعضا</Label>
                  <p className="text-sm text-muted-foreground">{lobby.settings.maxMembers} نفر</p>
                </div>
                
                <div>
                  <Label>حالت بازی</Label>
                  <p className="text-sm text-muted-foreground">{lobby.settings.gameMode}</p>
                </div>
                
                <div>
                  <Label>نقشه</Label>
                  <p className="text-sm text-muted-foreground">{lobby.settings.map}</p>
                </div>
                
                <div>
                  <Label>سرور</Label>
                  <p className="text-sm text-muted-foreground">{lobby.settings.server}</p>
                </div>
                
                <div>
                  <Label>حداقل سطح</Label>
                  <p className="text-sm text-muted-foreground">سطح {lobby.settings.minLevel}</p>
                </div>
                
                <div>
                  <Label>نوع لابی</Label>
                  <p className="text-sm text-muted-foreground">
                    {lobby.settings.isPrivate ? 'خصوصی' : 'عمومی'}
                  </p>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>چت صوتی</Label>
                    <p className="text-sm text-muted-foreground">فعال‌سازی ارتباط صوتی</p>
                  </div>
                  <Badge variant={lobby.settings.voiceChatEnabled ? "default" : "secondary"}>
                    {lobby.settings.voiceChatEnabled ? 'فعال' : 'غیرفعال'}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>نیاز به تایید</Label>
                    <p className="text-sm text-muted-foreground">تایید دستی اعضای جدید</p>
                  </div>
                  <Badge variant={lobby.settings.requiresApproval ? "default" : "secondary"}>
                    {lobby.settings.requiresApproval ? 'فعال' : 'غیرفعال'}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>شروع خودکار</Label>
                    <p className="text-sm text-muted-foreground">شروع بازی وقتی همه آماده شدند</p>
                  </div>
                  <Badge variant={lobby.settings.autoStart ? "default" : "secondary"}>
                    {lobby.settings.autoStart ? 'فعال' : 'غیرفعال'}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Stats Tab */}
        <TabsContent value="stats" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary">
                  {lobby.settings.currentMembers}
                </div>
                <div className="text-sm text-muted-foreground">اعضای حاضر</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-accent">
                  {members.filter(m => m.isReady).length}
                </div>
                <div className="text-sm text-muted-foreground">آماده</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-gaming-warning">
                  {Math.round(members.reduce((acc, m) => acc + m.stats.level, 0) / members.length)}
                </div>
                <div className="text-sm text-muted-foreground">میانگین سطح</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-gaming-error">
                  {(members.reduce((acc, m) => acc + m.stats.kd, 0) / members.length).toFixed(1)}
                </div>
                <div className="text-sm text-muted-foreground">میانگین K/D</div>
              </CardContent>
            </Card>
          </div>
          
          {/* Member Stats */}
          <Card>
            <CardHeader>
              <CardTitle>آمار اعضا</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {members.map(member => (
                  <div key={member.id} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3" dir="rtl">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={member.avatar} alt={member.username} />
                        <AvatarFallback>{member.username[0]}</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">{member.username}</span>
                    </div>
                    
                    <div className="flex items-center space-x-4 text-sm" dir="rtl">
                      <div className="text-center">
                        <div className="font-medium">{member.stats.level}</div>
                        <div className="text-xs text-muted-foreground">سطح</div>
                      </div>
                      <div className="text-center">
                        <div className="font-medium">{member.stats.wins}</div>
                        <div className="text-xs text-muted-foreground">برد</div>
                      </div>
                      <div className="text-center">
                        <div className="font-medium">{member.stats.kd}</div>
                        <div className="text-xs text-muted-foreground">K/D</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}