/**
 * Game Launch Notification Component
 * Shows status and instructions for game launches
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/mz-button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle, AlertTriangle, XCircle, Copy, ExternalLink, 
  Download, Clock, Gamepad2, Smartphone, Monitor, Info
} from 'lucide-react';
import { LaunchResult } from '../../utils/gameLauncher';

interface GameLaunchNotificationProps {
  result: LaunchResult | null;
  gameIcon?: string;
  gameName?: string;
  onDismiss?: () => void;
  onRetry?: () => void;
  autoHide?: boolean;
  autoHideDelay?: number;
}

export function GameLaunchNotification({
  result,
  gameIcon,
  gameName,
  onDismiss,
  onRetry,
  autoHide = true,
  autoHideDelay = 5000
}: GameLaunchNotificationProps) {
  const [progress, setProgress] = useState(0);
  const [showDetails, setShowDetails] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const onDismissRef = useRef(onDismiss);

  // Update ref when onDismiss changes
  useEffect(() => {
    onDismissRef.current = onDismiss;
  }, [onDismiss]);

  // Reset progress when result changes
  useEffect(() => {
    setProgress(0);
  }, [result]);

  useEffect(() => {
    if (result && autoHide && result.success) {
      const updateProgress = () => {
        setProgress(prev => {
          const nextProgress = prev + (100 / (autoHideDelay / 100));
          if (nextProgress >= 100) {
            if (timerRef.current) {
              clearInterval(timerRef.current);
              timerRef.current = null;
            }
            // Use setTimeout to avoid state update during render
            setTimeout(() => {
              onDismissRef.current?.();
            }, 0);
            return 100;
          }
          return nextProgress;
        });
      };

      timerRef.current = setInterval(updateProgress, 100);
      
      return () => {
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
      };
    }
  }, [result, autoHide, autoHideDelay]);

  if (!result) return null;

  const getIcon = () => {
    switch (result.method) {
      case 'direct':
        return <CheckCircle className="h-6 w-6 text-state-success" />;
      case 'store_redirect':
        return <Download className="h-6 w-6 text-state-info" />;
      case 'manual_copy':
        return <Copy className="h-6 w-6 text-state-warning" />;
      case 'failed':
        return <XCircle className="h-6 w-6 text-state-danger" />;
      default:
        return <Info className="h-6 w-6 text-text-secondary" />;
    }
  };

  const getTitle = () => {
    switch (result.method) {
      case 'direct':
        return 'بازی راه‌اندازی شد';
      case 'store_redirect':
        return 'هدایت به فروشگاه';
      case 'manual_copy':
        return 'اطلاعات کپی شد';
      case 'failed':
        return 'خطا در راه‌اندازی';
      default:
        return 'اطلاعیه بازی';
    }
  };

  const copyToClipboard = useCallback((text: string) => {
    navigator.clipboard.writeText(text);
    // Show toast
  }, []);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 50, scale: 0.95 }}
        className="fixed bottom-4 right-4 z-50 max-w-sm"
      >
        <Card className="shadow-2xl border-border-primary/50 overflow-hidden">
          {/* Progress bar for auto-hide */}
          {autoHide && result.success && (
            <div className="absolute top-0 left-0 right-0 h-1 bg-surface-secondary">
              <motion.div
                className="h-full bg-gradient-to-r from-brand-primary to-brand-secondary"
                initial={{ width: '0%' }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.1 }}
              />
            </div>
          )}

          <CardHeader className="pb-3">
            <CardTitle className="flex items-center justify-between text-base">
              <div className="flex items-center gap-3">
                {gameIcon && <span className="text-xl">{gameIcon}</span>}
                {getIcon()}
                <span>{getTitle()}</span>
              </div>
              
              {onDismiss && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onDismiss}
                  className="h-6 w-6 p-0"
                >
                  ✕
                </Button>
              )}
            </CardTitle>
          </CardHeader>

          <CardContent className="pt-0">
            <div className="space-y-3">
              {/* Game name */}
              {gameName && (
                <div className="flex items-center gap-2 text-sm text-text-secondary">
                  <Gamepad2 className="h-4 w-4" />
                  {gameName}
                </div>
              )}

              {/* Main message */}
              <p className="text-sm">{result.message}</p>

              {/* Data display */}
              {result.data && (
                <div className="space-y-2">
                  {result.data.roomCode && (
                    <div className="flex items-center justify-between p-2 bg-surface-secondary rounded">
                      <div>
                        <div className="text-xs text-text-secondary">کد روم</div>
                        <div className="font-mono text-sm">{result.data.roomCode}</div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(result.data!.roomCode!)}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  )}

                  {result.data.password && (
                    <div className="flex items-center justify-between p-2 bg-surface-secondary rounded">
                      <div>
                        <div className="text-xs text-text-secondary">رمز عبور</div>
                        <div className="font-mono text-sm">{result.data.password}</div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(result.data!.password!)}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  )}

                  {result.data.serverInfo && (
                    <div className="flex items-center justify-between p-2 bg-surface-secondary rounded">
                      <div>
                        <div className="text-xs text-text-secondary">سرور</div>
                        <div className="font-mono text-sm">{result.data.serverInfo}</div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(result.data!.serverInfo!)}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                </div>
              )}

              {/* Action buttons */}
              <div className="flex gap-2 pt-2">
                {result.method === 'failed' && onRetry && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={onRetry}
                    className="flex-1"
                  >
                    تلاش مجدد
                  </Button>
                )}

                {(result.method === 'store_redirect' || result.method === 'manual_copy') && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowDetails(!showDetails)}
                    className="flex-1"
                  >
                    <Info className="h-4 w-4" />
                    راهنما
                  </Button>
                )}
              </div>

              {/* Detailed instructions */}
              <AnimatePresence>
                {showDetails && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="border-t border-border-secondary pt-3 mt-3"
                  >
                    <div className="text-xs text-text-secondary space-y-2">
                      {result.method === 'store_redirect' && (
                        <div>
                          <p className="font-medium mb-1">نصب بازی:</p>
                          <ol className="list-decimal list-inside space-y-1">
                            <li>در فروشگاه بازی را پیدا کنید</li>
                            <li>روی نصب کلیک کنید</li>
                            <li>پس از نصب مجدداً تلاش کنید</li>
                          </ol>
                        </div>
                      )}

                      {result.method === 'manual_copy' && (
                        <div>
                          <p className="font-medium mb-1">مراحل پیوستن:</p>
                          <ol className="list-decimal list-inside space-y-1">
                            <li>بازی را باز کنید</li>
                            <li>به بخش Custom Room بروید</li>
                            <li>کد کپی شده را وارد کنید</li>
                            {result.data?.password && <li>رمز عبور را وارد کنید</li>}
                          </ol>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}

// Hook for managing launch notifications
export function useGameLaunchNotification() {
  const [notification, setNotification] = useState<{
    result: LaunchResult;
    gameIcon?: string;
    gameName?: string;
  } | null>(null);

  const showNotification = (
    result: LaunchResult,
    gameIcon?: string,
    gameName?: string
  ) => {
    setNotification({ result, gameIcon, gameName });
  };

  const hideNotification = () => {
    setNotification(null);
  };

  return {
    notification,
    showNotification,
    hideNotification
  };
}

export default GameLaunchNotification;