/**
 * Matchzone Gaming Platform
 * Lobby Card Adapter - تطبیق interface قدیمی با جدید
 */

import React from 'react';
import { EnhancedLobbyCard } from './EnhancedLobbyCard';
import { useNavigation } from '../navigation/NavigationProvider';

// Old interface for compatibility with EnhancedLobbiesPage
export interface EnhancedLobby {
  id: string;
  name: string; // title equivalent
  gameId: string; // game equivalent
  platform: 'mobile' | 'desktop';
  currentPlayers: number;
  maxPlayers: number;
  host: { // owner equivalent
    name: string; // username equivalent
    avatar?: string;
    level: string; // will be mapped to trustLevel
  };
  status: 'waiting' | 'starting' | 'active' | 'completed' | 'cancelled';
  gameMode?: string;
  isPrivate?: boolean; // visibility equivalent
  isPaidLobby?: boolean;
  entryFee?: number;
  isTournamentGame?: boolean;
  requiredLevel?: number;
  estimatedDuration?: number; // duration equivalent
  region?: string;
  ageRestriction?: string;
  genderRestriction?: string;
  createdAt?: Date; // startTime equivalent
}

interface LobbyCardAdapterProps {
  lobby: EnhancedLobby;
  onJoin?: () => void;
  onLeave?: () => void;
  onView?: () => void;
  onClick?: () => void;
  isJoined?: boolean;
  className?: string;
}

// Helper function to map trust level
const mapTrustLevel = (level: string): 'low' | 'mid' | 'high' => {
  switch (level.toLowerCase()) {
    case 'manager':
    case 'host':
      return 'high';
    case 'player':
      return 'mid';
    default:
      return 'low';
  }
};

// Helper function to map status
const mapStatus = (status: string): 'open' | 'nearfull' | 'full' | 'closed' | 'starting' | 'active' => {
  switch (status) {
    case 'waiting':
      return 'open';
    case 'starting':
      return 'starting';
    case 'active':
      return 'active';
    case 'completed':
      return 'closed';
    case 'cancelled':
      return 'closed';
    default:
      return 'open';
  }
};

export const LobbyCardAdapter: React.FC<LobbyCardAdapterProps> = ({
  lobby,
  onJoin,
  onLeave,
  onView,
  onClick,
  isJoined,
  className
}) => {
  const { navigateToLobby } = useNavigation();

  const handleCardClick = () => {
    navigateToLobby(lobby.id);
  };
  // Map old interface to new interface
  const mappedLobby = {
    id: lobby.id,
    title: lobby.name,
    game: lobby.gameId,
    platform: lobby.platform,
    currentPlayers: lobby.currentPlayers,
    maxPlayers: lobby.maxPlayers,
    owner: {
      id: `host-${lobby.id}`,
      username: lobby.host.name,
      avatar: lobby.host.avatar,
      trustLevel: mapTrustLevel(lobby.host.level),
      isVerified: lobby.host.level === 'manager' || lobby.host.level === 'host'
    },
    status: mapStatus(lobby.status),
    visibility: (lobby.isPrivate ? 'private' : 'public') as 'public' | 'private',
    entryFee: lobby.entryFee,
    duration: lobby.estimatedDuration,
    startTime: lobby.createdAt,
    region: lobby.region,
    tags: [
      ...(lobby.gameMode ? [lobby.gameMode] : []),
      ...(lobby.isTournamentGame ? ['مسابقه‌ای'] : []),
      ...(lobby.isPaidLobby ? ['پولی'] : ['رایگان']),
      ...(lobby.requiredLevel ? [`سطح ${lobby.requiredLevel}+`] : [])
    ].filter(Boolean)
  };
  
  return (
    <EnhancedLobbyCard
      {...mappedLobby}
      onJoin={onJoin}
      onView={onView}
      onClick={onClick || handleCardClick}
      className={className}
    />
  );
};

// Export the EnhancedLobby type for backward compatibility
export type { EnhancedLobby };