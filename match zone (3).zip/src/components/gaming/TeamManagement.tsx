/**
 * Team Management Component
 * Manages lobby teams with drag & drop functionality
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  Users, Crown, Shield, User, Move, MoreVertical, UserPlus,
  ArrowLeftRight, Settings, Trash2
} from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../ui/dropdown-menu';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useLobby } from './LobbyContext';
import { useUser } from '../providers/UserProvider';

interface TeamMember {
  id: string;
  username: string;
  avatar?: string;
  role: 'owner' | 'admin' | 'member';
  isReady: boolean;
  isOnline: boolean;
}

interface TeamManagementProps {
  lobbyId: string;
  members: TeamMember[];
  isOwner?: boolean;
  className?: string;
}

export function TeamManagement({ 
  lobbyId, 
  members = [], 
  isOwner = false, 
  className 
}: TeamManagementProps) {
  const { 
    getLobbyTeams, 
    getLobbyMembers,
    initializeLobbyTeams, 
    moveUserBetweenTeams, 
    addUserToTeam,
    removeUserFromTeam,
    autoAssignUserToTeam 
  } = useLobby();
  const { currentUser } = useUser();
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [targetTeam, setTargetTeam] = useState<string>('');
  const [showMoveDialog, setShowMoveDialog] = useState(false);

  const teams = getLobbyTeams(lobbyId);

  // Initialize teams if they don't exist
  useEffect(() => {
    if (teams.length === 0) {
      initializeLobbyTeams(lobbyId, 2, 2);
    }
  }, [lobbyId, teams.length, initializeLobbyTeams]);

  // Get all members (prioritize context members over props)
  const realMembers = getLobbyMembers(lobbyId);
  const allMembers: TeamMember[] = [];
  
  // Start with real members from context (most up-to-date)
  realMembers.forEach(realMember => {
    allMembers.push({
      id: realMember.id,
      username: realMember.username,
      avatar: realMember.avatar,
      role: realMember.role,
      isReady: false,
      isOnline: true
    });
  });
  
  // Add prop members that aren't in context
  members.forEach(propMember => {
    if (!allMembers.some(m => m.id === propMember.id)) {
      allMembers.push(propMember);
    }
  });
  
  console.log('🔍 TeamManagement - All members:', {
    lobbyId,
    contextMembers: realMembers.length,
    propMembers: members.length,
    totalMembers: allMembers.length,
    membersList: allMembers.map(m => ({ id: m.id, username: m.username }))
  });

  // Get member details by ID
  const getMemberById = (memberId: string): TeamMember | undefined => {
    return allMembers.find(m => m.id === memberId);
  };

  // Handle moving user between teams
  const handleMoveUser = () => {
    if (!selectedUser || !targetTeam) return;

    const currentTeam = teams.find(team => team.members.includes(selectedUser));
    if (currentTeam && currentTeam.id !== targetTeam) {
      moveUserBetweenTeams(lobbyId, selectedUser, currentTeam.id, targetTeam);
    }

    setShowMoveDialog(false);
    setSelectedUser(null);
    setTargetTeam('');
  };

  // Auto balance teams
  const handleAutoBalance = () => {
    const unassignedMembers = members.filter(member => 
      !teams.some(team => team.members.includes(member.id))
    );

    unassignedMembers.forEach(member => {
      autoAssignUserToTeam(lobbyId, member.id);
    });
  };

  const renderTeamMember = (memberId: string, teamId: string) => {
    const member = getMemberById(memberId);
    if (!member) return null;

    const getRoleIcon = (role: string) => {
      switch (role) {
        case 'owner': return Crown;
        case 'admin': return Shield;
        default: return User;
      }
    };

    const getRoleColor = (role: string) => {
      switch (role) {
        case 'owner': return 'text-yellow-400';
        case 'admin': return 'text-blue-400';
        default: return 'text-gray-400';
      }
    };

    const RoleIcon = getRoleIcon(member.role);

    return (
      <div 
        key={memberId}
        className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg hover:bg-surface-tertiary transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="relative">
            <Avatar className="w-8 h-8">
              <AvatarImage src={member.avatar} alt={member.username} />
              <AvatarFallback>{member.username[0]}</AvatarFallback>
            </Avatar>
            {member.isOnline && (
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-surface-secondary" />
            )}
          </div>
          
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">{member.username}</span>
              <RoleIcon className={`w-3 h-3 ${getRoleColor(member.role)}`} />
            </div>
            <div className="flex items-center gap-2 mt-1">
              {member.isReady && (
                <Badge variant="outline" className="text-xs px-2 py-0 bg-green-500/10 text-green-400 border-green-500/20">
                  آماده
                </Badge>
              )}
              {!member.isOnline && (
                <Badge variant="outline" className="text-xs px-2 py-0 bg-gray-500/10 text-gray-400 border-gray-500/20">
                  آفلاین
                </Badge>
              )}
            </div>
          </div>
        </div>

        {isOwner && member.id !== currentUser?.id && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={() => {
                  setSelectedUser(member.id);
                  setShowMoveDialog(true);
                }}
              >
                <ArrowLeftRight className="w-4 h-4 ml-2" />
                انتقال به تیم دیگر
              </DropdownMenuItem>
              <DropdownMenuItem
                className="text-red-400"
                onClick={() => removeUserFromTeam(lobbyId, teamId, member.id)}
              >
                <Trash2 className="w-4 h-4 ml-2" />
                حذف از تیم
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    );
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Header with actions */}
      {isOwner && (
        <div className="flex items-center justify-between">
          <h3 className="font-medium">مدیریت تیم‌ها</h3>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleAutoBalance}
            className="text-xs"
          >
            <Users className="w-4 h-4 ml-1" />
            توزیع خودکار
          </Button>
        </div>
      )}

      {/* Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {teams.map((team) => (
          <Card key={team.id} className="bg-surface-primary border-border-primary">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{team.name}</CardTitle>
                <Badge variant="outline" className="text-xs">
                  {team.members.length}/{team.maxMembers}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                {team.members.length > 0 ? (
                  team.members.map(memberId => renderTeamMember(memberId, team.id))
                ) : (
                  <div className="flex items-center justify-center p-4 border-2 border-dashed border-border-secondary rounded-lg text-text-tertiary">
                    <div className="text-center">
                      <UserPlus className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">تیم خالی</p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Unassigned Members */}
      {(() => {
        const unassignedMembers = members.filter(member => 
          !teams.some(team => team.members.includes(member.id))
        );
        
        if (unassignedMembers.length > 0) {
          return (
            <Card className="bg-surface-primary border-border-primary">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  اعضای بدون تیم
                  <Badge variant="outline" className="text-xs">
                    {unassignedMembers.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  {unassignedMembers.map(member => 
                    renderTeamMember(member.id, 'unassigned')
                  )}
                </div>
              </CardContent>
            </Card>
          );
        }
        return null;
      })()}

      {/* Move User Dialog */}
      <Dialog open={showMoveDialog} onOpenChange={setShowMoveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>انتقال عضو به تیم دیگر</DialogTitle>
            <DialogDescription>
              عضو مورد نظر را به تیم جدید منتقل کنید
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {selectedUser && (
              <div className="p-3 bg-surface-secondary rounded-lg">
                <p className="text-sm">
                  <span className="text-text-tertiary">عضو انتخاب شده: </span>
                  <span className="font-medium">
                    {getMemberById(selectedUser)?.username}
                  </span>
                </p>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium">تیم مقصد:</label>
              <Select value={targetTeam} onValueChange={setTargetTeam}>
                <SelectTrigger>
                  <SelectValue placeholder="تیم را انتخاب کنید" />
                </SelectTrigger>
                <SelectContent>
                  {teams.map(team => {
                    const canMove = team.members.length < team.maxMembers && 
                                   !team.members.includes(selectedUser || '');
                    return (
                      <SelectItem 
                        key={team.id} 
                        value={team.id}
                        disabled={!canMove}
                      >
                        {team.name} ({team.members.length}/{team.maxMembers})
                        {!canMove && " - پر"}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowMoveDialog(false)}>
              انصراف
            </Button>
            <Button onClick={handleMoveUser} disabled={!targetTeam}>
              انتقال
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}