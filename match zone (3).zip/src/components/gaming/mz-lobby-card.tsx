import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { Users, Crown, Shield, Lock, Clock, MapPin } from 'lucide-react';
import { cn } from '../ui/utils';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { useMobile } from '../ui/use-mobile';

const lobbyCardVariants = cva(
  [
    "relative overflow-hidden rounded-lg border bg-surface-primary transition-all duration-200",
    "hover:shadow-md hover:border-border-secondary",
    "cursor-pointer active:scale-[0.98]"
  ],
  {
    variants: {
      status: {
        open: "border-state-success/30 hover:border-state-success/50",
        nearfull: "border-state-warning/30 hover:border-state-warning/50",
        full: "border-border-primary opacity-75 cursor-not-allowed",
        closed: "border-border-muted opacity-60 cursor-not-allowed"
      },
      ownerTrust: {
        low: "",
        mid: "ring-1 ring-state-info/20",
        high: "ring-1 ring-state-success/30"
      },
      visibility: {
        public: "",
        private: "border-dashed"
      }
    },
    defaultVariants: {
      status: "open",
      ownerTrust: "low",
      visibility: "public"
    }
  }
);

interface UserSummary {
  id: string;
  username: string;
  avatar?: string;
  trustLevel: 'low' | 'mid' | 'high';
  isVerified?: boolean;
}

export interface LobbyCardProps extends VariantProps<typeof lobbyCardVariants> {
  id: string;
  title: string;
  game: string;
  gameIcon?: string;
  description?: string;
  owner: UserSummary;
  currentPlayers: number;
  maxPlayers: number;
  tags?: string[];
  createdAt: string;
  server?: string;
  gameMode?: string;
  requiresPassword?: boolean;
  minLevel?: number;
  className?: string;
  onClick?: () => void;
}

const LobbyCard = React.forwardRef<HTMLDivElement, LobbyCardProps>(
  ({ 
    id,
    title,
    game,
    gameIcon,
    description,
    owner,
    currentPlayers,
    maxPlayers,
    tags = [],
    createdAt,
    server,
    gameMode,
    requiresPassword,
    minLevel,
    status,
    ownerTrust,
    visibility,
    className,
    onClick,
    ...props 
  }, ref) => {
    const getStatusBadge = () => {
      switch (status) {
        case 'open':
          return <Badge variant="outline" className="border-state-success text-state-success">باز</Badge>;
        case 'nearfull':
          return <Badge variant="outline" className="border-state-warning text-state-warning">تقریباً پر</Badge>;
        case 'full':
          return <Badge variant="outline" className="border-border-primary text-text-secondary">پر</Badge>;
        case 'closed':
          return <Badge variant="outline" className="border-border-muted text-text-tertiary">بسته</Badge>;
        default:
          return null;
      }
    };

    const getTrustIcon = () => {
      switch (owner.trustLevel) {
        case 'high':
          return <Crown className="h-3 w-3 text-state-warning" />;
        case 'mid':
          return <Shield className="h-3 w-3 text-state-info" />;
        default:
          return null;
      }
    };

    const isInteractable = status === 'open' || status === 'nearfull';
    const isMobile = useMobile();

    return (
      <div
        ref={ref}
        className={cn(lobbyCardVariants({ status, ownerTrust, visibility, className }), 
          isMobile ? 'p-3' : 'p-4'
        )}
        onClick={isInteractable ? onClick : undefined}
        dir="rtl"
        {...props}
      >
        {/* Header */}
        <div className={`flex items-start justify-between ${isMobile ? 'mb-2' : 'mb-3'}`}>
          <div className={`flex items-start ${isMobile ? 'gap-2' : 'gap-3'}`}>
            {gameIcon && (
              <div className={`rounded-md overflow-hidden bg-surface-secondary flex-shrink-0 ${
                isMobile ? 'w-10 h-10' : 'w-12 h-12'
              }`}>
                <img src={gameIcon} alt={game} className="w-full h-full object-cover" />
              </div>
            )}
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className={`font-semibold text-text-primary truncate ${isMobile ? 'text-sm' : ''}`}>
                  {title}
                </h3>
                {visibility === 'private' && <Lock className={`text-text-tertiary ${isMobile ? 'h-3 w-3' : 'h-4 w-4'}`} />}
                {requiresPassword && <Lock className={`text-state-warning ${isMobile ? 'h-3 w-3' : 'h-4 w-4'}`} />}
              </div>
              
              <div className={`flex items-center gap-2 text-text-secondary ${isMobile ? 'text-xs' : 'text-sm'}`}>
                <span>{game}</span>
                {gameMode && !isMobile && (
                  <>
                    <span>•</span>
                    <span>{gameMode}</span>
                  </>
                )}
              </div>
              
              {/* CS2 Team Status */}
              {game === 'Counter-Strike 2' && (
                <div className="flex gap-2 mt-1">
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
                    <span className="text-xs text-text-tertiary">
                      تیم ۱: {currentPlayers >= Math.ceil(maxPlayers/2) ? 'پرشد' : 'نیاز به عضو'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                    <span className="text-xs text-text-tertiary">
                      تیم ۲: {maxPlayers - currentPlayers <= Math.floor(maxPlayers/2) ? 'پرشد' : 'نیاز به عضو'}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col items-end gap-1">
            {getStatusBadge()}
            <div className={`flex items-center gap-1 text-text-secondary ${isMobile ? 'text-xs' : 'text-sm'}`}>
              <Users className={isMobile ? 'h-3 w-3' : 'h-4 w-4'} />
              <span>{currentPlayers}/{maxPlayers}</span>
            </div>
          </div>
        </div>

        {/* Description */}
        {description && (
          <p className="text-sm text-text-secondary mb-3 line-clamp-2">
            {description}
          </p>
        )}

        {/* Tags */}
        {tags.length > 0 && (
          <div className={`flex flex-wrap gap-1 ${isMobile ? 'mb-2' : 'mb-3'}`}>
            {tags.slice(0, isMobile ? 2 : 3).map((tag, index) => (
              <Badge key={index} variant="secondary" className={isMobile ? 'text-xs px-1.5 py-0.5' : 'text-xs'}>
                {tag}
              </Badge>
            ))}
            {tags.length > (isMobile ? 2 : 3) && (
              <Badge variant="secondary" className={isMobile ? 'text-xs px-1.5 py-0.5' : 'text-xs'}>
                +{tags.length - (isMobile ? 2 : 3)}
              </Badge>
            )}
          </div>
        )}

        {/* Meta Information */}
        <div className={`flex items-center justify-between text-text-tertiary ${isMobile ? 'text-xs' : 'text-xs'}`}>
          <div className={`flex items-center ${isMobile ? 'gap-2' : 'gap-3'}`}>
            {server && !isMobile && (
              <div className="flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                <span>{server}</span>
              </div>
            )}
            
            {minLevel && !isMobile && (
              <div className="flex items-center gap-1">
                <span>حداقل سطح {minLevel}</span>
              </div>
            )}
            
            <div className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              <span>{createdAt}</span>
            </div>
          </div>
        </div>

        {/* Owner Info */}
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-border-secondary">
          <div className="flex items-center gap-2">
            <Avatar className="h-6 w-6">
              <AvatarImage src={owner.avatar} alt={owner.username} />
              <AvatarFallback className="text-xs">{owner.username[0]}</AvatarFallback>
            </Avatar>
            
            <div className="flex items-center gap-1">
              <span className="text-sm font-medium text-text-primary">
                {owner.username}
              </span>
              {getTrustIcon()}
              {owner.isVerified && (
                <div className="h-3 w-3 rounded-full bg-state-success flex items-center justify-center">
                  <Crown className="h-2 w-2 text-white" />
                </div>
              )}
            </div>
          </div>
          
          <span className="text-xs text-text-tertiary">میزبان</span>
        </div>

        {/* Status Overlay for non-interactive cards */}
        {!isInteractable && (
          <div className="absolute inset-0 bg-surface-primary/50 flex items-center justify-center">
            <div className="text-center">
              <div className="text-lg font-semibold text-text-secondary mb-1">
                {status === 'full' ? 'لابی پر است' : 'لابی بسته است'}
              </div>
              <div className="text-sm text-text-tertiary">
                {status === 'full' ? 'منتظر آزاد شدن جای خالی باشید' : 'این لابی در حال حاضر قابل دسترس نیست'}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
);

LobbyCard.displayName = "LobbyCard";

export { LobbyCard, lobbyCardVariants };