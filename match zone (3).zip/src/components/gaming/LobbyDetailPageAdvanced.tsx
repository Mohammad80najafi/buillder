/**
 * Advanced Lobby Detail Page
 * Complete lobby information with join capabilities
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/mz-button';
import { Input } from '../ui/mz-input';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { Avatar, AvatarImage, AvatarFallback } from '../ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, Users, Clock, MapPin, Gamepad2, Monitor, 
  Smartphone, Globe, Lock, Crown, Shield, Zap, Star, Play, 
  Copy, ExternalLink, Wifi, Signal, Trophy, Target, Flame,
  Steam, Download, Settings, RefreshCw, Share2, Heart,
  CheckCircle, AlertCircle, XCircle, Info, MessageCircle,
  UserPlus, UserMinus, Flag, MoreHorizontal, Volume2, VolumeX
} from 'lucide-react';
import { useMobile } from '../ui/use-mobile';
import { launchGame, LaunchResult } from '../../utils/gameLauncher';
import { GameLaunchNotification, useGameLaunchNotification } from './GameLaunchNotification';

// Extended lobby interface
interface ExtendedLobbyData {
  id: string;
  title: string;
  description?: string;
  game: {
    id: string;
    name: string;
    displayName: string;
    icon: string;
    platforms: string[];
    launchMethods: any;
    serverType: string;
    joinMethod: string;
    features: string[];
  };
  owner: {
    id: string;
    username: string;
    displayName: string;
    trustLevel: 'low' | 'mid' | 'high';
    isVerified: boolean;
    avatar?: string;
    level: number;
    gamesPlayed: number;
    winRate: number;
  };
  players: Array<{
    id: string;
    username: string;
    displayName: string;
    avatar?: string;
    level: number;
    role: 'owner' | 'admin' | 'player';
    joinedAt: string;
    isReady: boolean;
    ping?: number;
    team?: number;
  }>;
  currentPlayers: number;
  maxPlayers: number;
  status: 'open' | 'nearfull' | 'full' | 'starting' | 'live' | 'finished';
  createdAt: string;
  startTime?: string;
  server?: {
    ip: string;
    port: number;
    password?: string;
    region: string;
    ping: number;
    provider: string;
  };
  room?: {
    id: string;
    password?: string;
  };
  requirements?: {
    minLevel?: number;
    ageRestriction?: string;
    genderRestriction?: string;
    ranked?: boolean;
    verified?: boolean;
  };
  tags: string[];
  prize?: number;
  isPrivate: boolean;
  settings: {
    allowSpectators: boolean;
    autoStart: boolean;
    requireReady: boolean;
    voiceChat: boolean;
  };
  joinInfo?: {
    method: 'direct' | 'steam' | 'room_code' | 'invite';
    data: string;
  };
  chat: Array<{
    id: string;
    username: string;
    message: string;
    timestamp: string;
    type: 'message' | 'join' | 'leave' | 'system';
  }>;
}

interface LobbyDetailPageProps {
  lobbyId: string;
  onBack?: () => void;
}

export function LobbyDetailPageAdvanced({ lobbyId, onBack }: LobbyDetailPageProps) {
  const isMobile = useMobile();
  const { notification, showNotification, hideNotification } = useGameLaunchNotification();
  const [lobby, setLobby] = useState<ExtendedLobbyData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isJoining, setIsJoining] = useState(false);
  const [newMessage, setNewMessage] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const chatEndRef = React.useRef<HTMLDivElement>(null);
  const [showJoinPassword, setShowJoinPassword] = useState(false);
  const [joinPassword, setJoinPassword] = useState('');

  // Mock data - In real app, fetch from API
  useEffect(() => {
    const fetchLobby = async () => {
      setLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setLobby({
        id: lobbyId,
        title: 'مسابقه تیمی حرفه‌ای CS2 - جایزه ۵۰۰ هزار تومان',
        description: 'مسابقه تیمی 5v5 برای بازیکنان حرفه‌ای. حداقل رنک DMG. قوانین: ممنوعیت چیت، احترام به بقیه، Voice Chat اجباری در تیم.',
        game: {
          id: 'cs2',
          name: 'cs2',
          displayName: 'Counter-Strike 2',
          icon: '🔫',
          platforms: ['pc'],
          launchMethods: { pc: { steam: 'steam://run/730' } },
          serverType: 'dedicated',
          joinMethod: 'direct',
          features: ['یک‌کلیک واقعی', 'سرور اختصاصی', 'مدیریت کامل', 'پینگ عالی']
        },
        owner: {
          id: 'user-1',
          username: 'محمدرضا_پرو',
          displayName: 'محمدرضا',
          trustLevel: 'high',
          isVerified: true,
          avatar: '',
          level: 45,
          gamesPlayed: 1250,
          winRate: 78
        },
        players: [
          {
            id: 'user-1',
            username: 'محمدرضا_پرو',
            displayName: 'محمدرضا',
            level: 45,
            role: 'owner',
            joinedAt: '10 دقیقه پیش',
            isReady: true,
            ping: 25,
            team: 1
          },
          {
            id: 'user-2',
            username: 'علی_کیلر',
            displayName: 'علی',
            level: 38,
            role: 'player',
            joinedAt: '8 دقیقه پیش',
            isReady: true,
            ping: 30,
            team: 1
          },
          {
            id: 'user-3',
            username: 'حسن_اسنایپر',
            displayName: 'حسن',
            level: 42,
            role: 'player',
            joinedAt: '5 دقیقه پیش',
            isReady: false,
            ping: 28,
            team: 2
          },
          {
            id: 'user-4',
            username: 'سارا_گیمر',
            displayName: 'سارا',
            level: 35,
            role: 'player',
            joinedAt: '3 دقیقه پیش',
            isReady: true,
            ping: 32,
            team: 2
          },
          {
            id: 'user-5',
            username: 'امین_پرو',
            displayName: 'امین',
            level: 41,
            role: 'player',
            joinedAt: '2 دقیقه پیش',
            isReady: false,
            ping: 27,
            team: 1
          }
        ],
        currentPlayers: 5,
        maxPlayers: 10,
        status: 'open',
        createdAt: '15 دقیقه پیش',
        startTime: '20:30',
        server: {
          ip: '185.143.232.15',
          port: 27015,
          password: 'mz2024',
          region: 'تهران',
          ping: 25,
          provider: 'MaxGaming'
        },
        requirements: {
          minLevel: 15,
          ageRestriction: '16+',
          genderRestriction: 'none',
          ranked: true,
          verified: true
        },
        tags: ['رنک', 'تیمی', 'حرفه‌ای', 'جایزه‌دار'],
        prize: 500000,
        isPrivate: false,
        settings: {
          allowSpectators: true,
          autoStart: false,
          requireReady: true,
          voiceChat: true
        },
        joinInfo: {
          method: 'direct',
          data: 'steam://connect/185.143.232.15:27015/mz2024'
        },
        chat: [
          {
            id: 'msg-1',
            username: 'محمدرضا_پرو',
            message: 'سلام بچه‌ها! آماده‌اید؟',
            timestamp: '5 دقیقه پیش',
            type: 'message'
          },
          {
            id: 'msg-2',
            username: 'علی_کیلر',
            message: 'آماده‌ام! منتظر یه بازی خوب',
            timestamp: '4 دقیقه پیش',
            type: 'message'
          },
          {
            id: 'sys-1',
            username: 'System',
            message: 'حسن_اسنایپر به لابی پیوست',
            timestamp: '3 دقیقه پیش',
            type: 'join'
          }
        ]
      });
      
      setLoading(false);
    };

    fetchLobby();
  }, [lobbyId]);

  const handleJoinLobby = useCallback(async () => {
    if (!lobby) return;
    
    if (lobby.requirements?.verified && !lobby.owner.isVerified) {
      alert('این لابی فقط برای کاربران تأیید شده است');
      return;
    }

    if (lobby.server?.password && !joinPassword && lobby.isPrivate) {
      setShowJoinPassword(true);
      return;
    }

    setIsJoining(true);
    
    try {
      // Launch game
      const result = await launchGame(lobby.game, lobby);
      showNotification(result, lobby.game.icon, lobby.game.displayName);
    } catch (error) {
      console.error('Join error:', error);
    } finally {
      setIsJoining(false);
    }
  }, [lobby, joinPassword, showNotification]);

  const getStatusBadge = () => {
    switch (lobby?.status) {
      case 'open':
        return <Badge className="bg-state-success text-white animate-pulse">باز</Badge>;
      case 'nearfull':
        return <Badge className="bg-state-warning text-black">تقریباً پر</Badge>;
      case 'starting':
        return <Badge className="bg-state-info text-white">در حال شروع</Badge>;
      case 'live':
        return <Badge className="bg-brand-accent text-black">زنده</Badge>;
      case 'finished':
        return <Badge variant="outline">تمام شده</Badge>;
      default:
        return <Badge variant="outline">نامشخص</Badge>;
    }
  };

  const copyToClipboard = useCallback((text: string) => {
    navigator.clipboard.writeText(text);
    // Show toast
  }, []);

  const handleSendMessage = useCallback(async () => {
    if (!newMessage.trim() || !lobby || sendingMessage) return;
    
    setSendingMessage(true);
    
    // Simulate sending message
    const newMsg = {
      id: `msg-${Date.now()}`,
      username: 'شما', // In real app, get from auth context
      message: newMessage.trim(),
      timestamp: 'همین الان',
      type: 'message' as const
    };
    
    setLobby(prev => prev ? {
      ...prev,
      chat: [...prev.chat, newMsg]
    } : null);
    
    setNewMessage('');
    setSendingMessage(false);
    
    // Scroll to bottom
    setTimeout(() => {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }, [newMessage, lobby, sendingMessage]);

  const handleMessageInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setNewMessage(e.target.value);
  }, []);

  const handleKeyPress = useCallback((e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  }, [handleSendMessage]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-primary mx-auto mb-4"></div>
          <p className="text-text-secondary">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  if (!lobby) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <XCircle className="h-16 w-16 text-state-danger mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">لابی یافت نشد</h2>
          <p className="text-text-secondary mb-4">لابی مورد نظر وجود ندارد یا حذف شده است</p>
          <Button onClick={onBack} variant="outline">
            بازگشت
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background gaming-scroll" dir="rtl">
      <div className={`container mx-auto py-6 ${isMobile ? 'px-4' : 'px-6'}`}>
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-6"
        >
          {onBack && (
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowRight className="h-4 w-4" />
              بازگشت
            </Button>
          )}
          <div className="flex-1">
            <h1 className="text-2xl font-bold">{lobby.title}</h1>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-3xl">{lobby.game.icon}</span>
              <span className="text-text-secondary">{lobby.game.displayName}</span>
              {getStatusBadge()}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <Share2 className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Heart className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Lobby Info Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>اطلاعات لابی</span>
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      <span>{lobby.currentPlayers}/{lobby.maxPlayers}</span>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {lobby.description && (
                    <p className="text-text-secondary leading-relaxed">
                      {lobby.description}
                    </p>
                  )}

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-3 bg-surface-secondary rounded-lg">
                      <div className="text-lg font-bold">{lobby.currentPlayers}</div>
                      <div className="text-xs text-text-secondary">بازیکن فعلی</div>
                    </div>
                    <div className="text-center p-3 bg-surface-secondary rounded-lg">
                      <div className="text-lg font-bold">{lobby.maxPlayers}</div>
                      <div className="text-xs text-text-secondary">حداکثر</div>
                    </div>
                    <div className="text-center p-3 bg-surface-secondary rounded-lg">
                      <div className="text-lg font-bold">{lobby.server?.ping || '-'}ms</div>
                      <div className="text-xs text-text-secondary">پینگ</div>
                    </div>
                    <div className="text-center p-3 bg-surface-secondary rounded-lg">
                      <div className="text-lg font-bold">
                        {lobby.prize ? `${lobby.prize.toLocaleString()}` : 'رایگان'}
                      </div>
                      <div className="text-xs text-text-secondary">جایزه</div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>تکمیل لابی</span>
                      <span>{Math.round((lobby.currentPlayers / lobby.maxPlayers) * 100)}%</span>
                    </div>
                    <Progress value={(lobby.currentPlayers / lobby.maxPlayers) * 100} />
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2">
                    {lobby.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                    {lobby.prize && (
                      <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                        جایزه‌دار
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Tabs */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Tabs defaultValue="players" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="players">بازیکنان</TabsTrigger>
                  <TabsTrigger value="server">سرور</TabsTrigger>
                  <TabsTrigger value="requirements">الزامات</TabsTrigger>
                  <TabsTrigger value="settings">تنظیمات</TabsTrigger>
                </TabsList>

                <TabsContent value="players" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>بازیکنان ({lobby.players.length})</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {(() => {
                        // Group players by team
                        const teams = lobby.players.reduce((acc, player) => {
                          const teamNumber = player.team || 0;
                          if (!acc[teamNumber]) acc[teamNumber] = [];
                          acc[teamNumber].push(player);
                          return acc;
                        }, {} as Record<number, typeof lobby.players>);
                        
                        const teamNumbers = Object.keys(teams).map(Number).filter(n => n > 0);
                        const hasTeams = teamNumbers.length > 1;
                        
                        if (!hasTeams) {
                          // Show players without team divisions
                          return (
                            <div className="space-y-3">
                              {lobby.players.map((player) => (
                                <div key={player.id} className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                                  <div className="flex items-center gap-3">
                                    <Avatar className="h-10 w-10">
                                      <AvatarImage src={player.avatar} />
                                      <AvatarFallback>{player.displayName[0]}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                      <div className="flex items-center gap-2">
                                        <span className="font-medium">{player.displayName}</span>
                                        {player.role === 'owner' && <Crown className="h-4 w-4 text-brand-accent" />}
                                        {player.role === 'admin' && <Shield className="h-4 w-4 text-brand-primary" />}
                                      </div>
                                      <div className="text-sm text-text-secondary">
                                        سطح {player.level} • {player.joinedAt}
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    {player.ping && (
                                      <Badge variant="outline" className="text-xs">
                                        {player.ping}ms
                                      </Badge>
                                    )}
                                    <div className={`w-3 h-3 rounded-full ${
                                      player.isReady ? 'bg-state-success' : 'bg-state-warning'
                                    }`} />
                                  </div>
                                </div>
                              ))}
                            </div>
                          );
                        }
                        
                        // Show players divided by teams
                        return (
                          <div className="space-y-6">
                            {teamNumbers.sort().map((teamNumber) => (
                              <div key={teamNumber} className="space-y-3">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-3">
                                    <div className={`w-4 h-4 rounded-full ${
                                      teamNumber === 1 ? 'bg-gradient-to-r from-blue-500 to-cyan-500' : 
                                      teamNumber === 2 ? 'bg-gradient-to-r from-red-500 to-pink-500' :
                                      'bg-gradient-to-r from-purple-500 to-indigo-500'
                                    }`} />
                                    <h4 className="font-semibold">
                                      تیم {teamNumber}
                                    </h4>
                                  </div>
                                  <Badge variant="outline" className="text-xs">
                                    {teams[teamNumber].length} بازیکن • {teams[teamNumber].filter(p => p.isReady).length} آماده
                                  </Badge>
                                </div>
                                <div className="space-y-2 mr-6">
                                  {teams[teamNumber].map((player) => (
                                    <div key={player.id} className="flex items-center justify-between p-3 bg-surface-tertiary rounded-lg border-r-4" style={{
                                      borderRightColor: teamNumber === 1 ? '#3b82f6' : teamNumber === 2 ? '#ef4444' : '#8b5cf6'
                                    }}>
                                      <div className="flex items-center gap-3">
                                        <Avatar className="h-8 w-8">
                                          <AvatarImage src={player.avatar} />
                                          <AvatarFallback>{player.displayName[0]}</AvatarFallback>
                                        </Avatar>
                                        <div>
                                          <div className="flex items-center gap-2">
                                            <span className="font-medium text-sm">{player.displayName}</span>
                                            {player.role === 'owner' && <Crown className="h-3 w-3 text-brand-accent" />}
                                            {player.role === 'admin' && <Shield className="h-3 w-3 text-brand-primary" />}
                                          </div>
                                          <div className="text-xs text-text-secondary">
                                            سطح {player.level} • {player.joinedAt}
                                          </div>
                                        </div>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        {player.ping && (
                                          <Badge variant="outline" className="text-xs">
                                            {player.ping}ms
                                          </Badge>
                                        )}
                                        <div className={`w-2 h-2 rounded-full ${
                                          player.isReady ? 'bg-state-success' : 'bg-state-warning'
                                        }`} />
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        );
                      })()}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="server" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>اطلاعات سرور</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {lobby.server && (
                        <>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-sm font-medium">آدرس سرور</label>
                              <div className="flex items-center gap-2">
                                <Input 
                                  value={`${lobby.server.ip}:${lobby.server.port}`}
                                  readOnly
                                  className="font-mono"
                                />
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => copyToClipboard(`${lobby.server!.ip}:${lobby.server!.port}`)}
                                >
                                  <Copy className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>

                            {lobby.server.password && (
                              <div className="space-y-2">
                                <label className="text-sm font-medium">رمز سرور</label>
                                <div className="flex items-center gap-2">
                                  <Input 
                                    value={lobby.server.password}
                                    type="password"
                                    readOnly
                                    className="font-mono"
                                  />
                                  <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={() => copyToClipboard(lobby.server!.password!)}
                                  >
                                    <Copy className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="text-center p-3 bg-surface-tertiary rounded-lg">
                              <MapPin className="h-5 w-5 mx-auto mb-1 text-brand-primary" />
                              <div className="text-sm font-medium">{lobby.server.region}</div>
                              <div className="text-xs text-text-secondary">منطقه</div>
                            </div>
                            <div className="text-center p-3 bg-surface-tertiary rounded-lg">
                              <Wifi className="h-5 w-5 mx-auto mb-1 text-brand-secondary" />
                              <div className="text-sm font-medium">{lobby.server.ping}ms</div>
                              <div className="text-xs text-text-secondary">پینگ</div>
                            </div>
                            <div className="text-center p-3 bg-surface-tertiary rounded-lg">
                              <Globe className="h-5 w-5 mx-auto mb-1 text-brand-accent" />
                              <div className="text-sm font-medium">{lobby.server.provider}</div>
                              <div className="text-xs text-text-secondary">ارائه دهنده</div>
                            </div>
                            <div className="text-center p-3 bg-surface-tertiary rounded-lg">
                              <CheckCircle className="h-5 w-5 mx-auto mb-1 text-state-success" />
                              <div className="text-sm font-medium">آنلاین</div>
                              <div className="text-xs text-text-secondary">وضعیت</div>
                            </div>
                          </div>
                        </>
                      )}

                      {lobby.room && (
                        <div className="space-y-2">
                          <label className="text-sm font-medium">کد روم</label>
                          <div className="flex items-center gap-2">
                            <Input 
                              value={lobby.room.id}
                              readOnly
                              className="font-mono text-lg text-center"
                            />
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => copyToClipboard(lobby.room!.id)}
                            >
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="requirements" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>الزامات ورود</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {lobby.requirements && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {lobby.requirements.minLevel && (
                            <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                              <span>حداقل سطح</span>
                              <Badge variant="outline">سطح {lobby.requirements.minLevel}</Badge>
                            </div>
                          )}
                          
                          {lobby.requirements.ageRestriction && lobby.requirements.ageRestriction !== 'none' && (
                            <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                              <span>محدودیت سنی</span>
                              <Badge variant="outline">{lobby.requirements.ageRestriction}</Badge>
                            </div>
                          )}

                          {lobby.requirements.genderRestriction && lobby.requirements.genderRestriction !== 'none' && (
                            <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                              <span>محدودیت جنسیت</span>
                              <Badge variant="outline">
                                {lobby.requirements.genderRestriction === 'male' ? 'آقایان' :
                                 lobby.requirements.genderRestriction === 'female' ? 'خانم‌ها' : 'سایر'}
                              </Badge>
                            </div>
                          )}

                          {lobby.requirements.ranked && (
                            <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                              <span>نوع بازی</span>
                              <Badge variant="outline">رنک</Badge>
                            </div>
                          )}

                          {lobby.requirements.verified && (
                            <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                              <span>تأیید حساب</span>
                              <Badge className="bg-state-success text-white">الزامی</Badge>
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="settings" className="mt-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>تنظیمات لابی</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                          <span>تماشاگران مجاز</span>
                          <Badge variant={lobby.settings.allowSpectators ? 'default' : 'outline'}>
                            {lobby.settings.allowSpectators ? 'بله' : 'خیر'}
                          </Badge>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                          <span>شروع خودکار</span>
                          <Badge variant={lobby.settings.autoStart ? 'default' : 'outline'}>
                            {lobby.settings.autoStart ? 'فعال' : 'غیرفعال'}
                          </Badge>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                          <span>نیاز به آمادگی</span>
                          <Badge variant={lobby.settings.requireReady ? 'default' : 'outline'}>
                            {lobby.settings.requireReady ? 'الزامی' : 'اختیاری'}
                          </Badge>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                          <div className="flex items-center gap-2">
                            {lobby.settings.voiceChat ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                            <span>Voice Chat</span>
                          </div>
                          <Badge variant={lobby.settings.voiceChat ? 'default' : 'outline'}>
                            {lobby.settings.voiceChat ? 'فعال' : 'غیرفعال'}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            
            {/* Owner Card */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>میزبان لابی</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-3 mb-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={lobby.owner.avatar} />
                      <AvatarFallback>{lobby.owner.displayName[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">{lobby.owner.displayName}</span>
                        {lobby.owner.isVerified && <Crown className="h-4 w-4 text-brand-accent" />}
                      </div>
                      <div className="text-sm text-text-secondary">
                        @{lobby.owner.username}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div>
                      <div className="font-semibold">{lobby.owner.level}</div>
                      <div className="text-xs text-text-secondary">سطح</div>
                    </div>
                    <div>
                      <div className="font-semibold">{lobby.owner.gamesPlayed}</div>
                      <div className="text-xs text-text-secondary">بازی</div>
                    </div>
                    <div>
                      <div className="font-semibold">{lobby.owner.winRate}%</div>
                      <div className="text-xs text-text-secondary">برد</div>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full mt-4">
                    <MessageCircle className="h-4 w-4" />
                    پیام خصوصی
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Join Section */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="text-center">
                      <h3 className="font-semibold mb-2">پیوستن به لابی</h3>
                      <p className="text-sm text-text-secondary">
                        {lobby.game.joinMethod === 'direct' 
                          ? 'با یک کلیک وارد بازی شوید'
                          : 'کد لابی را کپی کنید'
                        }
                      </p>
                    </div>

                    {lobby.status === 'open' || lobby.status === 'nearfull' ? (
                      <Button 
                        onClick={handleJoinLobby}
                        loading={isJoining}
                        className="w-full bg-gradient-to-r from-brand-primary to-brand-secondary text-white"
                        size="lg"
                      >
                        <Play className="h-5 w-5" />
                        {lobby.game.joinMethod === 'direct' ? 'ورود مستقیم' : 'کپی کد و ورود'}
                      </Button>
                    ) : (
                      <Button disabled className="w-full" size="lg">
                        {lobby.status === 'starting' ? 'در حال شروع...' :
                         lobby.status === 'live' ? 'بازی شروع شده' :
                         lobby.status === 'full' ? 'لابی پر است' : 'غیرقابل دسترس'}
                      </Button>
                    )}

                    <div className="text-xs text-center text-text-tertiary">
                      ایجاد شده {lobby.createdAt}
                      {lobby.startTime && ` • شروع ${lobby.startTime}`}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Chat */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>چت لابی</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="h-64 overflow-y-auto p-4 space-y-3 gaming-scroll">
                    {lobby.chat.map((msg) => (
                      <div key={msg.id} className={`text-sm ${
                        msg.type === 'system' || msg.type === 'join' || msg.type === 'leave'
                          ? 'text-text-tertiary italic text-center'
                          : ''
                      }`}>
                        {msg.type === 'message' && (
                          <div className="space-y-1">
                            <div>
                              <span className="font-medium text-brand-primary">{msg.username}:</span>
                              <span className="mr-2">{msg.message}</span>
                            </div>
                            <div className="text-xs text-text-tertiary">{msg.timestamp}</div>
                          </div>
                        )}
                        {(msg.type === 'join' || msg.type === 'leave' || msg.type === 'system') && (
                          <div>{msg.message}</div>
                        )}
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>
                  
                  <div className="p-4 border-t border-border-primary">
                    <div className="flex gap-2">
                      <Input
                        placeholder="پیام خود را بنویسید..."
                        value={newMessage}
                        onChange={handleMessageInputChange}
                        onKeyPress={handleKeyPress}
                        className="flex-1"
                        disabled={sendingMessage}
                      />
                      <Button 
                        size="sm" 
                        onClick={handleSendMessage}
                        disabled={!newMessage.trim() || sendingMessage}
                        loading={sendingMessage}
                      >
                        ارسال
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Password Dialog */}
      <Dialog open={showJoinPassword} onOpenChange={setShowJoinPassword}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>ورود رمز لابی</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              type="password"
              placeholder="رمز لابی را وارد کنید"
              value={joinPassword}
              onChange={setJoinPassword}
            />
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => setShowJoinPassword(false)}
                className="flex-1"
              >
                انصراف
              </Button>
              <Button 
                onClick={handleJoinLobby}
                className="flex-1"
                disabled={!joinPassword}
              >
                تأیید
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Launch Notification */}
      {notification && (
        <GameLaunchNotification
          result={notification.result}
          gameIcon={notification.gameIcon}
          gameName={notification.gameName}
          onDismiss={hideNotification}
          onRetry={handleJoinLobby}
        />
      )}
    </div>
  );
}

export default LobbyDetailPageAdvanced;