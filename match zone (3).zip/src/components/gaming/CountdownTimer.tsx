import React, { useState, useEffect } from 'react';
import { cn } from '../ui/utils';

interface CountdownTimerProps {
  targetDate: Date;
  onComplete?: () => void;
  className?: string;
  compact?: boolean;
}

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export const CountdownTimer: React.FC<CountdownTimerProps> = ({
  targetDate,
  onComplete,
  className,
  compact = false,
}) => {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = targetDate.getTime() - new Date().getTime();
      
      if (difference <= 0) {
        setIsComplete(true);
        onComplete?.();
        return { days: 0, hours: 0, minutes: 0, seconds: 0 };
      }

      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    };

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    setTimeLeft(calculateTimeLeft());

    return () => clearInterval(timer);
  }, [targetDate, onComplete]);

  if (isComplete) {
    return (
      <div className={cn('text-destructive font-medium', className)}>
        زمان تمام شده
      </div>
    );
  }

  if (compact) {
    return (
      <div className={cn('font-mono text-lg font-medium', className)}>
        {timeLeft.days > 0 && `${timeLeft.days}d `}
        {String(timeLeft.hours).padStart(2, '0')}:
        {String(timeLeft.minutes).padStart(2, '0')}:
        {String(timeLeft.seconds).padStart(2, '0')}
      </div>
    );
  }

  return (
    <div className={cn('flex items-center gap-2', className)}>
      {timeLeft.days > 0 && (
        <div className="text-center">
          <div className="bg-primary text-primary-foreground rounded px-2 py-1 font-mono text-lg font-medium">
            {timeLeft.days}
          </div>
          <div className="text-xs text-muted-foreground mt-1">روز</div>
        </div>
      )}
      
      <div className="text-center">
        <div className="bg-primary text-primary-foreground rounded px-2 py-1 font-mono text-lg font-medium">
          {String(timeLeft.hours).padStart(2, '0')}
        </div>
        <div className="text-xs text-muted-foreground mt-1">ساعت</div>
      </div>
      
      <div className="text-muted-foreground text-lg">:</div>
      
      <div className="text-center">
        <div className="bg-primary text-primary-foreground rounded px-2 py-1 font-mono text-lg font-medium">
          {String(timeLeft.minutes).padStart(2, '0')}
        </div>
        <div className="text-xs text-muted-foreground mt-1">دقیقه</div>
      </div>
      
      <div className="text-muted-foreground text-lg">:</div>
      
      <div className="text-center">
        <div className="bg-primary text-primary-foreground rounded px-2 py-1 font-mono text-lg font-medium">
          {String(timeLeft.seconds).padStart(2, '0')}
        </div>
        <div className="text-xs text-muted-foreground mt-1">ثانیه</div>
      </div>
    </div>
  );
};