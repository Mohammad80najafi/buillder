import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

export function PropsNotesPage() {
  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8" dir="rtl">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">مستندات کامپوننت‌های Matchzone</h1>
        <p className="text-text-secondary">راهنمای کامل Props، Variants و States</p>
      </div>

      <Tabs defaultValue="base-components" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="base-components">کامپوننت‌های پایه</TabsTrigger>
          <TabsTrigger value="gaming-components">کامپوننت‌های گیمینگ</TabsTrigger>
          <TabsTrigger value="social-components">کامپوننت‌های اجتماعی</TabsTrigger>
          <TabsTrigger value="auth-components">کامپوننت‌های احراز هویت</TabsTrigger>
        </TabsList>

        {/* Base Components */}
        <TabsContent value="base-components" className="space-y-6">
          
          {/* Button Component */}
          <Card>
            <CardHeader>
              <CardTitle>📱 Button Component</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Props:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">نام</TableHead>
                      <TableHead className="text-right">نوع</TableHead>
                      <TableHead className="text-right">توضیحات</TableHead>
                      <TableHead className="text-right">مثال</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-mono">variant</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>نوع ظاهری دکمه</TableCell>
                      <TableCell className="font-mono">'primary' | 'secondary' | 'ghost' | 'danger'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">size</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>اندازه دکمه</TableCell>
                      <TableCell className="font-mono">'sm' | 'md' | 'lg'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">loading</TableCell>
                      <TableCell><Badge variant="outline">boolean</Badge></TableCell>
                      <TableCell>نمایش حالت بارگذاری</TableCell>
                      <TableCell className="font-mono">true | false</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">leftIcon</TableCell>
                      <TableCell><Badge variant="outline">ReactNode</Badge></TableCell>
                      <TableCell>آیکون سمت چپ (راست در RTL)</TableCell>
                      <TableCell className="font-mono"><Plus /></TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">rightIcon</TableCell>
                      <TableCell><Badge variant="outline">ReactNode</Badge></TableCell>
                      <TableCell>آیکون سمت راست (چپ در RTL)</TableCell>
                      <TableCell className="font-mono"><ArrowLeft /></TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Variants:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge>primary: دکمه اصلی با رنگ برند</Badge>
                  <Badge>secondary: دکمه ثانویه با حاشیه</Badge>
                  <Badge>ghost: دکمه شفاف بدون پس‌زمینه</Badge>
                  <Badge>danger: دکمه خطرناک قرمز رنگ</Badge>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">States:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge variant="outline">default: حالت عادی</Badge>
                  <Badge variant="outline">hover: هنگام هاور</Badge>
                  <Badge variant="outline">pressed: هنگام کلیک</Badge>
                  <Badge variant="outline">disabled: غیرفعال</Badge>
                  <Badge variant="outline">loading: در حال بارگذاری</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Input Component */}
          <Card>
            <CardHeader>
              <CardTitle>📝 Input Component</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Props:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">نام</TableHead>
                      <TableHead className="text-right">نوع</TableHead>
                      <TableHead className="text-right">توضیحات</TableHead>
                      <TableHead className="text-right">مثال</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-mono">state</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>وضعیت فیلد ورودی</TableCell>
                      <TableCell className="font-mono">'default' | 'error' | 'success' | 'disabled'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">leftIcon</TableCell>
                      <TableCell><Badge variant="outline">ReactNode</Badge></TableCell>
                      <TableCell>آیکون سمت چپ</TableCell>
                      <TableCell className="font-mono"><User /></TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">rightIcon</TableCell>
                      <TableCell><Badge variant="outline">ReactNode</Badge></TableCell>
                      <TableCell>آیکون سمت راست</TableCell>
                      <TableCell className="font-mono"><Search /></TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">helpText</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>متن کمکی</TableCell>
                      <TableCell className="font-mono">'نام کاربری خود را وارد کنید'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">errorText</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>متن خطا</TableCell>
                      <TableCell className="font-mono">'این فیلد الزامی است'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">successText</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>متن موفقیت</TableCell>
                      <TableCell className="font-mono">'نام کاربری معتبر است'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">label</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>برچسب فیلد</TableCell>
                      <TableCell className="font-mono">'نام کاربری'</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div>
                <h4 className="font-semibold mb-2">States:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge variant="outline">default: حالت عادی</Badge>
                  <Badge variant="outline">error: حالت خطا</Badge>
                  <Badge variant="outline">success: حالت موفقیت</Badge>
                  <Badge variant="outline">disabled: غیرفعال</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

        </TabsContent>

        {/* Gaming Components */}
        <TabsContent value="gaming-components" className="space-y-6">
          
          {/* LobbyCard Component */}
          <Card>
            <CardHeader>
              <CardTitle>🎮 LobbyCard Component</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Props:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">نام</TableHead>
                      <TableHead className="text-right">نوع</TableHead>
                      <TableHead className="text-right">توضیحات</TableHead>
                      <TableHead className="text-right">مثال</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-mono">id</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>شناسه یکتای لابی</TableCell>
                      <TableCell className="font-mono">'lobby-123'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">title</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>عنوان لابی</TableCell>
                      <TableCell className="font-mono">'مسابقه تیمی حرفه‌ای'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">game</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>نام بازی</TableCell>
                      <TableCell className="font-mono">'Call of Duty'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">status</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>وضعیت لابی</TableCell>
                      <TableCell className="font-mono">'open' | 'nearfull' | 'full' | 'closed'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">ownerTrust</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>سطح اعتماد مالک</TableCell>
                      <TableCell className="font-mono">'low' | 'mid' | 'high'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">visibility</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>قابلیت مشاهده</TableCell>
                      <TableCell className="font-mono">'public' | 'private'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">currentPlayers</TableCell>
                      <TableCell><Badge variant="outline">number</Badge></TableCell>
                      <TableCell>تعداد بازیکنان فعلی</TableCell>
                      <TableCell className="font-mono">3</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">maxPlayers</TableCell>
                      <TableCell><Badge variant="outline">number</Badge></TableCell>
                      <TableCell>حداکثر بازیکنان</TableCell>
                      <TableCell className="font-mono">4</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">owner</TableCell>
                      <TableCell><Badge variant="outline">UserSummary</Badge></TableCell>
                      <TableCell>اطلاعات مالک لابی</TableCell>
                      <TableCell className="font-mono">&#123; id, username, avatar, trustLevel &#125;</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Status Variants:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge className="bg-state-success">open: لابی باز و قابل پیوستن</Badge>
                  <Badge className="bg-state-warning">nearfull: نزدیک به پر شدن</Badge>
                  <Badge variant="secondary">full: لابی پر شده</Badge>
                  <Badge variant="outline">closed: لابی بسته شده</Badge>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Owner Trust Levels:</h4>
                <div className="grid grid-cols-3 gap-2">
                  <Badge variant="outline">low: اعتماد پایین</Badge>
                  <Badge className="bg-state-info">mid: اعتماد متوسط</Badge>
                  <Badge className="bg-state-success">high: اعتماد بالا</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* TournamentCard Component */}
          <Card>
            <CardHeader>
              <CardTitle>🏆 TournamentCard Component</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Props:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">نام</TableHead>
                      <TableHead className="text-right">نوع</TableHead>
                      <TableHead className="text-right">توضیحات</TableHead>
                      <TableHead className="text-right">مثال</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-mono">status</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>وضعیت مسابقه</TableCell>
                      <TableCell className="font-mono">'draft' | 'registration' | 'live' | 'ended'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">spotsTotal</TableCell>
                      <TableCell><Badge variant="outline">number</Badge></TableCell>
                      <TableCell>کل ظرفیت مسابقه</TableCell>
                      <TableCell className="font-mono">32</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">spotsFilled</TableCell>
                      <TableCell><Badge variant="outline">number</Badge></TableCell>
                      <TableCell>تعداد ثبت‌نام شده</TableCell>
                      <TableCell className="font-mono">24</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Status Variants:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge variant="outline">draft: پیش‌نویس</Badge>
                  <Badge className="bg-state-info">registration: ثبت‌نام باز</Badge>
                  <Badge className="bg-state-danger">live: در حال برگزاری</Badge>
                  <Badge variant="secondary">ended: پایان یافته</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

        </TabsContent>

        {/* Social Components */}
        <TabsContent value="social-components" className="space-y-6">
          
          {/* MessageBubble Component */}
          <Card>
            <CardHeader>
              <CardTitle>💬 MessageBubble Component</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Props:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">نام</TableHead>
                      <TableHead className="text-right">نوع</TableHead>
                      <TableHead className="text-right">توضیحات</TableHead>
                      <TableHead className="text-right">مثال</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-mono">kind</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>نوع پیام</TableCell>
                      <TableCell className="font-mono">'text' | 'image' | 'sticker' | 'system'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">mine</TableCell>
                      <TableCell><Badge variant="outline">boolean</Badge></TableCell>
                      <TableCell>پیام متعلق به خودم است</TableCell>
                      <TableCell className="font-mono">true | false</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">compact</TableCell>
                      <TableCell><Badge variant="outline">boolean</Badge></TableCell>
                      <TableCell>نمایش فشرده</TableCell>
                      <TableCell className="font-mono">true | false</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">content</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>محتوای پیام</TableCell>
                      <TableCell className="font-mono">'سلام، چطوری؟'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">user</TableCell>
                      <TableCell><Badge variant="outline">UserInfo</Badge></TableCell>
                      <TableCell>اطلاعات فرستنده</TableCell>
                      <TableCell className="font-mono">&#123; id, username, avatar, role &#125;</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">reactions</TableCell>
                      <TableCell><Badge variant="outline">array</Badge></TableCell>
                      <TableCell>واکنش‌های پیام</TableCell>
                      <TableCell className="font-mono">[&#123; emoji: "👍", count: 3, userReacted: true &#125;]</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Kind Variants:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge>text: پیام متنی</Badge>
                  <Badge>image: پیام تصویری</Badge>
                  <Badge>sticker: استیکر</Badge>
                  <Badge>system: پیام سیستمی</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* LiveRebroadcastCard Component */}
          <Card>
            <CardHeader>
              <CardTitle>📺 LiveRebroadcastCard Component</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Props:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">نام</TableHead>
                      <TableHead className="text-right">نوع</TableHead>
                      <TableHead className="text-right">توضیحات</TableHead>
                      <TableHead className="text-right">مثال</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-mono">id</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>شناسه یکتای پخش</TableCell>
                      <TableCell className="font-mono">'stream-456'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">creator</TableCell>
                      <TableCell><Badge variant="outline">UserSummary</Badge></TableCell>
                      <TableCell>اطلاعات کریتور</TableCell>
                      <TableCell className="font-mono">&#123; id, username, avatar, isVerified &#125;</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">title</TableCell>
                      <TableCell><Badge variant="outline">string</Badge></TableCell>
                      <TableCell>عنوان پخش</TableCell>
                      <TableCell className="font-mono">'پخش زنده بازی CS2'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">source</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>منبع پخش</TableCell>
                      <TableCell className="font-mono">'youtube' | 'aparat' | 'twitch' | 'kick'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">sourceUrl</TableCell>
                      <TableCell><Badge variant="outline">URL</Badge></TableCell>
                      <TableCell>لینک منبع</TableCell>
                      <TableCell className="font-mono">'https://youtube.com/watch?v=...'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">isLive</TableCell>
                      <TableCell><Badge variant="outline">boolean</Badge></TableCell>
                      <TableCell>آیا زنده است</TableCell>
                      <TableCell className="font-mono">true | false</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">currentViewers</TableCell>
                      <TableCell><Badge variant="outline">number</Badge></TableCell>
                      <TableCell>تعداد بیننده‌های فعلی</TableCell>
                      <TableCell className="font-mono">1250</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">sessionViews</TableCell>
                      <TableCell><Badge variant="outline">number</Badge></TableCell>
                      <TableCell>کل بازدید جلسه</TableCell>
                      <TableCell className="font-mono">5430</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">startedAt</TableCell>
                      <TableCell><Badge variant="outline">ISODate</Badge></TableCell>
                      <TableCell>زمان شروع</TableCell>
                      <TableCell className="font-mono">'2024-01-15T10:30:00Z'</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Source Variants:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge className="bg-red-500">youtube: یوتیوب</Badge>
                  <Badge className="bg-blue-500">aparat: آپارات</Badge>
                  <Badge className="bg-purple-500">twitch: تویچ</Badge>
                  <Badge className="bg-green-500">kick: کیک</Badge>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">State Variants:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge className="bg-state-success">live: در حال پخش زنده</Badge>
                  <Badge variant="secondary">ended: پایان یافته</Badge>
                  <Badge variant="outline">loading: در حال بارگذاری</Badge>
                  <Badge className="bg-state-danger">error: خطا در بارگذاری</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

        </TabsContent>

        {/* Auth Components */}
        <TabsContent value="auth-components" className="space-y-6">
          
          {/* SignupDemographicsForm Component */}
          <Card>
            <CardHeader>
              <CardTitle>👤 SignupDemographicsForm Component</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Props:</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">نام</TableHead>
                      <TableHead className="text-right">نوع</TableHead>
                      <TableHead className="text-right">توضیحات</TableHead>
                      <TableHead className="text-right">مثال</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-mono">gender</TableCell>
                      <TableCell><Badge variant="outline">enum</Badge></TableCell>
                      <TableCell>جنسیت کاربر</TableCell>
                      <TableCell className="font-mono">'female' | 'male' | 'prefer_not' | 'custom'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">genderCustom</TableCell>
                      <TableCell><Badge variant="outline">string?</Badge></TableCell>
                      <TableCell>جنسیت سفارشی</TableCell>
                      <TableCell className="font-mono">'غیربایناری'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">birthDate</TableCell>
                      <TableCell><Badge variant="outline">ISODate</Badge></TableCell>
                      <TableCell>تاریخ تولد</TableCell>
                      <TableCell className="font-mono">'1995-06-15'</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">privacy</TableCell>
                      <TableCell><Badge variant="outline">object</Badge></TableCell>
                      <TableCell>تنظیمات حریم خصوصی</TableCell>
                      <TableCell className="font-mono">&#123; showGender: boolean, showAge: boolean &#125;</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">minAge</TableCell>
                      <TableCell><Badge variant="outline">number</Badge></TableCell>
                      <TableCell>حداقل سن مجاز</TableCell>
                      <TableCell className="font-mono">13</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">onSubmit</TableCell>
                      <TableCell><Badge variant="outline">function</Badge></TableCell>
                      <TableCell>تابع ارسال فرم</TableCell>
                      <TableCell className="font-mono">(data) => void</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">onBack</TableCell>
                      <TableCell><Badge variant="outline">function?</Badge></TableCell>
                      <TableCell>تابع بازگشت</TableCell>
                      <TableCell className="font-mono">() => void</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-mono">isLoading</TableCell>
                      <TableCell><Badge variant="outline">boolean</Badge></TableCell>
                      <TableCell>حالت بارگذاری</TableCell>
                      <TableCell className="font-mono">true | false</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Gender Options:</h4>
                <div className="grid grid-cols-2 gap-2">
                  <Badge>female: زن</Badge>
                  <Badge>male: مرد</Badge>
                  <Badge>prefer_not: ترجیح می‌دهم نگویم</Badge>
                  <Badge>custom: سایر (نیاز به genderCustom)</Badge>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Privacy Object Structure:</h4>
                <div className="bg-surface-secondary p-4 rounded-lg font-mono text-sm">
                  <div>privacy: &#123;</div>
                  <div className="ml-4">showGender: boolean, // نمایش جنسیت در پروفایل</div>
                  <div className="ml-4">showAge: boolean     // نمایش سن در پروفایل</div>
                  <div>&#125;</div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">Validation Rules:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm text-text-secondary">
                  <li>تاریخ تولد الزامی است</li>
                  <li>سن باید بیشتر از minAge باشد</li>
                  <li>اگر gender = 'custom'، genderCustom الزامی است</li>
                  <li>تاریخ نباید از امروز بیشتر باشد</li>
                </ul>
              </div>
            </CardContent>
          </Card>

        </TabsContent>
      </Tabs>

      {/* Common Patterns */}
      <Card>
        <CardHeader>
          <CardTitle>🔧 الگوهای مشترک</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold mb-2">UserSummary Interface:</h4>
            <div className="bg-surface-secondary p-4 rounded-lg font-mono text-sm">
              <div>interface UserSummary &#123;</div>
              <div className="ml-4">id: string;</div>
              <div className="ml-4">username: string;</div>
              <div className="ml-4">avatar?: string;</div>
              <div className="ml-4">isVerified?: boolean;</div>
              <div className="ml-4">trustLevel?: 'low' | 'mid' | 'high';</div>
              <div className="ml-4">followerCount?: number;</div>
              <div>&#125;</div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Common States:</h4>
            <div className="grid grid-cols-3 gap-2">
              <Badge variant="outline">loading: در حال بارگذاری</Badge>
              <Badge variant="outline">empty: خالی</Badge>
              <Badge variant="outline">error: خطا</Badge>
              <Badge variant="outline">success: موفقیت</Badge>
              <Badge variant="outline">disabled: غیرفعال</Badge>
              <Badge variant="outline">hover: هاور</Badge>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-2">RTL Support:</h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-text-secondary">
              <li>تمام کامپوننت‌ها از dir="rtl" پشتیبانی می‌کنند</li>
              <li>آیکون‌های چپ/راست بر اساس RTL تنظیم می‌شوند</li>
              <li>text-align به صورت پیش‌فرض راست است</li>
              <li>فلکس باکس‌ها با flex-row-reverse کار می‌کنند</li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-2">Accessibility:</h4>
            <ul className="list-disc list-inside space-y-1 text-sm text-text-secondary">
              <li>تمام کامپوننت‌ها WCAG AA سازگار هستند</li>
              <li>کنتراست رنگ‌ها حداقل 4.5:1 است</li>
              <li>پشتیبانی از کیبورد navigation</li>
              <li>مناسب برای screen readers</li>
              <li>پشتیبانی از prefers-reduced-motion</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}