import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from './utils';

const inputVariants = cva(
  [
    "flex w-full rounded-md border px-3 py-2 text-sm transition-colors",
    "file:border-0 file:bg-transparent file:text-sm file:font-medium",
    "placeholder:text-text-tertiary",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
    "disabled:cursor-not-allowed disabled:opacity-50",
    "text-right" // RTL support
  ],
  {
    variants: {
      state: {
        default: [
          "border-border-primary bg-surface-primary text-text-primary",
          "hover:border-border-secondary",
          "focus:border-brand-primary"
        ],
        error: [
          "border-state-danger bg-state-danger-bg text-text-primary",
          "focus:border-state-danger focus:ring-state-danger"
        ],
        success: [
          "border-state-success bg-state-success-bg text-text-primary",
          "focus:border-state-success focus:ring-state-success"
        ],
        disabled: [
          "border-border-muted bg-surface-secondary text-text-tertiary cursor-not-allowed"
        ]
      },
      hasIcon: {
        none: "",
        left: "pr-10", // RTL: padding right for left icon
        right: "pl-10", // RTL: padding left for right icon
        both: "px-10"
      }
    },
    defaultVariants: {
      state: "default",
      hasIcon: "none"
    }
  }
);

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement>,
    VariantProps<typeof inputVariants> {
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  helpText?: string;
  errorText?: string;
  successText?: string;
  label?: string;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ 
    className, 
    state, 
    hasIcon, 
    leftIcon, 
    rightIcon, 
    helpText, 
    errorText, 
    successText, 
    label,
    disabled,
    ...props 
  }, ref) => {
    const iconPosition = leftIcon && rightIcon ? 'both' : leftIcon ? 'left' : rightIcon ? 'right' : 'none';
    const inputState = disabled ? 'disabled' : errorText ? 'error' : successText ? 'success' : state;
    
    return (
      <div className="space-y-2" dir="rtl">
        {label && (
          <label className="text-sm font-medium text-text-primary">
            {label}
          </label>
        )}
        
        <div className="relative">
          {leftIcon && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-tertiary">
              {leftIcon}
            </div>
          )}
          
          <input
            className={cn(inputVariants({ 
              state: inputState, 
              hasIcon: iconPosition, 
              className 
            }))}
            ref={ref}
            disabled={disabled}
            dir="rtl"
            {...props}
          />
          
          {rightIcon && (
            <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-tertiary">
              {rightIcon}
            </div>
          )}
        </div>
        
        {(helpText || errorText || successText) && (
          <p className={cn(
            "text-xs",
            errorText ? "text-state-danger" : 
            successText ? "text-state-success" : 
            "text-text-secondary"
          )}>
            {errorText || successText || helpText}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = "Input";

export { Input, inputVariants };