/**
 * Touch-Friendly Button
 * دکمه بهینه شده برای لمس
 */

import React from 'react';
import { Button, ButtonProps } from './button';
import { cn } from '../../lib/utils';

interface TouchFriendlyButtonProps extends ButtonProps {
  /** Minimum touch target size (default: 44px) */
  minTouchSize?: number;
  /** Add haptic feedback on touch */
  hapticFeedback?: boolean;
}

export function TouchFriendlyButton({
  className,
  minTouchSize = 44,
  hapticFeedback = false,
  onClick,
  children,
  ...props
}: TouchFriendlyButtonProps) {
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // Add haptic feedback for mobile devices
    if (hapticFeedback && 'vibrate' in navigator) {
      navigator.vibrate(10); // Very short vibration
    }
    
    onClick?.(e);
  };

  return (
    <Button
      className={cn(
        // Ensure minimum touch target size
        `min-h-[${minTouchSize}px] min-w-[${minTouchSize}px]`,
        // Better touch responsiveness
        'active:scale-95 transition-transform duration-100',
        // Prevent text selection on touch
        'select-none touch-manipulation',
        className
      )}
      onClick={handleClick}
      {...props}
    >
      {children}
    </Button>
  );
}

export default TouchFriendlyButton;