import React from 'react';
import { cn } from './utils';

export type Status = 'online' | 'away' | 'busy' | 'offline' | 'in-game';

interface StatusIndicatorProps {
  status: Status;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}

const statusConfig: Record<Status, { color: string; label: string; bgColor: string }> = {
  online: { color: 'bg-green-500', label: 'آنلاین', bgColor: 'text-green-700' },
  away: { color: 'bg-yellow-500', label: 'غایب', bgColor: 'text-yellow-700' },
  busy: { color: 'bg-red-500', label: 'مشغول', bgColor: 'text-red-700' },
  offline: { color: 'bg-gray-400', label: 'آفلاین', bgColor: 'text-gray-700' },
  'in-game': { color: 'bg-blue-500', label: 'در بازی', bgColor: 'text-blue-700' },
};

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status,
  size = 'md',
  showLabel = false,
  className,
}) => {
  const config = statusConfig[status];
  
  const sizes = {
    sm: 'w-2 h-2',
    md: 'w-3 h-3',
    lg: 'w-4 h-4',
  };

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <div
        className={cn(
          'rounded-full ring-2 ring-background',
          config.color,
          sizes[size]
        )}
      />
      {showLabel && (
        <span className={cn('text-sm font-medium', config.bgColor)}>
          {config.label}
        </span>
      )}
    </div>
  );
};