/**
 * Mobile Chat Header
 * هدر چت بهینه شده برای موبایل
 */

import React from 'react';
import { motion } from 'motion/react';
import { MessageCircle, Filter, Plus, Search } from 'lucide-react';
import { Button } from './button';
import { Input } from './input';
import { Sheet, SheetContent, SheetTrigger } from './sheet';

interface MobileChatHeaderProps {
  totalChats: number;
  unreadCount: number;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onNewChat: () => void;
  showFilters: boolean;
  onShowFilters: (show: boolean) => void;
  filterPanel: React.ReactNode;
}

export function MobileChatHeader({
  totalChats,
  unreadCount,
  searchQuery,
  onSearchChange,
  onNewChat,
  showFilters,
  onShowFilters,
  filterPanel
}: MobileChatHeaderProps) {
  return (
    <motion.div
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border/50 mobile-safe-area"
    >
      <div className="p-4 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0 flex-1">
            <div className="p-2 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex-shrink-0">
              <MessageCircle className="h-6 w-6 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-lg font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent truncate">
                مرکز ارتباطات
              </h1>
              <p className="text-xs text-muted-foreground truncate">
                {totalChats} چت {unreadCount > 0 && `• ${unreadCount} جدید`}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 rtl:space-x-reverse flex-shrink-0">
            <Sheet open={showFilters} onOpenChange={onShowFilters}>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="mobile-touch-target relative">
                  <Filter className="h-4 w-4" />
                  {unreadCount > 0 && (
                    <div className="absolute -top-1 -right-1 h-2 w-2 bg-blue-500 rounded-full animate-pulse" />
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                {filterPanel}
              </SheetContent>
            </Sheet>
            
            <Button 
              size="sm"
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 mobile-touch-target px-3"
              onClick={onNewChat}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
          <Input
            placeholder="جستجو در چت‌ها..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pr-10 text-right mobile-input bg-surface-secondary/50 border-border/50 focus:border-blue-500/50"
            dir="rtl"
          />
        </div>
      </div>
    </motion.div>
  );
}

export default MobileChatHeader;