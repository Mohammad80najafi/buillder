import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { Loader2 } from 'lucide-react';
import { cn } from './utils';

const buttonVariants = cva(
  [
    "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-semibold transition-colors",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
    "disabled:pointer-events-none disabled:opacity-50",
    "[&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0"
  ],
  {
    variants: {
      variant: {
        primary: [
          "bg-brand-primary text-white shadow-sm",
          "hover:bg-brand-primary/90",
          "active:bg-brand-primary/80"
        ],
        secondary: [
          "bg-surface-secondary text-text-primary border border-border-primary",
          "hover:bg-surface-tertiary",
          "active:bg-surface-tertiary/80"
        ],
        ghost: [
          "text-text-primary",
          "hover:bg-surface-secondary",
          "active:bg-surface-tertiary"
        ],
        danger: [
          "bg-state-danger text-white shadow-sm",
          "hover:bg-state-danger/90",
          "active:bg-state-danger/80"
        ]
      },
      size: {
        sm: "h-8 px-3 text-xs",
        md: "h-10 px-4 text-sm",
        lg: "h-12 px-6 text-base"
      },
      state: {
        default: "",
        loading: "pointer-events-none"
      },
      icon: {
        none: "",
        left: "flex-row-reverse", // RTL: icon on right
        right: "flex-row" // RTL: icon on left
      }
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
      state: "default",
      icon: "none"
    }
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  loading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, state, icon, loading, leftIcon, rightIcon, children, disabled, ...props }, ref) => {
    const isLoading = loading || state === 'loading';
    const iconPosition = leftIcon ? 'left' : rightIcon ? 'right' : 'none';
    
    return (
      <button
        className={cn(buttonVariants({ variant, size, state: isLoading ? 'loading' : state, icon: iconPosition, className }))}
        ref={ref}
        disabled={disabled || isLoading}
        dir="rtl"
        {...props}
      >
        {isLoading && <Loader2 className="animate-spin" />}
        {!isLoading && leftIcon && leftIcon}
        {children}
        {!isLoading && rightIcon && rightIcon}
      </button>
    );
  }
);

Button.displayName = "Button";

export { Button, buttonVariants };