import React from 'react';
import { 
  Users, CheckCircle, Crown, Star, Gamepad2,
  MessageCircle, UserPlus, Eye, Trophy
} from 'lucide-react';
import { Button } from './mz-button';
import { Badge } from './badge';
import { Avatar, AvatarFallback, AvatarImage } from './avatar';
import { Card, CardContent } from './card';

interface UserCardProps {
  user: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    verified?: boolean;
    level: string;
    followers?: number;
    isOnline?: boolean;
    bio?: string;
    favoriteGame?: string;
    recentAchievement?: string;
    clanName?: string;
  };
  variant?: 'compact' | 'detailed' | 'minimal';
  showActions?: boolean;
  onProfileClick?: (userId: string) => void;
  onMessageClick?: (userId: string) => void;
  onFollowClick?: (userId: string) => void;
  className?: string;
}

export function UserCard({ 
  user, 
  variant = 'detailed', 
  showActions = true,
  onProfileClick,
  onMessageClick,
  onFollowClick,
  className = ''
}: UserCardProps) {
  
  const formatNumber = (num?: number): string => {
    if (!num) return '0';
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  const handleProfileClick = () => {
    onProfileClick?.(user.id);
  };

  // Compact variant - برای لیست‌های کوچک
  if (variant === 'compact') {
    return (
      <div 
        className={`flex items-center gap-3 p-3 hover:bg-muted/50 rounded-lg cursor-pointer transition-colors ${className}`}
        onClick={handleProfileClick}
      >
        <div className="relative">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          {user.isOnline && (
            <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 bg-green-500 border-2 border-background rounded-full" />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-sm truncate">{user.name}</h3>
            {user.verified && (
              <CheckCircle className="h-3 w-3 text-blue-500 flex-shrink-0" />
            )}
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <span>{user.username}</span>
            <span>•</span>
            <Badge variant="secondary" className="text-xs px-1 py-0">{user.level}</Badge>
          </div>
        </div>

        {showActions && (
          <div className="flex gap-1">
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={(e) => { e.stopPropagation(); onMessageClick?.(user.id); }}>
              <MessageCircle className="h-3 w-3" />
            </Button>
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={(e) => { e.stopPropagation(); onFollowClick?.(user.id); }}>
              <UserPlus className="h-3 w-3" />
            </Button>
          </div>
        )}
      </div>
    );
  }

  // Minimal variant - برای preview ها
  if (variant === 'minimal') {
    return (
      <div 
        className={`flex items-center gap-2 cursor-pointer ${className}`}
        onClick={handleProfileClick}
      >
        <Avatar className="h-6 w-6">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback className="text-xs">{user.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <span className="text-sm font-medium truncate">{user.name}</span>
        {user.verified && (
          <CheckCircle className="h-3 w-3 text-blue-500 flex-shrink-0" />
        )}
      </div>
    );
  }

  // Detailed variant - کارت کامل
  return (
    <Card className={`hover:shadow-md transition-all duration-200 cursor-pointer ${className}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="relative" onClick={handleProfileClick}>
            <Avatar className="h-12 w-12 md:h-14 md:w-14">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback className="text-lg">{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            {user.isOnline && (
              <div className="absolute -bottom-1 -right-1 h-4 w-4 bg-green-500 border-2 border-background rounded-full" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1" onClick={handleProfileClick}>
              <h3 className="font-semibold truncate hover:text-primary transition-colors">
                {user.name}
              </h3>
              {user.verified && (
                <CheckCircle className="h-4 w-4 text-blue-500 flex-shrink-0" />
              )}
            </div>

            <div className="flex items-center gap-2 mb-2 text-sm text-muted-foreground">
              <span>{user.username}</span>
              <span>•</span>
              <Badge variant="secondary" className="text-xs">{user.level}</Badge>
              {user.followers && (
                <>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    {formatNumber(user.followers)}
                  </span>
                </>
              )}
            </div>

            {user.bio && (
              <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                {user.bio}
              </p>
            )}

            {/* Additional info */}
            <div className="flex flex-wrap gap-2 mb-3 text-xs">
              {user.favoriteGame && (
                <Badge variant="outline" className="text-xs">
                  <Gamepad2 className="h-2.5 w-2.5 mr-1" />
                  {user.favoriteGame}
                </Badge>
              )}
              {user.clanName && (
                <Badge variant="outline" className="text-xs">
                  <Crown className="h-2.5 w-2.5 mr-1" />
                  {user.clanName}
                </Badge>
              )}
              {user.recentAchievement && (
                <Badge variant="outline" className="text-xs">
                  <Trophy className="h-2.5 w-2.5 mr-1" />
                  {user.recentAchievement}
                </Badge>
              )}
            </div>

            {showActions && (
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={handleProfileClick}
                >
                  <Eye className="h-3 w-3 ml-1" />
                  مشاهده پروفایل
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={(e) => { e.stopPropagation(); onMessageClick?.(user.id); }}
                >
                  <MessageCircle className="h-3 w-3" />
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={(e) => { e.stopPropagation(); onFollowClick?.(user.id); }}
                >
                  <UserPlus className="h-3 w-3" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default UserCard;