/**
 * Copyable Field Component
 * A reusable field component with built-in copy functionality
 */

import React from 'react';
import { Input } from './input';
import { Button } from './button';
import { Copy, Check, AlertTriangle } from 'lucide-react';
import { useClipboard } from '../../hooks/useClipboard';
import { toast } from 'sonner@2.0.3';
import { cn } from '../../lib/utils';

interface CopyableFieldProps {
  value: string;
  label?: string;
  placeholder?: string;
  className?: string;
  inputClassName?: string;
  buttonClassName?: string;
  readonly?: boolean;
  successMessage?: string;
  errorMessage?: string;
  showCopyButton?: boolean;
  variant?: 'default' | 'inline' | 'separated';
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export function CopyableField({
  value,
  label,
  placeholder,
  className,
  inputClassName,
  buttonClassName,
  readonly = true,
  successMessage = 'کپی شد!',
  errorMessage = 'خطا در کپی',
  showCopyButton = true,
  variant = 'default',
  onChange
}: CopyableFieldProps) {
  const { copy, copied, error } = useClipboard({
    onSuccess: (method) => {
      toast.success(successMessage, {
        description: `روش کپی: ${method === 'clipboard-api' ? 'مدرن' : 
                     method === 'execCommand' ? 'سنتی' : 'انتخاب متن'}`,
        duration: 1500
      });
    },
    onError: (error) => {
      toast.error(errorMessage, {
        description: error,
        action: {
          label: 'کپی دستی',
          onClick: () => {
            // Create a modal or alert with the value for manual copy
            const div = document.createElement('div');
            div.style.position = 'fixed';
            div.style.top = '50%';
            div.style.left = '50%';
            div.style.transform = 'translate(-50%, -50%)';
            div.style.backgroundColor = '#1A1D24';
            div.style.border = '2px solid #3B82F6';
            div.style.borderRadius = '12px';
            div.style.padding = '16px';
            div.style.zIndex = '10000';
            div.style.color = '#E5E7EB';
            div.style.fontFamily = 'monospace';
            div.style.maxWidth = '90vw';
            div.style.wordBreak = 'break-all';
            div.innerHTML = `
              <div style="margin-bottom: 8px; font-weight: bold;">کپی دستی:</div>
              <div style="background: #242831; padding: 8px; border-radius: 6px; margin-bottom: 12px;">${value}</div>
              <button onclick="this.parentElement.remove()" style="background: #3B82F6; color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer;">بستن</button>
            `;
            document.body.appendChild(div);
            
            setTimeout(() => {
              if (document.body.contains(div)) {
                document.body.removeChild(div);
              }
            }, 10000);
          }
        }
      });
    }
  });

  const handleCopy = () => {
    if (value) {
      copy(value);
    }
  };

  const getIcon = () => {
    if (copied) return <Check className="w-4 h-4 text-green-500" />;
    if (error) return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
    return <Copy className="w-4 h-4" />;
  };

  if (variant === 'inline') {
    return (
      <div className={cn('flex items-center gap-2', className)}>
        {label && <span className="text-sm font-medium text-slate-400">{label}:</span>}
        <code className="bg-slate-700 px-2 py-1 rounded text-sm font-mono flex-1">
          {value || placeholder}
        </code>
        {showCopyButton && value && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleCopy}
            className={cn(
              'h-8 w-8 p-0 transition-colors',
              copied && 'border-green-500/50 bg-green-500/10',
              error && 'border-yellow-500/50 bg-yellow-500/10',
              buttonClassName
            )}
          >
            {getIcon()}
          </Button>
        )}
      </div>
    );
  }

  if (variant === 'separated') {
    return (
      <div className={cn('space-y-2', className)}>
        {label && <label className="text-sm font-medium">{label}</label>}
        <div className="flex gap-2">
          <Input
            value={value}
            placeholder={placeholder}
            readOnly={readonly}
            onChange={onChange}
            className={cn('flex-1', inputClassName)}
          />
          {showCopyButton && (
            <Button
              type="button"
              variant="outline"
              onClick={handleCopy}
              disabled={!value}
              className={cn(
                'px-3 transition-colors',
                copied && 'border-green-500/50 bg-green-500/10',
                error && 'border-yellow-500/50 bg-yellow-500/10',
                buttonClassName
              )}
            >
              {getIcon()}
            </Button>
          )}
        </div>
      </div>
    );
  }

  // Default variant
  return (
    <div className={cn('space-y-2', className)}>
      {label && <label className="text-sm font-medium">{label}</label>}
      <div className="relative">
        <Input
          value={value}
          placeholder={placeholder}
          readOnly={readonly}
          onChange={onChange}
          className={cn('pr-10', inputClassName)}
        />
        {showCopyButton && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleCopy}
            disabled={!value}
            className={cn(
              'absolute left-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0 transition-colors',
              copied && 'text-green-500',
              error && 'text-yellow-500',
              buttonClassName
            )}
          >
            {getIcon()}
          </Button>
        )}
      </div>
    </div>
  );
}