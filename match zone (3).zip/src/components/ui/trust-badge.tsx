import React from 'react';
import { cn } from './utils';
import { Badge } from './badge';

export type TrustLevel = 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond';

interface TrustBadgeProps {
  level: TrustLevel;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const trustLevels: Record<TrustLevel, { color: string; label: string; bgColor: string }> = {
  bronze: { color: 'text-amber-700', label: 'برنزی', bgColor: 'bg-amber-100 dark:bg-amber-900/20' },
  silver: { color: 'text-gray-700', label: 'نقره‌ای', bgColor: 'bg-gray-100 dark:bg-gray-900/20' },
  gold: { color: 'text-yellow-700', label: 'طلایی', bgColor: 'bg-yellow-100 dark:bg-yellow-900/20' },
  platinum: { color: 'text-indigo-700', label: 'پلاتینیوم', bgColor: 'bg-indigo-100 dark:bg-indigo-900/20' },
  diamond: { color: 'text-blue-700', label: 'الماسی', bgColor: 'bg-blue-100 dark:bg-blue-900/20' },
};

export const TrustBadge: React.FC<TrustBadgeProps> = ({
  level,
  showLabel = true,
  size = 'md',
  className,
}) => {
  const config = trustLevels[level];
  
  const sizes = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-2.5 py-1',
    lg: 'text-base px-3 py-1.5',
  };

  return (
    <Badge
      className={cn(
        'font-medium border-0',
        config.color,
        config.bgColor,
        sizes[size],
        className
      )}
    >
      {showLabel ? config.label : level.toUpperCase()}
    </Badge>
  );
};