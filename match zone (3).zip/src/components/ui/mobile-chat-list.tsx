/**
 * Mobile Chat List Component
 * کامپوننت لیست چت موبایل
 */

import React from 'react';
import { motion } from 'motion/react';
import { 
  Pin, 
  Volume2, 
  Hash, 
  ChevronRight, 
  Eye,
  Users
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './avatar';
import { Badge } from './badge';

interface ChatItem {
  id: string;
  name: string;
  type: 'group' | 'direct' | 'support' | 'clan' | 'gaming' | 'tournament';
  avatar?: string;
  gradient?: string;
  lastMessage: {
    content: string;
    timestamp: string;
    sender: string;
    type: 'text' | 'image' | 'voice' | 'game' | 'system';
  };
  unreadCount: number;
  isOnline?: boolean;
  members?: number;
  isPinned?: boolean;
  isActive?: boolean;
  status?: 'active' | 'resolved' | 'pending' | 'live' | 'scheduled';
  clanTag?: string;
  liveUsers?: number;
  mood?: 'happy' | 'focused' | 'competitive' | 'chill';
  voiceChannelActive?: boolean;
  isTyping?: boolean;
}

interface MobileChatListProps {
  chats: ChatItem[];
  selectedChatId?: string | null;
  onChatSelect: (chatId: string) => void;
}

export function MobileChatList({ chats, selectedChatId, onChatSelect }: MobileChatListProps) {
  const getMoodEmoji = (mood?: string) => {
    switch (mood) {
      case 'happy': return '😊';
      case 'focused': return '🎯';
      case 'competitive': return '🔥';
      case 'chill': return '😎';
      default: return '💬';
    }
  };

  return (
    <div className="divide-y divide-border/30">
      {chats.map((chat, index) => (
        <motion.div
          key={chat.id}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.05 }}
          whileTap={{ scale: 0.98 }}
          className="group"
        >
          <div 
            className={`
              flex items-center p-4 cursor-pointer transition-all duration-200
              ${selectedChatId === chat.id 
                ? 'bg-blue-500/10 border-r-4 border-r-blue-500' 
                : 'hover:bg-surface-secondary/30 active:bg-surface-secondary/50'
              }
            `}
            onClick={() => onChatSelect(chat.id)}
          >
            {/* Avatar */}
            <div className="relative ml-3">
              <div className={`p-0.5 rounded-full bg-gradient-to-br ${chat.gradient || 'from-gray-500 to-gray-600'}`}>
                <Avatar className="h-12 w-12 bg-background">
                  <AvatarImage src={chat.avatar} alt={chat.name} />
                  <AvatarFallback className="text-white bg-gradient-to-br from-blue-500 to-purple-500">
                    {chat.name[0]}
                  </AvatarFallback>
                </Avatar>
              </div>
              
              {/* Online Indicator */}
              {chat.isOnline && (
                <div className="absolute -bottom-1 -left-1 h-4 w-4 bg-green-500 rounded-full border-2 border-background animate-pulse" />
              )}
              
              {/* Voice Channel Active */}
              {chat.voiceChannelActive && (
                <div className="absolute -top-1 -right-1 h-5 w-5 bg-blue-500 rounded-full flex items-center justify-center">
                  <Volume2 className="h-2.5 w-2.5 text-white" />
                </div>
              )}
            </div>
            
            {/* Chat Info */}
            <div className="flex-1 min-w-0 mr-3">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <h3 className="font-semibold truncate flex items-center space-x-1 rtl:space-x-reverse">
                    <span>{chat.name}</span>
                    {chat.isPinned && <Pin className="h-3 w-3 text-yellow-400 flex-shrink-0" />}
                    {chat.status === 'live' && (
                      <div className="h-2 w-2 bg-red-500 rounded-full animate-pulse flex-shrink-0" />
                    )}
                  </h3>
                  
                  <span className="text-lg flex-shrink-0">{getMoodEmoji(chat.mood)}</span>
                  
                  {chat.clanTag && (
                    <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400 border-blue-500/30 flex-shrink-0">
                      <Hash className="w-2 h-2 ml-1" />
                      {chat.clanTag}
                    </Badge>
                  )}
                </div>
                
                <div className="flex items-center space-x-2 rtl:space-x-reverse flex-shrink-0">
                  <span className="text-xs text-muted-foreground">{chat.lastMessage.timestamp}</span>
                  {chat.unreadCount > 0 && (
                    <Badge className="h-5 min-w-[20px] px-1 text-xs rounded-full bg-gradient-to-r from-blue-500 to-purple-500">
                      {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground truncate flex items-center space-x-1 rtl:space-x-reverse">
                  {chat.isTyping ? (
                    <motion.span
                      animate={{ opacity: [1, 0.5, 1] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                      className="text-blue-400 flex items-center space-x-1 rtl:space-x-reverse"
                    >
                      <div className="flex space-x-1">
                        <div className="h-1 w-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="h-1 w-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="h-1 w-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                      <span>در حال تایپ...</span>
                    </motion.span>
                  ) : (
                    <>
                      {chat.type !== 'direct' && (
                        <span className="font-medium flex-shrink-0">{chat.lastMessage.sender}:</span>
                      )}
                      <span className="truncate">{chat.lastMessage.content}</span>
                    </>
                  )}
                </div>
                
                <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              </div>
              
              {/* Additional Info Row for Groups */}
              {(chat.members || chat.liveUsers) && (
                <div className="flex items-center space-x-3 rtl:space-x-reverse mt-1">
                  {chat.members && (
                    <div className="flex items-center space-x-1 rtl:space-x-reverse text-xs text-muted-foreground">
                      <Users className="h-3 w-3" />
                      <span>{chat.members} عضو</span>
                    </div>
                  )}
                  {chat.liveUsers && (
                    <div className="flex items-center space-x-1 rtl:space-x-reverse text-xs text-blue-400">
                      <Eye className="h-3 w-3" />
                      <span>{chat.liveUsers} آنلاین</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

export default MobileChatList;