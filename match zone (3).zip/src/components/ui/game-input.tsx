import React from 'react';
import { cn } from './utils';
import { Input } from './input';

interface GameInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
  variant?: 'default' | 'search' | 'password' | 'number';
}

export const GameInput: React.FC<GameInputProps> = ({
  label,
  error,
  icon,
  variant = 'default',
  className,
  ...props
}) => {
  return (
    <div className="space-y-1">
      {label && (
        <label className="block text-sm font-medium text-foreground">
          {label}
        </label>
      )}
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            {icon}
          </div>
        )}
        <Input
          className={cn(
            'bg-input-background border-border focus:border-primary focus:ring-2 focus:ring-primary/20',
            icon && 'pl-10',
            error && 'border-destructive focus:border-destructive focus:ring-destructive/20',
            variant === 'search' && 'rounded-full',
            className
          )}
          type={variant === 'password' ? 'password' : variant === 'number' ? 'number' : 'text'}
          {...props}
        />
      </div>
      {error && (
        <p className="text-sm text-destructive">{error}</p>
      )}
    </div>
  );
};