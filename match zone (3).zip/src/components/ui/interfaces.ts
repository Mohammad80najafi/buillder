/**
 * Matchzone UI Component Interfaces
 * Standardized props and types for all UI components
 */

import { ReactNode } from 'react';

// Base component props
export interface BaseComponentProps {
  className?: string;
  children?: ReactNode;
  id?: string;
  'data-testid'?: string;
}

// Size variants
export type Size = 'sm' | 'md' | 'lg';

// State variants  
export type ComponentState = 'default' | 'hover' | 'active' | 'disabled' | 'loading';

// Visual variants
export type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'success' | 'warning' | 'info';

// Trust levels for gaming components
export type TrustLevel = 'low' | 'mid' | 'high';

// Status types
export type Status = 'open' | 'nearfull' | 'full' | 'closed' | 'live' | 'ended';

// Gaming component base props
export interface GamingComponentProps extends BaseComponentProps {
  trustLevel?: TrustLevel;
  status?: Status;
  ownerVerified?: boolean;
}

// User information interface
export interface UserSummary {
  id: string;
  username: string;
  avatar?: string;
  isVerified?: boolean;
  trustLevel?: TrustLevel;
  followerCount?: number;
  role?: string;
}

// Event handlers
export interface EventHandlers {
  onClick?: () => void;
  onMouseEnter?: () => void;
  onMouseLeave?: () => void;
  onFocus?: () => void;
  onBlur?: () => void;
}

// Form component props
export interface FormComponentProps extends BaseComponentProps {
  label?: string;
  helpText?: string;
  errorText?: string;
  successText?: string;
  required?: boolean;
  disabled?: boolean;
}

// Input component props
export interface InputProps extends FormComponentProps {
  type?: 'text' | 'email' | 'password' | 'number' | 'tel' | 'url';
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  state?: 'default' | 'error' | 'success' | 'disabled';
  onChange?: (value: string) => void;
  onKeyPress?: (event: React.KeyboardEvent) => void;
}

// Button component props
export interface ButtonProps extends BaseComponentProps, EventHandlers {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  disabled?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  type?: 'button' | 'submit' | 'reset';
}

// Card component props
export interface CardProps extends BaseComponentProps {
  variant?: 'default' | 'elevated' | 'outlined' | 'gaming';
  padding?: Size;
  hoverable?: boolean;
  clickable?: boolean;
  onClick?: () => void;
}

// Animation props
export interface AnimationProps {
  animate?: boolean;
  duration?: number;
  delay?: number;
  easing?: string;
}

// Responsive props
export interface ResponsiveProps {
  mobile?: boolean;
  tablet?: boolean;
  desktop?: boolean;
  mobileFirst?: boolean;
}

// Accessibility props
export interface AccessibilityProps {
  'aria-label'?: string;
  'aria-describedby'?: string;
  'aria-expanded'?: boolean;
  'aria-selected'?: boolean;
  role?: string;
  tabIndex?: number;
}

// Complete component props interface
export interface ComponentProps 
  extends BaseComponentProps, 
          EventHandlers, 
          AnimationProps, 
          ResponsiveProps, 
          AccessibilityProps {}

// Gaming specific interfaces
export interface LobbyData {
  id: string;
  title: string;
  game: string;
  status: Status;
  currentPlayers: number;
  maxPlayers: number;
  owner: UserSummary;
  visibility: 'public' | 'private';
  createdAt: string;
  startTime?: string;
}

export interface TournamentData {
  id: string;
  title: string;
  game: string;
  prize: number;
  participants: number;
  maxParticipants: number;
  status: Status;
  startDate: string;
  endDate: string;
  organizer: UserSummary;
}

export interface MessageData {
  id: string;
  content: string;
  user: UserSummary;
  timestamp: string;
  kind: 'text' | 'image' | 'sticker' | 'system';
  reactions?: Array<{
    emoji: string;
    count: number;
    userReacted: boolean;
  }>;
}

// Theme and styling
export interface ThemeProps {
  theme?: 'light' | 'dark' | 'system';
  colorScheme?: 'default' | 'gaming' | 'professional';
}

// Export combined props type for maximum flexibility
export interface AllProps 
  extends ComponentProps, 
          FormComponentProps, 
          GamingComponentProps, 
          ThemeProps {}