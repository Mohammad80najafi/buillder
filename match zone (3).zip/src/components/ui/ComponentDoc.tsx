/**
 * Component Documentation Generator
 * Auto-generates props documentation for Matchzone components
 */

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './table';
import { Badge } from './badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './tabs';

export interface PropDefinition {
  name: string;
  type: string;
  description: string;
  required?: boolean;
  defaultValue?: string;
  examples?: string[];
}

export interface ComponentDocProps {
  componentName: string;
  description: string;
  props: PropDefinition[];
  variants?: Record<string, string>;
  states?: Record<string, string>;
  examples?: React.ReactNode;
  usage?: string;
  category?: 'base' | 'gaming' | 'social' | 'auth' | 'layout' | 'utility';
}

export function ComponentDoc({
  componentName,
  description,
  props,
  variants,
  states,
  examples,
  usage,
  category = 'base'
}: ComponentDocProps) {
  const categoryIcons = {
    base: '🔧',
    gaming: '🎮',
    social: '💬',
    auth: '👤',
    layout: '📱',
    utility: '⚙️'
  };

  const categoryColors = {
    base: 'bg-blue-500',
    gaming: 'bg-purple-500',
    social: 'bg-green-500',
    auth: 'bg-orange-500',
    layout: 'bg-indigo-500',
    utility: 'bg-gray-500'
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <span className="text-2xl">{categoryIcons[category]}</span>
          <div>
            <h3 className="text-xl font-bold">{componentName}</h3>
            <Badge className={`${categoryColors[category]} text-white`}>
              {category}
            </Badge>
          </div>
        </CardTitle>
        <p className="text-text-secondary">{description}</p>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="props" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="props">Props</TabsTrigger>
            {variants && <TabsTrigger value="variants">Variants</TabsTrigger>}
            {states && <TabsTrigger value="states">States</TabsTrigger>}
            {examples && <TabsTrigger value="examples">Examples</TabsTrigger>}
          </TabsList>

          {/* Props Table */}
          <TabsContent value="props">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">نام</TableHead>
                  <TableHead className="text-right">نوع</TableHead>
                  <TableHead className="text-right">الزامی</TableHead>
                  <TableHead className="text-right">پیش‌فرض</TableHead>
                  <TableHead className="text-right">توضیح</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {props.map((prop) => (
                  <TableRow key={prop.name}>
                    <TableCell className="font-mono font-medium">
                      {prop.name}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-mono">
                        {prop.type}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {prop.required ? (
                        <Badge className="bg-red-500 text-white">بله</Badge>
                      ) : (
                        <Badge variant="outline">خیر</Badge>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {prop.defaultValue || '-'}
                    </TableCell>
                    <TableCell>{prop.description}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>

          {/* Variants */}
          {variants && (
            <TabsContent value="variants">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(variants).map(([key, description]) => (
                  <Card key={key} className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="font-mono">
                        {key}
                      </Badge>
                    </div>
                    <p className="text-sm text-text-secondary">{description}</p>
                  </Card>
                ))}
              </div>
            </TabsContent>
          )}

          {/* States */}
          {states && (
            <TabsContent value="states">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(states).map(([key, description]) => (
                  <Card key={key} className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="font-mono">
                        {key}
                      </Badge>
                    </div>
                    <p className="text-sm text-text-secondary">{description}</p>
                  </Card>
                ))}
              </div>
            </TabsContent>
          )}

          {/* Examples */}
          {examples && (
            <TabsContent value="examples">
              <div className="space-y-6">
                {usage && (
                  <div>
                    <h4 className="font-semibold mb-2">استفاده:</h4>
                    <div className="bg-surface-secondary p-4 rounded-lg">
                      <pre className="text-sm overflow-x-auto">
                        <code>{usage}</code>
                      </pre>
                    </div>
                  </div>
                )}
                
                <div>
                  <h4 className="font-semibold mb-4">مثال‌های تعاملی:</h4>
                  <div className="space-y-4">
                    {examples}
                  </div>
                </div>
              </div>
            </TabsContent>
          )}
        </Tabs>
      </CardContent>
    </Card>
  );
}

// Helper to generate prop definitions from TypeScript interfaces
export function createPropDef(
  name: string,
  type: string,
  description: string,
  required = false,
  defaultValue?: string,
  examples?: string[]
): PropDefinition {
  return {
    name,
    type,
    description,
    required,
    defaultValue,
    examples
  };
}

// Pre-defined common prop definitions
export const commonProps = {
  className: createPropDef(
    'className',
    'string',
    'کلاس‌های CSS اضافی',
    false,
    'undefined'
  ),
  children: createPropDef(
    'children',
    'ReactNode',
    'محتوای داخلی کامپوننت',
    false
  ),
  id: createPropDef(
    'id',
    'string',
    'شناسه HTML المنت',
    false
  ),
  disabled: createPropDef(
    'disabled',
    'boolean',
    'غیرفعال کردن کامپوننت',
    false,
    'false'
  ),
  loading: createPropDef(
    'loading',
    'boolean',
    'نمایش حالت بارگذاری',
    false,
    'false'
  ),
  onClick: createPropDef(
    'onClick',
    '() => void',
    'تابع کلیک',
    false
  )
};

export default ComponentDoc;