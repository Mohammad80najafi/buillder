/**
 * Mobile-Optimized Chat Card
 * کارت چت بهینه شده برای موبایل
 */

import React from 'react';
import { motion } from 'motion/react';
import { Card, CardContent } from './card';
import { Avatar, AvatarFallback, AvatarImage } from './avatar';
import { Badge } from './badge';
import { Pin, Volume2, Users, Hash } from 'lucide-react';

interface MobileChatCardProps {
  id: string;
  name: string;
  type: 'group' | 'direct' | 'support' | 'clan' | 'gaming' | 'tournament';
  avatar?: string;
  gradient?: string;
  lastMessage: {
    content: string;
    timestamp: string;
    sender: string;
    type: 'text' | 'image' | 'voice' | 'game' | 'system';
  };
  unreadCount: number;
  isOnline?: boolean;
  members?: number;
  isPinned?: boolean;
  isActive?: boolean;
  status?: 'active' | 'resolved' | 'pending' | 'live' | 'scheduled';
  clanTag?: string;
  mood?: 'happy' | 'focused' | 'competitive' | 'chill';
  voiceChannelActive?: boolean;
  isTyping?: boolean;
  isSelected?: boolean;
  onClick?: () => void;
}

const getMoodEmoji = (mood?: string) => {
  switch (mood) {
    case 'happy': return '😊';
    case 'focused': return '🎯';
    case 'competitive': return '🔥';
    case 'chill': return '😎';
    default: return '💬';
  }
};

export function MobileChatCard({
  id,
  name,
  type,
  avatar,
  gradient = 'from-gray-500 to-gray-600',
  lastMessage,
  unreadCount,
  isOnline,
  members,
  isPinned,
  status,
  clanTag,
  mood,
  voiceChannelActive,
  isTyping,
  isSelected,
  onClick
}: MobileChatCardProps) {
  return (
    <motion.div
      key={id}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      whileTap={{ scale: 0.98 }}
      className="group w-full"
    >
      <Card 
        className={`cursor-pointer transition-all duration-300 border-0 shadow-sm hover:shadow-md active:scale-[0.98] ${
          isSelected 
            ? 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-l-4 border-l-blue-500' 
            : 'hover:bg-surface-secondary/30'
        }`}
        onClick={onClick}
      >
        <CardContent className="p-3">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            {/* Avatar */}
            <div className="relative flex-shrink-0">
              <div className={`p-0.5 rounded-full bg-gradient-to-br ${gradient}`}>
                <Avatar className="h-12 w-12 bg-background">
                  <AvatarImage src={avatar} alt={name} />
                  <AvatarFallback className="text-white bg-gradient-to-br from-blue-500 to-purple-500 text-sm font-semibold">
                    {name[0]}
                  </AvatarFallback>
                </Avatar>
              </div>
              
              {/* Online Status */}
              {isOnline && (
                <div className="absolute -bottom-1 -left-1 h-3 w-3 bg-green-500 rounded-full border-2 border-background animate-pulse" />
              )}
              
              {/* Voice Channel */}
              {voiceChannelActive && (
                <div className="absolute -top-1 -right-1 h-4 w-4 bg-blue-500 rounded-full flex items-center justify-center">
                  <Volume2 className="h-2 w-2 text-white" />
                </div>
              )}
            </div>
            
            {/* Content */}
            <div className="flex-1 min-w-0">
              {/* Header */}
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center space-x-2 rtl:space-x-reverse min-w-0 flex-1">
                  <h3 className="font-semibold truncate text-sm flex-1">
                    {name}
                  </h3>
                  <span className="text-base flex-shrink-0">{getMoodEmoji(mood)}</span>
                  {isPinned && <Pin className="h-3 w-3 text-yellow-400 flex-shrink-0" />}
                  {status === 'live' && <div className="h-2 w-2 bg-red-500 rounded-full animate-pulse flex-shrink-0" />}
                </div>
                
                <div className="flex items-center space-x-2 rtl:space-x-reverse flex-shrink-0 ml-2">
                  <span className="text-xs text-muted-foreground whitespace-nowrap">{lastMessage.timestamp}</span>
                  {unreadCount > 0 && (
                    <Badge className="h-5 w-5 p-0 text-xs rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center min-w-[20px]">
                      {unreadCount > 99 ? '99+' : unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
              
              {/* Message Preview */}
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground truncate flex items-center space-x-1 rtl:space-x-reverse min-w-0 flex-1">
                  {isTyping ? (
                    <motion.span
                      animate={{ opacity: [1, 0.5, 1] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                      className="text-blue-400 text-xs flex-shrink-0"
                    >
                      در حال تایپ...
                    </motion.span>
                  ) : (
                    <div className="flex items-center space-x-1 rtl:space-x-reverse min-w-0 flex-1">
                      {type !== 'direct' && (
                        <span className="font-medium text-xs flex-shrink-0">{lastMessage.sender}:</span>
                      )}
                      <span className="truncate text-xs flex-1">{lastMessage.content}</span>
                    </div>
                  )}
                </div>
                
                {/* Badges */}
                <div className="flex items-center space-x-1 rtl:space-x-reverse flex-shrink-0 ml-2">
                  {clanTag && (
                    <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400 border-blue-500/30 px-1 py-0 h-5">
                      <Hash className="w-2 h-2 mr-0.5" />
                      <span className="text-[10px]">{clanTag}</span>
                    </Badge>
                  )}
                  {members && members > 2 && (
                    <Badge variant="outline" className="text-xs px-1 py-0 h-5">
                      <Users className="w-2 h-2 mr-0.5" />
                      <span className="text-[10px]">{members}</span>
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default MobileChatCard;