import React, { forwardRef } from 'react';
import { cn } from './utils';
import { motion } from 'motion/react';

interface PremiumScrollAreaProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  orientation?: 'vertical' | 'horizontal' | 'both';
  variant?: 'default' | 'gaming' | 'fade' | 'minimal';
  showIndicator?: boolean;
  maxHeight?: string | number;
  maxWidth?: string | number;
}

const PremiumScrollArea = forwardRef<HTMLDivElement, PremiumScrollAreaProps>(
  ({ 
    children, 
    className, 
    orientation = 'vertical',
    variant = 'default',
    showIndicator = false,
    maxHeight,
    maxWidth,
    ...props 
  }, ref) => {
    const getScrollClasses = () => {
      const baseClasses = 'relative';
      
      switch (variant) {
        case 'gaming':
          return cn(baseClasses, 'gaming-scroll');
        case 'fade':
          return cn(baseClasses, 'fade-scrollbar');
        case 'minimal':
          return cn(baseClasses, 'scrollbar-thin');
        default:
          return baseClasses;
      }
    };

    const getOverflowClasses = () => {
      switch (orientation) {
        case 'horizontal':
          return 'overflow-x-auto overflow-y-hidden';
        case 'both':
          return 'overflow-auto';
        default:
          return 'overflow-y-auto overflow-x-hidden';
      }
    };

    const style = React.useMemo(() => {
      const computedStyle: React.CSSProperties = {};
      if (maxHeight) {
        computedStyle.maxHeight = typeof maxHeight === 'number' ? `${maxHeight}px` : maxHeight;
      }
      if (maxWidth) {
        computedStyle.maxWidth = typeof maxWidth === 'number' ? `${maxWidth}px` : maxWidth;
      }
      return computedStyle;
    }, [maxHeight, maxWidth]);

    return (
      <div
        ref={ref}
        className={cn(
          getScrollClasses(),
          getOverflowClasses(),
          showIndicator && 'snap-scroll',
          className
        )}
        style={style}
        {...props}
      >
        {children}
        
        {showIndicator && (
          <motion.div
            className="absolute top-4 right-4 z-10 flex items-center gap-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="w-1 h-4 bg-gradient-to-b from-brand-primary to-brand-secondary rounded-full opacity-60" />
            <div className="w-1 h-3 bg-gradient-to-b from-brand-secondary to-brand-accent rounded-full opacity-40" />
            <div className="w-1 h-2 bg-gradient-to-b from-brand-accent to-brand-primary rounded-full opacity-20" />
          </motion.div>
        )}
      </div>
    );
  }
);

PremiumScrollArea.displayName = 'PremiumScrollArea';

export { PremiumScrollArea };
export type { PremiumScrollAreaProps };