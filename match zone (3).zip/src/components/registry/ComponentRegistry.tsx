/**
 * Matchzone Component Registry
 * Centralized registration and documentation of all components
 */

import React from 'react';
import { ComponentDoc, ComponentDocProps, createPropDef, commonProps } from '../ui/ComponentDoc';

// Import all documented components
import { Button } from '../ui/mz-button';
import { Input } from '../ui/mz-input';
import { LobbyCard } from '../gaming/mz-lobby-card';
import { MessageBubble } from '../social/mz-message-bubble';
import { ScheduleCalendar } from '../calendar/ScheduleCalendar';
import { LobbyScheduleManager } from '../calendar/LobbyScheduleManager';

// Stage 4 Components
import TournamentAdminPage from '../pages/TournamentAdminPage';
import AdvancedNotificationSystem from '../system/AdvancedNotificationSystem';
import PlatformAnalyticsDashboard from '../analytics/PlatformAnalyticsDashboard';
import Stage4ShowcasePage from '../pages/Stage4ShowcasePage';

// Stage 5 Components
import { ProfessionalLeagueSystem } from '../leagues/ProfessionalLeagueSystem';
import { AdvancedEconomySystem } from '../economy/AdvancedEconomySystem';
import { MentorshipSystem } from '../coaching/MentorshipSystem';
import { AdvancedSocialFeatures } from '../social/AdvancedSocialFeatures';
import { Stage5ShowcasePage } from '../pages/Stage5ShowcasePage';

export interface ComponentRegistryItem {
  id: string;
  component: React.ComponentType<any>;
  documentation: ComponentDocProps;
}

// Component registry
export const componentRegistry: ComponentRegistryItem[] = [
  // Base Components
  {
    id: 'button',
    component: Button,
    documentation: {
      componentName: 'Button',
      description: 'کامپوننت دکمه اصلی با پشتیبانی از انواع مختلف و حالت‌های مختلف',
      category: 'base',
      props: [
        commonProps.className,
        commonProps.children,
        commonProps.disabled,
        commonProps.loading,
        commonProps.onClick,
        createPropDef(
          'variant',
          "'primary' | 'secondary' | 'ghost' | 'danger'",
          'نوع ظاهری دکمه',
          false,
          'primary'
        ),
        createPropDef(
          'size',
          "'sm' | 'md' | 'lg'",
          'اندازه دکمه',
          false,
          'md'
        ),
        createPropDef(
          'leftIcon',
          'ReactNode',
          'آیکون سمت چپ (راست در RTL)',
          false
        ),
        createPropDef(
          'rightIcon',
          'ReactNode',
          'آیکون سمت راست (چپ در RTL)',
          false
        ),
        createPropDef(
          'type',
          "'button' | 'submit' | 'reset'",
          'نوع HTML دکمه',
          false,
          'button'
        )
      ],
      variants: {
        primary: 'دکمه اصلی با پس‌زمینه برند',
        secondary: 'دکمه ثانویه با حاشیه',
        ghost: 'دکمه شفاف بدون پس‌زمینه',
        danger: 'دکمه خطرناک قرمز رنگ'
      },
      states: {
        default: 'حالت عادی قابل کلیک',
        hover: 'هنگام هاور ماوس',
        active: 'هنگام کلیک',
        disabled: 'غیرفعال',
        loading: 'در حال بارگذاری با spinner'
      },
      usage: `<Button variant="primary" size="lg" leftIcon={<Play />}>
  شروع بازی
</Button>

<Button variant="secondary" loading>
  در حال بارگذاری...
</Button>`,
      examples: (
        <div className="space-y-4">
          <div className="flex gap-2 flex-wrap">
            <Button variant="primary">اصلی</Button>
            <Button variant="secondary">ثانویه</Button>
            <Button variant="ghost">شفاف</Button>
            <Button variant="danger">خطرناک</Button>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button size="sm">کوچک</Button>
            <Button size="md">متوسط</Button>
            <Button size="lg">بزرگ</Button>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button loading>در حال بارگذاری</Button>
            <Button disabled>غیرفعال</Button>
          </div>
        </div>
      )
    }
  },

  // Input Component
  {
    id: 'input',
    component: Input,
    documentation: {
      componentName: 'Input',
      description: 'کامپوننت ورودی متن با پشتیبانی از حالت‌های مختلف و آیکون‌ها',
      category: 'base',
      props: [
        commonProps.className,
        commonProps.disabled,
        createPropDef(
          'type',
          "'text' | 'email' | 'password' | 'number' | 'tel' | 'url'",
          'نوع ورودی',
          false,
          'text'
        ),
        createPropDef(
          'placeholder',
          'string',
          'متن نمایشی',
          false
        ),
        createPropDef(
          'value',
          'string',
          'مقدار کنترل شده',
          false
        ),
        createPropDef(
          'state',
          "'default' | 'error' | 'success' | 'disabled'",
          'وضعیت فیلد',
          false,
          'default'
        ),
        createPropDef(
          'label',
          'string',
          'برچسب فیلد',
          false
        ),
        createPropDef(
          'helpText',
          'string',
          'متن راهنما',
          false
        ),
        createPropDef(
          'errorText',
          'string',
          'متن خطا',
          false
        ),
        createPropDef(
          'leftIcon',
          'ReactNode',
          'آیکون سمت چپ',
          false
        ),
        createPropDef(
          'rightIcon',
          'ReactNode',
          'آیکون سمت راست',
          false
        ),
        createPropDef(
          'onChange',
          '(value: string) => void',
          'تابع تغییر مقدار',
          false
        )
      ],
      states: {
        default: 'حالت عادی',
        error: 'حالت خطا با متن خطا',
        success: 'حالت موفقیت',
        disabled: 'غیرفعال'
      },
      usage: `<Input
  label="نام کاربری"
  placeholder="نام کاربری خود را وارد کنید"
  leftIcon={<User />}
  helpText="نام کاربری باید حداقل ۳ کاراکتر باشد"
/>`,
      examples: (
        <div className="space-y-4 max-w-md">
          <Input label="نام کاربری" placeholder="نام کاربری" />
          <Input label="ایمیل" type="email" state="error" errorText="ایمیل معتبر نیست" />
          <Input label="رمز عبور" type="password" state="success" successText="رمز عبور قوی است" />
          <Input label="غیرفعال" disabled placeholder="فیلد غیرفعال" />
        </div>
      )
    }
  },

  // Gaming Components
  {
    id: 'lobby-card',
    component: LobbyCard,
    documentation: {
      componentName: 'LobbyCard',
      description: 'کارت نمایش اطلاعات لابی بازی با جزئیات کامل و حالت‌های مختلف',
      category: 'gaming',
      props: [
        commonProps.className,
        commonProps.onClick,
        createPropDef(
          'id',
          'string',
          'شناسه یکتای لابی',
          true
        ),
        createPropDef(
          'title',
          'string',
          'عنوان لابی',
          true
        ),
        createPropDef(
          'game',
          'string',
          'نام بازی',
          true
        ),
        createPropDef(
          'status',
          "'open' | 'nearfull' | 'full' | 'closed'",
          'وضعیت لابی',
          true
        ),
        createPropDef(
          'currentPlayers',
          'number',
          'تعداد بازیکنان فعلی',
          true
        ),
        createPropDef(
          'maxPlayers',
          'number',
          'حداکثر بازیکنان',
          true
        ),
        createPropDef(
          'owner',
          'UserSummary',
          'اطلاعات مالک لابی',
          true
        ),
        createPropDef(
          'visibility',
          "'public' | 'private'",
          'نوع دسترسی لابی',
          false,
          'public'
        ),
        createPropDef(
          'ownerTrust',
          "'low' | 'mid' | 'high'",
          'سطح اعتماد مالک',
          false,
          'low'
        ),
        createPropDef(
          'tags',
          'string[]',
          'برچسب‌های لابی',
          false
        ),
        createPropDef(
          'description',
          'string',
          'توضیحات لابی',
          false
        )
      ],
      variants: {
        open: 'لابی باز و قابل پیوستن',
        nearfull: 'نزدیک به پر شدن - هشدار زرد',
        full: 'لابی پر شده - غیرقابل کلیک',
        closed: 'لابی بسته شده'
      },
      states: {
        interactive: 'قابل کلیک برای پیوستن',
        'non-interactive': 'غیرقابل کلیک (پر یا بسته)',
        hover: 'انیمیشن هاور با سایه',
        mobile: 'نمایش بهینه موبایل'
      },
      usage: `<LobbyCard
  id="lobby-123"
  title="مسابقه تیمی حرفه‌ای"
  game="Call of Duty"
  status="open"
  currentPlayers={3}
  maxPlayers={4}
  owner={{
    id: "user-1",
    username: "محمد",
    trustLevel: "high",
    isVerified: true
  }}
  tags={["رنک", "تیمی", "مسابقه"]}
  onClick={() => console.log("Join lobby")}
/>`,
      examples: (
        <div className="space-y-4 max-w-lg">
          <LobbyCard
            id="lobby-1"
            title="مسابقه تیمی حرفه‌ای"
            game="Call of Duty"
            status="open"
            currentPlayers={3}
            maxPlayers={4}
            owner={{
              id: "user-1",
              username: "محمد",
              trustLevel: "high",
              isVerified: true
            }}
            tags={["رنک", "تیمی"]}
            createdAt="۵ دقیقه پیش"
          />
          <LobbyCard
            id="lobby-2"
            title="لابی دوستانه"
            game="FIFA 24"
            status="nearfull"
            currentPlayers={7}
            maxPlayers={8}
            owner={{
              id: "user-2",
              username: "علی",
              trustLevel: "mid"
            }}
            tags={["دوستانه"]}
            createdAt="۱۰ دقیقه پیش"
          />
        </div>
      )
    }
  },

  // Calendar Components
  {
    id: 'schedule-calendar',
    component: ScheduleCalendar,
    documentation: {
      componentName: 'ScheduleCalendar',
      description: 'کامپوننت تقویم پیشرفته برای زمان‌بندی و مدیریت لابی‌ها با پشتیبانی از RTL و کنترل تداخل زمانی',
      category: 'calendar',
      props: [
        commonProps.className,
        createPropDef(
          'userId',
          'string',
          'شناسه کاربر برای فیلتر کردن لابی‌ها',
          false
        ),
        createPropDef(
          'onSlotSelect',
          '(slot: ScheduleSlot) => void',
          'تابع انتخاب لابی',
          false
        ),
        createPropDef(
          'showCreateButton',
          'boolean',
          'نمایش دکمه ایجاد لابی جدید',
          false,
          'false'
        ),
        createPropDef(
          'filterByUser',
          'boolean',
          'فیلتر کردن براساس کاربر',
          false,
          'false'
        )
      ],
      variants: {
        'calendar-view': 'نمایش تقویمی با تاریخ‌ها',
        'list-view': 'نمایش لیستی لابی‌ها'
      },
      states: {
        'loading': 'بارگذاری اطلاعات تقویم',
        'empty': 'بدون لابی برای نمایش',
        'conflict': 'تداخل زمانی شناسایی شده',
        'interactive': 'قابل تعامل و انتخاب'
      },
      usage: `<ScheduleCalendar
  userId="user-123"
  showCreateButton={true}
  onSlotSelect={(slot) => console.log('Selected:', slot)}
  filterByUser={true}
/>`,
      examples: (
        <div className="space-y-4">
          <p className="text-sm text-text-secondary">
            کامپوننت تقویم در محیط Schedule Provider نمایش داده می‌شود
          </p>
          <div className="p-4 border rounded-lg bg-surface-secondary">
            <p className="text-center">نمایش نمونه تقویم</p>
          </div>
        </div>
      )
    }
  },

  {
    id: 'lobby-schedule-manager',
    component: LobbyScheduleManager,
    documentation: {
      componentName: 'LobbyScheduleManager',
      description: 'مدیر کامل لابی��های زمان‌بندی شده با امکان ایجاد، ویرایش، حذف و مدیریت پیشرفته',
      category: 'calendar',
      props: [
        commonProps.className,
        createPropDef(
          'onLobbyCreated',
          '(lobby: ScheduleSlot) => void',
          'تابع اجرا شده هنگام ایجاد لابی',
          false
        ),
        createPropDef(
          'onLobbyUpdated',
          '(lobby: ScheduleSlot) => void',
          'تابع اجرا شده هنگام بروزرسانی لابی',
          false
        ),
        createPropDef(
          'onLobbyDeleted',
          '(lobbyId: string) => void',
          'تابع اجرا شده هنگام حذف لابی',
          false
        )
      ],
      variants: {
        'manager-view': 'نمایش مدیریتی با فیلترها',
        'user-view': 'نمایش کاربری ساده'
      },
      states: {
        'creating': 'در حال ایجاد لابی جدید',
        'editing': 'ویرایش لابی موجود',
        'filtering': 'فیلتر کردن لابی‌ها',
        'empty': 'بدون لابی برای نمایش'
      },
      usage: `<LobbyScheduleManager
  onLobbyCreated={(lobby) => console.log('Created:', lobby)}
  onLobbyUpdated={(lobby) => console.log('Updated:', lobby)}
  onLobbyDeleted={(id) => console.log('Deleted:', id)}
/>`,
      examples: (
        <div className="space-y-4">
          <p className="text-sm text-text-secondary">
            مدیر لابی‌ها شامل فیلترهای پیشرفته و امکان مدیریت کامل
          </p>
          <div className="p-4 border rounded-lg bg-surface-secondary">
            <p className="text-center">نمایش نمونه مدیر لابی‌ها</p>
          </div>
        </div>
      )
    }
  }
];

// Component registry utilities
export function getComponentById(id: string): ComponentRegistryItem | undefined {
  return componentRegistry.find(item => item.id === id);
}

export function getComponentsByCategory(category: string): ComponentRegistryItem[] {
  return componentRegistry.filter(item => item.documentation.category === category);
}

export function getAllCategories(): string[] {
  const categories = componentRegistry.map(item => item.documentation.category || 'other');
  return [...new Set(categories)];
}

// Component registry display component
export function ComponentRegistryDisplay() {
  const categories = getAllCategories();

  return (
    <div className="space-y-8" dir="rtl">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">کتابخانه کامپوننت‌های Matchzone</h1>
        <p className="text-text-secondary">مستندات کامل تمام کامپوننت‌ها</p>
      </div>

      {categories.map(category => {
        const components = getComponentsByCategory(category);
        return (
          <div key={category} className="space-y-6">
            <h2 className="text-2xl font-bold">
              کامپوننت‌های {category === 'base' ? 'پایه' : 
                              category === 'gaming' ? 'گیمینگ' : 
                              category === 'social' ? 'اجتماعی' : 
                              category === 'auth' ? 'احراز هویت' : 
                              category === 'calendar' ? 'تقویم و زمان‌بندی' :
                              category}
            </h2>
            
            {components.map(item => (
              <ComponentDoc key={item.id} {...item.documentation} />
            ))}
          </div>
        );
      })}
    </div>
  );
}

export default ComponentRegistryDisplay;