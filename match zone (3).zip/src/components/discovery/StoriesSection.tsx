// This file has been removed - Stories system no longer needed
// Use DiscoverFeed instead for discovery functionality