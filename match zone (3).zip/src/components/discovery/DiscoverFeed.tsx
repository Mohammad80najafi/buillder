import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { GameButton } from '../ui/game-button';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  GamepadIcon, 
  Trophy, 
  Users, 
  PlayCircle, 
  Clock,
  Star,
  TrendingUp
} from 'lucide-react';

export interface DiscoverItem {
  id: string;
  type: 'lobby' | 'tournament' | 'video' | 'clan' | 'creator';
  title: string;
  description: string;
  image?: string;
  game?: string;
  creator?: {
    id: string;
    name: string;
    avatar?: string;
  };
  metadata: {
    // Lobby/Tournament
    playerCount?: number;
    maxPlayers?: number;
    prizePool?: number;
    entryFee?: number;
    startTime?: Date;
    
    // Video
    views?: number;
    duration?: number;
    likes?: number;
    
    // Clan
    memberCount?: number;
    wins?: number;
    losses?: number;
    
    // Creator
    followers?: number;
    totalVideos?: number;
    isVerified?: boolean;
  };
  tags: string[];
  isPopular?: boolean;
  isTrending?: boolean;
  isPremium?: boolean;
}

interface DiscoverFeedProps {
  items: DiscoverItem[];
  onItemClick?: (item: DiscoverItem) => void;
  onActionClick?: (item: DiscoverItem, action: string) => void;
  className?: string;
}

const typeIcons = {
  lobby: GamepadIcon,
  tournament: Trophy,
  video: PlayCircle,
  clan: Users,
  creator: Star,
};

const typeColors = {
  lobby: 'text-blue-600',
  tournament: 'text-yellow-600',
  video: 'text-red-600',
  clan: 'text-purple-600',
  creator: 'text-orange-600',
};

const typeLabels = {
  lobby: 'لابی',
  tournament: 'تورنومنت',
  video: 'ویدیو',
  clan: 'کلن',
  creator: 'کریتور',
};

export const DiscoverFeed: React.FC<DiscoverFeedProps> = ({
  items,
  onItemClick,
  onActionClick,
  className,
}) => {
  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toLocaleString('fa-IR');
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const getActionButton = (item: DiscoverItem) => {
    switch (item.type) {
      case 'lobby':
        return { text: 'پیوستن', action: 'join', variant: 'primary' as const };
      case 'tournament':
        return { text: 'ثبت‌نام', action: 'register', variant: 'primary' as const };
      case 'video':
        return { text: 'تماشا', action: 'watch', variant: 'secondary' as const };
      case 'clan':
        return { text: 'مشاهده', action: 'view', variant: 'secondary' as const };
      case 'creator':
        return { text: 'دنبال کردن', action: 'follow', variant: 'primary' as const };
      default:
        return { text: 'مشاهده', action: 'view', variant: 'secondary' as const };
    }
  };

  return (
    <div className={cn('space-y-4', className)}>
      {items.map((item) => {
        const Icon = typeIcons[item.type];
        const actionButton = getActionButton(item);
        
        return (
          <Card 
            key={item.id} 
            className="group cursor-pointer transition-all duration-200 hover:shadow-lg"
            onClick={() => onItemClick?.(item)}
          >
            <CardContent className="p-0">
              <div className="flex gap-4 p-4">
                {/* Image/Thumbnail */}
                {item.image && (
                  <div className="relative w-32 h-20 flex-shrink-0 rounded-lg overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
                    />
                    
                    {item.type === 'video' && item.metadata.duration && (
                      <div className="absolute bottom-1 right-1">
                        <Badge variant="secondary" className="text-xs bg-black/70 text-white">
                          {formatDuration(item.metadata.duration)}
                        </Badge>
                      </div>
                    )}
                    
                    {item.isPopular && (
                      <div className="absolute top-1 left-1">
                        <Badge className="bg-yellow-500 text-white text-xs">
                          محبوب
                        </Badge>
                      </div>
                    )}
                    
                    {item.isTrending && (
                      <div className="absolute top-1 left-1">
                        <Badge className="bg-red-500 text-white text-xs">
                          <TrendingUp className="w-3 h-3 mr-1" />
                          ترند
                        </Badge>
                      </div>
                    )}
                  </div>
                )}

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Icon className={cn('w-4 h-4', typeColors[item.type])} />
                      <Badge variant="outline" className="text-xs">
                        {typeLabels[item.type]}
                      </Badge>
                      {item.game && (
                        <Badge variant="secondary" className="text-xs">
                          {item.game}
                        </Badge>
                      )}
                      {item.isPremium && (
                        <Badge className="bg-purple-500 text-white text-xs">
                          پریمیوم
                        </Badge>
                      )}
                    </div>
                  </div>

                  <h3 className="font-medium text-foreground mb-1 line-clamp-1 group-hover:text-primary transition-colors">
                    {item.title}
                  </h3>
                  
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                    {item.description}
                  </p>

                  {/* Creator Info */}
                  {item.creator && (
                    <div className="flex items-center gap-2 mb-3">
                      <Avatar className="w-6 h-6">
                        <AvatarImage src={item.creator.avatar} alt={item.creator.name} />
                        <AvatarFallback className="text-xs">{item.creator.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm text-muted-foreground">{item.creator.name}</span>
                      {item.metadata.isVerified && (
                        <Badge className="bg-blue-500 text-white text-xs px-1">
                          ✓
                        </Badge>
                      )}
                    </div>
                  )}

                  {/* Metadata */}
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                    {item.metadata.playerCount !== undefined && (
                      <span>{item.metadata.playerCount}/{item.metadata.maxPlayers} بازیکن</span>
                    )}
                    {item.metadata.prizePool && (
                      <span className="text-yellow-600">
                        جایزه: {formatNumber(item.metadata.prizePool)} سکه
                      </span>
                    )}
                    {item.metadata.views && (
                      <span>{formatNumber(item.metadata.views)} بازدید</span>
                    )}
                    {item.metadata.memberCount && (
                      <span>{item.metadata.memberCount} عضو</span>
                    )}
                    {item.metadata.followers && (
                      <span>{formatNumber(item.metadata.followers)} دنبال‌کننده</span>
                    )}
                    {item.metadata.startTime && (
                      <span>
                        <Clock className="w-3 h-3 inline ml-1" />
                        {new Date(item.metadata.startTime).toLocaleTimeString('fa-IR', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    )}
                  </div>

                  {/* Tags */}
                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap gap-1">
                      {item.tags.slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>

                    <GameButton
                      variant={actionButton.variant}
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onActionClick?.(item, actionButton.action);
                      }}
                    >
                      {actionButton.text}
                    </GameButton>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
      
      {items.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Star className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>محتوای جدیدی برای کشف یافت نشد</p>
          <p className="text-sm">بعداً دوباره بررسی کنید</p>
        </div>
      )}
    </div>
  );
};