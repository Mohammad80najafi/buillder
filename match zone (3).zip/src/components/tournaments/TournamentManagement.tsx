import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Alert, AlertDescription } from '../ui/alert';
import { 
  Settings, Users, Trophy, Play, Pause, Square, Eye,
  MessageSquare, Ban, CheckCircle, XCircle, Clock,
  RefreshCw, AlertTriangle, TrendingUp, DollarSign,
  Calendar, Camera, Mic, Volume2, Crown, Award,
  Target, Zap, Shield, Flag, Share2, Download
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion, AnimatePresence } from 'motion/react';

export interface Participant {
  id: string;
  name: string;
  avatar?: string;
  rank: string;
  level: number;
  isReady: boolean;
  isOnline: boolean;
  registrationTime: string;
  team?: {
    name: string;
    members: string[];
  };
  warnings: number;
  status: 'active' | 'disqualified' | 'withdrawn';
}

export interface TournamentMatch {
  id: string;
  round: string;
  participant1: Participant;
  participant2: Participant;
  winner?: string;
  status: 'upcoming' | 'live' | 'paused' | 'finished' | 'cancelled';
  startTime?: string;
  endTime?: string;
  score1?: number;
  score2?: number;
  streamUrl?: string;
  chatRoom?: string;
  moderator?: string;
}

export interface TournamentManagementData {
  id: string;
  title: string;
  status: 'registration' | 'starting' | 'live' | 'paused' | 'finished' | 'cancelled';
  participants: Participant[];
  matches: TournamentMatch[];
  currentRound: string;
  maxParticipants: number;
  prize: string;
  entryFee: number;
  startTime: string;
  organizer: string;
  streamUrl?: string;
  chatEnabled: boolean;
  autoAdvance: boolean;
  allowSpectators: boolean;
  settings: {
    matchDuration: number; // minutes
    breakBetweenRounds: number; // minutes
    disqualificationTime: number; // minutes late
    allowChat: boolean;
    allowPause: boolean;
    moderationLevel: 'low' | 'medium' | 'high';
  };
  stats: {
    totalMatches: number;
    completedMatches: number;
    liveMatches: number;
    totalPrize: number;
    revenue: number;
    averageMatchTime: number;
    spectators: number;
  };
}

export interface TournamentManagementProps {
  tournament: TournamentManagementData;
  onUpdateTournament: (tournament: TournamentManagementData) => void;
  onStartTournament: () => Promise<void>;
  onPauseTournament: () => Promise<void>;
  onResumeTournament: () => Promise<void>;
  onCancelTournament: () => Promise<void>;
  onEndTournament: () => Promise<void>;
  isLoading?: boolean;
}

export function TournamentManagement({
  tournament,
  onUpdateTournament,
  onStartTournament,
  onPauseTournament,
  onResumeTournament,
  onCancelTournament,
  onEndTournament,
  isLoading = false
}: TournamentManagementProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedParticipant, setSelectedParticipant] = useState<Participant | null>(null);
  const [selectedMatch, setSelectedMatch] = useState<TournamentMatch | null>(null);
  const [moderationAction, setModerationAction] = useState<string>('');
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState(true);

  // Auto-refresh tournament data
  useEffect(() => {
    if (!autoRefreshEnabled) return;
    
    const interval = setInterval(() => {
      // Simulate real-time updates
      console.log('Refreshing tournament data...');
    }, 5000);

    return () => clearInterval(interval);
  }, [autoRefreshEnabled]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'registration': return 'bg-blue-500/20 text-blue-400 border-blue-500/50';
      case 'starting': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      case 'live': return 'bg-green-500/20 text-green-400 border-green-500/50';
      case 'paused': return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'finished': return 'bg-purple-500/20 text-purple-400 border-purple-500/50';
      case 'cancelled': return 'bg-red-500/20 text-red-400 border-red-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const handleParticipantAction = async (participantId: string, action: string) => {
    try {
      // Handle participant actions
      switch (action) {
        case 'disqualify':
          toast.success('بازیکن محروم شد');
          break;
        case 'warn':
          toast.success('اخطار داده شد');
          break;
        case 'kick':
          toast.success('بازیکن حذف شد');
          break;
        case 'mute':
          toast.success('بازیکن ساکت شد');
          break;
        default:
          break;
      }
    } catch (error) {
      toast.error('خطا در انجام عملیات');
    }
  };

  const handleMatchAction = async (matchId: string, action: string) => {
    try {
      switch (action) {
        case 'start':
          toast.success('مسابقه شروع شد');
          break;
        case 'pause':
          toast.success('مسابقه متوقف شد');
          break;
        case 'resume':
          toast.success('مسابقه ادامه یافت');
          break;
        case 'cancel':
          toast.success('مسابقه لغو شد');
          break;
        case 'declare-winner':
          toast.success('برنده اعلام شد');
          break;
        default:
          break;
      }
    } catch (error) {
      toast.error('خطا در انجام عملیات');
    }
  };

  const getTournamentProgress = () => {
    const total = tournament.stats.totalMatches;
    const completed = tournament.stats.completedMatches;
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header - Tournament Status */}
      <Card className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-purple-500/20 rounded-lg">
                <Trophy className="w-8 h-8 text-purple-400" />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-bold">{tournament.title}</h1>
                  <Badge className={`px-3 py-1 ${getStatusColor(tournament.status)}`}>
                    {tournament.status === 'registration' ? 'ثبت‌نام' : 
                     tournament.status === 'starting' ? 'در حال شروع' :
                     tournament.status === 'live' ? 'زنده' :
                     tournament.status === 'paused' ? 'متوقف' :
                     tournament.status === 'finished' ? 'پایان یافته' : 'لغو شده'}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {tournament.participants.length}/{tournament.maxParticipants} شرکت‌کننده
                  </span>
                  <span className="flex items-center gap-1">
                    <DollarSign className="w-4 h-4" />
                    جایزه: {tournament.prize}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    شروع: {tournament.startTime}
                  </span>
                </div>
              </div>
            </div>

            {/* Control Buttons */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoRefreshEnabled(!autoRefreshEnabled)}
                className={autoRefreshEnabled ? 'bg-green-500/10' : ''}
              >
                <RefreshCw className={`w-4 h-4 ml-2 ${autoRefreshEnabled ? 'animate-spin' : ''}`} />
                تازه‌سازی خودکار
              </Button>

              {tournament.status === 'registration' && (
                <Button onClick={onStartTournament} disabled={isLoading}>
                  <Play className="w-4 h-4 ml-2" />
                  شروع تورنومنت
                </Button>
              )}

              {tournament.status === 'live' && (
                <>
                  <Button variant="outline" onClick={onPauseTournament} disabled={isLoading}>
                    <Pause className="w-4 h-4 ml-2" />
                    توقف
                  </Button>
                  <Button variant="destructive" onClick={onEndTournament} disabled={isLoading}>
                    <Square className="w-4 h-4 ml-2" />
                    پایان
                  </Button>
                </>
              )}

              {tournament.status === 'paused' && (
                <Button onClick={onResumeTournament} disabled={isLoading}>
                  <Play className="w-4 h-4 ml-2" />
                  ادامه
                </Button>
              )}

              {['registration', 'starting', 'live', 'paused'].includes(tournament.status) && (
                <Button variant="outline" onClick={onCancelTournament} disabled={isLoading}>
                  <XCircle className="w-4 h-4 ml-2" />
                  لغو
                </Button>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          {tournament.status !== 'registration' && (
            <div className="mt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span>پیشرفت تورنومنت</span>
                <span>{getTournamentProgress()}%</span>
              </div>
              <Progress value={getTournamentProgress()} className="h-2" />
            </div>
          )}
        </CardHeader>
      </Card>

      {/* Real-time Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-500">{tournament.stats.completedMatches}</div>
            <div className="text-sm text-muted-foreground">مسابقات تمام شده</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-500">{tournament.stats.liveMatches}</div>
            <div className="text-sm text-muted-foreground">مسابقات زنده</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-500">{tournament.stats.spectators}</div>
            <div className="text-sm text-muted-foreground">تماشاگر</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-500">{tournament.stats.averageMatchTime}m</div>
            <div className="text-sm text-muted-foreground">متوسط زمان مسابقه</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-500">{tournament.stats.revenue.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">درآمد (تومان)</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Management Panel */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">نمای کلی</TabsTrigger>
          <TabsTrigger value="participants">شرکت‌کنندگان</TabsTrigger>
          <TabsTrigger value="matches">مسابقات</TabsTrigger>
          <TabsTrigger value="stream">پخش زنده</TabsTrigger>
          <TabsTrigger value="moderation">تعدیل</TabsTrigger>
          <TabsTrigger value="settings">تنظیمات</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {/* Current Round Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  دور جاری: {tournament.currentRound}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="p-3 bg-green-500/10 rounded-lg">
                    <div className="text-lg font-bold text-green-500">
                      {tournament.matches.filter(m => m.status === 'finished' && m.round === tournament.currentRound).length}
                    </div>
                    <div className="text-xs text-muted-foreground">تمام شده</div>
                  </div>
                  <div className="p-3 bg-red-500/10 rounded-lg">
                    <div className="text-lg font-bold text-red-500">
                      {tournament.matches.filter(m => m.status === 'live' && m.round === tournament.currentRound).length}
                    </div>
                    <div className="text-xs text-muted-foreground">زنده</div>
                  </div>
                </div>

                <Separator />

                {/* Live Matches */}
                <div className="space-y-2">
                  <h4 className="font-medium text-sm">مسابقات زنده</h4>
                  {tournament.matches.filter(m => m.status === 'live').length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      هیچ مسابقه‌ای در حال برگزاری نیست
                    </p>
                  ) : (
                    tournament.matches.filter(m => m.status === 'live').map((match) => (
                      <div key={match.id} className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 text-sm">
                            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                            {match.participant1.name} vs {match.participant2.name}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button size="sm" variant="outline" onClick={() => setSelectedMatch(match)}>
                              <Eye className="w-3 h-3 ml-1" />
                              مشاهده
                            </Button>
                            {match.streamUrl && (
                              <Button size="sm">
                                <Camera className="w-3 h-3 ml-1" />
                                استریم
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Top Participants */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Crown className="w-5 h-5" />
                  برترین شرکت‌کنندگان
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {tournament.participants
                    .filter(p => p.status === 'active')
                    .sort((a, b) => b.level - a.level)
                    .slice(0, 5)
                    .map((participant, index) => (
                      <div key={participant.id} className="flex items-center gap-3 p-2 rounded-lg bg-secondary/30">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white font-bold text-sm">
                          {index + 1}
                        </div>
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={participant.avatar} />
                          <AvatarFallback>{participant.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="font-medium text-sm">{participant.name}</div>
                          <div className="text-xs text-muted-foreground">{participant.rank}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium">Level {participant.level}</div>
                          <div className={`w-2 h-2 rounded-full ${participant.isOnline ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Alerts & Notifications */}
          {tournament.status === 'live' && (
            <div className="space-y-3">
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  تورنومنت در حال اجرا است. تمام تغییرات به صورت زنده اعمال می‌شوند.
                </AlertDescription>
              </Alert>
            </div>
          )}
        </TabsContent>

        {/* Participants Tab */}
        <TabsContent value="participants" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    مدیریت شرکت‌کنندگان ({tournament.participants.length})
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 ml-2" />
                      خروجی Excel
                    </Button>
                    <Button variant="outline" size="sm">
                      <Share2 className="w-4 h-4 ml-2" />
                      اشتراک‌گذاری
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Filters */}
                  <div className="flex gap-4">
                    <Input placeholder="جستجوی نام..." className="flex-1" />
                    <Select defaultValue="all">
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                        <SelectItem value="active">فعال</SelectItem>
                        <SelectItem value="disqualified">محروم</SelectItem>
                        <SelectItem value="withdrawn">انصراف</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Participants List */}
                  <div className="space-y-2">
                    {tournament.participants.map((participant) => (
                      <div key={participant.id} className="flex items-center gap-4 p-4 border rounded-lg">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={participant.avatar} />
                          <AvatarFallback>{participant.name[0]}</AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{participant.name}</span>
                            <div className={`w-2 h-2 rounded-full ${participant.isOnline ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                            {participant.isReady && <Badge variant="secondary" className="text-xs">آماده</Badge>}
                            <Badge variant="outline" className="text-xs">{participant.rank}</Badge>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Level {participant.level} • ثبت‌نام: {participant.registrationTime}
                            {participant.warnings > 0 && (
                              <span className="text-yellow-500 mr-2">
                                • {participant.warnings} اخطار
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Badge 
                            variant={participant.status === 'active' ? 'default' : 'destructive'}
                            className="text-xs"
                          >
                            {participant.status === 'active' ? 'فعال' : 
                             participant.status === 'disqualified' ? 'محروم' : 'انصراف'}
                          </Badge>

                          {participant.status === 'active' && (
                            <div className="flex gap-1">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleParticipantAction(participant.id, 'warn')}
                              >
                                <AlertTriangle className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleParticipantAction(participant.id, 'mute')}
                              >
                                <Volume2 className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleParticipantAction(participant.id, 'disqualify')}
                              >
                                <Ban className="w-3 h-3" />
                              </Button>
                            </div>
                          )}
                          
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setSelectedParticipant(participant)}
                          >
                            <Eye className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Matches Tab */}
        <TabsContent value="matches" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  مدیریت مسابقات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Match Controls */}
                  <div className="flex justify-between items-center">
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Play className="w-4 h-4 ml-2" />
                        شروع همه مسابقات
                      </Button>
                      <Button variant="outline" size="sm">
                        <Pause className="w-4 h-4 ml-2" />
                        توقف همه
                      </Button>
                    </div>
                    <Select defaultValue={tournament.currentRound}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="یک‌چهارم">یک‌چهارم نهایی</SelectItem>
                        <SelectItem value="نیمه‌نهایی">نیمه‌نهایی</SelectItem>
                        <SelectItem value="فینال">فینال</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Matches Grid */}
                  <div className="grid gap-4">
                    {tournament.matches
                      .filter(m => m.round === tournament.currentRound)
                      .map((match) => (
                        <Card key={match.id} className="border">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              {/* Match Info */}
                              <div className="flex items-center gap-4 flex-1">
                                <Badge className={getStatusColor(match.status)}>
                                  {match.status === 'upcoming' ? 'در انتظار' :
                                   match.status === 'live' ? 'زنده' :
                                   match.status === 'paused' ? 'متوقف' :
                                   match.status === 'finished' ? 'تمام' : 'لغو'}
                                </Badge>
                                
                                <div className="flex items-center gap-3">
                                  <div className="text-center">
                                    <div className="font-medium">{match.participant1.name}</div>
                                    <div className="text-sm text-muted-foreground">{match.participant1.rank}</div>
                                  </div>
                                  
                                  <div className="text-center px-4">
                                    <div className="text-lg font-bold">
                                      {match.score1 ?? 0} - {match.score2 ?? 0}
                                    </div>
                                    <div className="text-xs text-muted-foreground">VS</div>
                                  </div>
                                  
                                  <div className="text-center">
                                    <div className="font-medium">{match.participant2.name}</div>
                                    <div className="text-sm text-muted-foreground">{match.participant2.rank}</div>
                                  </div>
                                </div>
                              </div>

                              {/* Match Actions */}
                              <div className="flex items-center gap-2">
                                {match.status === 'upcoming' && (
                                  <Button 
                                    size="sm" 
                                    onClick={() => handleMatchAction(match.id, 'start')}
                                  >
                                    <Play className="w-3 h-3 ml-1" />
                                    شروع
                                  </Button>
                                )}
                                
                                {match.status === 'live' && (
                                  <>
                                    <Button 
                                      size="sm" 
                                      variant="outline"
                                      onClick={() => handleMatchAction(match.id, 'pause')}
                                    >
                                      <Pause className="w-3 h-3 ml-1" />
                                      توقف
                                    </Button>
                                    <Button 
                                      size="sm" 
                                      variant="outline"
                                      onClick={() => handleMatchAction(match.id, 'declare-winner')}
                                    >
                                      <Crown className="w-3 h-3 ml-1" />
                                      اعلام برنده
                                    </Button>
                                  </>
                                )}
                                
                                {match.status === 'paused' && (
                                  <Button 
                                    size="sm"
                                    onClick={() => handleMatchAction(match.id, 'resume')}
                                  >
                                    <Play className="w-3 h-3 ml-1" />
                                    ادامه
                                  </Button>
                                )}

                                {match.streamUrl && (
                                  <Button size="sm" variant="outline">
                                    <Camera className="w-3 h-3 ml-1" />
                                    استریم
                                  </Button>
                                )}
                                
                                <Button 
                                  size="sm" 
                                  variant="ghost"
                                  onClick={() => setSelectedMatch(match)}
                                >
                                  <Eye className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Stream Tab */}
        <TabsContent value="stream" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="w-5 h-5" />
                  مدیریت پخش زنده
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">آدرس استریم اصلی</label>
                      <Input value={tournament.streamUrl || ''} placeholder="https://twitch.tv/..." />
                    </div>
                    <div>
                      <label className="text-sm font-medium">کیفیت پخش</label>
                      <Select defaultValue="1080p">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="720p">HD (720p)</SelectItem>
                          <SelectItem value="1080p">Full HD (1080p)</SelectItem>
                          <SelectItem value="4k">4K UHD</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <input type="checkbox" id="autoSwitch" defaultChecked />
                      <label htmlFor="autoSwitch" className="text-sm">تعویض خودکار بین مسابقات</label>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-sm font-medium text-green-500">پخش زنده فعال</span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {tournament.stats.spectators} تماشاگر آنلاین
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Button className="w-full">
                        <Mic className="w-4 h-4 ml-2" />
                        شروع تفسیر زنده
                      </Button>
                      <Button variant="outline" className="w-full">
                        <Volume2 className="w-4 h-4 ml-2" />
                        تنظیمات صدا
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Moderation Tab */}
        <TabsContent value="moderation" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  تعدیل و نظارت
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <Flag className="h-4 w-4" />
                  <AlertDescription>
                    گزارش‌های جدید: 3 گزارش در انتظار بررسی
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="font-medium">اقدامات سریع</h4>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <Ban className="w-4 h-4 ml-2" />
                        محروم کردن بازیکن
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Volume2 className="w-4 h-4 ml-2" />
                        ساکت کردن در چت
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <AlertTriangle className="w-4 h-4 ml-2" />
                        ارسال اخطار
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <XCircle className="w-4 h-4 ml-2" />
                        لغو مسابقه
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-medium">آمار تعدیل</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>اخطارهای داده شده:</span>
                        <span className="font-medium">12</span>
                      </div>
                      <div className="flex justify-between">
                        <span>بازیکنان محروم:</span>
                        <span className="font-medium text-red-500">3</span>
                      </div>
                      <div className="flex justify-between">
                        <span>مسابقات لغو شده:</span>
                        <span className="font-medium">1</span>
                      </div>
                      <div className="flex justify-between">
                        <span>گزارش‌های بررسی شده:</span>
                        <span className="font-medium text-green-500">28</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  تنظیمات تورنومنت
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium">تنظیمات زمانی</h4>
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm">مدت هر مسابقه (دقیقه)</label>
                        <Input type="number" value={tournament.settings.matchDuration} />
                      </div>
                      <div>
                        <label className="text-sm">استراحت بین دورها (دقیقه)</label>
                        <Input type="number" value={tournament.settings.breakBetweenRounds} />
                      </div>
                      <div>
                        <label className="text-sm">زمان محرومیت تاخیر (دقیقه)</label>
                        <Input type="number" value={tournament.settings.disqualificationTime} />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-medium">تنظیمات عمومی</h4>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <input type="checkbox" id="allowChat" defaultChecked={tournament.settings.allowChat} />
                        <label htmlFor="allowChat" className="text-sm">فعال بودن چت</label>
                      </div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <input type="checkbox" id="allowPause" defaultChecked={tournament.settings.allowPause} />
                        <label htmlFor="allowPause" className="text-sm">امکان توقف مسابقات</label>
                      </div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <input type="checkbox" id="autoAdvance" defaultChecked={tournament.autoAdvance} />
                        <label htmlFor="autoAdvance" className="text-sm">پیشروی خودکار بین دورها</label>
                      </div>
                      <div>
                        <label className="text-sm">سطح نظارت</label>
                        <Select defaultValue={tournament.settings.moderationLevel}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">کم</SelectItem>
                            <SelectItem value="medium">متوسط</SelectItem>
                            <SelectItem value="high">بالا</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex justify-end gap-3">
                  <Button variant="outline">
                    بازگرداندن پیش‌فرض
                  </Button>
                  <Button>
                    <CheckCircle className="w-4 h-4 ml-2" />
                    ذخیره تغییرات
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>

      {/* Participant Detail Dialog */}
      <Dialog open={!!selectedParticipant} onOpenChange={() => setSelectedParticipant(null)}>
        <DialogContent className="max-w-2xl" dir="rtl">
          <DialogHeader>
            <DialogTitle>جزئیات شرکت‌کننده</DialogTitle>
          </DialogHeader>
          {selectedParticipant && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={selectedParticipant.avatar} />
                  <AvatarFallback>{selectedParticipant.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-bold text-lg">{selectedParticipant.name}</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Badge variant="outline">{selectedParticipant.rank}</Badge>
                    <span>Level {selectedParticipant.level}</span>
                    <div className={`w-2 h-2 rounded-full ${selectedParticipant.isOnline ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">وضعیت:</span>
                  <Badge className="mr-2" variant={selectedParticipant.status === 'active' ? 'default' : 'destructive'}>
                    {selectedParticipant.status === 'active' ? 'فعال' : 
                     selectedParticipant.status === 'disqualified' ? 'محروم' : 'انصراف'}
                  </Badge>
                </div>
                <div>
                  <span className="text-muted-foreground">تعداد اخطار:</span>
                  <span className="mr-2 font-medium">{selectedParticipant.warnings}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">زمان ثبت‌نام:</span>
                  <span className="mr-2">{selectedParticipant.registrationTime}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">آماده:</span>
                  <span className="mr-2">{selectedParticipant.isReady ? '✓ آماده' : '✗ آماده نیست'}</span>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1">ارسال پیام</Button>
                <Button variant="outline" className="flex-1">مشاهده پروفایل</Button>
                <Button variant="destructive">محروم کردن</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}