import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Textarea } from '../ui/textarea';
import { Switch } from '../ui/switch';
import { Slider } from '../ui/slider';
import { 
  Camera, Mic, MicOff, Volume2, VolumeX, Play, Pause,
  Square, Settings, Users, Eye, MessageSquare, Share2,
  Monitor, Maximize, Minimize, RotateCcw, Zap, Radio,
  Clock, Trophy, Target, Flag, Heart, ThumbsUp,
  Send, Gift, Star, Crown, Shield, AlertCircle
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion, AnimatePresence } from 'motion/react';

export interface StreamSettings {
  quality: '720p' | '1080p' | '4K';
  bitrate: number;
  fps: number;
  audioQuality: 'low' | 'medium' | 'high';
  enableChat: boolean;
  enableDonations: boolean;
  moderationLevel: 'low' | 'medium' | 'high';
  autoSwitchScenes: boolean;
  recordStream: boolean;
  allowClips: boolean;
}

export interface StreamViewer {
  id: string;
  username: string;
  avatar?: string;
  isSubscribed: boolean;
  isModerator: boolean;
  isVip: boolean;
  joinTime: string;
  country: string;
}

export interface ChatMessage {
  id: string;
  user: StreamViewer;
  message: string;
  timestamp: string;
  type: 'message' | 'donation' | 'subscription' | 'system';
  amount?: number; // for donations
  highlighted?: boolean;
  emotes?: string[];
}

export interface StreamStats {
  viewers: number;
  peakViewers: number;
  averageViewTime: number;
  chatMessages: number;
  donations: number;
  totalDonationAmount: number;
  followers: number;
  subscribers: number;
  uptime: string;
  quality: {
    dropped: number;
    bitrate: number;
    fps: number;
  };
}

export interface TournamentStreamProps {
  tournamentId: string;
  tournamentTitle: string;
  isLive: boolean;
  streamUrl?: string;
  settings: StreamSettings;
  viewers: StreamViewer[];
  messages: ChatMessage[];
  stats: StreamStats;
  currentMatch?: {
    id: string;
    player1: string;
    player2: string;
    score1: number;
    score2: number;
    round: string;
  };
  onUpdateSettings: (settings: StreamSettings) => void;
  onStartStream: () => void;
  onStopStream: () => void;
  onSendMessage: (message: string) => void;
  onModerateUser: (userId: string, action: 'mute' | 'ban' | 'timeout') => void;
  onSwitchScene: (scene: string) => void;
}

const STREAM_SCENES = [
  { id: 'match', name: 'مسابقه اصلی', icon: Trophy },
  { id: 'lobby', name: 'لابی انتظار', icon: Users },
  { id: 'bracket', name: 'جدول مسابقات', icon: Target },
  { id: 'interview', name: 'مصاحبه', icon: Mic },
  { id: 'break', name: 'استراحت', icon: Clock },
  { id: 'ceremony', name: 'مراسم اهدا', icon: Crown }
];

export function TournamentStream({
  tournamentId,
  tournamentTitle,
  isLive,
  streamUrl,
  settings,
  viewers,
  messages,
  stats,
  currentMatch,
  onUpdateSettings,
  onStartStream,
  onStopStream,
  onSendMessage,
  onModerateUser,
  onSwitchScene
}: TournamentStreamProps) {
  const [activeTab, setActiveTab] = useState('stream');
  const [currentScene, setCurrentScene] = useState('match');
  const [newMessage, setNewMessage] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [volume, setVolume] = useState(50);
  const [isMuted, setIsMuted] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [chatFilter, setChatFilter] = useState('all');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const chatRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    onSendMessage(newMessage.trim());
    setNewMessage('');
  };

  const handleSceneChange = (sceneId: string) => {
    setCurrentScene(sceneId);
    onSwitchScene(sceneId);
    toast.success(`صحنه تغییر یافت به: ${STREAM_SCENES.find(s => s.id === sceneId)?.name}`);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      videoRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const formatUptime = (uptime: string) => {
    // Convert uptime to Persian format
    return uptime.replace(/(\d+)h (\d+)m (\d+)s/, '$1 ساعت $2 دقیقه $3 ثانیه');
  };

  const getViewerBadge = (viewer: StreamViewer) => {
    if (viewer.isModerator) return <Badge variant="destructive" className="text-xs">مدیر</Badge>;
    if (viewer.isVip) return <Badge variant="default" className="text-xs">VIP</Badge>;
    if (viewer.isSubscribed) return <Badge variant="secondary" className="text-xs">عضو</Badge>;
    return null;
  };

  const getMessageTypeColor = (type: ChatMessage['type']) => {
    switch (type) {
      case 'donation': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'subscription': return 'text-purple-500 bg-purple-500/10 border-purple-500/20';
      case 'system': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      default: return '';
    }
  };

  const filteredMessages = messages.filter(msg => {
    if (chatFilter === 'all') return true;
    if (chatFilter === 'donations') return msg.type === 'donation';
    if (chatFilter === 'subscribers') return msg.user.isSubscribed;
    if (chatFilter === 'moderators') return msg.user.isModerator;
    return true;
  });

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-red-500/10 to-purple-500/10 border-red-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-red-500/20 rounded-lg">
                <Camera className="w-8 h-8 text-red-400" />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-bold">{tournamentTitle}</h1>
                  {isLive && (
                    <Badge className="bg-red-500 text-white animate-pulse px-3 py-1">
                      <div className="w-2 h-2 bg-white rounded-full ml-2 animate-pulse"></div>
                      زنده
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    {stats.viewers.toLocaleString()} تماشاگر
                  </span>
                  {isLive && (
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {formatUptime(stats.uptime)}
                    </span>
                  )}
                  <span className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    {stats.chatMessages.toLocaleString()} پیام
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setShowSettings(!showSettings)}>
                <Settings className="w-4 h-4 ml-2" />
                تنظیمات
              </Button>
              
              {!isLive ? (
                <Button onClick={onStartStream} className="bg-red-500 hover:bg-red-600">
                  <Radio className="w-4 h-4 ml-2" />
                  شروع پخش زنده
                </Button>
              ) : (
                <Button variant="destructive" onClick={onStopStream}>
                  <Square className="w-4 h-4 ml-2" />
                  پایان پخش
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Current Match Info */}
      {currentMatch && (
        <Card className="bg-gradient-to-r from-blue-500/10 to-green-500/10 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-center gap-6">
              <div className="text-center">
                <div className="font-bold text-lg">{currentMatch.player1}</div>
                <div className="text-2xl font-bold text-blue-500">{currentMatch.score1}</div>
              </div>
              <div className="text-center px-6">
                <div className="text-sm text-muted-foreground">{currentMatch.round}</div>
                <div className="text-lg font-medium">VS</div>
              </div>
              <div className="text-center">
                <div className="font-bold text-lg">{currentMatch.player2}</div>
                <div className="text-2xl font-bold text-green-500">{currentMatch.score2}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Stream Player */}
        <div className="lg:col-span-3 space-y-4">
          <Card>
            <CardContent className="p-0">
              <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
                {streamUrl ? (
                  <video 
                    ref={videoRef}
                    className="w-full h-full object-cover"
                    controls
                    autoPlay
                    muted={isMuted}
                  >
                    <source src={streamUrl} type="application/x-mpegURL" />
                    مرورگر شما از ویدئو پشتیبانی نمی‌کند.
                  </video>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    <div className="text-center">
                      <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p>استریم در دسترس نیست</p>
                    </div>
                  </div>
                )}
                
                {/* Stream Overlay */}
                {isLive && (
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-red-500 text-white">
                      <div className="w-2 h-2 bg-white rounded-full ml-2 animate-pulse"></div>
                      زنده
                    </Badge>
                  </div>
                )}
                
                {/* Viewer Count Overlay */}
                <div className="absolute top-4 right-4">
                  <Badge variant="secondary" className="bg-black/50 backdrop-blur">
                    <Eye className="w-3 h-3 ml-1" />
                    {stats.viewers.toLocaleString()}
                  </Badge>
                </div>

                {/* Stream Controls */}
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="bg-black/50 backdrop-blur"
                      onClick={() => setIsMuted(!isMuted)}
                    >
                      {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </Button>
                    
                    <div className="flex items-center gap-2">
                      <Volume2 className="w-4 h-4 text-white" />
                      <Slider
                        value={[volume]}
                        onValueChange={(value) => setVolume(value[0])}
                        max={100}
                        step={1}
                        className="w-20"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="bg-black/50 backdrop-blur"
                      onClick={toggleFullscreen}
                    >
                      {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Scene Control */}
          {isLive && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Monitor className="w-5 h-5" />
                  کنترل صحنه
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                  {STREAM_SCENES.map((scene) => {
                    const IconComponent = scene.icon;
                    return (
                      <Button
                        key={scene.id}
                        variant={currentScene === scene.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleSceneChange(scene.id)}
                        className="flex flex-col gap-1 h-auto py-3"
                      >
                        <IconComponent className="w-4 h-4" />
                        <span className="text-xs">{scene.name}</span>
                      </Button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Stream Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Zap className="w-5 h-5" />
                آمار زنده
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="p-2 bg-blue-500/10 rounded">
                  <div className="font-bold text-blue-500">{stats.viewers.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">تماشاگر</div>
                </div>
                <div className="p-2 bg-green-500/10 rounded">
                  <div className="font-bold text-green-500">{stats.peakViewers.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">حداکثر</div>
                </div>
                <div className="p-2 bg-purple-500/10 rounded">
                  <div className="font-bold text-purple-500">{stats.chatMessages.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">پیام</div>
                </div>
                <div className="p-2 bg-yellow-500/10 rounded">
                  <div className="font-bold text-yellow-500">{stats.followers.toLocaleString()}</div>
                  <div className="text-xs text-muted-foreground">فالوور</div>
                </div>
              </div>
              
              {stats.donations > 0 && (
                <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-center">
                  <div className="font-bold text-yellow-500">
                    {stats.totalDonationAmount.toLocaleString()} تومان
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {stats.donations} حمایت مالی
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Chat */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  چت زنده
                </CardTitle>
                <Select value={chatFilter} onValueChange={setChatFilter}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">همه</SelectItem>
                    <SelectItem value="donations">حمایت‌ها</SelectItem>
                    <SelectItem value="subscribers">اعضا</SelectItem>
                    <SelectItem value="moderators">مدیران</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Chat Messages */}
              <div 
                ref={chatRef}
                className="h-80 overflow-y-auto space-y-2 p-2 bg-secondary/20 rounded border scrollbar-hide"
              >
                <AnimatePresence>
                  {filteredMessages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className={`p-2 rounded-lg border ${
                        message.highlighted ? 'bg-yellow-500/10 border-yellow-500/30' : ''
                      } ${getMessageTypeColor(message.type)}`}
                    >
                      <div className="flex items-start gap-2">
                        <Avatar className="w-6 h-6">
                          <AvatarImage src={message.user.avatar} />
                          <AvatarFallback className="text-xs">
                            {message.user.username[0]}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm truncate">
                              {message.user.username}
                            </span>
                            {getViewerBadge(message.user)}
                            {message.amount && (
                              <Badge variant="default" className="text-xs bg-yellow-500">
                                <Gift className="w-3 h-3 ml-1" />
                                {message.amount.toLocaleString()}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm break-words">{message.message}</p>
                          {message.emotes && (
                            <div className="flex gap-1 mt-1">
                              {message.emotes.map((emote, index) => (
                                <span key={index} className="text-lg">{emote}</span>
                              ))}
                            </div>
                          )}
                        </div>
                        
                        <span className="text-xs text-muted-foreground">
                          {new Date(message.timestamp).toLocaleTimeString('fa-IR')}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* Send Message */}
              <div className="flex gap-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="پیام خود را بنویسید..."
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-1"
                />
                <Button onClick={handleSendMessage} size="sm">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Active Viewers */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="w-5 h-5" />
                تماشاگران فعال ({viewers.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-40 overflow-y-auto scrollbar-hide">
                {viewers.slice(0, 10).map((viewer) => (
                  <div key={viewer.id} className="flex items-center gap-2 p-2 rounded bg-secondary/30">
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={viewer.avatar} />
                      <AvatarFallback className="text-xs">{viewer.username[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{viewer.username}</div>
                      <div className="text-xs text-muted-foreground">{viewer.country}</div>
                    </div>
                    {getViewerBadge(viewer)}
                  </div>
                ))}
                {viewers.length > 10 && (
                  <div className="text-center text-sm text-muted-foreground pt-2">
                    و {viewers.length - 10} نفر دیگر...
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <Card className="fixed inset-4 z-50 bg-background border shadow-lg overflow-auto">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                تنظیمات پخش زنده
              </CardTitle>
              <Button variant="ghost" onClick={() => setShowSettings(false)}>
                ✕
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <Tabs defaultValue="video" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="video">ویدئو</TabsTrigger>
                <TabsTrigger value="audio">صدا</TabsTrigger>
                <TabsTrigger value="chat">چت</TabsTrigger>
                <TabsTrigger value="advanced">پیشرفته</TabsTrigger>
              </TabsList>
              
              <TabsContent value="video" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">کیفیت ویدئو</label>
                    <Select 
                      value={settings.quality} 
                      onValueChange={(value: any) => onUpdateSettings({ ...settings, quality: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="720p">HD (720p)</SelectItem>
                        <SelectItem value="1080p">Full HD (1080p)</SelectItem>
                        <SelectItem value="4K">4K UHD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">نرخ فریم</label>
                    <Input 
                      type="number" 
                      value={settings.fps} 
                      onChange={(e) => onUpdateSettings({ ...settings, fps: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Bitrate (kbps)</label>
                    <Input 
                      type="number" 
                      value={settings.bitrate} 
                      onChange={(e) => onUpdateSettings({ ...settings, bitrate: parseInt(e.target.value) })}
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={settings.recordStream}
                      onCheckedChange={(checked) => onUpdateSettings({ ...settings, recordStream: checked })}
                    />
                    <label className="text-sm">ضبط استریم</label>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="audio" className="space-y-4">
                <div>
                  <label className="text-sm font-medium">کیفیت صدا</label>
                  <Select 
                    value={settings.audioQuality} 
                    onValueChange={(value: any) => onUpdateSettings({ ...settings, audioQuality: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">کم (128 kbps)</SelectItem>
                      <SelectItem value="medium">متوسط (256 kbps)</SelectItem>
                      <SelectItem value="high">بالا (320 kbps)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>
              
              <TabsContent value="chat" className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={settings.enableChat}
                      onCheckedChange={(checked) => onUpdateSettings({ ...settings, enableChat: checked })}
                    />
                    <label className="text-sm">فعال بودن چت</label>
                  </div>
                  
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={settings.enableDonations}
                      onCheckedChange={(checked) => onUpdateSettings({ ...settings, enableDonations: checked })}
                    />
                    <label className="text-sm">فعال بودن حمایت مالی</label>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">سطح نظارت</label>
                    <Select 
                      value={settings.moderationLevel} 
                      onValueChange={(value: any) => onUpdateSettings({ ...settings, moderationLevel: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">کم</SelectItem>
                        <SelectItem value="medium">متوسط</SelectItem>
                        <SelectItem value="high">بالا</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="advanced" className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={settings.autoSwitchScenes}
                      onCheckedChange={(checked) => onUpdateSettings({ ...settings, autoSwitchScenes: checked })}
                    />
                    <label className="text-sm">تعویض خودکار صحنه</label>
                  </div>
                  
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={settings.allowClips}
                      onCheckedChange={(checked) => onUpdateSettings({ ...settings, allowClips: checked })}
                    />
                    <label className="text-sm">اجازه ساخت کلیپ</label>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowSettings(false)}>
                لغو
              </Button>
              <Button onClick={() => setShowSettings(false)}>
                ذخیره تنظیمات
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}