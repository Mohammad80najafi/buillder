import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Switch } from '../ui/switch';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Separator } from '../ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { 
  Plus, Trophy, Users, Clock, DollarSign, Globe, MapPin,
  Target, Settings, Shield, Calendar, Tag, Star,
  AlertCircle, CheckCircle, Camera, Gamepad2, Award,
  Crown, Save, Eye, Share2
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion, AnimatePresence } from 'motion/react';

export interface TournamentFormat {
  id: string;
  name: string;
  description: string;
  minParticipants: number;
  maxParticipants: number;
  teamSize: number;
  rounds: string[];
}

export interface TournamentCreationData {
  // Basic Info
  title: string;
  description: string;
  game: string;
  gameMode: string;
  
  // Format & Structure
  format: string;
  teamSize: number;
  maxParticipants: number;
  
  // Timing
  registrationStart: string;
  registrationEnd: string;
  tournamentStart: string;
  estimatedDuration: number; // hours
  timezone: string;
  
  // Financial
  entryFee: number;
  prizePool: number;
  prizeDistribution: { rank: number; percentage: number }[];
  currency: 'IRT' | 'USD';
  
  // Rules & Requirements
  rules: string[];
  requirements: {
    minRank?: string;
    maxRank?: string;
    region?: string;
    age?: string;
    verified?: boolean;
  };
  
  // Settings
  isPublic: boolean;
  allowSpectators: boolean;
  streamEnabled: boolean;
  streamUrl?: string;
  autoStart: boolean;
  allowSubstitutes: boolean;
  
  // Branding
  banner?: string;
  logo?: string;
  tags: string[];
  sponsorLogos: string[];
}

export interface TournamentCreationProps {
  onSubmit: (data: TournamentCreationData) => Promise<void>;
  onDraft: (data: Partial<TournamentCreationData>) => void;
  initialData?: Partial<TournamentCreationData>;
  isLoading?: boolean;
}

const TOURNAMENT_FORMATS: TournamentFormat[] = [
  {
    id: 'single-elimination',
    name: 'حذفی تک‌مرحله‌ای',
    description: 'هر شکست = حذف فوری، سریع و هیجان‌انگیز',
    minParticipants: 4,
    maxParticipants: 128,
    teamSize: 1,
    rounds: ['یک‌هشتم', 'یک‌چهارم', 'نیمه‌نهایی', 'فینال']
  },
  {
    id: 'double-elimination',
    name: 'حذفی دوطرفه',
    description: 'دو شانس برای هر تیم، عادلانه‌تر و طولانی‌تر',
    minParticipants: 6,
    maxParticipants: 64,
    teamSize: 1,
    rounds: ['دور اول', 'دور دوم', 'نیمه‌نهایی', 'فینال']
  },
  {
    id: 'round-robin',
    name: 'دور برگشت',
    description: 'همه با همه، کاملاً عادلانه',
    minParticipants: 4,
    maxParticipants: 16,
    teamSize: 1,
    rounds: ['مرحله گروهی']
  },
  {
    id: 'swiss-system',
    name: 'سیستم سوئیسی',
    description: 'تطبیق مبتنی بر امتیاز، بدون حذف',
    minParticipants: 8,
    maxParticipants: 32,
    teamSize: 1,
    rounds: ['دور 1', 'دور 2', 'دور 3', 'دور 4', 'دور 5']
  }
];

const GAMES_LIST = [
  { id: 'cod', name: 'کالاف دیوتی', modes: ['تیم‌دث‌مچ', 'سرچ اند دیسترای', 'هاردپوینت', 'دامینیشن'] },
  { id: 'fifa', name: 'فیفا 24', modes: ['کیک آف', 'ایونت FUT', 'سیزن', 'دراگ'] },
  { id: 'valorant', name: 'والورانت', modes: ['انرتد', 'سوئیفت‌پلی', 'اسپایک راش', 'کامپتیتیو'] },
  { id: 'pubg', name: 'پابجی موبایل', modes: ['کلاسیک', 'TDM', 'دومینو', 'وار'] },
  { id: 'csgo', name: 'CS:GO', modes: ['کامپتیتیو', 'وینگمن', 'خطر', 'مهمات'] },
  { id: 'lol', name: 'لیگ آف لجندز', modes: ['ایونت 5v5', 'ARAM', 'TFT'] }
];

const RANKS_LIST = ['برنزی', 'نقره‌ای', 'طلایی', 'پلاتین', 'الماسی', 'استاد', 'رقیب', 'رادیانت'];

export function TournamentCreation({ 
  onSubmit, 
  onDraft, 
  initialData = {}, 
  isLoading = false 
}: TournamentCreationProps) {
  const [activeTab, setActiveTab] = useState('basic');
  const [formData, setFormData] = useState<Partial<TournamentCreationData>>({
    // Defaults
    format: 'single-elimination',
    teamSize: 1,
    maxParticipants: 32,
    currency: 'IRT',
    isPublic: true,
    allowSpectators: true,
    streamEnabled: false,
    autoStart: false,
    allowSubstitutes: true,
    prizeDistribution: [
      { rank: 1, percentage: 50 },
      { rank: 2, percentage: 30 },
      { rank: 3, percentage: 20 }
    ],
    rules: [],
    tags: [],
    requirements: {},
    ...initialData
  });
  
  const [newRule, setNewRule] = useState('');
  const [newTag, setNewTag] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const selectedFormat = TOURNAMENT_FORMATS.find(f => f.id === formData.format);
  const selectedGame = GAMES_LIST.find(g => g.id === formData.game);

  const updateField = <K extends keyof TournamentCreationData>(
    field: K,
    value: TournamentCreationData[K]
  ) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const updateRequirement = (key: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      requirements: { ...prev.requirements, [key]: value }
    }));
  };

  const addRule = () => {
    if (!newRule.trim()) return;
    const rules = [...(formData.rules || []), newRule.trim()];
    updateField('rules', rules);
    setNewRule('');
    toast.success('قانون جدید اضافه شد');
  };

  const removeRule = (index: number) => {
    const rules = formData.rules?.filter((_, i) => i !== index) || [];
    updateField('rules', rules);
  };

  const addTag = () => {
    if (!newTag.trim()) return;
    const tags = [...(formData.tags || []), newTag.trim()];
    updateField('tags', tags);
    setNewTag('');
  };

  const removeTag = (tag: string) => {
    const tags = formData.tags?.filter(t => t !== tag) || [];
    updateField('tags', tags);
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.title?.trim()) newErrors.title = 'نام تورنومنت الزامی است';
    if (!formData.description?.trim()) newErrors.description = 'توضیحات الزامی است';
    if (!formData.game) newErrors.game = 'انتخاب بازی الزامی است';
    if (!formData.gameMode) newErrors.gameMode = 'انتخاب حالت بازی الزامی است';
    
    if (!formData.registrationStart) newErrors.registrationStart = 'زمان شروع ثبت‌نام الزامی است';
    if (!formData.registrationEnd) newErrors.registrationEnd = 'زمان پایان ثبت‌نام الزامی است';
    if (!formData.tournamentStart) newErrors.tournamentStart = 'زمان شروع تورنومنت الزامی است';

    if (!formData.entryFee || formData.entryFee < 0) newErrors.entryFee = 'ورودی باید عدد مثبت باشد';
    if (!formData.prizePool || formData.prizePool < 0) newErrors.prizePool = 'جایزه باید عدد مثبت باشد';

    if (!formData.rules || formData.rules.length === 0) newErrors.rules = 'حداقل یک قانون اضافه کنید';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      toast.error('لطفاً موارد مشخص شده را تکمیل کنید');
      return;
    }

    try {
      await onSubmit(formData as TournamentCreationData);
      toast.success('تورنومنت با موفقیت ایجاد شد');
    } catch (error) {
      toast.error('خطا در ایجاد تورنومنت');
    }
  };

  const saveDraft = () => {
    onDraft(formData);
    toast.success('پیش‌نویس ذخیره شد');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6" dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Trophy className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <CardTitle className="text-xl">ایجاد تورنومنت جدید</CardTitle>
                <p className="text-muted-foreground text-sm">
                  تورنومنت حرفه‌ای خود را طراحی و برگزار کنید
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={saveDraft} disabled={isLoading}>
                <Save className="w-4 h-4 ml-2" />
                ذخیره پیش‌نویس
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Form */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="basic">اطلاعات کلی</TabsTrigger>
          <TabsTrigger value="format">فرمت و ساختار</TabsTrigger>
          <TabsTrigger value="timing">زمان‌بندی</TabsTrigger>
          <TabsTrigger value="financial">مالی و جوایز</TabsTrigger>
          <TabsTrigger value="rules">قوانین و تنظیمات</TabsTrigger>
        </TabsList>

        {/* Basic Info Tab */}
        <TabsContent value="basic" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  اطلاعات اولیه
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">نام تورنومنت *</Label>
                    <Input
                      id="title"
                      value={formData.title || ''}
                      onChange={(e) => updateField('title', e.target.value)}
                      placeholder="مثلاً: کاپ طلایی کالاف دیوتی"
                      className={errors.title ? 'border-red-500' : ''}
                    />
                    {errors.title && (
                      <p className="text-sm text-red-500 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {errors.title}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="game">بازی *</Label>
                    <Select value={formData.game} onValueChange={(value) => updateField('game', value)}>
                      <SelectTrigger className={errors.game ? 'border-red-500' : ''}>
                        <SelectValue placeholder="انتخاب بازی" />
                      </SelectTrigger>
                      <SelectContent>
                        {GAMES_LIST.map((game) => (
                          <SelectItem key={game.id} value={game.id}>
                            <div className="flex items-center gap-2">
                              <Gamepad2 className="w-4 h-4" />
                              {game.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.game && (
                      <p className="text-sm text-red-500 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {errors.game}
                      </p>
                    )}
                  </div>
                </div>

                {selectedGame && (
                  <div className="space-y-2">
                    <Label htmlFor="gameMode">حالت بازی *</Label>
                    <Select value={formData.gameMode} onValueChange={(value) => updateField('gameMode', value)}>
                      <SelectTrigger className={errors.gameMode ? 'border-red-500' : ''}>
                        <SelectValue placeholder="انتخاب حالت بازی" />
                      </SelectTrigger>
                      <SelectContent>
                        {selectedGame.modes.map((mode) => (
                          <SelectItem key={mode} value={mode}>
                            {mode}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.gameMode && (
                      <p className="text-sm text-red-500 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {errors.gameMode}
                      </p>
                    )}
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="description">توضیحات تورنومنت *</Label>
                  <Textarea
                    id="description"
                    value={formData.description || ''}
                    onChange={(e) => updateField('description', e.target.value)}
                    placeholder="توضیحات کاملی از تورنومنت، قوانین کلی، و نکات مهم..."
                    className={`min-h-[100px] ${errors.description ? 'border-red-500' : ''}`}
                  />
                  {errors.description && (
                    <p className="text-sm text-red-500 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {errors.description}
                    </p>
                  )}
                </div>

                {/* Tags */}
                <div className="space-y-2">
                  <Label>برچسب‌ها (اختیاری)</Label>
                  <div className="flex gap-2">
                    <Input
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      placeholder="اضافه کردن برچسب..."
                      onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                      className="flex-1"
                    />
                    <Button onClick={addTag} variant="outline" size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  {formData.tags && formData.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {formData.tags.map((tag) => (
                        <Badge 
                          key={tag} 
                          variant="secondary" 
                          className="cursor-pointer hover:bg-red-500/20"
                          onClick={() => removeTag(tag)}
                        >
                          <Tag className="w-3 h-3 ml-1" />
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Format & Structure Tab */}
        <TabsContent value="format" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  فرمت تورنومنت
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {TOURNAMENT_FORMATS.map((format) => (
                    <Card 
                      key={format.id}
                      className={`cursor-pointer border-2 transition-all duration-200 ${
                        formData.format === format.id 
                          ? 'border-blue-500 bg-blue-500/5' 
                          : 'border-border hover:border-blue-400'
                      }`}
                      onClick={() => updateField('format', format.id)}
                    >
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">{format.name}</h4>
                            {formData.format === format.id && (
                              <CheckCircle className="w-5 h-5 text-blue-500" />
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{format.description}</p>
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>{format.minParticipants}-{format.maxParticipants} نفر</span>
                            <span>تیم {format.teamSize} نفره</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                <Separator />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="teamSize">اندازه تیم</Label>
                    <Select 
                      value={formData.teamSize?.toString()} 
                      onValueChange={(value) => updateField('teamSize', parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">انفردی (۱ نفر)</SelectItem>
                        <SelectItem value="2">دوتایی (۲ نفر)</SelectItem>
                        <SelectItem value="3">سه‌نفره (۳ نفر)</SelectItem>
                        <SelectItem value="4">چهارنفره (۴ نفر)</SelectItem>
                        <SelectItem value="5">پنج‌نفره (۵ نفر)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxParticipants">حداکثر شرکت‌کنندگان</Label>
                    <Select 
                      value={formData.maxParticipants?.toString()} 
                      onValueChange={(value) => updateField('maxParticipants', parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {selectedFormat && Array.from(
                          { length: Math.floor((selectedFormat.maxParticipants - selectedFormat.minParticipants) / 2) + 1 },
                          (_, i) => selectedFormat.minParticipants + i * 2
                        ).filter(n => n <= selectedFormat.maxParticipants).map((num) => (
                          <SelectItem key={num} value={num.toString()}>
                            {num} {formData.teamSize === 1 ? 'بازیکن' : 'تیم'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="estimatedDuration">مدت تخمینی (ساعت)</Label>
                    <Input
                      type="number"
                      value={formData.estimatedDuration || ''}
                      onChange={(e) => updateField('estimatedDuration', parseInt(e.target.value) || 0)}
                      placeholder="مثلاً ۳"
                      min="1"
                      max="48"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Timing Tab */}
        <TabsContent value="timing" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  برنامه‌ریزی زمانی
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="registrationStart">شروع ثبت‌نام *</Label>
                    <Input
                      type="datetime-local"
                      id="registrationStart"
                      value={formData.registrationStart || ''}
                      onChange={(e) => updateField('registrationStart', e.target.value)}
                      className={errors.registrationStart ? 'border-red-500' : ''}
                    />
                    {errors.registrationStart && (
                      <p className="text-sm text-red-500">{errors.registrationStart}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="registrationEnd">پایان ثبت‌نام *</Label>
                    <Input
                      type="datetime-local"
                      id="registrationEnd"
                      value={formData.registrationEnd || ''}
                      onChange={(e) => updateField('registrationEnd', e.target.value)}
                      className={errors.registrationEnd ? 'border-red-500' : ''}
                    />
                    {errors.registrationEnd && (
                      <p className="text-sm text-red-500">{errors.registrationEnd}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="tournamentStart">شروع تورنومنت *</Label>
                    <Input
                      type="datetime-local"
                      id="tournamentStart"
                      value={formData.tournamentStart || ''}
                      onChange={(e) => updateField('tournamentStart', e.target.value)}
                      className={errors.tournamentStart ? 'border-red-500' : ''}
                    />
                    {errors.tournamentStart && (
                      <p className="text-sm text-red-500">{errors.tournamentStart}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="timezone">منطقه زمانی</Label>
                    <Select 
                      value={formData.timezone || 'Asia/Tehran'} 
                      onValueChange={(value) => updateField('timezone', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Asia/Tehran">تهران (GMT+3:30)</SelectItem>
                        <SelectItem value="UTC">UTC (GMT+0)</SelectItem>
                        <SelectItem value="Europe/London">لندن (GMT+1)</SelectItem>
                        <SelectItem value="America/New_York">نیویورک (GMT-5)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={formData.autoStart || false}
                      onCheckedChange={(checked) => updateField('autoStart', checked)}
                    />
                    <Label className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      شروع خودکار تورنومنت
                    </Label>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    تورنومنت به صورت خودکار در زمان تعیین شده شروع خواهد شد
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Financial Tab */}
        <TabsContent value="financial" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  تنظیمات مالی و جوایز
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="entryFee">ورودی (تومان) *</Label>
                    <Input
                      type="number"
                      id="entryFee"
                      value={formData.entryFee || ''}
                      onChange={(e) => updateField('entryFee', parseInt(e.target.value) || 0)}
                      placeholder="۰"
                      min="0"
                      className={errors.entryFee ? 'border-red-500' : ''}
                    />
                    {errors.entryFee && (
                      <p className="text-sm text-red-500">{errors.entryFee}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="prizePool">جایزه کل (تومان) *</Label>
                    <Input
                      type="number"
                      id="prizePool"
                      value={formData.prizePool || ''}
                      onChange={(e) => updateField('prizePool', parseInt(e.target.value) || 0)}
                      placeholder="۰"
                      min="0"
                      className={errors.prizePool ? 'border-red-500' : ''}
                    />
                    {errors.prizePool && (
                      <p className="text-sm text-red-500">{errors.prizePool}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="currency">واحد پولی</Label>
                    <Select 
                      value={formData.currency} 
                      onValueChange={(value: 'IRT' | 'USD') => updateField('currency', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="IRT">تومان (IRT)</SelectItem>
                        <SelectItem value="USD">دلار آمریکا (USD)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">توزیع جوایز</h4>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        const newDistribution = [...(formData.prizeDistribution || [])];
                        newDistribution.push({ rank: newDistribution.length + 1, percentage: 0 });
                        updateField('prizeDistribution', newDistribution);
                      }}
                    >
                      <Plus className="w-4 h-4 ml-2" />
                      اضافه کردن رنک
                    </Button>
                  </div>

                  <div className="grid gap-3">
                    {formData.prizeDistribution?.map((prize, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                        <Badge variant="outline">
                          <Crown className="w-3 h-3 ml-1" />
                          مقام {prize.rank}
                        </Badge>
                        <div className="flex items-center gap-2 flex-1">
                          <Input
                            type="number"
                            value={prize.percentage}
                            onChange={(e) => {
                              const newDistribution = [...(formData.prizeDistribution || [])];
                              newDistribution[index].percentage = parseInt(e.target.value) || 0;
                              updateField('prizeDistribution', newDistribution);
                            }}
                            placeholder="درصد"
                            min="0"
                            max="100"
                            className="w-20"
                          />
                          <span className="text-sm">%</span>
                          <span className="text-sm text-muted-foreground flex-1">
                            = {((formData.prizePool || 0) * prize.percentage / 100).toLocaleString()} {formData.currency === 'IRT' ? 'تومان' : 'دلار'}
                          </span>
                        </div>
                        {formData.prizeDistribution && formData.prizeDistribution.length > 1 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              const newDistribution = formData.prizeDistribution?.filter((_, i) => i !== index) || [];
                              updateField('prizeDistribution', newDistribution);
                            }}
                            className="text-red-500 hover:text-red-600"
                          >
                            حذف
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="p-3 bg-blue-500/10 rounded-lg">
                    <div className="flex items-center justify-between text-sm">
                      <span>مجموع درصدها:</span>
                      <span className={
                        (formData.prizeDistribution?.reduce((sum, p) => sum + p.percentage, 0) || 0) === 100 
                          ? 'text-green-500' 
                          : 'text-red-500'
                      }>
                        {formData.prizeDistribution?.reduce((sum, p) => sum + p.percentage, 0) || 0}%
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Rules & Settings Tab */}
        <TabsContent value="rules" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  قوانین و الزامات
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Tournament Rules */}
                <div className="space-y-2">
                  <Label>قوانین تورنومنت *</Label>
                  <div className="flex gap-2">
                    <Input
                      value={newRule}
                      onChange={(e) => setNewRule(e.target.value)}
                      placeholder="اضافه کردن قانون جدید..."
                      onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addRule())}
                      className="flex-1"
                    />
                    <Button onClick={addRule} variant="outline" size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  {errors.rules && (
                    <p className="text-sm text-red-500">{errors.rules}</p>
                  )}
                  
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {formData.rules?.map((rule, index) => (
                      <div key={index} className="flex items-start gap-2 p-2 bg-secondary/30 rounded-lg">
                        <span className="text-sm text-muted-foreground mt-1">{index + 1}.</span>
                        <span className="text-sm flex-1">{rule}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeRule(index)}
                          className="text-red-500 hover:text-red-600 p-1 h-auto"
                        >
                          حذف
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                {/* Requirements */}
                <div className="space-y-4">
                  <h4 className="font-medium">الزامات شرکت</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="minRank">حداقل رنک</Label>
                      <Select 
                        value={formData.requirements?.minRank || ''} 
                        onValueChange={(value) => updateRequirement('minRank', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="بدون محدودیت" />
                        </SelectTrigger>
                        <SelectContent>
                          {RANKS_LIST.map((rank) => (
                            <SelectItem key={rank} value={rank}>{rank}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="maxRank">حداکثر رنک</Label>
                      <Select 
                        value={formData.requirements?.maxRank || ''} 
                        onValueChange={(value) => updateRequirement('maxRank', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="بدون محدودیت" />
                        </SelectTrigger>
                        <SelectContent>
                          {RANKS_LIST.map((rank) => (
                            <SelectItem key={rank} value={rank}>{rank}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="region">منطقه</Label>
                      <Select 
                        value={formData.requirements?.region || ''} 
                        onValueChange={(value) => updateRequirement('region', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="بدون محدودیت" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="iran">ایران</SelectItem>
                          <SelectItem value="middle-east">خاورمیانه</SelectItem>
                          <SelectItem value="asia">آسیا</SelectItem>
                          <SelectItem value="worldwide">جهانی</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="age">محدودیت سنی</Label>
                      <Select 
                        value={formData.requirements?.age || ''} 
                        onValueChange={(value) => updateRequirement('age', value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="بدون محدودیت" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="13+">13+ سال</SelectItem>
                          <SelectItem value="16+">16+ سال</SelectItem>
                          <SelectItem value="18+">18+ سال</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Switch
                      checked={formData.requirements?.verified || false}
                      onCheckedChange={(checked) => updateRequirement('verified', checked)}
                    />
                    <Label className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      فقط اکانت‌های تایید شده
                    </Label>
                  </div>
                </div>

                <Separator />

                {/* General Settings */}
                <div className="space-y-4">
                  <h4 className="font-medium">تنظیمات عمومی</h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Switch
                        checked={formData.isPublic || false}
                        onCheckedChange={(checked) => updateField('isPublic', checked)}
                      />
                      <Label className="flex items-center gap-2">
                        <Globe className="w-4 h-4" />
                        تورنومنت عمومی
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Switch
                        checked={formData.allowSpectators || false}
                        onCheckedChange={(checked) => updateField('allowSpectators', checked)}
                      />
                      <Label className="flex items-center gap-2">
                        <Eye className="w-4 h-4" />
                        اجازه تماشای مسابقات
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Switch
                        checked={formData.allowSubstitutes || false}
                        onCheckedChange={(checked) => updateField('allowSubstitutes', checked)}
                      />
                      <Label className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        اجازه تعویض بازیکنان
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Switch
                        checked={formData.streamEnabled || false}
                        onCheckedChange={(checked) => updateField('streamEnabled', checked)}
                      />
                      <Label className="flex items-center gap-2">
                        <Camera className="w-4 h-4" />
                        پخش زنده
                      </Label>
                    </div>

                    {formData.streamEnabled && (
                      <div className="mr-6 space-y-2">
                        <Label htmlFor="streamUrl">آدرس استریم</Label>
                        <Input
                          id="streamUrl"
                          value={formData.streamUrl || ''}
                          onChange={(e) => updateField('streamUrl', e.target.value)}
                          placeholder="https://twitch.tv/channel or https://youtube.com/watch?v=..."
                        />
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>

      {/* Action Buttons */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <div className="text-sm text-muted-foreground">
              لطفاً تمام بخش‌ها را تکمیل کنید
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={saveDraft} disabled={isLoading}>
                <Save className="w-4 h-4 ml-2" />
                ذخیره پیش‌نویس
              </Button>
              <Button variant="outline" disabled={isLoading}>
                <Eye className="w-4 h-4 ml-2" />
                پیش‌نمایش
              </Button>
              <Button onClick={handleSubmit} disabled={isLoading} className="min-w-[120px]">
                {isLoading ? (
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                ) : (
                  <>
                    <Trophy className="w-4 h-4 ml-2" />
                    ایجاد تورنومنت
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}