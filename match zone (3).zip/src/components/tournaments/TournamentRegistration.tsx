import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Checkbox } from '../ui/checkbox';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { toast } from 'sonner@2.0.3';
import { 
  DollarSign, Users, Trophy, Clock, Shield, AlertTriangle, 
  CreditCard, Wallet, CheckCircle, XCircle, Info, Star,
  Calendar, MapPin, GamepadIcon 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface Tournament {
  id: string;
  title: string;
  game: string;
  description: string;
  prize: string;
  prizePool: string;
  entryFee: number;
  participants: { current: number; max: number };
  status: 'registration' | 'started' | 'finished';
  startTime: string;
  startDate: string;
  organizer: { name: string; verified: boolean; avatar?: string };
  format: string;
  rules: string[];
  requirements: {
    minRank?: string;
    maxLevel?: number;
    region?: string;
    age?: string;
  };
  paymentMethods: string[];
  earlyBirdDiscount?: number;
  teamSize?: number;
}

export interface TournamentRegistrationProps {
  tournament: Tournament;
  onRegister: (registrationData: any) => void;
  userBalance: number;
  userRank?: string;
}

export function TournamentRegistration({ 
  tournament, 
  onRegister, 
  userBalance,
  userRank = 'طلایی'
}: TournamentRegistrationProps) {
  const [step, setStep] = useState(1);
  const [teamMembers, setTeamMembers] = useState<string[]>(['']);
  const [selectedPayment, setSelectedPayment] = useState('wallet');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [formData, setFormData] = useState({
    playerName: '',
    contactInfo: '',
    experience: '',
    teamName: '',
    specialRequests: ''
  });
  const [isProcessing, setIsProcessing] = useState(false);

  const isTeamTournament = tournament.teamSize && tournament.teamSize > 1;
  const discountedFee = tournament.earlyBirdDiscount 
    ? tournament.entryFee * (1 - tournament.earlyBirdDiscount / 100)
    : tournament.entryFee;
  const canAfford = userBalance >= discountedFee;

  const checkEligibility = () => {
    const issues = [];
    
    if (tournament.requirements.minRank && userRank && userRank !== tournament.requirements.minRank) {
      issues.push(`رنک مورد نیاز: ${tournament.requirements.minRank}`);
    }
    
    if (!canAfford) {
      issues.push(`موجودی ناکافی: ${discountedFee.toLocaleString()} تومان مورد نیاز`);
    }

    return issues;
  };

  const eligibilityIssues = checkEligibility();
  const isEligible = eligibilityIssues.length === 0;

  const handleNextStep = () => {
    if (step < 3) setStep(step + 1);
  };

  const handlePrevStep = () => {
    if (step > 1) setStep(step - 1);
  };

  const addTeamMember = () => {
    if (teamMembers.length < (tournament.teamSize || 1) - 1) {
      setTeamMembers([...teamMembers, '']);
    }
  };

  const removeTeamMember = (index: number) => {
    const newMembers = teamMembers.filter((_, i) => i !== index);
    setTeamMembers(newMembers);
  };

  const updateTeamMember = (index: number, value: string) => {
    const newMembers = [...teamMembers];
    newMembers[index] = value;
    setTeamMembers(newMembers);
  };

  const handleSubmitRegistration = async () => {
    setIsProcessing(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const registrationData = {
        tournament: tournament.id,
        formData,
        teamMembers: isTeamTournament ? teamMembers.filter(m => m.trim()) : [],
        paymentMethod: selectedPayment,
        amount: discountedFee
      };

      onRegister(registrationData);
      
      toast.success('ثبت‌نام موفقیت‌آمیز بود!', {
        description: 'شما با موفقیت در تورنومنت ثبت‌نام شدید.'
      });
      
      setStep(4); // Success step
    } catch (error) {
      toast.error('خطا در ثبت‌نام', {
        description: 'لطفا دوباره تلاش کنید.'
      });
    }
    
    setIsProcessing(false);
  };

  const getStepIcon = (stepNumber: number) => {
    if (step > stepNumber) return <CheckCircle className="w-5 h-5 text-green-500" />;
    if (step === stepNumber) return <div className="w-5 h-5 rounded-full bg-primary" />;
    return <div className="w-5 h-5 rounded-full bg-muted border-2" />;
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          className="w-full"
          disabled={!isEligible}
          variant={isEligible ? "default" : "outline"}
        >
          <DollarSign className="w-4 h-4 ml-2" />
          {isEligible ? 'ثبت‌نام و پرداخت' : 'شرایط ثبت‌نام ندارید'}
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-right flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            ثبت‌نام در {tournament.title}
          </DialogTitle>
        </DialogHeader>

        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-4 py-4">
          {[1, 2, 3, 4].map((stepNum) => (
            <div key={stepNum} className="flex items-center">
              <div className="flex flex-col items-center">
                {getStepIcon(stepNum)}
                <span className={`text-xs mt-1 ${step === stepNum ? 'text-primary' : 'text-muted-foreground'}`}>
                  {stepNum === 1 && 'اطلاعات'}
                  {stepNum === 2 && isTeamTournament ? 'تیم' : 'تایید'}
                  {stepNum === 3 && 'پرداخت'}
                  {stepNum === 4 && 'تکمیل'}
                </span>
              </div>
              {stepNum < 4 && (
                <div className={`w-8 h-0.5 mx-2 ${step > stepNum ? 'bg-green-500' : 'bg-muted'}`} />
              )}
            </div>
          ))}
        </div>

        <Separator />

        {/* Eligibility Check */}
        {!isEligible && (
          <Card className="bg-destructive/5 border-destructive/20">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-destructive mt-0.5" />
                <div className="space-y-2">
                  <h4 className="font-medium text-destructive">موانع ثبت‌نام:</h4>
                  <ul className="space-y-1 text-sm">
                    {eligibilityIssues.map((issue, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <XCircle className="w-3 h-3" />
                        {issue}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">اطلاعات شخصی</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="playerName">نام بازیکن *</Label>
                    <Input
                      id="playerName"
                      value={formData.playerName}
                      onChange={(e) => setFormData({...formData, playerName: e.target.value})}
                      placeholder="نام کاربری یا نام واقعی"
                      dir="rtl"
                    />
                  </div>

                  <div>
                    <Label htmlFor="contactInfo">اطلاعات تماس *</Label>
                    <Input
                      id="contactInfo"
                      value={formData.contactInfo}
                      onChange={(e) => setFormData({...formData, contactInfo: e.target.value})}
                      placeholder="دیسکورد، تلگرام یا ایمیل"
                      dir="rtl"
                    />
                  </div>

                  <div>
                    <Label htmlFor="experience">سابقه بازی</Label>
                    <Select value={formData.experience} onValueChange={(value) => setFormData({...formData, experience: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="سطح تجربه خود را انتخاب کنید" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">مبتدی (کمتر از 6 ماه)</SelectItem>
                        <SelectItem value="intermediate">متوسط (6 ماه تا 2 سال)</SelectItem>
                        <SelectItem value="advanced">پیشرفته (2 تا 5 سال)</SelectItem>
                        <SelectItem value="pro">حرفه‌ای (بیش از 5 سال)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {isTeamTournament && (
                    <div>
                      <Label htmlFor="teamName">نام تیم *</Label>
                      <Input
                        id="teamName"
                        value={formData.teamName}
                        onChange={(e) => setFormData({...formData, teamName: e.target.value})}
                        placeholder="نام تیم شما"
                        dir="rtl"
                      />
                    </div>
                  )}

                  <div>
                    <Label htmlFor="specialRequests">درخواست‌های ویژه</Label>
                    <Textarea
                      id="specialRequests"
                      value={formData.specialRequests}
                      onChange={(e) => setFormData({...formData, specialRequests: e.target.value})}
                      placeholder="اگر درخواست خاصی دارید اینجا بنویسید..."
                      dir="rtl"
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>

              <Button 
                onClick={handleNextStep} 
                className="w-full"
                disabled={!formData.playerName || !formData.contactInfo || (isTeamTournament && !formData.teamName)}
              >
                مرحله بعد
              </Button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              {isTeamTournament ? (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      اعضای تیم ({tournament.teamSize} نفره)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      {teamMembers.map((member, index) => (
                        <div key={index} className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeTeamMember(index)}
                            disabled={teamMembers.length <= 1}
                          >
                            <XCircle className="w-3 h-3" />
                          </Button>
                          <Input
                            value={member}
                            onChange={(e) => updateTeamMember(index, e.target.value)}
                            placeholder={`نام عضو ${index + 2}`}
                            dir="rtl"
                            className="flex-1"
                          />
                        </div>
                      ))}
                    </div>

                    {teamMembers.length < (tournament.teamSize || 1) - 1 && (
                      <Button
                        variant="outline"
                        onClick={addTeamMember}
                        className="w-full"
                      >
                        <Users className="w-4 h-4 ml-2" />
                        اضافه کردن عضو تیم
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">تایید اطلاعات</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">بازیکن:</span>
                        <p className="text-muted-foreground">{formData.playerName}</p>
                      </div>
                      <div>
                        <span className="font-medium">تماس:</span>
                        <p className="text-muted-foreground">{formData.contactInfo}</p>
                      </div>
                      <div>
                        <span className="font-medium">تجربه:</span>
                        <p className="text-muted-foreground">{formData.experience}</p>
                      </div>
                      <div>
                        <span className="font-medium">رنک فعلی:</span>
                        <p className="text-muted-foreground">{userRank}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="flex gap-2">
                <Button variant="outline" onClick={handlePrevStep} className="flex-1">
                  مرحله قبل
                </Button>
                <Button onClick={handleNextStep} className="flex-1">
                  مرحله بعد
                </Button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              {/* Payment Summary */}
              <Card className="bg-gradient-to-r from-green-500/5 to-blue-500/5">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-lg">
                        {discountedFee.toLocaleString()} تومان
                      </span>
                      <span>هزینه ثبت‌نام:</span>
                    </div>
                    
                    {tournament.earlyBirdDiscount && (
                      <div className="flex justify-between text-sm text-green-600">
                        <span>-%{tournament.earlyBirdDiscount}</span>
                        <span>تخفیف زودهنگام:</span>
                      </div>
                    )}

                    <Separator />
                    
                    <div className="text-sm space-y-1">
                      <div className="flex justify-between">
                        <span>{tournament.prizePool}</span>
                        <span>کل جایزه:</span>
                      </div>
                      <div className="flex justify-between">
                        <span>{tournament.participants.current}/{tournament.participants.max}</span>
                        <span>شرکت‌کنندگان:</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Methods */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">روش پرداخت</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {tournament.paymentMethods.map((method) => (
                    <div key={method} className="flex items-center space-x-2">
                      <Checkbox
                        id={method}
                        checked={selectedPayment === method}
                        onCheckedChange={() => setSelectedPayment(method)}
                      />
                      <Label htmlFor={method} className="flex items-center gap-2 cursor-pointer">
                        {method === 'wallet' && <Wallet className="w-4 h-4" />}
                        {method === 'card' && <CreditCard className="w-4 h-4" />}
                        {method === 'wallet' && `کیف پول (موجودی: ${userBalance.toLocaleString()} تومان)`}
                        {method === 'card' && 'کارت بانکی'}
                      </Label>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Terms */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Checkbox
                      id="terms"
                      checked={agreedToTerms}
                      onCheckedChange={setAgreedToTerms}
                    />
                    <Label htmlFor="terms" className="text-sm cursor-pointer">
                      قوانین و مقررات تورنومنت و سیاست‌های پرداخت را مطالعه کرده و می‌پذیرم
                    </Label>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-2">
                <Button variant="outline" onClick={handlePrevStep} className="flex-1">
                  مرحله قبل
                </Button>
                <Button 
                  onClick={handleSubmitRegistration}
                  disabled={!agreedToTerms || !canAfford || isProcessing}
                  className="flex-1"
                >
                  {isProcessing ? 'در حال پردازش...' : 'تکمیل ثبت‌نام'}
                </Button>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-4 py-8"
            >
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="font-bold text-xl">ثبت‌نام موفقیت‌آمیز!</h3>
              <p className="text-muted-foreground">
                شما با موفقیت در تورنومنت {tournament.title} ثبت‌نام شدید
              </p>
              
              <Card className="bg-blue-50 border-blue-200 text-right" dir="rtl">
                <CardContent className="p-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>{tournament.startDate}</span>
                    <span>تاریخ شروع:</span>
                  </div>
                  <div className="flex justify-between">
                    <span>{tournament.startTime}</span>
                    <span>ساعت شروع:</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ایمیل و پیامک</span>
                    <span>اطلاع‌رسانی:</span>
                  </div>
                </CardContent>
              </Card>

              <Button onClick={() => setStep(1)} variant="outline" className="w-full">
                بستن
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}