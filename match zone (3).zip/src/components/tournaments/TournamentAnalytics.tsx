import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { 
  TrendingUp, TrendingDown, Users, Trophy, DollarSign, Clock,
  Eye, MessageSquare, Share2, Download, Calendar, Target,
  Award, Star, Zap, BarChart3, PieChart, LineChart,
  Globe, MapPin, Gamepad2, Crown, Flag, Activity
} from 'lucide-react';
import { motion } from 'motion/react';
import {
  LineChart as RechartsLineChart,
  AreaChart,
  BarChart,
  PieChart as RechartsPieChart,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  Bar,
  Line,
  Pie
} from 'recharts';

export interface TournamentAnalyticsData {
  tournamentId: string;
  tournamentName: string;
  duration: string; // e.g., "2 روز"
  status: 'finished' | 'live' | 'cancelled';
  
  // Participation Stats
  participation: {
    registered: number;
    showed: number;
    completed: number;
    dropped: number;
    disqualified: number;
    registrationTrend: { date: string; count: number }[];
    demographicsByRank: { rank: string; count: number; percentage: number }[];
    demographicsByRegion: { region: string; count: number; percentage: number }[];
  };

  // Performance Stats
  performance: {
    totalMatches: number;
    completedMatches: number;
    averageMatchDuration: number; // minutes
    fastestMatch: number;
    longestMatch: number;
    matchesPerHour: number;
    upsetCount: number; // lower rank beating higher rank
    performanceByRound: { round: string; avgTime: number; upsets: number }[];
    playerSatisfaction: number; // 1-5 scale
  };

  // Financial Stats
  financial: {
    totalRevenue: number;
    entryFees: number;
    sponsorship: number;
    expenses: number;
    profit: number;
    prizeDistribution: { rank: number; amount: number; winner: string }[];
    revenueBreakdown: { source: string; amount: number; percentage: number }[];
  };

  // Engagement Stats
  engagement: {
    totalViews: number;
    peakConcurrentViewers: number;
    averageViewTime: number; // minutes
    chatMessages: number;
    socialShares: number;
    highlights: number;
    viewersByTime: { time: string; viewers: number }[];
    topCountries: { country: string; viewers: number; percentage: number }[];
    engagementRate: number; // percentage
  };

  // Quality Metrics
  quality: {
    technicalIssues: number;
    disputes: number;
    resolvedDisputes: number;
    averageResponseTime: number; // minutes
    moderationActions: number;
    playerReports: number;
    streamUptime: number; // percentage
    qualityScore: number; // 1-10 scale
  };

  // Comparisons with previous tournaments
  comparisons: {
    participationGrowth: number; // percentage
    revenueGrowth: number;
    viewershipGrowth: number;
    qualityImprovement: number;
  };
}

export interface TournamentAnalyticsProps {
  data: TournamentAnalyticsData;
  onExport?: (format: 'pdf' | 'excel' | 'csv') => void;
  onShare?: () => void;
}

const CHART_COLORS = ['#3B82F6', '#22C55E', '#FACC15', '#EF4444', '#8B5CF6', '#F97316'];

export function TournamentAnalytics({ data, onExport, onShare }: TournamentAnalyticsProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [timeRange, setTimeRange] = useState('all');

  const calculateROI = () => {
    if (data.financial.entryFees === 0) return 0;
    return Math.round((data.financial.profit / data.financial.entryFees) * 100);
  };

  const getGrowthColor = (growth: number) => {
    if (growth > 0) return 'text-green-500';
    if (growth < 0) return 'text-red-500';
    return 'text-gray-500';
  };

  const getGrowthIcon = (growth: number) => {
    if (growth > 0) return <TrendingUp className="w-4 h-4" />;
    if (growth < 0) return <TrendingDown className="w-4 h-4" />;
    return <Activity className="w-4 h-4" />;
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-500/20 rounded-lg">
                <BarChart3 className="w-8 h-8 text-purple-400" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">{data.tournamentName}</h1>
                <p className="text-muted-foreground">
                  آنالیز کامل عملکرد تورنومنت • مدت: {data.duration}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">کل دوره</SelectItem>
                  <SelectItem value="daily">روزانه</SelectItem>
                  <SelectItem value="hourly">ساعتی</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" onClick={onShare}>
                <Share2 className="w-4 h-4 ml-2" />
                اشتراک
              </Button>
              
              <Select onValueChange={(value) => onExport?.(value as any)}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="خروجی" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="excel">Excel</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Key Metrics Overview */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-500">
              {data.participation.completed.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">شرکت‌کنندگان</div>
            <div className={`text-xs flex items-center justify-center gap-1 mt-1 ${getGrowthColor(data.comparisons.participationGrowth)}`}>
              {getGrowthIcon(data.comparisons.participationGrowth)}
              {Math.abs(data.comparisons.participationGrowth)}%
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-500">
              {data.financial.totalRevenue.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">درآمد کل</div>
            <div className={`text-xs flex items-center justify-center gap-1 mt-1 ${getGrowthColor(data.comparisons.revenueGrowth)}`}>
              {getGrowthIcon(data.comparisons.revenueGrowth)}
              {Math.abs(data.comparisons.revenueGrowth)}%
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-500">
              {data.engagement.totalViews.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">بازدید کل</div>
            <div className={`text-xs flex items-center justify-center gap-1 mt-1 ${getGrowthColor(data.comparisons.viewershipGrowth)}`}>
              {getGrowthIcon(data.comparisons.viewershipGrowth)}
              {Math.abs(data.comparisons.viewershipGrowth)}%
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-500">
              {data.performance.averageMatchDuration}m
            </div>
            <div className="text-sm text-muted-foreground">متوسط مسابقه</div>
            <div className="text-xs text-muted-foreground mt-1">
              {data.performance.matchesPerHour.toFixed(1)}/ساعت
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-500">
              {data.engagement.peakConcurrentViewers.toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">حداکثر تماشاگر</div>
            <div className="text-xs text-muted-foreground mt-1">
              {data.engagement.engagementRate}% فعال
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-indigo-500">
              {data.quality.qualityScore.toFixed(1)}
            </div>
            <div className="text-sm text-muted-foreground">کیفیت کلی</div>
            <div className={`text-xs flex items-center justify-center gap-1 mt-1 ${getGrowthColor(data.comparisons.qualityImprovement)}`}>
              {getGrowthIcon(data.comparisons.qualityImprovement)}
              {Math.abs(data.comparisons.qualityImprovement).toFixed(1)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">نمای کلی</TabsTrigger>
          <TabsTrigger value="participation">شرکت‌کنندگان</TabsTrigger>
          <TabsTrigger value="performance">عملکرد</TabsTrigger>
          <TabsTrigger value="financial">مالی</TabsTrigger>
          <TabsTrigger value="engagement">تعامل</TabsTrigger>
          <TabsTrigger value="quality">کیفیت</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {/* Registration Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  روند ثبت‌نام
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={data.participation.registrationTrend}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="count" 
                      stroke="#3B82F6" 
                      fill="#3B82F6"
                      fillOpacity={0.3}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Viewer Engagement */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  تعامل تماشاگران
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={data.engagement.viewersByTime}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line 
                      type="monotone" 
                      dataKey="viewers" 
                      stroke="#22C55E" 
                      strokeWidth={2}
                      dot={{ fill: '#22C55E', strokeWidth: 2, r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Performance Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  خلاصه عملکرد
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">نرخ تکمیل</span>
                    <div className="flex items-center gap-2">
                      <Progress 
                        value={(data.participation.completed / data.participation.registered) * 100} 
                        className="w-16 h-2"
                      />
                      <span className="text-sm font-medium">
                        {Math.round((data.participation.completed / data.participation.registered) * 100)}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">کیفیت استریم</span>
                    <div className="flex items-center gap-2">
                      <Progress value={data.quality.streamUptime} className="w-16 h-2" />
                      <span className="text-sm font-medium">{data.quality.streamUptime}%</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">رضایت بازیکنان</span>
                    <div className="flex items-center gap-2">
                      <Progress value={(data.performance.playerSatisfaction / 5) * 100} className="w-16 h-2" />
                      <span className="text-sm font-medium">{data.performance.playerSatisfaction}/5</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">ROI</span>
                    <span className={`text-sm font-medium ${calculateROI() > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {calculateROI()}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Top Performing Countries */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  کشورهای برتر
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.engagement.topCountries.map((country, index) => (
                    <div key={country.country} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 text-xs font-bold">
                          {index + 1}
                        </div>
                        <span className="text-sm">{country.country}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Progress value={country.percentage} className="w-16 h-2" />
                        <span className="text-sm font-medium w-12 text-left">
                          {country.viewers.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Participation Tab */}
        <TabsContent value="participation" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {/* Participation Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  تجزیه و تحلیل شرکت
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="p-3 bg-blue-500/10 rounded-lg">
                    <div className="text-lg font-bold text-blue-500">{data.participation.registered}</div>
                    <div className="text-xs text-muted-foreground">ثبت‌نام کردند</div>
                  </div>
                  <div className="p-3 bg-green-500/10 rounded-lg">
                    <div className="text-lg font-bold text-green-500">{data.participation.showed}</div>
                    <div className="text-xs text-muted-foreground">حضور یافتند</div>
                  </div>
                  <div className="p-3 bg-yellow-500/10 rounded-lg">
                    <div className="text-lg font-bold text-yellow-500">{data.participation.dropped}</div>
                    <div className="text-xs text-muted-foreground">انصراف دادند</div>
                  </div>
                  <div className="p-3 bg-red-500/10 rounded-lg">
                    <div className="text-lg font-bold text-red-500">{data.participation.disqualified}</div>
                    <div className="text-xs text-muted-foreground">محروم شدند</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Demographics by Rank */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  توزیع بر اساس رنک
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <RechartsPieChart>
                    <Pie
                      data={data.participation.demographicsByRank}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                      label={({ rank, percentage }) => `${rank} (${percentage}%)`}
                    >
                      {data.participation.demographicsByRank.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Regional Distribution */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  توزیع جغرافیایی شرکت‌کنندگان
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={data.participation.demographicsByRegion}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="region" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#3B82F6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {/* Match Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  عملکرد مسابقات
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">کل مسابقات:</span>
                    <span className="font-medium">{data.performance.totalMatches}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">تکمیل شده:</span>
                    <span className="font-medium text-green-500">{data.performance.completedMatches}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">متوسط زمان:</span>
                    <span className="font-medium">{data.performance.averageMatchDuration} دقیقه</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">سریع‌ترین:</span>
                    <span className="font-medium text-blue-500">{data.performance.fastestMatch} دقیقه</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">طولانی‌ترین:</span>
                    <span className="font-medium text-red-500">{data.performance.longestMatch} دقیقه</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">مسابقات غافلگیرکننده:</span>
                    <span className="font-medium text-yellow-500">{data.performance.upsetCount}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Performance by Round */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5" />
                  عملکرد بر اساس دور
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={data.performance.performanceByRound}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="round" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Bar yAxisId="left" dataKey="avgTime" fill="#3B82F6" name="متوسط زمان (دقیقه)" />
                    <Bar yAxisId="right" dataKey="upsets" fill="#FACC15" name="مسابقات غافلگیرکننده" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Player Satisfaction */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-5 h-5" />
                  رضایت بازیکنان و کیفیت
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-yellow-500 mb-2">
                      {data.performance.playerSatisfaction}/5
                    </div>
                    <div className="text-sm text-muted-foreground">رضایت بازیکنان</div>
                    <div className="flex justify-center mt-2">
                      {Array.from({ length: 5 }, (_, i) => (
                        <Star 
                          key={i} 
                          className={`w-4 h-4 ${i < data.performance.playerSatisfaction ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-500 mb-2">
                      {data.quality.streamUptime}%
                    </div>
                    <div className="text-sm text-muted-foreground">کیفیت استریم</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-500 mb-2">
                      {data.performance.matchesPerHour.toFixed(1)}
                    </div>
                    <div className="text-sm text-muted-foreground">مسابقه در ساعت</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-500 mb-2">
                      {data.quality.qualityScore.toFixed(1)}/10
                    </div>
                    <div className="text-sm text-muted-foreground">کیفیت کلی</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Financial Tab */}
        <TabsContent value="financial" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {/* Revenue Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  تجزیه درآمد
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="p-3 bg-green-500/10 rounded-lg">
                      <div className="text-lg font-bold text-green-500">
                        {data.financial.totalRevenue.toLocaleString()}
                      </div>
                      <div className="text-xs text-muted-foreground">درآمد کل</div>
                    </div>
                    <div className="p-3 bg-blue-500/10 rounded-lg">
                      <div className="text-lg font-bold text-blue-500">
                        {data.financial.profit.toLocaleString()}
                      </div>
                      <div className="text-xs text-muted-foreground">سود خالص</div>
                    </div>
                  </div>
                  
                  <ResponsiveContainer width="100%" height={150}>
                    <RechartsPieChart>
                      <Pie
                        data={data.financial.revenueBreakdown}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        fill="#8884d8"
                        dataKey="amount"
                        label={({ percentage }) => `${percentage}%`}
                      >
                        {data.financial.revenueBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Prize Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Crown className="w-5 h-5" />
                  توزیع جوایز
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.financial.prizeDistribution.map((prize) => (
                    <div key={prize.rank} className="flex items-center justify-between p-3 bg-yellow-500/10 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="text-xs">
                          مقام {prize.rank}
                        </Badge>
                        <span className="font-medium text-sm">{prize.winner}</span>
                      </div>
                      <div className="font-bold text-yellow-500">
                        {prize.amount.toLocaleString()} تومان
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Financial Summary */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  خلاصه مالی
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-6 text-center">
                  <div>
                    <div className="text-xl font-bold text-blue-500">
                      {data.financial.entryFees.toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">ورودی‌ها</div>
                  </div>
                  
                  <div>
                    <div className="text-xl font-bold text-purple-500">
                      {data.financial.sponsorship.toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">حمایت‌ها</div>
                  </div>
                  
                  <div>
                    <div className="text-xl font-bold text-red-500">
                      {data.financial.expenses.toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">هزینه‌ها</div>
                  </div>
                  
                  <div>
                    <div className="text-xl font-bold text-green-500">
                      {data.financial.profit.toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">سود</div>
                  </div>
                  
                  <div>
                    <div className={`text-xl font-bold ${calculateROI() > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {calculateROI()}%
                    </div>
                    <div className="text-sm text-muted-foreground">ROI</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Engagement Tab */}
        <TabsContent value="engagement" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Engagement Overview */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {data.engagement.totalViews.toLocaleString()}
                  </div>
                  <div className="text-sm text-muted-foreground">بازدید کل</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-red-500">
                    {data.engagement.peakConcurrentViewers.toLocaleString()}
                  </div>
                  <div className="text-sm text-muted-foreground">حداکثر تماشاگر</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {data.engagement.chatMessages.toLocaleString()}
                  </div>
                  <div className="text-sm text-muted-foreground">پیام چت</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-500">
                    {data.engagement.socialShares.toLocaleString()}
                  </div>
                  <div className="text-sm text-muted-foreground">اشتراک‌گذاری</div>
                </CardContent>
              </Card>
            </div>

            {/* Viewership Timeline */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="w-5 h-5" />
                  روند تماشاگران
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={data.engagement.viewersByTime}>
                    <defs>
                      <linearGradient id="colorViewers" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="time" />
                    <YAxis />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Tooltip />
                    <Area 
                      type="monotone" 
                      dataKey="viewers" 
                      stroke="#3B82F6" 
                      fillOpacity={1} 
                      fill="url(#colorViewers)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Quality Tab */}
        <TabsContent value="quality" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {/* Technical Quality */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  کیفیت فنی
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">مشکلات فنی:</span>
                    <span className="font-medium text-red-500">{data.quality.technicalIssues}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">اختلافات:</span>
                    <span className="font-medium">{data.quality.disputes}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">حل شده:</span>
                    <span className="font-medium text-green-500">{data.quality.resolvedDisputes}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">زمان پاسخ متوسط:</span>
                    <span className="font-medium">{data.quality.averageResponseTime} دقیقه</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">اقدامات تعدیل:</span>
                    <span className="font-medium">{data.quality.moderationActions}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quality Score Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  امتیاز کیفیت
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-4xl font-bold text-blue-500 mb-2">
                    {data.quality.qualityScore.toFixed(1)}/10
                  </div>
                  <div className="text-sm text-muted-foreground">امتیاز کلی</div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">استریم</span>
                    <div className="flex items-center gap-2">
                      <Progress value={data.quality.streamUptime} className="w-16 h-2" />
                      <span className="text-sm font-medium">{data.quality.streamUptime}%</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">رضایت</span>
                    <div className="flex items-center gap-2">
                      <Progress value={(data.performance.playerSatisfaction / 5) * 100} className="w-16 h-2" />
                      <span className="text-sm font-medium">{data.performance.playerSatisfaction}/5</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">تعامل</span>
                    <div className="flex items-center gap-2">
                      <Progress value={data.engagement.engagementRate} className="w-16 h-2" />
                      <span className="text-sm font-medium">{data.engagement.engagementRate}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
}