import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Alert, AlertDescription } from '../ui/alert';
import { 
  Crown, DollarSign, Trophy, Gift, CreditCard, Banknote,
  CheckCircle, XCircle, Clock, AlertTriangle, TrendingUp,
  Download, Upload, RefreshCw, Eye, Edit, Plus, Trash2,
  Send, History, Shield, Star, Zap, Target, Award
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion, AnimatePresence } from 'motion/react';

export interface PrizeDistribution {
  rank: number;
  amount: number;
  percentage: number;
  currency: 'IRT' | 'USD';
  type: 'cash' | 'item' | 'trophy' | 'points';
  description?: string;
  sponsored?: boolean;
  sponsorName?: string;
}

export interface Winner {
  id: string;
  name: string;
  username: string;
  avatar?: string;
  rank: number;
  finalScore: number;
  teamId?: string;
  teamName?: string;
  country: string;
  contactEmail: string;
  phoneNumber?: string;
  bankDetails?: {
    accountNumber: string;
    bankName: string;
    cardNumber: string;
    iban: string;
  };
  taxId?: string;
  verified: boolean;
  kyc: 'pending' | 'approved' | 'rejected';
}

export interface Payment {
  id: string;
  winnerId: string;
  amount: number;
  currency: 'IRT' | 'USD';
  method: 'bank_transfer' | 'card' | 'wallet' | 'crypto' | 'check';
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  initiatedAt: string;
  completedAt?: string;
  transactionId?: string;
  receipt?: string;
  failureReason?: string;
  fees: number;
  netAmount: number;
  exchangeRate?: number;
  processingTime: string; // estimated
  verificationRequired: boolean;
}

export interface Sponsor {
  id: string;
  name: string;
  logo: string;
  contribution: number;
  currency: 'IRT' | 'USD';
  type: 'monetary' | 'item' | 'service';
  items?: string[];
  contactPerson: string;
  email: string;
  website?: string;
  tier: 'gold' | 'silver' | 'bronze';
}

export interface PrizesManagementData {
  tournamentId: string;
  tournamentName: string;
  totalPrizePool: number;
  currency: 'IRT' | 'USD';
  prizeDistribution: PrizeDistribution[];
  winners: Winner[];
  payments: Payment[];
  sponsors: Sponsor[];
  financialSummary: {
    totalRevenue: number;
    entryFees: number;
    sponsorships: number;
    totalPrizes: number;
    totalFees: number;
    netPayout: number;
    remainingBalance: number;
    pendingPayments: number;
  };
  paymentStats: {
    completed: number;
    pending: number;
    failed: number;
    averageProcessingTime: string;
    successRate: number;
  };
}

export interface PrizesManagementProps {
  data: PrizesManagementData;
  onUpdatePrizeDistribution: (distribution: PrizeDistribution[]) => void;
  onProcessPayment: (paymentId: string) => Promise<void>;
  onCancelPayment: (paymentId: string) => Promise<void>;
  onRetryPayment: (paymentId: string) => Promise<void>;
  onVerifyWinner: (winnerId: string, action: 'approve' | 'reject') => Promise<void>;
  onExportReports: (type: 'financial' | 'winners' | 'payments') => void;
  isLoading?: boolean;
}

const PAYMENT_METHODS = [
  { id: 'bank_transfer', name: 'حواله بانکی', icon: Banknote, processingTime: '1-2 روز کاری' },
  { id: 'card', name: 'کارت به کارت', icon: CreditCard, processingTime: '2-24 ساعت' },
  { id: 'wallet', name: 'کیف پول', icon: DollarSign, processingTime: 'فوری' },
  { id: 'crypto', name: 'رمزارز', icon: Zap, processingTime: '10-60 دقیقه' },
  { id: 'check', name: 'چک', icon: Upload, processingTime: '5-7 روز کاری' }
];

export function PrizesManagement({
  data,
  onUpdatePrizeDistribution,
  onProcessPayment,
  onCancelPayment,
  onRetryPayment,
  onVerifyWinner,
  onExportReports,
  isLoading = false
}: PrizesManagementProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedWinner, setSelectedWinner] = useState<Winner | null>(null);
  const [selectedPayment, setSelectedPayment] = useState<Payment | null>(null);
  const [newPrize, setNewPrize] = useState<Partial<PrizeDistribution>>({});
  const [showAddPrize, setShowAddPrize] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-500 bg-green-500/10 border-green-500/20';
      case 'processing': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      case 'pending': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'failed': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'cancelled': return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
      default: return 'text-gray-500 bg-gray-500/10 border-gray-500/20';
    }
  };

  const getKycStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'text-green-500';
      case 'rejected': return 'text-red-500';
      case 'pending': return 'text-yellow-500';
      default: return 'text-gray-500';
    }
  };

  const getPaymentMethodIcon = (method: string) => {
    const methodInfo = PAYMENT_METHODS.find(m => m.id === method);
    return methodInfo ? methodInfo.icon : DollarSign;
  };

  const formatCurrency = (amount: number, currency: 'IRT' | 'USD') => {
    return `${amount.toLocaleString()} ${currency === 'IRT' ? 'تومان' : 'دلار'}`;
  };

  const calculateTotalDistribution = () => {
    return data.prizeDistribution.reduce((sum, prize) => sum + prize.percentage, 0);
  };

  const handleAddPrize = () => {
    if (!newPrize.rank || !newPrize.amount) {
      toast.error('لطفاً تمام فیلدهای الزامی را پر کنید');
      return;
    }

    const updatedDistribution = [...data.prizeDistribution, {
      ...newPrize,
      rank: newPrize.rank!,
      amount: newPrize.amount!,
      percentage: (newPrize.amount! / data.totalPrizePool) * 100,
      currency: newPrize.currency || 'IRT',
      type: newPrize.type || 'cash'
    } as PrizeDistribution];

    onUpdatePrizeDistribution(updatedDistribution);
    setNewPrize({});
    setShowAddPrize(false);
    toast.success('جایزه جدید اضافه شد');
  };

  const handleRemovePrize = (rank: number) => {
    const updatedDistribution = data.prizeDistribution.filter(p => p.rank !== rank);
    onUpdatePrizeDistribution(updatedDistribution);
    toast.success('جایزه حذف شد');
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-yellow-500/20 rounded-lg">
                <Crown className="w-8 h-8 text-yellow-400" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">{data.tournamentName}</h1>
                <p className="text-muted-foreground">
                  مدیریت جوایز و پرداخت‌ها • مجموع: {formatCurrency(data.totalPrizePool, data.currency)}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => onExportReports('financial')}>
                <Download className="w-4 h-4 ml-2" />
                گزارش مالی
              </Button>
              
              <Button variant="outline" onClick={() => onExportReports('winners')}>
                <Download className="w-4 h-4 ml-2" />
                فهرست برندگان
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Financial Overview */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-500">
              {formatCurrency(data.financialSummary.totalRevenue, data.currency)}
            </div>
            <div className="text-sm text-muted-foreground">درآمد کل</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-500">
              {formatCurrency(data.financialSummary.totalPrizes, data.currency)}
            </div>
            <div className="text-sm text-muted-foreground">کل جوایز</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-500">
              {data.paymentStats.pending}
            </div>
            <div className="text-sm text-muted-foreground">پرداخت در انتظار</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-500">
              {data.paymentStats.completed}
            </div>
            <div className="text-sm text-muted-foreground">پرداخت موفق</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-500">
              {formatCurrency(data.financialSummary.remainingBalance, data.currency)}
            </div>
            <div className="text-sm text-muted-foreground">باقیمانده</div>
          </CardContent>
        </Card>
      </div>

      {/* Payment Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            آمار پرداخت‌ها
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-500 mb-2">
                {data.paymentStats.successRate}%
              </div>
              <div className="text-sm text-muted-foreground">نرخ موفقیت</div>
              <Progress value={data.paymentStats.successRate} className="mt-2" />
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-500 mb-2">
                {data.paymentStats.averageProcessingTime}
              </div>
              <div className="text-sm text-muted-foreground">متوسط زمان پردازش</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-500 mb-2">
                {data.paymentStats.pending}
              </div>
              <div className="text-sm text-muted-foreground">در انتظار</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-red-500 mb-2">
                {data.paymentStats.failed}
              </div>
              <div className="text-sm text-muted-foreground">ناموفق</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Management Panel */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">نمای کلی</TabsTrigger>
          <TabsTrigger value="prizes">توزیع جوایز</TabsTrigger>
          <TabsTrigger value="winners">برندگان</TabsTrigger>
          <TabsTrigger value="payments">پرداخت‌ها</TabsTrigger>
          <TabsTrigger value="sponsors">حامیان</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {/* Prize Distribution Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  توزیع جوایز
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.prizeDistribution.slice(0, 5).map((prize) => (
                    <div key={prize.rank} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Badge variant="outline" className="text-xs">
                          <Crown className="w-3 h-3 ml-1" />
                          مقام {prize.rank}
                        </Badge>
                        <span className="text-sm">{prize.description || `برنده مقام ${prize.rank}`}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-yellow-500">
                          {formatCurrency(prize.amount, prize.currency)}
                        </div>
                        <div className="text-xs text-muted-foreground">{prize.percentage.toFixed(1)}%</div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {calculateTotalDistribution() !== 100 && (
                  <Alert className="mt-4">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      مجموع درصدهای توزیع {calculateTotalDistribution()}% است. برای توزیع کامل باید 100% باشد.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Recent Payments */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5" />
                  پرداخت‌های اخیر
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.payments.slice(0, 5).map((payment) => {
                    const winner = data.winners.find(w => w.id === payment.winnerId);
                    const PaymentIcon = getPaymentMethodIcon(payment.method);
                    
                    return (
                      <div key={payment.id} className="flex items-center gap-3 p-3 border rounded-lg">
                        <PaymentIcon className="w-5 h-5 text-blue-500" />
                        <div className="flex-1">
                          <div className="font-medium text-sm">{winner?.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {formatCurrency(payment.amount, payment.currency)} • {payment.method}
                          </div>
                        </div>
                        <Badge className={`text-xs ${getStatusColor(payment.status)}`}>
                          {payment.status === 'completed' ? 'موفق' :
                           payment.status === 'pending' ? 'در انتظار' :
                           payment.status === 'processing' ? 'در حال پردازش' :
                           payment.status === 'failed' ? 'ناموفق' : 'لغو شده'}
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Winner Verification Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  وضعیت تایید برندگان
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.winners.filter(w => w.kyc === 'pending').slice(0, 3).map((winner) => (
                    <div key={winner.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={winner.avatar} />
                          <AvatarFallback>{winner.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{winner.name}</div>
                          <div className="text-sm text-muted-foreground">مقام {winner.rank}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={`text-xs ${getKycStatusColor(winner.kyc)}`}>
                          {winner.kyc === 'pending' ? 'در انتظار تایید' :
                           winner.kyc === 'approved' ? 'تایید شده' : 'رد شده'}
                        </Badge>
                        <Button 
                          size="sm" 
                          onClick={() => onVerifyWinner(winner.id, 'approve')}
                          disabled={isLoading}
                        >
                          <CheckCircle className="w-3 h-3" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => onVerifyWinner(winner.id, 'reject')}
                          disabled={isLoading}
                        >
                          <XCircle className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {data.winners.filter(w => w.kyc === 'pending').length === 0 && (
                    <div className="text-center py-4 text-muted-foreground">
                      همه برندگان تایید شده‌اند
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Top Sponsors */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-5 h-5" />
                  حامیان اصلی
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {data.sponsors.slice(0, 3).map((sponsor) => (
                    <div key={sponsor.id} className="flex items-center gap-3 p-3 bg-secondary/30 rounded-lg">
                      <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center">
                        <Crown className="w-5 h-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">{sponsor.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {formatCurrency(sponsor.contribution, sponsor.currency)}
                        </div>
                      </div>
                      <Badge 
                        className={`text-xs ${
                          sponsor.tier === 'gold' ? 'bg-yellow-500/20 text-yellow-600' :
                          sponsor.tier === 'silver' ? 'bg-gray-500/20 text-gray-600' : 
                          'bg-orange-500/20 text-orange-600'
                        }`}
                      >
                        {sponsor.tier === 'gold' ? 'طلایی' : sponsor.tier === 'silver' ? 'نقره‌ای' : 'برنزی'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Prizes Tab */}
        <TabsContent value="prizes" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center gap-2">
                    <Gift className="w-5 h-5" />
                    توزیع جوایز
                  </CardTitle>
                  <Button onClick={() => setShowAddPrize(true)}>
                    <Plus className="w-4 h-4 ml-2" />
                    افزودن جایزه
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Summary */}
                  <div className="p-4 bg-blue-500/10 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">مجموع جوایز:</span>
                      <span className="font-bold text-blue-500">
                        {formatCurrency(data.totalPrizePool, data.currency)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">درصد توزیع:</span>
                      <span className={`text-sm font-medium ${
                        calculateTotalDistribution() === 100 ? 'text-green-500' : 'text-red-500'
                      }`}>
                        {calculateTotalDistribution()}%
                      </span>
                    </div>
                  </div>

                  {/* Prize List */}
                  <div className="space-y-3">
                    {data.prizeDistribution.map((prize) => (
                      <Card key={prize.rank} className="border">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <Badge variant="outline" className="text-sm">
                                <Crown className="w-4 h-4 ml-1" />
                                مقام {prize.rank}
                              </Badge>
                              
                              <div className="space-y-1">
                                <div className="font-medium">
                                  {formatCurrency(prize.amount, prize.currency)}
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  {prize.description || `جایزه مقام ${prize.rank}`}
                                </div>
                                {prize.sponsored && (
                                  <Badge variant="secondary" className="text-xs">
                                    حمایت {prize.sponsorName}
                                  </Badge>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-3">
                              <div className="text-right">
                                <div className="text-sm font-medium">{prize.percentage.toFixed(1)}%</div>
                                <div className="text-xs text-muted-foreground capitalize">
                                  {prize.type === 'cash' ? 'نقدی' : 
                                   prize.type === 'item' ? 'جایزه' :
                                   prize.type === 'trophy' ? 'کاپ' : 'امتیاز'}
                                </div>
                              </div>
                              
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleRemovePrize(prize.rank)}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Add Prize Form */}
                  {showAddPrize && (
                    <Card className="border-2 border-dashed border-blue-500/30">
                      <CardContent className="p-4">
                        <div className="space-y-4">
                          <h4 className="font-medium">افزودن جایزه جدید</h4>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div>
                              <label className="text-sm font-medium">مقام</label>
                              <Input
                                type="number"
                                value={newPrize.rank || ''}
                                onChange={(e) => setNewPrize({...newPrize, rank: parseInt(e.target.value)})}
                                placeholder="1"
                              />
                            </div>
                            
                            <div>
                              <label className="text-sm font-medium">مقدار جایزه</label>
                              <Input
                                type="number"
                                value={newPrize.amount || ''}
                                onChange={(e) => setNewPrize({...newPrize, amount: parseInt(e.target.value)})}
                                placeholder="100000"
                              />
                            </div>
                            
                            <div>
                              <label className="text-sm font-medium">واحد</label>
                              <Select 
                                value={newPrize.currency} 
                                onValueChange={(value: 'IRT' | 'USD') => setNewPrize({...newPrize, currency: value})}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="تومان" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="IRT">تومان</SelectItem>
                                  <SelectItem value="USD">دلار</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            
                            <div>
                              <label className="text-sm font-medium">نوع</label>
                              <Select 
                                value={newPrize.type} 
                                onValueChange={(value: any) => setNewPrize({...newPrize, type: value})}
                              >
                                <SelectTrigger>
                                  <SelectValue placeholder="نقدی" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="cash">نقدی</SelectItem>
                                  <SelectItem value="item">جایزه</SelectItem>
                                  <SelectItem value="trophy">کاپ</SelectItem>
                                  <SelectItem value="points">امتیاز</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          
                          <div>
                            <label className="text-sm font-medium">توضیحات (اختیاری)</label>
                            <Input
                              value={newPrize.description || ''}
                              onChange={(e) => setNewPrize({...newPrize, description: e.target.value})}
                              placeholder="توضیحات جایزه..."
                            />
                          </div>
                          
                          <div className="flex justify-end gap-2">
                            <Button variant="outline" onClick={() => setShowAddPrize(false)}>
                              لغو
                            </Button>
                            <Button onClick={handleAddPrize}>
                              <Plus className="w-4 h-4 ml-2" />
                              افزودن
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Winners Tab */}
        <TabsContent value="winners" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  برندگان تورنومنت
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.winners.map((winner) => {
                    const prize = data.prizeDistribution.find(p => p.rank === winner.rank);
                    
                    return (
                      <Card key={winner.id} className="border">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <Badge 
                                variant="outline" 
                                className={`text-sm ${
                                  winner.rank === 1 ? 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30' :
                                  winner.rank === 2 ? 'bg-gray-500/20 text-gray-600 border-gray-500/30' :
                                  winner.rank === 3 ? 'bg-orange-500/20 text-orange-600 border-orange-500/30' :
                                  'bg-blue-500/20 text-blue-600 border-blue-500/30'
                                }`}
                              >
                                <Crown className="w-4 h-4 ml-1" />
                                مقام {winner.rank}
                              </Badge>
                              
                              <Avatar className="w-12 h-12">
                                <AvatarImage src={winner.avatar} />
                                <AvatarFallback>{winner.name[0]}</AvatarFallback>
                              </Avatar>
                              
                              <div>
                                <div className="font-medium flex items-center gap-2">
                                  {winner.name}
                                  {winner.verified && (
                                    <CheckCircle className="w-4 h-4 text-green-500" />
                                  )}
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  @{winner.username} • {winner.country}
                                </div>
                                {winner.teamName && (
                                  <div className="text-xs text-muted-foreground">
                                    تیم: {winner.teamName}
                                  </div>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-4">
                              <div className="text-right">
                                <div className="font-bold text-green-500">
                                  {prize && formatCurrency(prize.amount, prize.currency)}
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  امتیاز نهایی: {winner.finalScore}
                                </div>
                                <Badge className={`text-xs mt-1 ${getKycStatusColor(winner.kyc)}`}>
                                  {winner.kyc === 'pending' ? 'در انتظار تایید' :
                                   winner.kyc === 'approved' ? 'تایید شده' : 'رد شده'}
                                </Badge>
                              </div>
                              
                              <div className="flex items-center gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setSelectedWinner(winner)}
                                >
                                  <Eye className="w-3 h-3 ml-1" />
                                  جزئیات
                                </Button>
                                
                                {winner.kyc === 'pending' && (
                                  <>
                                    <Button
                                      size="sm"
                                      onClick={() => onVerifyWinner(winner.id, 'approve')}
                                      disabled={isLoading}
                                    >
                                      <CheckCircle className="w-3 h-3" />
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      onClick={() => onVerifyWinner(winner.id, 'reject')}
                                      disabled={isLoading}
                                    >
                                      <XCircle className="w-3 h-3" />
                                    </Button>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Payments Tab */}
        <TabsContent value="payments" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  مدیریت پرداخت‌ها
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.payments.map((payment) => {
                    const winner = data.winners.find(w => w.id === payment.winnerId);
                    const PaymentIcon = getPaymentMethodIcon(payment.method);
                    
                    return (
                      <Card key={payment.id} className="border">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <PaymentIcon className="w-8 h-8 text-blue-500" />
                              
                              <div>
                                <div className="font-medium flex items-center gap-2">
                                  {winner?.name}
                                  <Badge className={`text-xs ${getStatusColor(payment.status)}`}>
                                    {payment.status === 'completed' ? 'موفق' :
                                     payment.status === 'pending' ? 'در انتظار' :
                                     payment.status === 'processing' ? 'در حال پردازش' :
                                     payment.status === 'failed' ? 'ناموفق' : 'لغو شده'}
                                  </Badge>
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  {formatCurrency(payment.amount, payment.currency)} • 
                                  {PAYMENT_METHODS.find(m => m.id === payment.method)?.name}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  شروع: {new Date(payment.initiatedAt).toLocaleDateString('fa-IR')}
                                  {payment.completedAt && (
                                    <span> • تکمیل: {new Date(payment.completedAt).toLocaleDateString('fa-IR')}</span>
                                  )}
                                </div>
                                {payment.failureReason && (
                                  <div className="text-xs text-red-500 mt-1">
                                    علت خطا: {payment.failureReason}
                                  </div>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex items-center gap-2">
                              <div className="text-right mr-4">
                                <div className="font-bold">
                                  {formatCurrency(payment.netAmount, payment.currency)}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  کارمزد: {formatCurrency(payment.fees, payment.currency)}
                                </div>
                                {payment.transactionId && (
                                  <div className="text-xs text-muted-foreground">
                                    شناسه: {payment.transactionId}
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex flex-col gap-1">
                                {payment.status === 'pending' && (
                                  <Button
                                    size="sm"
                                    onClick={() => onProcessPayment(payment.id)}
                                    disabled={isLoading}
                                  >
                                    <Send className="w-3 h-3 ml-1" />
                                    پردازش
                                  </Button>
                                )}
                                
                                {payment.status === 'failed' && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => onRetryPayment(payment.id)}
                                    disabled={isLoading}
                                  >
                                    <RefreshCw className="w-3 h-3 ml-1" />
                                    تلاش مجدد
                                  </Button>
                                )}
                                
                                {['pending', 'processing'].includes(payment.status) && (
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => onCancelPayment(payment.id)}
                                    disabled={isLoading}
                                  >
                                    <XCircle className="w-3 h-3 ml-1" />
                                    لغو
                                  </Button>
                                )}
                                
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setSelectedPayment(payment)}
                                >
                                  <Eye className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Sponsors Tab */}
        <TabsContent value="sponsors" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-5 h-5" />
                  حامیان تورنومنت
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.sponsors.map((sponsor) => (
                    <Card key={sponsor.id} className="border">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                              sponsor.tier === 'gold' ? 'bg-gradient-to-br from-yellow-500 to-orange-500' :
                              sponsor.tier === 'silver' ? 'bg-gradient-to-br from-gray-400 to-gray-600' :
                              'bg-gradient-to-br from-orange-500 to-red-500'
                            }`}>
                              <Star className="w-6 h-6 text-white" />
                            </div>
                            
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                {sponsor.name}
                                <Badge 
                                  className={`text-xs ${
                                    sponsor.tier === 'gold' ? 'bg-yellow-500/20 text-yellow-600' :
                                    sponsor.tier === 'silver' ? 'bg-gray-500/20 text-gray-600' : 
                                    'bg-orange-500/20 text-orange-600'
                                  }`}
                                >
                                  {sponsor.tier === 'gold' ? 'طلایی' : sponsor.tier === 'silver' ? 'نقره‌ای' : 'برنزی'}
                                </Badge>
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {sponsor.contactPerson} • {sponsor.email}
                              </div>
                              {sponsor.website && (
                                <div className="text-xs text-blue-500">
                                  {sponsor.website}
                                </div>
                              )}
                              {sponsor.items && sponsor.items.length > 0 && (
                                <div className="text-xs text-muted-foreground mt-1">
                                  اقلام: {sponsor.items.join(', ')}
                                </div>
                              )}
                            </div>
                          </div>
                          
                          <div className="text-right">
                            <div className="font-bold text-green-500">
                              {formatCurrency(sponsor.contribution, sponsor.currency)}
                            </div>
                            <div className="text-sm text-muted-foreground capitalize">
                              {sponsor.type === 'monetary' ? 'حمایت مالی' :
                               sponsor.type === 'item' ? 'اهدای جایزه' : 'ارائه خدمات'}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
}