import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Crown, Trophy, Users, Clock, Play, Eye, Target, TrendingUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface BracketMatch {
  id: string;
  team1: {
    name: string;
    avatar?: string;
    score?: number;
    rank?: string;
    seed: number;
  };
  team2: {
    name: string;
    avatar?: string;
    score?: number;
    rank?: string;
    seed: number;
  };
  winner?: 'team1' | 'team2' | null;
  status: 'upcoming' | 'live' | 'finished';
  round: string;
  startTime?: string;
  streamUrl?: string;
}

export interface TournamentBracketProps {
  matches: BracketMatch[];
  format: 'single-elimination' | 'double-elimination' | 'round-robin';
  currentRound?: string;
  isLive?: boolean;
}

export function TournamentBracket({ matches, format, currentRound, isLive = false }: TournamentBracketProps) {
  const [selectedMatch, setSelectedMatch] = useState<BracketMatch | null>(null);

  // Group matches by round
  const groupedMatches = matches.reduce((acc, match) => {
    if (!acc[match.round]) {
      acc[match.round] = [];
    }
    acc[match.round].push(match);
    return acc;
  }, {} as Record<string, BracketMatch[]>);

  const rounds = Object.keys(groupedMatches);

  const getMatchStatus = (match: BracketMatch) => {
    if (match.status === 'live') return { color: 'bg-red-500/20 border-red-500/50', text: 'زنده', icon: Play };
    if (match.status === 'finished') return { color: 'bg-green-500/20 border-green-500/50', text: 'تمام', icon: Trophy };
    return { color: 'bg-blue-500/20 border-blue-500/50', text: 'در انتظار', icon: Clock };
  };

  const getWinnerStyle = (match: BracketMatch, teamKey: 'team1' | 'team2') => {
    if (match.winner === teamKey) {
      return 'bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500/50 text-yellow-300';
    }
    if (match.winner && match.winner !== teamKey) {
      return 'opacity-60';
    }
    return '';
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {isLive && (
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <Badge variant="destructive">پخش زنده</Badge>
            </div>
          )}
          <Badge variant="outline">{format === 'single-elimination' ? 'حذفی' : format === 'double-elimination' ? 'حذفی دوطرفه' : 'دور برگشت'}</Badge>
        </div>
        
        <h3 className="font-semibold flex items-center gap-2">
          <Target className="w-5 h-5" />
          جدول مسابقات
        </h3>
      </div>

      {/* Current Round Info */}
      {currentRound && (
        <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="default">{matches.filter(m => m.round === currentRound && m.status === 'live').length} بازی زنده</Badge>
                <Badge variant="outline">{matches.filter(m => m.round === currentRound && m.status === 'upcoming').length} بازی در انتظار</Badge>
              </div>
              <h4 className="font-medium">دور فعلی: {currentRound}</h4>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Bracket Grid */}
      <div className="overflow-x-auto">
        <div className="flex gap-8 min-w-max pb-4">
          {rounds.map((round, roundIndex) => (
            <motion.div
              key={round}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: roundIndex * 0.1 }}
              className="min-w-[280px] space-y-4"
            >
              {/* Round Header */}
              <div className="text-center">
                <Badge 
                  variant={round === currentRound ? "default" : "outline"}
                  className="text-sm py-1 px-3"
                >
                  {round}
                </Badge>
              </div>

              {/* Matches */}
              <div className="space-y-4">
                {groupedMatches[round].map((match) => {
                  const status = getMatchStatus(match);
                  const StatusIcon = status.icon;
                  
                  return (
                    <Dialog key={match.id}>
                      <DialogTrigger asChild>
                        <motion.div
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className={`
                            p-4 rounded-lg border cursor-pointer transition-all duration-200
                            hover:shadow-lg ${status.color}
                          `}
                        >
                          {/* Match Status */}
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2 text-xs">
                              <StatusIcon className="w-3 h-3" />
                              {status.text}
                            </div>
                            {match.startTime && (
                              <span className="text-xs text-muted-foreground">{match.startTime}</span>
                            )}
                          </div>

                          {/* Team 1 */}
                          <div className={`
                            flex items-center justify-between p-2 rounded border
                            ${getWinnerStyle(match, 'team1')}
                          `}>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">#{match.team1.seed}</Badge>
                              {match.team1.score !== undefined && (
                                <span className="font-bold text-lg">{match.team1.score}</span>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="text-right">
                                <div className="font-medium">{match.team1.name}</div>
                                {match.team1.rank && (
                                  <div className="text-xs text-muted-foreground">{match.team1.rank}</div>
                                )}
                              </div>
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={match.team1.avatar} />
                                <AvatarFallback className="text-xs">{match.team1.name[0]}</AvatarFallback>
                              </Avatar>
                            </div>
                          </div>

                          {/* VS */}
                          <div className="text-center py-2">
                            <span className="text-xs text-muted-foreground font-medium">VS</span>
                          </div>

                          {/* Team 2 */}
                          <div className={`
                            flex items-center justify-between p-2 rounded border
                            ${getWinnerStyle(match, 'team2')}
                          `}>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">#{match.team2.seed}</Badge>
                              {match.team2.score !== undefined && (
                                <span className="font-bold text-lg">{match.team2.score}</span>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="text-right">
                                <div className="font-medium">{match.team2.name}</div>
                                {match.team2.rank && (
                                  <div className="text-xs text-muted-foreground">{match.team2.rank}</div>
                                )}
                              </div>
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={match.team2.avatar} />
                                <AvatarFallback className="text-xs">{match.team2.name[0]}</AvatarFallback>
                              </Avatar>
                            </div>
                          </div>

                          {/* Winner Crown */}
                          {match.winner && (
                            <div className="flex justify-center mt-2">
                              <Crown className="w-5 h-5 text-yellow-500" />
                            </div>
                          )}
                        </motion.div>
                      </DialogTrigger>

                      {/* Match Details Dialog */}
                      <DialogContent className="max-w-2xl" dir="rtl">
                        <DialogHeader>
                          <DialogTitle className="text-right">
                            جزئیات مسابقه - {match.round}
                          </DialogTitle>
                        </DialogHeader>
                        
                        <Tabs defaultValue="overview" className="w-full">
                          <TabsList className="grid w-full grid-cols-3">
                            <TabsTrigger value="overview">نمای کلی</TabsTrigger>
                            <TabsTrigger value="stats">آمارها</TabsTrigger>
                            <TabsTrigger value="history">تاریخچه</TabsTrigger>
                          </TabsList>
                          
                          <TabsContent value="overview" className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              {/* Team Details */}
                              <Card>
                                <CardHeader>
                                  <CardTitle className="text-sm flex items-center gap-2">
                                    <Avatar className="w-6 h-6">
                                      <AvatarImage src={match.team1.avatar} />
                                      <AvatarFallback className="text-xs">{match.team1.name[0]}</AvatarFallback>
                                    </Avatar>
                                    {match.team1.name}
                                  </CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <div className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                      <span>{match.team1.score || 0}</span>
                                      <span>امتیاز:</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span>{match.team1.rank || 'نامشخص'}</span>
                                      <span>رنک:</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span>#{match.team1.seed}</span>
                                      <span>ترتیب:</span>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>

                              <Card>
                                <CardHeader>
                                  <CardTitle className="text-sm flex items-center gap-2">
                                    <Avatar className="w-6 h-6">
                                      <AvatarImage src={match.team2.avatar} />
                                      <AvatarFallback className="text-xs">{match.team2.name[0]}</AvatarFallback>
                                    </Avatar>
                                    {match.team2.name}
                                  </CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <div className="space-y-2 text-sm">
                                    <div className="flex justify-between">
                                      <span>{match.team2.score || 0}</span>
                                      <span>امتیاز:</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span>{match.team2.rank || 'نامشخص'}</span>
                                      <span>رنک:</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span>#{match.team2.seed}</span>
                                      <span>ترتیب:</span>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </div>

                            {/* Actions */}
                            <div className="flex gap-2">
                              {match.status === 'live' && match.streamUrl && (
                                <Button className="flex-1">
                                  <Play className="w-4 h-4 ml-2" />
                                  تماشای زنده
                                </Button>
                              )}
                              {match.status === 'finished' && (
                                <Button variant="outline" className="flex-1">
                                  <TrendingUp className="w-4 h-4 ml-2" />
                                  گزارش کامل
                                </Button>
                              )}
                              {match.status === 'upcoming' && (
                                <Button variant="outline" className="flex-1">
                                  <Eye className="w-4 h-4 ml-2" />
                                  یادآوری
                                </Button>
                              )}
                            </div>
                          </TabsContent>

                          <TabsContent value="stats" className="space-y-4">
                            <div className="text-center text-muted-foreground">
                              آمارهای تفصیلی پس از پایان مسابقه در دسترس خواهد بود
                            </div>
                          </TabsContent>

                          <TabsContent value="history" className="space-y-4">
                            <div className="text-center text-muted-foreground">
                              تاریخچه رویارویی‌های قبلی
                            </div>
                          </TabsContent>
                        </Tabs>
                      </DialogContent>
                    </Dialog>
                  );
                })}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Tournament Stats */}
      <Card className="bg-gradient-to-r from-purple-500/5 to-blue-500/5">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-xl font-bold text-green-500">{matches.filter(m => m.status === 'finished').length}</div>
              <div className="text-xs text-muted-foreground">مسابقه تمام شده</div>
            </div>
            <div>
              <div className="text-xl font-bold text-red-500">{matches.filter(m => m.status === 'live').length}</div>
              <div className="text-xs text-muted-foreground">بازی زنده</div>
            </div>
            <div>
              <div className="text-xl font-bold text-blue-500">{matches.filter(m => m.status === 'upcoming').length}</div>
              <div className="text-xs text-muted-foreground">در انتظار</div>
            </div>
            <div>
              <div className="text-xl font-bold text-purple-500">{rounds.length}</div>
              <div className="text-xs text-muted-foreground">دور مسابقات</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}