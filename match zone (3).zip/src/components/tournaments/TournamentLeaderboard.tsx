import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { 
  Trophy, Crown, Medal, Star, TrendingUp, Target, 
  Gamepad2, Users, Clock, Award, ChevronUp, ChevronDown,
  Filter, Search, Calendar, BarChart3
} from 'lucide-react';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { motion, AnimatePresence } from 'motion/react';

export interface LeaderboardPlayer {
  id: string;
  name: string;
  avatar?: string;
  rank: number;
  previousRank?: number;
  points: number;
  wins: number;
  losses: number;
  winRate: number;
  tournamentsPlayed: number;
  totalEarnings: number;
  currentStreak: number;
  bestFinish: number;
  gameRank?: string;
  country?: string;
  team?: string;
  status: 'online' | 'offline' | 'in-game';
  lastActive: string;
  achievements: string[];
}

export interface TournamentStats {
  totalPlayers: number;
  totalPrizePool: number;
  averageSkill: string;
  topCountries: { name: string; count: number }[];
  recentWinners: LeaderboardPlayer[];
}

export interface TournamentLeaderboardProps {
  players: LeaderboardPlayer[];
  stats: TournamentStats;
  tournamentTitle: string;
  isLive?: boolean;
  showGlobalRanking?: boolean;
}

export function TournamentLeaderboard({ 
  players, 
  stats, 
  tournamentTitle,
  isLive = false,
  showGlobalRanking = false
}: TournamentLeaderboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'rank' | 'points' | 'winRate' | 'earnings'>('rank');
  const [filterBy, setFilterBy] = useState<'all' | 'online' | 'top10' | 'rising'>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<'current' | 'monthly' | 'alltime'>('current');

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-5 h-5 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-amber-600" />;
    return null;
  };

  const getRankChange = (player: LeaderboardPlayer) => {
    if (!player.previousRank) return null;
    const change = player.previousRank - player.rank;
    if (change > 0) return { direction: 'up', value: change, color: 'text-green-500' };
    if (change < 0) return { direction: 'down', value: Math.abs(change), color: 'text-red-500' };
    return { direction: 'same', value: 0, color: 'text-muted-foreground' };
  };

  const getStatusIndicator = (status: LeaderboardPlayer['status']) => {
    switch (status) {
      case 'online':
        return <div className="w-2 h-2 bg-green-500 rounded-full" />;
      case 'in-game':
        return <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />;
      default:
        return <div className="w-2 h-2 bg-gray-500 rounded-full" />;
    }
  };

  const filteredAndSortedPlayers = players
    .filter(player => {
      if (!searchQuery) return true;
      return player.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
             (player.team && player.team.toLowerCase().includes(searchQuery.toLowerCase()));
    })
    .filter(player => {
      switch (filterBy) {
        case 'online':
          return player.status !== 'offline';
        case 'top10':
          return player.rank <= 10;
        case 'rising':
          const change = getRankChange(player);
          return change && change.direction === 'up';
        default:
          return true;
      }
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'points':
          return b.points - a.points;
        case 'winRate':
          return b.winRate - a.winRate;
        case 'earnings':
          return b.totalEarnings - a.totalEarnings;
        default:
          return a.rank - b.rank;
      }
    });

  const topPerformers = players.slice(0, 3);

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-xl flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-primary" />
            جدول امتیازات {tournamentTitle}
          </h2>
          <p className="text-muted-foreground">
            {stats.totalPlayers} بازیکن • جایزه کل: {stats.totalPrizePool.toLocaleString()} تومان
          </p>
        </div>
        
        {isLive && (
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            <Badge variant="destructive">به‌روزرسانی زنده</Badge>
          </div>
        )}
      </div>

      {/* Top Performers */}
      <Card className="bg-gradient-to-r from-yellow-500/5 to-orange-500/5 border-yellow-500/20">
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Trophy className="w-4 h-4 text-yellow-500" />
            برترین عملکردها
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            {topPerformers.map((player, index) => (
              <motion.div
                key={player.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`text-center p-4 rounded-lg border ${
                  index === 0 ? 'bg-gradient-to-b from-yellow-500/20 to-yellow-600/10 border-yellow-500/30' :
                  index === 1 ? 'bg-gradient-to-b from-gray-400/20 to-gray-500/10 border-gray-400/30' :
                  'bg-gradient-to-b from-amber-600/20 to-amber-700/10 border-amber-600/30'
                }`}
              >
                <div className="relative mb-3">
                  <Avatar className={`w-16 h-16 mx-auto ${index === 0 ? 'ring-2 ring-yellow-500' : ''}`}>
                    <AvatarImage src={player.avatar} />
                    <AvatarFallback>{player.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="absolute -top-1 -right-1">
                    {getRankIcon(player.rank)}
                  </div>
                </div>
                
                <div className="space-y-1">
                  <h4 className="font-semibold">{player.name}</h4>
                  <div className="text-xs text-muted-foreground">
                    {player.team && <div>{player.team}</div>}
                    <div>{player.points.toLocaleString()} امتیاز</div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    رتبه {player.rank}
                  </Badge>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Filters and Controls */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="جستجو در بازیکنان..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
                dir="rtl"
              />
            </div>

            {/* Filters */}
            <div className="flex gap-2">
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rank">رتبه</SelectItem>
                  <SelectItem value="points">امتیاز</SelectItem>
                  <SelectItem value="winRate">درصد برد</SelectItem>
                  <SelectItem value="earnings">درآمد</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterBy} onValueChange={(value: any) => setFilterBy(value)}>
                <SelectTrigger className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  <SelectItem value="online">آنلاین</SelectItem>
                  <SelectItem value="top10">تاپ 10</SelectItem>
                  <SelectItem value="rising">صعودی</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedPeriod} onValueChange={(value: any) => setSelectedPeriod(value)}>
                <SelectTrigger className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="current">جاری</SelectItem>
                  <SelectItem value="monthly">ماهانه</SelectItem>
                  <SelectItem value="alltime">همه وقت</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="leaderboard" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="leaderboard">جدول امتیازات</TabsTrigger>
          <TabsTrigger value="stats">آمار کلی</TabsTrigger>
          <TabsTrigger value="history">تاریخچه</TabsTrigger>
        </TabsList>

        <TabsContent value="leaderboard" className="space-y-4">
          {/* Leaderboard Table */}
          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {filteredAndSortedPlayers.map((player, index) => {
                  const rankChange = getRankChange(player);
                  
                  return (
                    <motion.div
                      key={player.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.02 }}
                      className="p-4 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        {/* Left side - Stats */}
                        <div className="flex items-center gap-4 text-sm">
                          <div className="text-center min-w-[60px]">
                            <div className="font-bold">{player.points.toLocaleString()}</div>
                            <div className="text-xs text-muted-foreground">امتیاز</div>
                          </div>
                          
                          <div className="text-center min-w-[50px]">
                            <div className="font-medium">{player.winRate}%</div>
                            <div className="text-xs text-muted-foreground">برد</div>
                          </div>
                          
                          <div className="text-center min-w-[60px]">
                            <div className="font-medium">{player.wins}W/{player.losses}L</div>
                            <div className="text-xs text-muted-foreground">نتایج</div>
                          </div>

                          {player.totalEarnings > 0 && (
                            <div className="text-center min-w-[80px]">
                              <div className="font-medium text-green-600">
                                {player.totalEarnings.toLocaleString()}
                              </div>
                              <div className="text-xs text-muted-foreground">تومان</div>
                            </div>
                          )}
                        </div>

                        {/* Center - Player Info */}
                        <div className="flex items-center gap-3 flex-1 justify-end">
                          {/* Player Details */}
                          <div className="text-right">
                            <div className="flex items-center gap-2">
                              <span className="font-semibold">{player.name}</span>
                              {getStatusIndicator(player.status)}
                            </div>
                            
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              {player.team && <span>{player.team}</span>}
                              {player.gameRank && (
                                <Badge variant="outline" className="text-xs">
                                  {player.gameRank}
                                </Badge>
                              )}
                              {player.achievements.length > 0 && (
                                <div className="flex gap-1">
                                  {player.achievements.slice(0, 2).map((achievement, i) => (
                                    <Award key={i} className="w-3 h-3 text-yellow-500" />
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Avatar */}
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={player.avatar} />
                            <AvatarFallback>{player.name[0]}</AvatarFallback>
                          </Avatar>
                        </div>

                        {/* Right side - Rank */}
                        <div className="flex items-center gap-2 min-w-[100px]">
                          {/* Rank Change */}
                          <div className="flex flex-col items-center">
                            {rankChange && rankChange.direction !== 'same' && (
                              <div className={`flex items-center gap-1 text-xs ${rankChange.color}`}>
                                {rankChange.direction === 'up' ? 
                                  <ChevronUp className="w-3 h-3" /> : 
                                  <ChevronDown className="w-3 h-3" />
                                }
                                {rankChange.value}
                              </div>
                            )}
                          </div>

                          {/* Rank Number */}
                          <div className="flex items-center gap-2">
                            {getRankIcon(player.rank)}
                            <span className={`font-bold text-lg ${
                              player.rank <= 3 ? 'text-yellow-600' : 
                              player.rank <= 10 ? 'text-blue-600' : ''
                            }`}>
                              #{player.rank}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Additional Info for Top Players */}
                      {player.rank <= 3 && (
                        <div className="mt-3 pt-3 border-t border-muted">
                          <div className="grid grid-cols-3 gap-4 text-xs">
                            <div className="text-center">
                              <div className="font-medium">{player.tournamentsPlayed}</div>
                              <div className="text-muted-foreground">مسابقه</div>
                            </div>
                            <div className="text-center">
                              <div className="font-medium">{player.currentStreak}</div>
                              <div className="text-muted-foreground">برد پیاپی</div>
                            </div>
                            <div className="text-center">
                              <div className="font-medium">#{player.bestFinish}</div>
                              <div className="text-muted-foreground">بهترین رتبه</div>
                            </div>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats" className="space-y-4">
          {/* Tournament Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="text-center p-4">
              <div className="text-2xl font-bold text-primary">{stats.totalPlayers}</div>
              <div className="text-sm text-muted-foreground">بازیکن</div>
            </Card>
            
            <Card className="text-center p-4">
              <div className="text-2xl font-bold text-green-500">
                {stats.totalPrizePool.toLocaleString()}
              </div>
              <div className="text-sm text-muted-foreground">تومان جایزه</div>
            </Card>
            
            <Card className="text-center p-4">
              <div className="text-2xl font-bold text-blue-500">{stats.averageSkill}</div>
              <div className="text-sm text-muted-foreground">متوسط مهارت</div>
            </Card>
            
            <Card className="text-center p-4">
              <div className="text-2xl font-bold text-purple-500">
                {Math.round(players.reduce((sum, p) => sum + p.winRate, 0) / players.length)}%
              </div>
              <div className="text-sm text-muted-foreground">متوسط برد</div>
            </Card>
          </div>

          {/* Top Countries */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">کشورهای برتر</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats.topCountries.map((country, index) => (
                  <div key={country.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">#{index + 1}</Badge>
                      <span>{country.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-20 bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full"
                          style={{ width: `${(country.count / stats.totalPlayers) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{country.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          {/* Recent Winners */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">برندگان اخیر</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stats.recentWinners.map((winner, index) => (
                  <div key={winner.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Trophy className="w-4 h-4 text-yellow-500" />
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={winner.avatar} />
                        <AvatarFallback>{winner.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{winner.name}</div>
                        <div className="text-xs text-muted-foreground">{winner.lastActive}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600">
                        {winner.totalEarnings.toLocaleString()} تومان
                      </div>
                      <div className="text-xs text-muted-foreground">جایزه</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}