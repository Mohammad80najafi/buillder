import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: Date;
}

interface BadgeShowcaseProps {
  achievements: Achievement[];
  maxVisible?: number;
  className?: string;
}

const rarityColors: Record<Achievement['rarity'], string> = {
  common: 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300',
  rare: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300',
  epic: 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300',
  legendary: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300',
};

export const BadgeShowcase: React.FC<BadgeShowcaseProps> = ({
  achievements,
  maxVisible = 6,
  className,
}) => {
  const visibleAchievements = achievements.slice(0, maxVisible);
  const remainingCount = Math.max(0, achievements.length - maxVisible);

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-right">دستاوردها و جوایز</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {visibleAchievements.map((achievement) => (
            <div
              key={achievement.id}
              className="flex flex-col items-center p-3 rounded-lg border border-border hover:bg-accent/50 transition-colors"
            >
              <div className="text-2xl mb-2">{achievement.icon}</div>
              <h4 className="font-medium text-sm text-center mb-1">
                {achievement.name}
              </h4>
              <Badge
                className={cn(
                  'text-xs mb-2',
                  rarityColors[achievement.rarity]
                )}
              >
                {achievement.rarity === 'common' && 'عادی'}
                {achievement.rarity === 'rare' && 'نادر'}
                {achievement.rarity === 'epic' && 'حماسی'}
                {achievement.rarity === 'legendary' && 'افسانه‌ای'}
              </Badge>
              <p className="text-xs text-muted-foreground text-center">
                {achievement.description}
              </p>
              {achievement.unlockedAt && (
                <p className="text-xs text-muted-foreground mt-1">
                  {new Date(achievement.unlockedAt).toLocaleDateString('fa-IR')}
                </p>
              )}
            </div>
          ))}
          
          {remainingCount > 0 && (
            <div className="flex flex-col items-center justify-center p-3 rounded-lg border border-dashed border-border text-muted-foreground">
              <div className="text-2xl mb-2">+</div>
              <p className="text-sm">
                {remainingCount} دستاورد دیگر
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};