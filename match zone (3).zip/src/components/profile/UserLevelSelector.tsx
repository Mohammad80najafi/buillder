/**
 * User Level Selector Component
 * For testing and switching between user levels
 */

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Progress } from '../ui/progress';
import { Users, Crown, Gem, Star, Coins } from 'lucide-react';
import { useUser, UserLevel, USER_LEVELS, getUserLevelBadge, getRequiredXPForNextLevel } from '../providers/UserProvider';

const levelIcons = {
  player: Users,
  host: Crown,
  manager: Gem
};

export function UserLevelSelector() {
  const { user, currentLevelInfo, setUserLevel, addXP, addCoins } = useUser();
  
  const LevelIcon = levelIcons[user.level];
  const nextLevel = user.level === 'player' ? 'host' : user.level === 'host' ? 'manager' : null;
  const requiredXP = nextLevel ? getRequiredXPForNextLevel(user.level) : null;
  const xpProgress = requiredXP ? (user.xp / requiredXP) * 100 : 100;

  const handleLevelChange = (newLevel: UserLevel) => {
    setUserLevel(newLevel);
    // Add appropriate XP for the level
    const minXP = {
      player: 0,
      host: 1000,
      manager: 5000
    };
    if (user.xp < minXP[newLevel]) {
      addXP(minXP[newLevel] - user.xp);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <LevelIcon className={`w-5 h-5 ${currentLevelInfo.color}`} />
          سطح کاربری
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Level Display */}
        <div className="flex items-center justify-between p-4 rounded-lg bg-muted/30 border">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${currentLevelInfo.bgColor}`}>
              <LevelIcon className={`w-6 h-6 ${currentLevelInfo.color}`} />
            </div>
            <div>
              <h3 className="font-medium">{currentLevelInfo.name}</h3>
              <p className="text-sm text-muted-foreground">{currentLevelInfo.description}</p>
            </div>
          </div>
          <Badge variant="outline" className={`${currentLevelInfo.bgColor} ${currentLevelInfo.color} border-0`}>
            {getUserLevelBadge(user.level)} سطح {Math.floor(user.xp / 100)}
          </Badge>
        </div>

        {/* XP Progress */}
        {nextLevel && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>پیشرفت تا سطح بعدی ({USER_LEVELS[nextLevel].name})</span>
              <span>{user.xp.toLocaleString()} / {requiredXP?.toLocaleString()} XP</span>
            </div>
            <Progress value={xpProgress} className="h-2" />
          </div>
        )}

        {/* Level Selector for Testing */}
        <div className="space-y-2">
          <label className="text-sm font-medium">تغییر سطح (برای تست):</label>
          <Select value={user.level} onValueChange={handleLevelChange}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(USER_LEVELS).map(([level, info]) => {
                const Icon = levelIcons[level as UserLevel];
                return (
                  <SelectItem key={level} value={level}>
                    <div className="flex items-center gap-2">
                      <Icon className={`w-4 h-4 ${info.color}`} />
                      <span>{info.name}</span>
                      <span className="text-xs text-muted-foreground">({info.description})</span>
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        {/* User Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 rounded-lg bg-muted/20">
            <Star className="w-5 h-5 mx-auto text-yellow-500 mb-1" />
            <div className="font-medium">{user.xp.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">امتیاز تجربه</div>
          </div>
          <div className="text-center p-3 rounded-lg bg-muted/20">
            <Coins className="w-5 h-5 mx-auto text-yellow-600 mb-1" />
            <div className="font-medium">{user.coins.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">سکه</div>
          </div>
        </div>

        {/* Level Permissions */}
        <div className="space-y-2">
          <h4 className="font-medium text-sm">دسترسی‌های این سطح:</h4>
          <div className="space-y-1 text-sm">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${currentLevelInfo.canCreatePaidLobbies ? 'bg-green-500' : 'bg-gray-400'}`} />
              <span className={currentLevelInfo.canCreatePaidLobbies ? 'text-foreground' : 'text-muted-foreground'}>
                ایجاد لابی‌های پولی
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${currentLevelInfo.canCreateTournaments ? 'bg-green-500' : 'bg-gray-400'}`} />
              <span className={currentLevelInfo.canCreateTournaments ? 'text-foreground' : 'text-muted-foreground'}>
                برگزاری تورنومنت
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${currentLevelInfo.canCreateClans ? 'bg-green-500' : 'bg-gray-400'}`} />
              <span className={currentLevelInfo.canCreateClans ? 'text-foreground' : 'text-muted-foreground'}>
                ایجاد کلن و گروه
              </span>
            </div>
          </div>
        </div>

        {/* Quick Actions for Testing */}
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => addXP(100)}
          >
            +100 XP
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => addCoins(1000)}
          >
            +1000 سکه
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}