import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent } from '../ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { TrustBadge, TrustLevel } from '../ui/trust-badge';
import { StatusIndicator, Status } from '../ui/status-indicator';

export type UserRole = 'player' | 'organizer' | 'creator' | 'admin';

interface ProfileCardProps {
  user: {
    id: string;
    name: string;
    username: string;
    avatar?: string;
    trustLevel: TrustLevel;
    status: Status;
    role: UserRole;
    level?: number;
    xp?: number;
    coins?: number;
  };
  variant?: 'compact' | 'full';
  showStats?: boolean;
  className?: string;
  onClick?: () => void;
}

const roleLabels: Record<UserRole, string> = {
  player: 'بازیکن',
  organizer: 'برگزارکننده',
  creator: 'کریتور',
  admin: 'ادمین',
};

const roleColors: Record<UserRole, string> = {
  player: 'text-blue-600 bg-blue-100 dark:bg-blue-900/20',
  organizer: 'text-purple-600 bg-purple-100 dark:bg-purple-900/20',
  creator: 'text-orange-600 bg-orange-100 dark:bg-orange-900/20',
  admin: 'text-red-600 bg-red-100 dark:bg-red-900/20',
};

export const ProfileCard: React.FC<ProfileCardProps> = ({
  user,
  variant = 'compact',
  showStats = false,
  className,
  onClick,
}) => {
  const isClickable = !!onClick;

  return (
    <Card
      className={cn(
        'relative transition-all duration-200',
        isClickable && 'cursor-pointer hover:shadow-lg hover:scale-[1.02]',
        className
      )}
      onClick={onClick}
    >
      <CardContent className={cn('p-4', variant === 'compact' && 'p-3')}>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Avatar className={variant === 'compact' ? 'h-10 w-10' : 'h-12 w-12'}>
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="absolute -bottom-1 -right-1">
              <StatusIndicator status={user.status} size="sm" />
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-medium text-foreground truncate">
                {user.name}
              </h3>
              <TrustBadge level={user.trustLevel} size="sm" showLabel={false} />
            </div>
            
            <div className="flex items-center gap-2">
              <p className="text-sm text-muted-foreground">@{user.username}</p>
              <span
                className={cn(
                  'px-2 py-0.5 rounded-full text-xs font-medium',
                  roleColors[user.role]
                )}
              >
                {roleLabels[user.role]}
              </span>
            </div>

            {variant === 'full' && showStats && (
              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                {user.level && (
                  <span>سطح {user.level}</span>
                )}
                {user.xp && (
                  <span>{user.xp.toLocaleString('fa-IR')} XP</span>
                )}
                {user.coins && (
                  <span>{user.coins.toLocaleString('fa-IR')} سکه</span>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};