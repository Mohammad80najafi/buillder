/**
 * Economy System Components Export
 * اکسپورت کامپوننت‌های سیستم اقتصادی
 */

export { AdvancedEconomySystem } from './AdvancedEconomySystem';