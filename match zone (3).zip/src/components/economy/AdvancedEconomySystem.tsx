/**
 * Advanced Economy System - Comprehensive wallet and marketplace
 * مرحله 5: سیستم اقتصادی پیشرفته
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { 
  Wallet, 
  Coins, 
  Gem, 
  TrendingUp, 
  TrendingDown,
  ShoppingCart, 
  Gift,
  CreditCard,
  History,
  Star,
  Crown,
  Zap,
  Shield,
  Award,
  Timer,
  Users,
  Target,
  ArrowUpRight,
  ArrowDownLeft,
  Plus,
  Minus,
  RefreshCw,
  Trophy
} from 'lucide-react';

interface WalletBalance {
  coins: number;
  gems: number;
  premiumCredits: number;
  vipPoints: number;
}

interface Transaction {
  id: string;
  type: 'earn' | 'spend' | 'transfer' | 'purchase';
  currency: 'coins' | 'gems' | 'premium' | 'vip';
  amount: number;
  description: string;
  timestamp: string;
  source?: string;
  isPositive: boolean;
}

interface MarketItem {
  id: string;
  name: string;
  description: string;
  type: 'skin' | 'avatar' | 'frame' | 'badge' | 'boost' | 'premium';
  rarity: 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';
  price: {
    coins?: number;
    gems?: number;
    premium?: number;
  };
  discount?: number;
  timeLeft?: string;
  preview: string;
  isOwned: boolean;
  isPurchasable: boolean;
}

interface InvestmentOption {
  id: string;
  name: string;
  description: string;
  minAmount: number;
  expectedReturn: number;
  duration: string;
  riskLevel: 'low' | 'medium' | 'high';
  currentParticipants: number;
  maxParticipants: number;
  icon: React.ReactNode;
}

const mockWalletBalance: WalletBalance = {
  coins: 12750,
  gems: 450,
  premiumCredits: 25,
  vipPoints: 890
};

const mockTransactions: Transaction[] = [
  {
    id: '1',
    type: 'earn',
    currency: 'coins',
    amount: 500,
    description: 'برد در تورنومنت طلایی',
    timestamp: '2 ساعت پیش',
    source: 'tournament',
    isPositive: true
  },
  {
    id: '2',
    type: 'spend',
    currency: 'gems',
    amount: 50,
    description: 'خرید آواتار ویژه',
    timestamp: '5 ساعت پیش',
    source: 'store',
    isPositive: false
  },
  {
    id: '3',
    type: 'earn',
    currency: 'vip',
    amount: 100,
    description: 'انجام ماموریت هفتگی',
    timestamp: '1 روز پیش',
    source: 'mission',
    isPositive: true
  }
];

const mockMarketItems: MarketItem[] = [
  {
    id: '1',
    name: 'آواتار اژدهای آتشین',
    description: 'آواتار افسانه‌ای با انیمیشن ویژه',
    type: 'avatar',
    rarity: 'legendary',
    price: { gems: 200 },
    discount: 15,
    timeLeft: '2 روز',
    preview: '/avatars/fire-dragon.png',
    isOwned: false,
    isPurchasable: true
  },
  {
    id: '2',
    name: 'فریم پروفایل الماسی',
    description: 'فریم درخشان برای نمایش رتبه',
    type: 'frame',
    rarity: 'epic',
    price: { coins: 2500 },
    preview: '/frames/diamond.png',
    isOwned: false,
    isPurchasable: true
  },
  {
    id: '3',
    name: 'بوست XP مضاعف',
    description: 'دو برابر کردن تجربه برای 24 ساعت',
    type: 'boost',
    rarity: 'rare',
    price: { premium: 5 },
    preview: '/boosts/double-xp.png',
    isOwned: true,
    isPurchasable: false
  }
];

const mockInvestments: InvestmentOption[] = [
  {
    id: '1',
    name: 'صندوق تورنومنت',
    description: 'سرمایه‌گذاری در جوایز تورنومنت‌های آینده',
    minAmount: 1000,
    expectedReturn: 15,
    duration: '1 ماه',
    riskLevel: 'low',
    currentParticipants: 245,
    maxParticipants: 500,
    icon: <Trophy className="w-5 h-5" />
  },
  {
    id: '2',
    name: 'صندوق کلن',
    description: 'حمایت از تیم‌های حرفه‌ای و دریافت سود',
    minAmount: 2500,
    expectedReturn: 25,
    duration: '2 ماه',
    riskLevel: 'medium',
    currentParticipants: 89,
    maxParticipants: 200,
    icon: <Users className="w-5 h-5" />
  },
  {
    id: '3',
    name: 'صندوق نوآوری',
    description: 'سرمایه‌گذاری در ویژگی‌های جدید پلتفرم',
    minAmount: 5000,
    expectedReturn: 40,
    duration: '3 ماه',
    riskLevel: 'high',
    currentParticipants: 34,
    maxParticipants: 100,
    icon: <Zap className="w-5 h-5" />
  }
];

const getRarityColor = (rarity: string) => {
  const colors = {
    common: 'text-gray-500 bg-gray-100 dark:bg-gray-900',
    rare: 'text-blue-500 bg-blue-100 dark:bg-blue-900',
    epic: 'text-purple-500 bg-purple-100 dark:bg-purple-900',
    legendary: 'text-orange-500 bg-orange-100 dark:bg-orange-900',
    mythic: 'text-red-500 bg-red-100 dark:bg-red-900'
  };
  return colors[rarity as keyof typeof colors] || colors.common;
};

const getRiskColor = (risk: string) => {
  const colors = {
    low: 'text-green-600 bg-green-100 dark:bg-green-900',
    medium: 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900',
    high: 'text-red-600 bg-red-100 dark:bg-red-900'
  };
  return colors[risk as keyof typeof colors] || colors.medium;
};

export function AdvancedEconomySystem() {
  const [selectedCurrency, setSelectedCurrency] = useState<string>('coins');
  const [investmentAmount, setInvestmentAmount] = useState<number>(1000);
  const [isLoading, setIsLoading] = useState(false);

  const handlePurchase = async (item: MarketItem) => {
    setIsLoading(true);
    // Simulate purchase
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
  };

  const handleInvestment = async (investment: InvestmentOption) => {
    setIsLoading(true);
    // Simulate investment
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
  };

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto" dir="rtl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center gap-3">
          <Wallet className="w-8 h-8 text-green-500" />
          <h1 className="text-3xl font-bold">سیستم اقتصادی Matchzone</h1>
        </div>
      </motion.div>

      {/* Wallet Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border-green-500/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wallet className="w-6 h-6 text-green-500" />
              کیف پول شما
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                <Coins className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-yellow-500">
                  {mockWalletBalance.coins.toLocaleString()}
                </p>
                <p className="text-sm text-muted-foreground">سکه</p>
              </div>
              
              <div className="text-center p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <Gem className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-blue-500">
                  {mockWalletBalance.gems.toLocaleString()}
                </p>
                <p className="text-sm text-muted-foreground">جواهر</p>
              </div>
              
              <div className="text-center p-4 bg-purple-500/10 rounded-lg border border-purple-500/20">
                <Crown className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-purple-500">
                  {mockWalletBalance.premiumCredits.toLocaleString()}
                </p>
                <p className="text-sm text-muted-foreground">اعتبار پریمیوم</p>
              </div>
              
              <div className="text-center p-4 bg-orange-500/10 rounded-lg border border-orange-500/20">
                <Star className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-orange-500">
                  {mockWalletBalance.vipPoints.toLocaleString()}
                </p>
                <p className="text-sm text-muted-foreground">امتیاز VIP</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Main Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Tabs defaultValue="marketplace" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="marketplace">فروشگاه</TabsTrigger>
            <TabsTrigger value="investments">سرمایه‌گذاری</TabsTrigger>
            <TabsTrigger value="transactions">تراکنش‌ها</TabsTrigger>
            <TabsTrigger value="analytics">آمارها</TabsTrigger>
          </TabsList>

          {/* Marketplace */}
          <TabsContent value="marketplace" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">فروشگاه آیتم‌ها</h2>
              <Button variant="outline" size="sm">
                <RefreshCw className="w-4 h-4 ml-2" />
                به‌روزرسانی
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockMarketItems.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="overflow-hidden hover:shadow-lg transition-all">
                    <div className="aspect-video bg-gradient-to-br from-blue-500/20 to-purple-500/20 relative">
                      <div className="absolute top-2 left-2 flex gap-2">
                        <Badge className={getRarityColor(item.rarity)}>
                          {item.rarity}
                        </Badge>
                        {item.discount && (
                          <Badge variant="destructive">
                            {item.discount}% تخفیف
                          </Badge>
                        )}
                      </div>
                      {item.timeLeft && (
                        <div className="absolute bottom-2 left-2">
                          <Badge variant="secondary" className="text-xs">
                            <Timer className="w-3 h-3 ml-1" />
                            {item.timeLeft}
                          </Badge>
                        </div>
                      )}
                    </div>
                    
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2">{item.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">
                        {item.description}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          {item.price.coins && (
                            <div className="flex items-center gap-1">
                              <Coins className="w-4 h-4 text-yellow-500" />
                              <span className={`text-sm ${item.discount ? 'line-through text-muted-foreground' : 'font-semibold'}`}>
                                {item.price.coins.toLocaleString()}
                              </span>
                              {item.discount && (
                                <span className="text-sm font-semibold text-green-600">
                                  {Math.round(item.price.coins * (1 - item.discount / 100)).toLocaleString()}
                                </span>
                              )}
                            </div>
                          )}
                          {item.price.gems && (
                            <div className="flex items-center gap-1">
                              <Gem className="w-4 h-4 text-blue-500" />
                              <span className="text-sm font-semibold">
                                {item.price.gems.toLocaleString()}
                              </span>
                            </div>
                          )}
                          {item.price.premium && (
                            <div className="flex items-center gap-1">
                              <Crown className="w-4 h-4 text-purple-500" />
                              <span className="text-sm font-semibold">
                                {item.price.premium.toLocaleString()}
                              </span>
                            </div>
                          )}
                        </div>
                        
                        <Button
                          size="sm"
                          disabled={item.isOwned || !item.isPurchasable || isLoading}
                          onClick={() => handlePurchase(item)}
                        >
                          {item.isOwned ? 'دارید' : 'خرید'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Investments */}
          <TabsContent value="investments" className="space-y-4">
            <div className="text-center space-y-2">
              <h2 className="text-xl font-semibold">صندوق‌های سرمایه‌گذاری</h2>
              <p className="text-sm text-muted-foreground">
                با سرمایه‌گذاری در پروژه‌های مختلف، درآمد کسب کنید
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockInvestments.map((investment, index) => (
                <motion.div
                  key={investment.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full">
                    <CardHeader>
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          {investment.icon}
                        </div>
                        <div>
                          <CardTitle className="text-lg">{investment.name}</CardTitle>
                          <Badge className={getRiskColor(investment.riskLevel)}>
                            ریسک {investment.riskLevel === 'low' ? 'کم' : investment.riskLevel === 'medium' ? 'متوسط' : 'بالا'}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        {investment.description}
                      </p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="space-y-1">
                          <p className="text-muted-foreground">حداقل سرمایه:</p>
                          <p className="font-semibold">
                            {investment.minAmount.toLocaleString()} سکه
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-muted-foreground">بازده مورد انتظار:</p>
                          <p className="font-semibold text-green-600">
                            {investment.expectedReturn}%
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-muted-foreground">مدت زمان:</p>
                          <p className="font-semibold">{investment.duration}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-muted-foreground">شرکت‌کنندگان:</p>
                          <p className="font-semibold">
                            {investment.currentParticipants}/{investment.maxParticipants}
                          </p>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <p className="text-sm text-muted-foreground">میزان پر شدن:</p>
                        <Progress 
                          value={(investment.currentParticipants / investment.maxParticipants) * 100} 
                        />
                      </div>
                      
                      <Button 
                        className="w-full"
                        onClick={() => handleInvestment(investment)}
                        disabled={isLoading}
                      >
                        سرمایه‌گذاری
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Transactions */}
          <TabsContent value="transactions" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">تاریخچه تراکنش‌ها</h2>
              <Button variant="outline" size="sm">
                <History className="w-4 h-4 ml-2" />
                مشاهده همه
              </Button>
            </div>

            <div className="space-y-3">
              {mockTransactions.map((transaction, index) => (
                <motion.div
                  key={transaction.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-full ${
                            transaction.isPositive 
                              ? 'bg-green-100 dark:bg-green-900 text-green-600'
                              : 'bg-red-100 dark:bg-red-900 text-red-600'
                          }`}>
                            {transaction.isPositive ? (
                              <ArrowUpRight className="w-4 h-4" />
                            ) : (
                              <ArrowDownLeft className="w-4 h-4" />
                            )}
                          </div>
                          
                          <div>
                            <p className="font-medium">{transaction.description}</p>
                            <p className="text-sm text-muted-foreground">
                              {transaction.timestamp}
                            </p>
                          </div>
                        </div>
                        
                        <div className="text-left">
                          <div className="flex items-center gap-1">
                            {transaction.currency === 'coins' && <Coins className="w-4 h-4 text-yellow-500" />}
                            {transaction.currency === 'gems' && <Gem className="w-4 h-4 text-blue-500" />}
                            {transaction.currency === 'premium' && <Crown className="w-4 h-4 text-purple-500" />}
                            {transaction.currency === 'vip' && <Star className="w-4 h-4 text-orange-500" />}
                            
                            <span className={`font-semibold ${
                              transaction.isPositive ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {transaction.isPositive ? '+' : '-'}{transaction.amount.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-4">
            <h2 className="text-xl font-semibold">آمار اقتصادی</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <TrendingUp className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-green-600">+24.5%</p>
                  <p className="text-sm text-muted-foreground">درآمد این ماه</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <ShoppingCart className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold">127</p>
                  <p className="text-sm text-muted-foreground">خرید این ماه</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <Gift className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold">1,250</p>
                  <p className="text-sm text-muted-foreground">امتیاز هدیه</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <Target className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold">85%</p>
                  <p className="text-sm text-muted-foreground">هدف ماهانه</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}