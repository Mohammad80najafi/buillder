/**
 * Matchzone User Provider
 * Centralized user management and level system
 */

import React, { createContext, useContext, useState, useCallback } from 'react';
import { Users, Crown, Gem } from 'lucide-react';

// User levels definition
export type UserLevel = 'player' | 'host' | 'manager';

export interface UserLevelInfo {
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  bgColor: string;
  canCreatePaidLobbies: boolean;
  canCreateTournaments: boolean;
  canCreateClans: boolean;
}

export const USER_LEVELS: Record<UserLevel, UserLevelInfo> = {
  player: {
    name: 'بازیکن',
    description: 'لابی‌های رایگان و پیدا کردن دوست',
    icon: Users,
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10',
    canCreatePaidLobbies: false,
    canCreateTournaments: false,
    canCreateClans: false
  },
  host: {
    name: 'برگذارکننده',
    description: 'لابی‌های پولی و تورنومنت',
    icon: Crown,
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-400/10',
    canCreatePaidLobbies: true,
    canCreateTournaments: true,
    canCreateClans: false
  },
  manager: {
    name: 'مدیر گیم‌نت',
    description: 'کلن‌ها و گروه‌های تیمی',
    icon: Gem,
    color: 'text-purple-400',
    bgColor: 'bg-purple-400/10',
    canCreatePaidLobbies: true,
    canCreateTournaments: true,
    canCreateClans: true
  }
};

// User state interface
interface UserState {
  id: string;
  level: UserLevel;
  username: string;
  avatar?: string;
  xp: number;
  coins: number;
  clanId?: string;
  clanName?: string;
  badges: string[];
}

// User context interface
interface UserContextType {
  // State
  user: UserState;
  currentUser: UserState | null; // alias for consistency
  
  // Actions
  setUserLevel: (level: UserLevel) => void;
  updateUser: (updates: Partial<UserState>) => void;
  addXP: (amount: number) => void;
  addCoins: (amount: number) => void;
  spendCoins: (amount: number) => boolean;
  joinClan: (clanId: string, clanName: string) => void;
  leaveClan: () => void;
  addBadge: (badge: string) => void;
  
  // Computed
  currentLevelInfo: UserLevelInfo;
  canCreatePaidLobbies: boolean;
  canCreateTournaments: boolean;
  canCreateClans: boolean;
}

const UserContext = createContext<UserContextType | null>(null);

interface UserProviderProps {
  children: React.ReactNode;
  initialLevel?: UserLevel;
}

export function UserProvider({ children, initialLevel = 'player' }: UserProviderProps) {
  const [user, setUser] = useState<UserState>({
    id: 'current-user-1',
    level: initialLevel,
    username: 'کاربر MatchZone',
    xp: 150,
    coins: 2500,
    badges: ['newcomer']
  });

  const setUserLevel = useCallback((level: UserLevel) => {
    setUser(prev => ({ ...prev, level }));
  }, []);

  const updateUser = useCallback((updates: Partial<UserState>) => {
    setUser(prev => ({ ...prev, ...updates }));
  }, []);

  const addXP = useCallback((amount: number) => {
    setUser(prev => ({ ...prev, xp: prev.xp + amount }));
  }, []);

  const addCoins = useCallback((amount: number) => {
    setUser(prev => ({ ...prev, coins: prev.coins + amount }));
  }, []);

  const spendCoins = useCallback((amount: number): boolean => {
    if (user.coins >= amount) {
      setUser(prev => ({ ...prev, coins: prev.coins - amount }));
      return true;
    }
    return false;
  }, [user.coins]);

  const joinClan = useCallback((clanId: string, clanName: string) => {
    setUser(prev => ({ ...prev, clanId, clanName }));
  }, []);

  const leaveClan = useCallback(() => {
    setUser(prev => ({ ...prev, clanId: undefined, clanName: undefined }));
  }, []);

  const addBadge = useCallback((badge: string) => {
    setUser(prev => ({
      ...prev,
      badges: prev.badges.includes(badge) ? prev.badges : [...prev.badges, badge]
    }));
  }, []);

  const currentLevelInfo = USER_LEVELS[user.level];

  const value: UserContextType = {
    // State
    user,
    currentUser: user, // alias for consistency
    
    // Actions
    setUserLevel,
    updateUser,
    addXP,
    addCoins,
    spendCoins,
    joinClan,
    leaveClan,
    addBadge,
    
    // Computed
    currentLevelInfo,
    canCreatePaidLobbies: currentLevelInfo.canCreatePaidLobbies,
    canCreateTournaments: currentLevelInfo.canCreateTournaments,
    canCreateClans: currentLevelInfo.canCreateClans
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within UserProvider');
  }
  return context;
}

// Utility functions
export function getUserLevelBadge(level: UserLevel): string {
  const levelEmojis = {
    player: '👤',
    host: '👑', 
    manager: '💎'
  };
  return levelEmojis[level];
}

export function getRequiredXPForNextLevel(level: UserLevel): number {
  const xpRequirements = {
    player: 1000,
    host: 5000,
    manager: 15000
  };
  return xpRequirements[level];
}

export function canUpgradeToLevel(currentXP: number, targetLevel: UserLevel): boolean {
  return currentXP >= getRequiredXPForNextLevel(targetLevel);
}