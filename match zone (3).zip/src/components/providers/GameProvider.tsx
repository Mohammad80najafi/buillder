/**
 * Matchzone Game Provider
 * Centralized game definitions and platform management
 */

import React, { createContext, useContext } from 'react';

// Game platform types
export type GamePlatform = 'desktop' | 'mobile';

// Game definition interface
export interface GameDefinition {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  bgColor: string;
  emoji: string;
  platform: GamePlatform;
  isTournamentGame: boolean;
  gameModes: Record<string, GameModeDefinition>;
  maps: Record<string, MapDefinition[]>;
}

export interface GameModeDefinition {
  name: string;
  description: string;
  icon: string;
  teamSize: string;
  maxRounds: number;
  roundTime: number;
  color: string;
  bgColor: string;
  players: number;
}

export interface MapDefinition {
  id: string;
  name: string;
  description: string;
  emoji: string;
}

// Desktop Games Configuration
export const DESKTOP_GAMES: Record<string, GameDefinition> = {
  cs2: {
    id: 'cs2',
    name: 'Counter-Strike 2',
    description: 'بازی تیمی تاکتیکی FPS',
    icon: 'Target',
    color: 'text-orange-400',
    bgColor: 'bg-orange-400/10',
    emoji: '🔫',
    platform: 'desktop',
    isTournamentGame: true,
    gameModes: {
      competitive: {
        name: 'رقابتی',
        description: 'فرمت استاندارد جهانی Esports',
        icon: 'Trophy',
        teamSize: '5v5',
        maxRounds: 24,
        roundTime: 115,
        color: 'text-yellow-400',
        bgColor: 'bg-yellow-400/10',
        players: 10
      },
      wingman: {
        name: 'وینگمن',
        description: 'سریع و محبوب برای کلن‌های کوچک',
        icon: 'Target',
        teamSize: '2v2',
        maxRounds: 16,
        roundTime: 90,
        color: 'text-blue-400',
        bgColor: 'bg-blue-400/10',
        players: 4
      }
    },
    maps: {
      competitive: [
        { id: 'de_mirage', name: 'Mirage', description: 'پرمحبوب‌ترین، همیشه در لیست', emoji: '🏜️' },
        { id: 'de_inferno', name: 'Inferno', description: 'خیلی بالانس و کلاسیک', emoji: '🔥' },
        { id: 'de_nuke', name: 'Nuke', description: 'برای تیم‌های حرفه‌ای', emoji: '☢️' }
      ],
      wingman: [
        { id: 'de_shortdust', name: 'Short Dust', description: 'نسخه کوچک Dust2', emoji: '🏜️' },
        { id: 'de_inferno_2v2', name: 'Inferno (2v2)', description: 'نسخه کوچک Inferno', emoji: '🔥' }
      ]
    }
  },
  valorant: {
    id: 'valorant',
    name: 'Valorant',
    description: 'بازی تیمی تاکتیکی با قابلیت‌های خاص',
    icon: 'Zap',
    color: 'text-red-400',
    bgColor: 'bg-red-400/10',
    emoji: '⚡',
    platform: 'desktop',
    isTournamentGame: false,
    gameModes: {
      unrated: {
        name: 'Unrated',
        description: 'حالت عادی و تمرینی',
        icon: 'Users',
        teamSize: '5v5',
        maxRounds: 24,
        roundTime: 100,
        color: 'text-green-400',
        bgColor: 'bg-green-400/10',
        players: 10
      }
    },
    maps: {
      unrated: [
        { id: 'bind', name: 'Bind', description: 'مپ کلاسیک Valorant', emoji: '🌊' },
        { id: 'haven', name: 'Haven', description: 'مپ 3 site', emoji: '🏛️' }
      ]
    }
  },
  lol: {
    id: 'lol',
    name: 'League of Legends',
    description: 'بازی MOBA استراتژیک',
    icon: 'Sword',
    color: 'text-purple-400',
    bgColor: 'bg-purple-400/10',
    emoji: '⚔️',
    platform: 'desktop',
    isTournamentGame: false,
    gameModes: {
      summoners_rift: {
        name: 'Summoner\'s Rift',
        description: 'مپ اصلی LoL',
        icon: 'Sword',
        teamSize: '5v5',
        maxRounds: 1,
        roundTime: 2400,
        color: 'text-purple-400',
        bgColor: 'bg-purple-400/10',
        players: 10
      }
    },
    maps: {
      summoners_rift: [
        { id: 'sr_classic', name: 'Summoner\'s Rift', description: 'مپ کلاسیک LoL', emoji: '🏰' }
      ]
    }
  },
  rocket_league: {
    id: 'rocket_league',
    name: 'Rocket League',
    description: 'فوتبال با ماشین‌های پرنده',
    icon: 'Users',
    color: 'text-green-400',
    bgColor: 'bg-green-400/10',
    emoji: '🚗',
    platform: 'desktop',
    isTournamentGame: false,
    gameModes: {
      standard: {
        name: 'Standard',
        description: 'حالت استاندارد 3v3',
        icon: 'Users',
        teamSize: '3v3',
        maxRounds: 1,
        roundTime: 300,
        color: 'text-green-400',
        bgColor: 'bg-green-400/10',
        players: 6
      }
    },
    maps: {
      standard: [
        { id: 'urban_central', name: 'Urban Central', description: 'مپ کلاسیک Rocket League', emoji: '🏟️' }
      ]
    }
  }
};

// Mobile Games Configuration
export const MOBILE_GAMES: Record<string, GameDefinition> = {
  pubg_mobile: {
    id: 'pubg_mobile',
    name: 'PUBG Mobile',
    description: 'بازی بتل رویال موبایل',
    icon: 'Target',
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-400/10',
    emoji: '📱',
    platform: 'mobile',
    isTournamentGame: true,
    gameModes: {
      squad: {
        name: 'Squad',
        description: 'تیم 4 نفره',
        icon: 'Users',
        teamSize: '4-Squad',
        maxRounds: 1,
        roundTime: 1500,
        color: 'text-blue-400',
        bgColor: 'bg-blue-400/10',
        players: 4
      }
    },
    maps: {
      squad: [
        { id: 'erangel', name: 'Erangel', description: 'مپ کلاسیک PUBG', emoji: '🏝️' }
      ]
    }
  },
  cod_mobile: {
    id: 'cod_mobile',
    name: 'Call of Duty Mobile',
    description: 'بازی FPS موبایل',
    icon: 'Target',
    color: 'text-red-400',
    bgColor: 'bg-red-400/10',
    emoji: '🎯',
    platform: 'mobile',
    isTournamentGame: true,
    gameModes: {
      battle_royale: {
        name: 'Battle Royale',
        description: 'حالت بتل رویال',
        icon: 'Target',
        teamSize: '4-Squad',
        maxRounds: 1,
        roundTime: 1200,
        color: 'text-red-400',
        bgColor: 'bg-red-400/10',
        players: 4
      }
    },
    maps: {
      battle_royale: [
        { id: 'blackout', name: 'Blackout', description: 'مپ اصلی COD Mobile', emoji: '🗺️' }
      ]
    }
  },
  fifa_mobile: {
    id: 'fifa_mobile',
    name: 'FIFA Mobile',
    description: 'فوتبال موبایل',
    icon: 'Trophy',
    color: 'text-green-400',
    bgColor: 'bg-green-400/10',
    emoji: '⚽',
    platform: 'mobile',
    isTournamentGame: true,
    gameModes: {
      quick_match: {
        name: 'مسابقه سریع',
        description: 'بازی 11 در برابر 11',
        icon: 'Trophy',
        teamSize: '1v1',
        maxRounds: 1,
        roundTime: 600,
        color: 'text-green-400',
        bgColor: 'bg-green-400/10',
        players: 2
      }
    },
    maps: {
      quick_match: [
        { id: 'camp_nou', name: 'Camp Nou', description: 'ورزشگاه بارسلونا', emoji: '🏟️' }
      ]
    }
  },
  fortnite: {
    id: 'fortnite',
    name: 'Fortnite Mobile',
    description: 'بازی بتل رویال موبایل',
    icon: 'Trophy',
    color: 'text-blue-400',
    bgColor: 'bg-blue-400/10',
    emoji: '🏆',
    platform: 'mobile',
    isTournamentGame: false,
    gameModes: {
      squad: {
        name: 'Squad',
        description: 'تیم 4 نفره',
        icon: 'Users',
        teamSize: '4-Squad',
        maxRounds: 1,
        roundTime: 1500,
        color: 'text-blue-400',
        bgColor: 'bg-blue-400/10',
        players: 4
      }
    },
    maps: {
      squad: [
        { id: 'battle_royale', name: 'Battle Royale', description: 'مپ اصلی فورتنایت', emoji: '🏝️' }
      ]
    }
  }
};

// Combined games object
export const ALL_GAMES = { ...DESKTOP_GAMES, ...MOBILE_GAMES };

// Game context interface
interface GameContextType {
  // Games collections
  desktopGames: Record<string, GameDefinition>;
  mobileGames: Record<string, GameDefinition>;
  allGames: Record<string, GameDefinition>;
  tournamentGames: Record<string, GameDefinition>;
  
  // Utility functions
  getGame: (gameId: string) => GameDefinition | undefined;
  getGamesByPlatform: (platform: GamePlatform) => Record<string, GameDefinition>;
  getTournamentGames: () => Record<string, GameDefinition>;
  getGameModes: (gameId: string) => Record<string, GameModeDefinition>;
  getMaps: (gameId: string, gameMode: string) => MapDefinition[];
}

const GameContext = createContext<GameContextType | null>(null);

interface GameProviderProps {
  children: React.ReactNode;
}

export function GameProvider({ children }: GameProviderProps) {
  const getGame = (gameId: string): GameDefinition | undefined => {
    return ALL_GAMES[gameId];
  };

  const getGamesByPlatform = (platform: GamePlatform): Record<string, GameDefinition> => {
    return platform === 'desktop' ? DESKTOP_GAMES : MOBILE_GAMES;
  };

  const getTournamentGames = (): Record<string, GameDefinition> => {
    return Object.fromEntries(
      Object.entries(ALL_GAMES).filter(([_, game]) => game.isTournamentGame)
    );
  };

  const getGameModes = (gameId: string): Record<string, GameModeDefinition> => {
    const game = getGame(gameId);
    return game?.gameModes || {};
  };

  const getMaps = (gameId: string, gameMode: string): MapDefinition[] => {
    const game = getGame(gameId);
    return game?.maps[gameMode] || [];
  };

  const value: GameContextType = {
    // Games collections
    desktopGames: DESKTOP_GAMES,
    mobileGames: MOBILE_GAMES,
    allGames: ALL_GAMES,
    tournamentGames: getTournamentGames(),
    
    // Utility functions
    getGame,
    getGamesByPlatform,
    getTournamentGames,
    getGameModes,
    getMaps
  };

  return (
    <GameContext.Provider value={value}>
      {children}
    </GameContext.Provider>
  );
}

export function useGames() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGames must be used within GameProvider');
  }
  return context;
}

// Utility functions for game-related operations
export function getGamePlatformIcon(platform: GamePlatform): string {
  return platform === 'desktop' ? 'Monitor' : 'Smartphone';
}

export function getGameLevelRequirement(gameId: string): number {
  // Tournament games require higher level
  const game = ALL_GAMES[gameId];
  return game?.isTournamentGame ? 10 : 1;
}

export function formatGameDuration(minutes: number): string {
  if (minutes < 60) {
    return `${minutes} دقیقه`;
  }
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return remainingMinutes > 0 ? `${hours}س ${remainingMinutes}د` : `${hours} ساعت`;
}