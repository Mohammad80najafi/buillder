import React, { createContext, useContext, useState, useCallback } from 'react';
import { ClanCreationData } from '../clans/ClanCreation';
import { toast } from 'sonner@2.0.3';

export interface ClanMember {
  name: string;
  avatar?: string;
  level: number;
}

export interface Clan {
  id: string;
  name: string;
  tag: string;
  description: string;
  logo?: string;
  banner?: string;
  level: number;
  xp: number;
  maxXp: number;
  members: { current: number; max: number };
  leader: ClanMember;
  officers: ClanMember[];
  type: 'public' | 'private' | 'invite-only';
  requirements: {
    minLevel: number;
    minTrophies?: number;
    minAge?: number;
    region?: string;
  };
  stats: {
    wins: number;
    losses: number;
    winRate: number;
    totalTrophies: number;
    rank: number;
    weeklyXp: number;
  };
  activities: {
    activeMembers: number;
    lastActive: string;
    weeklyMatches: number;
  };
  achievements: string[];
  region: string;
  language?: string;
  gameTypes: string[];
  joinedDate?: string;
  isJoined: boolean;
  createdByUser?: boolean; // Flag برای کلن‌های ایجاد شده توسط کاربر
}

export interface ClanChat {
  id: string;
  clanId: string;
  clanName: string;
  clanLogo?: string;
  clanTag: string;
  lastMessage?: {
    content: string;
    timestamp: string;
    senderName: string;
  };
  unreadCount: number;
  isActive: boolean;
  joinedAt: string;
}

interface ClanContextType {
  clans: Clan[];
  userClans: Clan[];
  clanChats: ClanChat[];
  addClan: (clanData: ClanCreationData, userId: string) => Clan;
  joinClan: (clanId: string) => void;
  leaveClan: (clanId: string) => void;
  getUserClan: () => Clan | undefined;
  addClanChat: (clan: Clan) => void;
  removeClanChat: (clanId: string) => void;
  updateClanChatLastMessage: (clanId: string, message: any) => void;
  markClanChatAsRead: (clanId: string) => void;
}

const ClanContext = createContext<ClanContextType | null>(null);

// Mock initial clans data
const initialClans: Clan[] = [
  {
    id: 'clan-1',
    name: 'امپراطوری پارس',
    tag: 'IRAN',
    description: 'بهترین کلن ایرانی با تمرکز بر تورنومنت‌ها و رقابت‌های حرفه‌ای',
    logo: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=64',
    banner: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800',
    level: 47,
    xp: 85000,
    maxXp: 100000,
    members: { current: 48, max: 50 },
    leader: {
      name: 'کوروش_کبیر',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=64',
      level: 89
    },
    officers: [
      { name: 'داریوش_بزرگ', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64', level: 76 },
      { name: 'رستم_زال', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64', level: 72 }
    ],
    type: 'invite-only',
    requirements: {
      minLevel: 30,
      minTrophies: 2000,
      region: 'ایران'
    },
    stats: {
      wins: 245,
      losses: 32,
      winRate: 88,
      totalTrophies: 125000,
      rank: 3,
      weeklyXp: 15000
    },
    activities: {
      activeMembers: 42,
      lastActive: '5 دقیقه پیش',
      weeklyMatches: 78
    },
    achievements: ['برنده کاپ طلایی', 'بهترین کلن ماه', 'رکورد پیروزی پیاپی'],
    region: 'ایران',
    language: 'فارسی',
    gameTypes: ['کالاف دیوتی', 'والورانت', 'فیفا 24'],
    joinedDate: '۱۴۰۲/۰۵/۱۲',
    isJoined: false
  },
  {
    id: 'clan-2',
    name: 'شیرهای طلایی',
    tag: 'GOLD',
    description: 'کلن دوستانه برای بازیکنان حرفه‌ای و نیمه‌حرفه‌ای',
    logo: 'https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=64',
    level: 32,
    xp: 45000,
    maxXp: 60000,
    members: { current: 35, max: 40 },
    leader: {
      name: 'شیر_طلایی',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
      level: 67
    },
    officers: [
      { name: 'عقاب_سیاه', level: 54 }
    ],
    type: 'public',
    requirements: {
      minLevel: 15,
      minTrophies: 800
    },
    stats: {
      wins: 156,
      losses: 48,
      winRate: 76,
      totalTrophies: 78000,
      rank: 12,
      weeklyXp: 8500
    },
    activities: {
      activeMembers: 28,
      lastActive: '1 ساعت پیش',
      weeklyMatches: 45
    },
    achievements: ['کلن پرفعالیت'],
    region: 'تهران',
    gameTypes: ['کالاف دیوتی', 'فیفا 24', 'لیگ آف لجندز'],
    isJoined: false
  },
  {
    id: 'clan-3',
    name: 'گیمرهای آزاد',
    tag: 'FREE',
    description: 'کلن باز برای همه بازیکنان که دوست دارند با هم بازی کنند',
    level: 18,
    xp: 12000,
    maxXp: 25000,
    members: { current: 22, max: 30 },
    leader: {
      name: 'آزاد_گیمر',
      level: 42
    },
    officers: [],
    type: 'public',
    requirements: {
      minLevel: 5,
      minTrophies: 100
    },
    stats: {
      wins: 89,
      losses: 67,
      winRate: 57,
      totalTrophies: 32000,
      rank: 45,
      weeklyXp: 3200
    },
    activities: {
      activeMembers: 18,
      lastActive: '3 ساعت پیش',
      weeklyMatches: 28
    },
    achievements: [],
    region: 'اصفهان',
    gameTypes: ['همه بازی‌ها'],
    isJoined: false
  }
];

interface ClanProviderProps {
  children: React.ReactNode;
}

export function ClanProvider({ children }: ClanProviderProps) {
  const [clans, setClans] = useState<Clan[]>(initialClans);
  const [clanChats, setClanChats] = useState<ClanChat[]>([]);

  const addClan = useCallback((clanData: ClanCreationData, userId: string): Clan => {
    const newClan: Clan = {
      id: `user-clan-${Date.now()}`,
      name: clanData.name,
      tag: clanData.tag,
      description: clanData.description,
      logo: clanData.logo ? URL.createObjectURL(clanData.logo) : undefined,
      banner: clanData.banner ? URL.createObjectURL(clanData.banner) : undefined,
      level: 1,
      xp: 0,
      maxXp: 1000,
      members: { current: 1, max: 50 },
      leader: {
        name: 'شما', // نام کاربر واقعی باید از context آمده باشد
        level: 25 // سطح کاربر واقعی
      },
      officers: [],
      type: clanData.type,
      requirements: {
        minLevel: clanData.requirements.minLevel,
        minTrophies: 0,
        minAge: clanData.requirements.minAge,
        region: clanData.region
      },
      stats: {
        wins: 0,
        losses: 0,
        winRate: 0,
        totalTrophies: 0,
        rank: 999, // کلن جدید در انتها
        weeklyXp: 0
      },
      activities: {
        activeMembers: 1,
        lastActive: 'الان',
        weeklyMatches: 0
      },
      achievements: [],
      region: clanData.region,
      gameTypes: clanData.gameTypes,
      joinedDate: new Date().toLocaleDateString('fa-IR'),
      isJoined: true,
      createdByUser: true
    };

    setClans(prev => [newClan, ...prev]); // کلن جدید در ابتدای لیست
    return newClan;
  }, []);

  const joinClan = useCallback((clanId: string) => {
    setClans(prev => prev.map(clan => 
      clan.id === clanId 
        ? { 
            ...clan, 
            isJoined: true,
            members: { 
              ...clan.members, 
              current: clan.members.current + 1 
            }
          }
        : clan
    ));

    // اضافه کردن چت کلن به لیست چت‌های کاربر
    const joinedClan = clans.find(clan => clan.id === clanId);
    if (joinedClan) {
      addClanChat(joinedClan);
      toast.success(`به چت کلن ${joinedClan.name} اضافه شدید!`, {
        description: 'حالا می‌تونید با اعضای کلن چت کنید'
      });
    }
  }, [clans]);

  const leaveClan = useCallback((clanId: string) => {
    const leavingClan = clans.find(clan => clan.id === clanId);
    
    setClans(prev => prev.map(clan => 
      clan.id === clanId 
        ? { 
            ...clan, 
            isJoined: false,
            members: { 
              ...clan.members, 
              current: Math.max(1, clan.members.current - 1)
            }
          }
        : clan
    ));

    // حذف چت کلن از لیست چت‌های کاربر
    removeClanChat(clanId);
    
    if (leavingClan) {
      toast.info(`از کلن ${leavingClan.name} خارج شدید`, {
        description: 'چت کلن از لیست چت‌های شما حذف شد'
      });
    }
  }, [clans]);

  const getUserClan = useCallback(() => {
    return clans.find(clan => clan.isJoined);
  }, [clans]);

  const addClanChat = useCallback((clan: Clan) => {
    const existingChat = clanChats.find(chat => chat.clanId === clan.id);
    if (existingChat) return; // چت قبلاً اضافه شده

    const newClanChat: ClanChat = {
      id: `clan-chat-${clan.id}`,
      clanId: clan.id,
      clanName: clan.name,
      clanLogo: clan.logo,
      clanTag: clan.tag,
      lastMessage: {
        content: `به کلن ${clan.name} خوش آمدید!`,
        timestamp: 'الان',
        senderName: 'سیستم'
      },
      unreadCount: 1,
      isActive: true,
      joinedAt: new Date().toISOString()
    };

    setClanChats(prev => [newClanChat, ...prev]);
  }, [clanChats]);

  const removeClanChat = useCallback((clanId: string) => {
    setClanChats(prev => prev.filter(chat => chat.clanId !== clanId));
  }, []);

  const updateClanChatLastMessage = useCallback((clanId: string, message: any) => {
    setClanChats(prev => prev.map(chat => 
      chat.clanId === clanId 
        ? {
            ...chat,
            lastMessage: {
              content: message.content,
              timestamp: message.timestamp,
              senderName: message.senderName
            },
            unreadCount: chat.unreadCount + 1
          }
        : chat
    ));
  }, []);

  const markClanChatAsRead = useCallback((clanId: string) => {
    setClanChats(prev => prev.map(chat => 
      chat.clanId === clanId 
        ? { ...chat, unreadCount: 0 }
        : chat
    ));
  }, []);

  const userClans = clans.filter(clan => clan.isJoined);

  const value: ClanContextType = {
    clans,
    userClans,
    clanChats,
    addClan,
    joinClan,
    leaveClan,
    getUserClan,
    addClanChat,
    removeClanChat,
    updateClanChatLastMessage,
    markClanChatAsRead
  };

  return (
    <ClanContext.Provider value={value}>
      {children}
    </ClanContext.Provider>
  );
}

export function useClan() {
  const context = useContext(ClanContext);
  if (!context) {
    throw new Error('useClan must be used within ClanProvider');
  }
  return context;
}