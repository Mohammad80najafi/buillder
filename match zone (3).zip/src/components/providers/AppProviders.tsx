/**
 * Matchzone App Providers
 * Centralized provider composition for the entire app
 */

import React from 'react';
import { NotificationProvider } from '../system/NotificationService';
import { NavigationProvider } from '../navigation/NavigationProvider';
import { LobbyProvider } from '../gaming/LobbyContext';
import { UserProvider } from './UserProvider';
import { GameProvider } from './GameProvider';
import { ClanProvider } from './ClanProvider';

interface AppProvidersProps {
  children: React.ReactNode;
}

export function AppProviders({ children }: AppProvidersProps) {
  return (
    <UserProvider initialLevel="player">
      <GameProvider>
        <NavigationProvider initialPage="home" initialAuth={true}>
          <NotificationProvider>
            <ClanProvider>
              <LobbyProvider>
                {children}
              </LobbyProvider>
            </ClanProvider>
          </NotificationProvider>
        </NavigationProvider>
      </GameProvider>
    </UserProvider>
  );
}

export default AppProviders;