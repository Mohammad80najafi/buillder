/**
 * Matchzone Auth Guard
 * Authentication wrapper component
 */

import React from 'react';
import { AuthPage } from '../pages/AuthPage';
import { useNavigation } from '../navigation/NavigationProvider';
import { pageMetadata } from '../layout/PageRenderer';

interface AuthGuardProps {
  children: React.ReactNode;
}

export function AuthGuard({ children }: AuthGuardProps) {
  const { isAuthenticated, currentPage, authenticate } = useNavigation();

  // Check if current page requires authentication
  const requiresAuth = pageMetadata[currentPage]?.requiresAuth || false;

  // If not authenticated and page requires auth, show auth page
  if (!isAuthenticated && requiresAuth) {
    return <AuthPage onAuth={authenticate} />;
  }

  // If not authenticated but on auth page, show auth page
  if (!isAuthenticated && currentPage === 'auth') {
    return <AuthPage onAuth={authenticate} />;
  }

  // Show children (app content) if authenticated or page doesn't require auth
  return <>{children}</>;
}

export default AuthGuard;