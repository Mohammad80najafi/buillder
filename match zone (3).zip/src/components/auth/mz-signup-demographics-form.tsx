import React, { useState } from 'react';
import { Calendar, User, Shield, Eye, EyeOff } from 'lucide-react';
import { cn } from '../ui/utils';
import { Button } from '../ui/mz-button';
import { Input } from '../ui/mz-input';
import { Label } from '../ui/label';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { Switch } from '../ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

export interface SignupDemographicsFormProps {
  gender?: 'female' | 'male' | 'prefer_not' | 'custom';
  genderCustom?: string;
  birthDate?: string; // ISO Date
  privacy?: {
    showGender: boolean;
    showAge: boolean;
  };
  minAge?: number;
  onSubmit: (data: {
    gender: 'female' | 'male' | 'prefer_not' | 'custom';
    genderCustom?: string;
    birthDate: string;
    privacy: {
      showGender: boolean;
      showAge: boolean;
    };
  }) => void;
  onBack?: () => void;
  isLoading?: boolean;
  className?: string;
}

const SignupDemographicsForm = React.forwardRef<HTMLDivElement, SignupDemographicsFormProps>(
  ({
    gender = 'prefer_not',
    genderCustom = '',
    birthDate = '',
    privacy = { showGender: false, showAge: false },
    minAge = 13,
    onSubmit,
    onBack,
    isLoading = false,
    className,
    ...props
  }, ref) => {
    const [formData, setFormData] = useState({
      gender,
      genderCustom,
      birthDate,
      privacy
    });
    
    const [errors, setErrors] = useState<Record<string, string>>({});

    const validateForm = () => {
      const newErrors: Record<string, string> = {};
      
      // Validate birth date
      if (!formData.birthDate) {
        newErrors.birthDate = 'تاریخ تولد الزامی است';
      } else {
        const birthYear = new Date(formData.birthDate).getFullYear();
        const currentYear = new Date().getFullYear();
        const age = currentYear - birthYear;
        
        if (age < minAge) {
          newErrors.birthDate = `حداقل سن برای ثبت‌نام ${minAge} سال است`;
        }
      }
      
      // Validate custom gender
      if (formData.gender === 'custom' && !formData.genderCustom.trim()) {
        newErrors.genderCustom = 'لطفاً جنسیت خود را مشخص کنید';
      }
      
      setErrors(newErrors);
      return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      
      if (validateForm()) {
        onSubmit(formData);
      }
    };

    const calculateAge = (birthDate: string) => {
      if (!birthDate) return 0;
      const today = new Date();
      const birth = new Date(birthDate);
      let age = today.getFullYear() - birth.getFullYear();
      const monthDiff = today.getMonth() - birth.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
      }
      
      return age;
    };

    const formatPersianDate = (dateString: string) => {
      if (!dateString) return '';
      
      const date = new Date(dateString);
      const persianMonths = [
        'فروردین', 'اردیبهشت', 'خردad', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
      ];
      
      // This is a simplified conversion - in real app use proper Persian calendar library
      return `${date.getDate()} ${persianMonths[date.getMonth()]} ${date.getFullYear()}`;
    };

    return (
      <div ref={ref} className={cn("max-w-md mx-auto", className)} dir="rtl" {...props}>
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-12 h-12 bg-brand-primary/10 rounded-full flex items-center justify-center">
              <User className="h-6 w-6 text-brand-primary" />
            </div>
            
            <CardTitle className="text-xl">تکمیل اطلاعات</CardTitle>
            <CardDescription>
              برای ارائه تجربه بهتر، لطفاً اطلاعات زیر را تکمیل کنید
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Gender Selection */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">جنسیت</Label>
                
                <RadioGroup
                  value={formData.gender}
                  onValueChange={(value: 'female' | 'male' | 'prefer_not' | 'custom') => 
                    setFormData(prev => ({ ...prev, gender: value }))
                  }
                >
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <RadioGroupItem value="female" id="female" />
                    <Label htmlFor="female" className="font-normal">زن</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <RadioGroupItem value="male" id="male" />
                    <Label htmlFor="male" className="font-normal">مرد</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <RadioGroupItem value="prefer_not" id="prefer_not" />
                    <Label htmlFor="prefer_not" className="font-normal">ترجیح می‌دهم نگویم</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <RadioGroupItem value="custom" id="custom" />
                    <Label htmlFor="custom" className="font-normal">سایر</Label>
                  </div>
                </RadioGroup>
                
                {/* Custom Gender Input */}
                {formData.gender === 'custom' && (
                  <Input
                    placeholder="جنسیت خود را مشخص کنید"
                    value={formData.genderCustom}
                    onChange={(e) => setFormData(prev => ({ 
                      ...prev, 
                      genderCustom: e.target.value 
                    }))}
                    errorText={errors.genderCustom}
                  />
                )}
              </div>

              {/* Birth Date */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">تاریخ تولد</Label>
                
                <Input
                  type="date"
                  value={formData.birthDate}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    birthDate: e.target.value 
                  }))}
                  leftIcon={<Calendar className="h-4 w-4" />}
                  errorText={errors.birthDate}
                  max={new Date().toISOString().split('T')[0]}
                />
                
                {formData.birthDate && (
                  <div className="text-sm text-text-secondary">
                    سن شما: {calculateAge(formData.birthDate)} سال
                    {/* <span className="mr-2">({formatPersianDate(formData.birthDate)})</span> */}
                  </div>
                )}
              </div>

              {/* Privacy Settings */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-brand-primary" />
                  <Label className="text-sm font-medium">تنظیمات حریم خصوصی</Label>
                </div>
                
                <div className="space-y-3 bg-surface-secondary rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <Label className="text-sm font-medium">نمایش جنسیت در پروفایل</Label>
                      <p className="text-xs text-text-secondary mt-1">
                        سایر کاربران جنسیت شما را خواهند دید
                      </p>
                    </div>
                    
                    <Switch
                      checked={formData.privacy.showGender}
                      onCheckedChange={(checked) => 
                        setFormData(prev => ({
                          ...prev,
                          privacy: { ...prev.privacy, showGender: checked }
                        }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <Label className="text-sm font-medium">نمایش سن در پروفایل</Label>
                      <p className="text-xs text-text-secondary mt-1">
                        سایر کاربران سن شما را خواهند دید
                      </p>
                    </div>
                    
                    <Switch
                      checked={formData.privacy.showAge}
                      onCheckedChange={(checked) => 
                        setFormData(prev => ({
                          ...prev,
                          privacy: { ...prev.privacy, showAge: checked }
                        }))
                      }
                    />
                  </div>
                  
                  <div className="mt-3 p-3 bg-surface-primary rounded border border-border-secondary">
                    <div className="flex items-start gap-2">
                      <Eye className="h-4 w-4 text-text-secondary mt-0.5 flex-shrink-0" />
                      <div className="text-xs text-text-secondary">
                        <p className="font-medium mb-1">نکته حریم خصوصی:</p>
                        <p>
                          این اطلاعات صرفاً برای بهبود تجربه شما استفاده می‌شود. 
                          می‌توانید هر زمان تنظیمات حریم خصوصی خود را تغییر دهید.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Buttons */}
              <div className="flex gap-3 pt-4">
                {onBack && (
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={onBack}
                    className="flex-1"
                    disabled={isLoading}
                  >
                    قبلی
                  </Button>
                )}
                
                <Button
                  type="submit"
                  className="flex-1"
                  loading={isLoading}
                >
                  ادامه
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }
);

SignupDemographicsForm.displayName = "SignupDemographicsForm";

export { SignupDemographicsForm };