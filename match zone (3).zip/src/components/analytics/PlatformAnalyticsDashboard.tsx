/**
 * Platform Analytics Dashboard - مرحله 4 سیستم طراحی
 * داشبورد آنالیز جامع پلتفرم با نمودارهای تعاملی و گزارشات پیشرفته
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { 
  BarChart3, TrendingUp, TrendingDown, Users, Trophy, DollarSign,
  Eye, Clock, Target, Star, Zap, Globe, Calendar, Activity,
  Award, Shield, Flag, Crown, Gamepad2, MessageSquare,
  Download, Share2, RefreshCw, Filter, ArrowUp, ArrowDown,
  Percent, Hash, ArrowRight, PieChart, LineChart,
  AreaChart, BarChart, Activity as ActivityIcon, AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LineChart as RechartsLineChart,
  AreaChart as RechartsAreaChart,
  BarChart as RechartsBarChart,
  PieChart as RechartsPieChart,
  RadialBarChart,
  ComposedChart,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  Bar,
  Line,
  Pie,
  RadialBar,
  ReferenceLine,
  Funnel,
  FunnelChart
} from 'recharts';

export interface PlatformMetrics {
  // User Metrics
  totalUsers: number;
  activeUsers: number;
  newUsersToday: number;
  userGrowthRate: number;
  retentionRate: number;
  averageSessionTime: number; // minutes
  
  // Tournament Metrics
  totalTournaments: number;
  activeTournaments: number;
  tournamentsToday: number;
  tournamentGrowthRate: number;
  averageParticipants: number;
  completionRate: number;
  
  // Financial Metrics
  totalRevenue: number;
  revenueToday: number;
  revenueGrowthRate: number;
  averageTransactionValue: number;
  totalPrizesAwarded: number;
  profitMargin: number;
  
  // Engagement Metrics
  totalViews: number;
  viewsToday: number;
  viewGrowthRate: number;
  averageViewDuration: number; // minutes
  chatMessages: number;
  socialShares: number;
  
  // Performance Metrics
  platformUptime: number; // percentage
  averageResponseTime: number; // ms
  errorRate: number; // percentage
  customerSatisfaction: number; // 1-5 scale
  supportTickets: number;
  resolvedTickets: number;
  
  // Quality Metrics
  gameQualityScore: number; // 1-10
  streamQualityScore: number; // 1-10
  userExperienceScore: number; // 1-10
  securityScore: number; // 1-10
  
  // Last updated
  lastUpdated: string;
}

export interface ChartData {
  userActivity: { date: string; activeUsers: number; newUsers: number; sessions: number }[];
  tournamentStats: { date: string; tournaments: number; participants: number; revenue: number }[];
  revenueBreakdown: { category: string; value: number; color: string }[];
  engagementMetrics: { metric: string; value: number; target: number; color: string }[];
  geographicData: { region: string; users: number; tournaments: number; revenue: number }[];
  gamePopularity: { game: string; tournaments: number; participants: number; revenue: number }[];
  userFunnel: { stage: string; users: number; conversion: number }[];
  performanceMetrics: { time: string; responseTime: number; uptime: number; errors: number }[];
}

// Mock data
const MOCK_PLATFORM_METRICS: PlatformMetrics = {
  totalUsers: 125483,
  activeUsers: 23847,
  newUsersToday: 342,
  userGrowthRate: 23.5,
  retentionRate: 68.2,
  averageSessionTime: 47,
  
  totalTournaments: 8924,
  activeTournaments: 47,
  tournamentsToday: 12,
  tournamentGrowthRate: 31.2,
  averageParticipants: 64,
  completionRate: 94.7,
  
  totalRevenue: 1847500000,
  revenueToday: 2340000,
  revenueGrowthRate: 42.8,
  averageTransactionValue: 87500,
  totalPrizesAwarded: 987500000,
  profitMargin: 32.4,
  
  totalViews: 3847592,
  viewsToday: 8274,
  viewGrowthRate: 18.9,
  averageViewDuration: 23,
  chatMessages: 847392,
  socialShares: 15847,
  
  platformUptime: 99.97,
  averageResponseTime: 145,
  errorRate: 0.03,
  customerSatisfaction: 4.7,
  supportTickets: 234,
  resolvedTickets: 221,
  
  gameQualityScore: 8.9,
  streamQualityScore: 9.2,
  userExperienceScore: 8.7,
  securityScore: 9.5,
  
  lastUpdated: '2 دقیقه پیش'
};

const MOCK_CHART_DATA: ChartData = {
  userActivity: [
    { date: '۱۴۰۳/۰۹/۰۱', activeUsers: 18500, newUsers: 245, sessions: 23400 },
    { date: '۱۴۰۳/۰۹/۰۲', activeUsers: 19200, newUsers: 312, sessions: 24100 },
    { date: '۱۴۰۳/۰۹/۰۳', activeUsers: 20100, newUsers: 289, sessions: 25300 },
    { date: '۱۴۰۳/۰۹/۰۴', activeUsers: 21800, newUsers: 367, sessions: 27200 },
    { date: '۱۴۰۳/۰۹/۰۵', activeUsers: 22400, newUsers: 423, sessions: 28600 },
    { date: '۱۴۰۳/۰۹/۰۶', activeUsers: 23200, newUsers: 381, sessions: 29100 },
    { date: '۱۴۰۳/۰۹/۰۷', activeUsers: 23847, newUsers: 342, sessions: 30200 }
  ],
  
  tournamentStats: [
    { date: '۱۴۰۳/۰۹/۰۱', tournaments: 8, participants: 487, revenue: 1850000 },
    { date: '۱۴۰۳/۰۹/۰۲', tournaments: 12, participants: 624, revenue: 2340000 },
    { date: '۱۴۰۳/۰۹/۰۳', tournaments: 15, participants: 789, revenue: 2890000 },
    { date: '۱۴۰۳/۰۹/۰۴', tournaments: 18, participants: 943, revenue: 3420000 },
    { date: '۱۴۰۳/۰۹/۰۵', tournaments: 21, participants: 1124, revenue: 4180000 },
    { date: '۱۴۰۳/۰۹/۰۶', tournaments: 19, participants: 1087, revenue: 3950000 },
    { date: '۱۴۰۳/۰۹/۰۷', tournaments: 16, participants: 923, revenue: 3230000 }
  ],
  
  revenueBreakdown: [
    { category: 'ورودی تورنومنت', value: 45, color: '#3B82F6' },
    { category: 'اشتراک پریمیوم', value: 25, color: '#22C55E' },
    { category: 'فروشگاه', value: 15, color: '#FACC15' },
    { category: 'تبلیغات', value: 10, color: '#EF4444' },
    { category: 'سایر', value: 5, color: '#8B5CF6' }
  ],
  
  engagementMetrics: [
    { metric: 'نرخ تعامل', value: 78, target: 80, color: '#3B82F6' },
    { metric: 'زمان جلسه', value: 85, target: 90, color: '#22C55E' },
    { metric: 'بازگشت کاربر', value: 68, target: 75, color: '#FACC15' },
    { metric: 'مشارکت در چت', value: 42, target: 50, color: '#EF4444' },
    { metric: 'اشتراک‌گذاری', value: 35, target: 40, color: '#8B5CF6' }
  ],
  
  geographicData: [
    { region: 'تهران', users: 45823, tournaments: 3247, revenue: 847500000 },
    { region: 'اصفهان', users: 23416, tournaments: 1689, revenue: 423800000 },
    { region: 'شیراز', users: 18574, tournaments: 1324, revenue: 334200000 },
    { region: 'مشهد', users: 21347, tournaments: 1543, revenue: 387600000 },
    { region: 'کرج', users: 16592, tournaments: 1121, revenue: 276500000 }
  ],
  
  gamePopularity: [
    { game: 'کالاف دیوتی', tournaments: 2847, participants: 18943, revenue: 576800000 },
    { game: 'والورانت', tournaments: 1956, participants: 12487, revenue: 398500000 },
    { game: 'فیفا ۲۴', tournaments: 1623, participants: 10234, revenue: 287300000 },
    { game: 'پابجی موبایل', tournaments: 1345, participants: 8976, revenue: 245600000 },
    { game: 'CS:GO', tournaments: 1153, participants: 7865, revenue: 198400000 }
  ],
  
  userFunnel: [
    { stage: 'بازدید سایت', users: 100000, conversion: 100 },
    { stage: 'ثبت‌نام', users: 35000, conversion: 35 },
    { stage: 'تایید ایمیل', users: 28000, conversion: 28 },
    { stage: 'تکمیل پروفایل', users: 22000, conversion: 22 },
    { stage: 'اولین تورنومنت', users: 15000, conversion: 15 },
    { stage: 'کاربر فعال', users: 8000, conversion: 8 }
  ],
  
  performanceMetrics: [
    { time: '00:00', responseTime: 134, uptime: 100, errors: 0 },
    { time: '04:00', responseTime: 142, uptime: 99.98, errors: 1 },
    { time: '08:00', responseTime: 178, uptime: 100, errors: 0 },
    { time: '12:00', responseTime: 195, uptime: 99.95, errors: 2 },
    { time: '16:00', responseTime: 167, uptime: 100, errors: 0 },
    { time: '20:00', responseTime: 156, uptime: 99.99, errors: 0 },
    { time: '23:59', responseTime: 145, uptime: 99.97, errors: 1 }
  ]
};

const CHART_COLORS = ['#3B82F6', '#22C55E', '#FACC15', '#EF4444', '#8B5CF6', '#F97316', '#06B6D4', '#84CC16'];

export interface PlatformAnalyticsDashboardProps {
  metrics?: PlatformMetrics;
  chartData?: ChartData;
  onExport?: (format: 'pdf' | 'excel' | 'csv') => void;
  onRefresh?: () => void;
  autoRefresh?: boolean;
}

export function PlatformAnalyticsDashboard({
  metrics = MOCK_PLATFORM_METRICS,
  chartData = MOCK_CHART_DATA,
  onExport,
  onRefresh,
  autoRefresh = true
}: PlatformAnalyticsDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [dateRange, setDateRange] = useState('7d');
  const [isLoading, setIsLoading] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(new Date());

  // Auto refresh
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      setLastRefresh(new Date());
      onRefresh?.();
    }, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, [autoRefresh, onRefresh]);

  const handleRefresh = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
    setLastRefresh(new Date());
    onRefresh?.();
    setIsLoading(false);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000000) return (num / 1000000000).toFixed(1) + 'B';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const formatCurrency = (amount: number) => {
    return (amount / 1000000).toFixed(1) + 'M تومان';
  };

  const getGrowthColor = (growth: number) => {
    if (growth > 0) return 'text-green-500';
    if (growth < 0) return 'text-red-500';
    return 'text-gray-500';
  };

  const getGrowthIcon = (growth: number) => {
    if (growth > 0) return <TrendingUp className="w-4 h-4" />;
    if (growth < 0) return <TrendingDown className="w-4 h-4" />;
    return <ArrowRight className="w-4 h-4" />;
  };

  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-green-500';
    if (score >= 70) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-500/20 rounded-lg">
                <BarChart3 className="w-8 h-8 text-purple-400" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">آنالیز پلتفرم</h1>
                <p className="text-muted-foreground">
                  داشبورد جامع عملکرد و آمار پلتفرم MatchZone
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1d">امروز</SelectItem>
                  <SelectItem value="7d">7 روز</SelectItem>
                  <SelectItem value="30d">30 روز</SelectItem>
                  <SelectItem value="90d">3 ماه</SelectItem>
                  <SelectItem value="1y">یک سال</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" onClick={handleRefresh} disabled={isLoading}>
                <RefreshCw className={`w-4 h-4 ml-2 ${isLoading ? 'animate-spin' : ''}`} />
                تازه‌سازی
              </Button>
              
              <Select onValueChange={(value) => onExport?.(value as any)}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="خروجی" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="excel">Excel</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Last Updated */}
          <div className="text-sm text-muted-foreground">
            آخرین بروزرسانی: {metrics.lastUpdated} • 
            {autoRefresh ? ' تازه‌سازی خودکار فعال' : ' تازه‌سازی خودکار غیرفعال'}
          </div>
        </CardHeader>
      </Card>

      {/* Platform Health Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className={`text-2xl font-bold ${getHealthColor(metrics.platformUptime)}`}>
              {metrics.platformUptime}%
            </div>
            <div className="text-sm text-muted-foreground">آپتایم پلتفرم</div>
            <div className="text-xs text-green-500 mt-1">
              99.5% هدف
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className={`text-2xl font-bold ${getHealthColor(100 - metrics.errorRate * 100)}`}>
              {metrics.averageResponseTime}ms
            </div>
            <div className="text-sm text-muted-foreground">زمان پاسخ</div>
            <div className="text-xs text-green-500 mt-1">
              هدف: کمتر از 200ms
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className={`text-2xl font-bold ${getHealthColor(metrics.customerSatisfaction * 20)}`}>
              {metrics.customerSatisfaction}/5
            </div>
            <div className="text-sm text-muted-foreground">رضایت کاربران</div>
            <div className="text-xs text-green-500 mt-1">
              هدف: بالای 4.5
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className={`text-2xl font-bold ${getHealthColor(metrics.securityScore * 10)}`}>
              {metrics.securityScore}/10
            </div>
            <div className="text-sm text-muted-foreground">امنیت پلتفرم</div>
            <div className="text-xs text-green-500 mt-1">
              عالی
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-500">
              {Math.round((metrics.resolvedTickets / metrics.supportTickets) * 100)}%
            </div>
            <div className="text-sm text-muted-foreground">حل تیکت</div>
            <div className="text-xs text-muted-foreground mt-1">
              {metrics.resolvedTickets}/{metrics.supportTickets}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">نمای کلی</TabsTrigger>
          <TabsTrigger value="users">کاربران</TabsTrigger>
          <TabsTrigger value="tournaments">تورنومنت‌ها</TabsTrigger>
          <TabsTrigger value="financial">مالی</TabsTrigger>
          <TabsTrigger value="engagement">تعامل</TabsTrigger>
          <TabsTrigger value="performance">عملکرد</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-blue-500">
                        {formatNumber(metrics.totalUsers)}
                      </div>
                      <div className="text-sm text-muted-foreground">کل کاربران</div>
                    </div>
                    <Users className="w-8 h-8 text-blue-500" />
                  </div>
                  <div className={`text-xs flex items-center gap-1 mt-2 ${getGrowthColor(metrics.userGrowthRate)}`}>
                    {getGrowthIcon(metrics.userGrowthRate)}
                    {Math.abs(metrics.userGrowthRate)}% این ماه
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-green-500">
                        {formatNumber(metrics.totalTournaments)}
                      </div>
                      <div className="text-sm text-muted-foreground">کل تورنومنت‌ها</div>
                    </div>
                    <Trophy className="w-8 h-8 text-green-500" />
                  </div>
                  <div className={`text-xs flex items-center gap-1 mt-2 ${getGrowthColor(metrics.tournamentGrowthRate)}`}>
                    {getGrowthIcon(metrics.tournamentGrowthRate)}
                    {Math.abs(metrics.tournamentGrowthRate)}% این ماه
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-yellow-500">
                        {formatCurrency(metrics.totalRevenue)}
                      </div>
                      <div className="text-sm text-muted-foreground">کل درآمد</div>
                    </div>
                    <DollarSign className="w-8 h-8 text-yellow-500" />
                  </div>
                  <div className={`text-xs flex items-center gap-1 mt-2 ${getGrowthColor(metrics.revenueGrowthRate)}`}>
                    {getGrowthIcon(metrics.revenueGrowthRate)}
                    {Math.abs(metrics.revenueGrowthRate)}% این ماه
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold text-purple-500">
                        {formatNumber(metrics.totalViews)}
                      </div>
                      <div className="text-sm text-muted-foreground">کل بازدیدها</div>
                    </div>
                    <Eye className="w-8 h-8 text-purple-500" />
                  </div>
                  <div className={`text-xs flex items-center gap-1 mt-2 ${getGrowthColor(metrics.viewGrowthRate)}`}>
                    {getGrowthIcon(metrics.viewGrowthRate)}
                    {Math.abs(metrics.viewGrowthRate)}% این ماه
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Chart - User Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ActivityIcon className="w-5 h-5" />
                  فعالیت کاربران
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={chartData.userActivity}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="date" stroke="#9CA3AF" />
                    <YAxis yAxisId="left" stroke="#9CA3AF" />
                    <YAxis yAxisId="right" orientation="left" stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Area
                      yAxisId="left"
                      type="monotone"
                      dataKey="activeUsers"
                      fill="#3B82F6"
                      fillOpacity={0.3}
                      stroke="#3B82F6"
                      name="کاربران فعال"
                    />
                    <Bar yAxisId="right" dataKey="newUsers" fill="#22C55E" name="کاربران جدید" />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="sessions"
                      stroke="#FACC15"
                      strokeWidth={2}
                      name="جلسات"
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Revenue Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="w-5 h-5" />
                    تقسیم‌بندی درآمد
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <RechartsPieChart>
                      <Pie
                        data={chartData.revenueBreakdown}
                        dataKey="value"
                        nameKey="category"
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        label={({ name, value }) => `${name}: ${value}%`}
                      >
                        {chartData.revenueBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    متریک‌های تعامل
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {chartData.engagementMetrics.map((metric, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{metric.metric}</span>
                        <span>{metric.value}% / {metric.target}%</span>
                      </div>
                      <div className="relative">
                        <Progress value={metric.value} className="h-2" />
                        <div 
                          className="absolute top-0 h-2 w-0.5 bg-white/50"
                          style={{ left: `${metric.target}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* User Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {formatNumber(metrics.activeUsers)}
                  </div>
                  <div className="text-sm text-muted-foreground">کاربران فعال</div>
                  <div className="text-xs text-green-500 mt-1">
                    +{metrics.newUsersToday} امروز
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {metrics.retentionRate}%
                  </div>
                  <div className="text-sm text-muted-foreground">نرخ بازگشت</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    7 روزه
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-500">
                    {metrics.averageSessionTime}m
                  </div>
                  <div className="text-sm text-muted-foreground">متوسط جلسه</div>
                  <div className="text-xs text-green-500 mt-1">
                    +12% این هفته
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-500">
                    {formatNumber(metrics.chatMessages)}
                  </div>
                  <div className="text-sm text-muted-foreground">پیام‌های چت</div>
                  <div className="text-xs text-green-500 mt-1">
                    امروز
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* User Funnel */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  قیف تبدیل کاربر
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <FunnelChart>
                    <Tooltip />
                    <Funnel
                      dataKey="users"
                      data={chartData.userFunnel}
                      isAnimationActive
                    >
                      {chartData.userFunnel.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Funnel>
                  </FunnelChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Geographic Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  توزیع جغرافیایی
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <RechartsBarChart data={chartData.geographicData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="region" stroke="#9CA3AF" />
                    <YAxis stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Bar dataKey="users" fill="#3B82F6" name="کاربران" />
                    <Bar dataKey="tournaments" fill="#22C55E" name="تورنومنت‌ها" />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Tournament Tab */}
        <TabsContent value="tournaments" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Tournament Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {metrics.activeTournaments}
                  </div>
                  <div className="text-sm text-muted-foreground">تورنومنت‌های فعال</div>
                  <div className="text-xs text-green-500 mt-1">
                    +{metrics.tournamentsToday} امروز
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {metrics.averageParticipants}
                  </div>
                  <div className="text-sm text-muted-foreground">متوسط شرکت‌کنندگان</div>
                  <div className="text-xs text-green-500 mt-1">
                    +8% این ماه
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-500">
                    {metrics.completionRate}%
                  </div>
                  <div className="text-sm text-muted-foreground">نرخ تکمیل</div>
                  <div className="text-xs text-green-500 mt-1">
                    بسیار خوب
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-500">
                    {formatCurrency(metrics.totalPrizesAwarded)}
                  </div>
                  <div className="text-sm text-muted-foreground">جوایز اهدایی</div>
                  <div className="text-xs text-green-500 mt-1">
                    این ماه
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tournament Stats Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  آمار تورنومنت‌ها
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={chartData.tournamentStats}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="date" stroke="#9CA3AF" />
                    <YAxis yAxisId="left" stroke="#9CA3AF" />
                    <YAxis yAxisId="right" orientation="left" stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Bar yAxisId="left" dataKey="tournaments" fill="#3B82F6" name="تعداد تورنومنت" />
                    <Area
                      yAxisId="right"
                      type="monotone"
                      dataKey="participants"
                      fill="#22C55E"
                      fillOpacity={0.3}
                      stroke="#22C55E"
                      name="شرکت‌کنندگان"
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="revenue"
                      stroke="#FACC15"
                      strokeWidth={2}
                      name="درآمد"
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Game Popularity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gamepad2 className="w-5 h-5" />
                  محبوبیت بازی‌ها
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <RechartsBarChart data={chartData.gamePopularity} layout="horizontal">
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis type="number" stroke="#9CA3AF" />
                    <YAxis dataKey="game" type="category" stroke="#9CA3AF" width={100} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Bar dataKey="tournaments" fill="#3B82F6" name="تورنومنت‌ها" />
                    <Bar dataKey="participants" fill="#22C55E" name="شرکت‌کنندگان" />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Financial Tab */}
        <TabsContent value="financial" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Financial Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {formatCurrency(metrics.revenueToday)}
                  </div>
                  <div className="text-sm text-muted-foreground">درآمد امروز</div>
                  <div className="text-xs text-green-500 mt-1">
                    +{metrics.revenueGrowthRate}%
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {formatNumber(metrics.averageTransactionValue)}
                  </div>
                  <div className="text-sm text-muted-foreground">متوسط تراکنش</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    تومان
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-500">
                    {metrics.profitMargin}%
                  </div>
                  <div className="text-sm text-muted-foreground">حاشیه سود</div>
                  <div className="text-xs text-green-500 mt-1">
                    بالای هدف
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-500">
                    {formatCurrency(metrics.totalPrizesAwarded)}
                  </div>
                  <div className="text-sm text-muted-foreground">کل جوایز</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    اهدا شده
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Revenue Chart and Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    روند درآمد
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <RechartsAreaChart data={chartData.tournamentStats}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                      <XAxis dataKey="date" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1F2937',
                          border: '1px solid #374151',
                          borderRadius: '8px'
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="revenue"
                        stroke="#22C55E"
                        fill="#22C55E"
                        fillOpacity={0.3}
                      />
                    </RechartsAreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChart className="w-5 h-5" />
                    منابع درآمد
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {chartData.revenueBreakdown.map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: item.color }}
                          />
                          <span className="text-sm">{item.category}</span>
                        </div>
                        <div className="text-sm font-medium">{item.value}%</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>

        {/* Engagement Tab */}
        <TabsContent value="engagement" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <Card>
              <CardContent className="text-center py-12">
                <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  صفحه آنالیز تعامل در حال توسعه است
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Performance Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {metrics.platformUptime}%
                  </div>
                  <div className="text-sm text-muted-foreground">آپتایم</div>
                  <div className="text-xs text-green-500 mt-1">
                    99.5% هدف
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {metrics.averageResponseTime}ms
                  </div>
                  <div className="text-sm text-muted-foreground">زمان پاسخ</div>
                  <div className="text-xs text-green-500 mt-1">
                    هدف: کمتر از 200ms
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-red-500">
                    {(metrics.errorRate * 100).toFixed(2)}%
                  </div>
                  <div className="text-sm text-muted-foreground">نرخ خطا</div>
                  <div className="text-xs text-green-500 mt-1">
                    هدف: کمتر از 0.1%
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-500">
                    {metrics.gameQualityScore}/10
                  </div>
                  <div className="text-sm text-muted-foreground">کیفیت بازی</div>
                  <div className="text-xs text-green-500 mt-1">
                    عالی
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Performance Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5" />
                  عملکرد سیستم
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={chartData.performanceMetrics}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                    <XAxis dataKey="time" stroke="#9CA3AF" />
                    <YAxis yAxisId="left" stroke="#9CA3AF" />
                    <YAxis yAxisId="right" orientation="left" stroke="#9CA3AF" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Line
                      yAxisId="left"
                      type="monotone"
                      dataKey="responseTime"
                      stroke="#3B82F6"
                      strokeWidth={2}
                      name="زمان پاسخ (ms)"
                    />
                    <Area
                      yAxisId="right"
                      type="monotone"
                      dataKey="uptime"
                      fill="#22C55E"
                      fillOpacity={0.3}
                      stroke="#22C55E"
                      name="آپتایم (%)"
                    />
                    <Bar yAxisId="left" dataKey="errors" fill="#EF4444" name="خطاها" />
                    <ReferenceLine yAxisId="left" y={200} stroke="#FACC15" strokeDasharray="5 5" />
                  </ComposedChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default PlatformAnalyticsDashboard;