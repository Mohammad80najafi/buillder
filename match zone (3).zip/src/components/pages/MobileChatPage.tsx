/**
 * Mobile Chat Page
 * صفحه چت موبایل با layout کاملاً fixed
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Smile, 
  Paperclip, 
  Mic, 
  MicOff, 
  Heart, 
  ThumbsUp, 
  Laugh,
  ArrowLeft,
  MoreVertical,
  VideoIcon,
  Phone,
  Volume2,
  VolumeX,
  Crown,
  Shield,
  Star,
  Zap,
  Info
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  isOwn: boolean;
  type: 'text' | 'gift' | 'system';
  role: 'player' | 'admin' | 'vip' | 'moderator';
  reactions?: { emoji: string; count: number; users: string[] }[];
  giftsData?: {
    type: string;
    value: number;
    from: string;
  };
}

interface ChatRoom {
  id: string;
  name: string;
  memberCount: number;
  avatar?: string;
  status: 'online' | 'away' | 'busy';
}

export function MobileChatPage() {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const emojiReactions = ['❤️', '👍', '😂', '😮', '😢', '😡', '🔥', '⚡', '🎯', '💎'];

  // Mock data
  const currentRoom: ChatRoom = {
    id: 'general',
    name: 'چت عمومی',
    memberCount: 156,
    status: 'online'
  };

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      username: 'Captain Phoenix',
      message: 'سلام به همه! آماده برای بازی امشب؟ 🎮',
      timestamp: new Date(Date.now() - 300000),
      isOwn: false,
      type: 'text',
      role: 'admin',
      reactions: [
        { emoji: '🔥', count: 5, users: ['user1', 'user2'] },
        { emoji: '👍', count: 3, users: ['user3'] }
      ]
    },
    {
      id: '2',
      username: 'Sarah Pro Gamer',
      message: 'بله! چه بازی‌ای رو پیشنهاد می‌دی؟',
      timestamp: new Date(Date.now() - 240000),
      isOwn: false,
      type: 'text',
      role: 'vip'
    },
    {
      id: '3',
      username: 'شما',
      message: 'من آماده‌ام، بزن بریم! 💪',
      timestamp: new Date(Date.now() - 180000),
      isOwn: true,
      type: 'text',
      role: 'player'
    },
    {
      id: '4',
      username: 'Ali Champion',
      message: '',
      timestamp: new Date(Date.now() - 120000),
      isOwn: false,
      type: 'gift',
      role: 'player',
      giftsData: {
        type: 'جایزه طلایی',
        value: 100,
        from: 'Ali Champion'
      }
    },
    {
      id: '5',
      username: 'Team Leader',
      message: 'بچه‌ها واقعاً عالی بازی کردین! 🏆',
      timestamp: new Date(Date.now() - 60000),
      isOwn: false,
      type: 'text',
      role: 'moderator'
    },
    {
      id: '6',
      username: 'شما',
      message: 'ممنون! تیم‌ورک فوق‌العاده بود',
      timestamp: new Date(Date.now() - 30000),
      isOwn: true,
      type: 'text',
      role: 'player'
    }
  ]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      username: 'شما',
      message: message.trim(),
      timestamp: new Date(),
      isOwn: true,
      type: 'text',
      role: 'player'
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const existingReaction = msg.reactions?.find(r => r.emoji === emoji);
        if (existingReaction) {
          return {
            ...msg,
            reactions: msg.reactions?.map(r => 
              r.emoji === emoji 
                ? { ...r, count: r.count + 1 }
                : r
            )
          };
        } else {
          return {
            ...msg,
            reactions: [
              ...(msg.reactions || []),
              { emoji, count: 1, users: ['current-user'] }
            ]
          };
        }
      }
      return msg;
    }));
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="h-3 w-3 text-yellow-400" />;
      case 'moderator': return <Shield className="h-3 w-3 text-blue-400" />;
      case 'vip': return <Star className="h-3 w-3 text-purple-400" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const MessageComponent = ({ message: msg }: { message: ChatMessage }) => (
    <div className={`group mb-3 ${msg.isOwn ? 'text-left' : 'text-right'}`} dir={msg.isOwn ? 'ltr' : 'rtl'}>
      <div className={`flex items-start gap-2 ${msg.isOwn ? 'flex-row' : 'flex-row-reverse'}`}>
        {!msg.isOwn && (
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarFallback className="text-xs">{msg.username[0]}</AvatarFallback>
          </Avatar>
        )}
        
        <div className={`flex-1 min-w-0 ${msg.isOwn ? 'text-left' : 'text-right'}`}>
          {!msg.isOwn && (
            <div className="flex items-center gap-1 mb-1">
              {getRoleIcon(msg.role)}
              <span className="text-xs font-medium">{msg.username}</span>
              <span className="text-xs text-muted-foreground">
                {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          )}
          
          <div className={`max-w-[280px] ${msg.isOwn ? 'mr-auto' : 'ml-auto'}`}>
            {msg.type === 'system' ? (
              <div className="bg-muted/50 text-center p-2 rounded-lg text-xs text-muted-foreground">
                {msg.message}
              </div>
            ) : msg.type === 'gift' ? (
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 p-2 rounded-lg text-xs border border-yellow-500/30">
                <div className="flex items-center gap-1">
                  <Zap className="h-3 w-3 text-yellow-400" />
                  <span>
                    {msg.giftsData?.from} یک {msg.giftsData?.type} به ارزش {msg.giftsData?.value} سکه فرستاد!
                  </span>
                </div>
              </div>
            ) : (
              <div className={`p-2 rounded-lg text-sm ${
                msg.isOwn 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted'
              }`}>
                {msg.message}
                {msg.isOwn && (
                  <div className="text-xs opacity-70 mt-1">
                    {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                )}
              </div>
            )}
            
            {/* Message Reactions */}
            {msg.reactions && msg.reactions.length > 0 && (
              <div className="flex gap-1 mt-1">
                {msg.reactions.map((reaction, idx) => (
                  <Button
                    key={idx}
                    variant="ghost"
                    size="sm"
                    className="h-5 px-1 text-xs hover:bg-muted"
                    onClick={() => handleReaction(msg.id, reaction.emoji)}
                  >
                    {reaction.emoji} {reaction.count}
                  </Button>
                ))}
              </div>
            )}
            
            {/* Quick Reactions (visible on hold/hover) */}
            <div className="hidden group-hover:flex gap-1 mt-1">
              {emojiReactions.slice(0, 4).map((emoji) => (
                <Button
                  key={emoji}
                  variant="ghost"
                  size="sm"
                  className="h-5 w-5 p-0 hover:bg-muted"
                  onClick={() => handleReaction(msg.id, emoji)}
                >
                  {emoji}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* Fixed Header */}
      <div className="flex-shrink-0 border-b bg-card/95 backdrop-blur-sm">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="p-1">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            
            <div className="flex items-center gap-3">
              <div className="relative">
                <Avatar className="h-10 w-10">
                  <AvatarFallback>{currentRoom.name[0]}</AvatarFallback>
                </Avatar>
                <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-background ${getStatusColor(currentRoom.status)}`} />
              </div>
              
              <div className="text-right" dir="rtl">
                <h2 className="font-medium">{currentRoom.name}</h2>
                <p className="text-xs text-muted-foreground">
                  {currentRoom.memberCount} عضو آنلاین
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" className="p-1">
              <VideoIcon className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="p-1">
              <Phone className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-1"
              onClick={() => setIsMuted(!isMuted)}
            >
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="sm" className="p-1">
              <Info className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages Area - Only This Part Scrolls */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto px-4">
          <div className="py-4 space-y-1">
            {messages.map((msg) => (
              <MessageComponent key={msg.id} message={msg} />
            ))}
            {isTyping && (
              <div className="text-muted-foreground text-xs text-right px-2" dir="rtl">
                <div className="flex items-center justify-end gap-1">
                  <span>کاربری در حال تایپ</span>
                  <div className="flex gap-0.5">
                    <div className="w-1 h-1 bg-current rounded-full animate-pulse" />
                    <div className="w-1 h-1 bg-current rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                    <div className="w-1 h-1 bg-current rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>
      </div>

      {/* Fixed Input Area */}
      <div className="flex-shrink-0 border-t bg-card/95 backdrop-blur-sm">
        <div className="p-4">
          <div className="flex items-center gap-2 rtl:space-x-reverse">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="پیام خود را بنویسید..."
              className="flex-1 min-w-0 h-10"
              dir="rtl"
            />
            
            <Button variant="ghost" size="sm" className="p-2 flex-shrink-0">
              <Paperclip className="h-4 w-4" />
            </Button>
            
            <Button variant="ghost" size="sm" className="p-2 flex-shrink-0">
              <Smile className="h-4 w-4" />
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm"
              className={`p-2 flex-shrink-0 ${isRecording ? 'text-red-500' : ''}`}
              onClick={() => setIsRecording(!isRecording)}
            >
              {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
            
            <Button 
              onClick={handleSendMessage}
              disabled={!message.trim()}
              size="sm"
              className="p-2 flex-shrink-0"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}