/**
 * Countdown Timer Demo Page
 * Demonstrates the lobby countdown timer functionality
 */

import React, { useState } from 'react';
import { LobbyCountdownTimer } from '../gaming/LobbyCountdownTimer';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  Timer, 
  Play, 
  RotateCcw, 
  Settings,
  Clock,
  Bell
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export function CountdownTimerDemo() {
  const [selectedDemo, setSelectedDemo] = useState<string>('demo1');

  const demos = {
    demo1: {
      name: 'تایمر 30 ثانیه (برای تست)',
      startTime: new Date(Date.now() + 30 * 1000), // 30 seconds from now
      duration: 2,
      autoStart: true,
      notifyBeforeStart: true,
      notificationTime: 10 // 10 seconds notification
    },
    demo2: {
      name: 'تایمر 2 دقیقه',
      startTime: new Date(Date.now() + 2 * 60 * 1000), // 2 minutes from now
      duration: 1,
      autoStart: true,
      notifyBeforeStart: true,
      notificationTime: 1 // 1 minute notification
    },
    demo3: {
      name: 'تایمر 1 ساعت',
      startTime: new Date(Date.now() + 60 * 60 * 1000), // 1 hour from now
      duration: 3,
      autoStart: false,
      notifyBeforeStart: true,
      notificationTime: 5
    },
    demo4: {
      name: 'بازی شروع شده',
      startTime: new Date(Date.now() - 10 * 1000), // 10 seconds ago (already started)
      duration: 2,
      autoStart: true,
      notifyBeforeStart: true,
      notificationTime: 5
    }
  };

  const currentDemo = demos[selectedDemo as keyof typeof demos];

  const handleStart = () => {
    toast.success('بازی شروع شد! 🎮', {
      description: 'کاربر وارد بازی شد',
      duration: 3000
    });
  };

  const handleTimeUp = () => {
    console.log('Timer finished');
  };

  const resetDemo = () => {
    // Force re-render by changing key
    setSelectedDemo(selectedDemo + '_reset');
    setTimeout(() => {
      setSelectedDemo(selectedDemo);
    }, 100);
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-2xl font-bold">تست سیستم تایمر لابی</h1>
          <p className="text-muted-foreground">
            این صفحه برای تست عملکرد countdown timer و notifications است
          </p>
        </div>

        {/* Demo Selector */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              انتخاب حالت تست
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(demos).map(([key, demo]) => (
                <div
                  key={key}
                  onClick={() => setSelectedDemo(key)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    selectedDemo === key
                      ? 'border-blue-500 bg-blue-500/10'
                      : 'border-border hover:border-border/80'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold">{demo.name}</h3>
                    <Timer className="w-4 h-4 text-blue-400" />
                  </div>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      <span>مدت: {demo.duration} ساعت</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Play className="w-3 h-3" />
                      <span>شروع خودکار: {demo.autoStart ? 'فعال' : 'غیرفعال'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Bell className="w-3 h-3" />
                      <span>اعلان: {demo.notificationTime} 
                        {demo.notificationTime === 10 ? ' ثانیه' : ' دقیقه'} قبل
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Current Demo Info */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Timer className="w-5 h-5 text-blue-400" />
                {currentDemo.name}
              </CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={resetDemo}
                className="flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                ریست
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">شروع:</span>
                <Badge variant="outline">
                  {currentDemo.startTime.toLocaleTimeString('fa-IR')}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">مدت:</span>
                <Badge variant="outline">
                  {currentDemo.duration} ساعت
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">خودکار:</span>
                <Badge variant={currentDemo.autoStart ? "default" : "secondary"}>
                  {currentDemo.autoStart ? 'فعال' : 'غیرفعال'}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">اعلان:</span>
                <Badge variant="outline">
                  {currentDemo.notificationTime} 
                  {currentDemo.notificationTime === 10 ? ' ثانیه' : ' دقیقه'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Timer Display */}
        <LobbyCountdownTimer
          key={selectedDemo} // Force re-render when demo changes
          startTime={currentDemo.startTime}
          duration={currentDemo.duration}
          autoStart={currentDemo.autoStart}
          notifyBeforeStart={currentDemo.notifyBeforeStart}
          notificationTime={currentDemo.notificationTime}
          onStart={handleStart}
          onTimeUp={handleTimeUp}
        />

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>راهنما</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="space-y-1">
              <p className="font-medium">1. تست سریع (30 ثانیه):</p>
              <p className="text-muted-foreground">• برای تست فوری عملکرد timer</p>
              <p className="text-muted-foreground">• 10 ثانیه قبل از پایان اعلان می‌دهد</p>
              <p className="text-muted-foreground">• بعد از پایان، پیام شروع بازی نمایش داده می‌شود</p>
            </div>
            
            <div className="space-y-1">
              <p className="font-medium">2. تست متوسط (2 دقیقه):</p>
              <p className="text-muted-foreground">• برای تست با زمان واقعی‌تر</p>
              <p className="text-muted-foreground">• 1 دقیقه قبل از پایان اعلان می‌دهد</p>
            </div>
            
            <div className="space-y-1">
              <p className="font-medium">3. تست طولانی (1 ساعت):</p>
              <p className="text-muted-foreground">• نمایش timer برای مدت طولانی</p>
              <p className="text-muted-foreground">• شروع خودکار غیرفعال است</p>
            </div>
            
            <div className="space-y-1">
              <p className="font-medium">4. بازی شروع شده:</p>
              <p className="text-muted-foreground">• نمایش حالت بعد از شروع بازی</p>
              <p className="text-muted-foreground">• دکمه ورود به بازی نمایش داده می‌شود</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default CountdownTimerDemo;