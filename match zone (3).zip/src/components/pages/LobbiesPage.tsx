import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Switch } from '../ui/switch';
import { Plus, Search, Filter, Users, Play, Clock, Settings, MessageCircle } from 'lucide-react';
import { useMobile } from '../ui/use-mobile';
import { LobbyDetailPage } from '../gaming/LobbyDetailPage';

export function LobbiesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [gameFilter, setGameFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedLobby, setSelectedLobby] = useState<number | null>(null);
  const [viewingLobbyId, setViewingLobbyId] = useState<string | null>(null);
  const isMobile = useMobile();

  const [newLobby, setNewLobby] = useState({
    game: '',
    title: '',
    capacity: '10',
    visibility: 'public',
    description: '',
    rules: ''
  });

  const lobbies = [
    {
      id: 1,
      game: 'کالاف دیوتی',
      title: 'مسابقه تیمی 5v5 کامپتیتیو',
      description: 'مسابقه سطح بالا برای بازیکنان حرفه‌ای',
      capacity: { current: 8, max: 10 },
      status: 'در انتظار',
      host: { name: 'علی_گیمر', avatar: '/avatars/ali.jpg', trustBadge: true },
      members: [
        { name: 'محمد_پرو', avatar: '/avatars/m1.jpg' },
        { name: 'سارا_گیمر', avatar: '/avatars/s1.jpg' },
        { name: 'حسن_استریمر', avatar: '/avatars/h1.jpg' },
      ],
      rules: 'بدون فحاشی، تنها بازیکنان با تجربه',
      createdAt: '۱۰ دقیقه پیش'
    },
    {
      id: 2,
      game: 'فیفا 24',
      title: 'تورنومنت سریع آنلاین',
      description: 'مسابقات کوتاه و سرگرم‌کننده',
      capacity: { current: 15, max: 16 },
      status: 'شروع شده',
      host: { name: 'حسن_پرو', avatar: '/avatars/hassan.jpg', trustBadge: true },
      members: [],
      rules: 'قوانین فیفا استاندارد',
      createdAt: '۳۰ دقیقه پیش'
    },
    {
      id: 3,
      game: 'والورانت',
      title: 'کامپتیتیو رنک - سطح بالا',
      description: 'فقط برای بازیکنان رنک الماسی',
      capacity: { current: 4, max: 10 },
      status: 'در انتظار',
      host: { name: 'سارا_وال', avatar: '/avatars/sara.jpg', trustBadge: false },
      members: [],
      rules: 'رنک الماسی یا بالاتر، مایک اجباری',
      createdAt: '۱ ساعت پیش'
    },
    {
      id: 4,
      game: 'کالاف دیوتی',
      title: 'بازی دوستانه مبتدی‌ها',
      description: 'محیط دوستانه برای یادگیری',
      capacity: { current: 10, max: 10 },
      status: 'پر',
      host: { name: 'امیر_نوب', avatar: '/avatars/amir.jpg', trustBadge: false },
      members: [],
      rules: 'محیط آموزشی، کمک به یکدیگر',
      createdAt: '۲ ساعت پیش'
    }
  ];

  const filteredLobbies = lobbies.filter(lobby => {
    const matchesSearch = lobby.title.includes(searchQuery) || lobby.game.includes(searchQuery);
    const matchesGame = gameFilter === 'all' || lobby.game === gameFilter;
    const matchesStatus = statusFilter === 'all' || lobby.status === statusFilter;
    return matchesSearch && matchesGame && matchesStatus;
  });

  const handleCreateLobby = () => {
    console.log('Creating lobby:', newLobby);
    setIsCreateModalOpen(false);
    setNewLobby({
      game: '',
      title: '',
      capacity: '10',
      visibility: 'public',
      description: '',
      rules: ''
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'در انتظار': return 'default';
      case 'شروع شده': return 'secondary';
      case 'پر': return 'destructive';
      default: return 'default';
    }
  };

  // Show lobby detail page if viewing a specific lobby
  if (viewingLobbyId) {
    return (
      <LobbyDetailPage 
        lobbyId={viewingLobbyId} 
        onBack={() => setViewingLobbyId(null)} 
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 ml-2" />
                  ایجاد لابی
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-right" dir="rtl">ایجاد لابی جدید</DialogTitle>
                  <DialogDescription className="text-right" dir="rtl">
                    لابی خود را برای سایر بازیکنان ایجاد کنید
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="game" className="text-right" dir="rtl">بازی</Label>
                    <Select value={newLobby.game} onValueChange={(value) => setNewLobby({...newLobby, game: value})}>
                      <SelectTrigger className="text-right" dir="rtl">
                        <SelectValue placeholder="انتخاب بازی" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="کالاف دیوتی">کالاف دیوتی</SelectItem>
                        <SelectItem value="فیفا 24">فیفا 24</SelectItem>
                        <SelectItem value="والورانت">والورانت</SelectItem>
                        <SelectItem value="لیگ آف لجندز">لیگ آف لجندز</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="title" className="text-right" dir="rtl">عنوان لابی</Label>
                    <Input
                      id="title"
                      placeholder="عنوان جذابی انتخاب کنید"
                      value={newLobby.title}
                      onChange={(e) => setNewLobby({...newLobby, title: e.target.value})}
                      className="text-right"
                      dir="rtl"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="capacity" className="text-right" dir="rtl">ظرفیت</Label>
                    <Select value={newLobby.capacity} onValueChange={(value) => setNewLobby({...newLobby, capacity: value})}>
                      <SelectTrigger className="text-right" dir="rtl">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="4">۴ نفر</SelectItem>
                        <SelectItem value="6">۶ نفر</SelectItem>
                        <SelectItem value="8">۸ نفر</SelectItem>
                        <SelectItem value="10">۱۰ نفر</SelectItem>
                        <SelectItem value="16">۱۶ نفر</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Switch
                      checked={newLobby.visibility === 'public'}
                      onCheckedChange={(checked) => setNewLobby({...newLobby, visibility: checked ? 'public' : 'private'})}
                    />
                    <Label className="text-right" dir="rtl">لابی عمومی</Label>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="rules" className="text-right" dir="rtl">قوانین (اختیاری)</Label>
                    <Textarea
                      id="rules"
                      placeholder="قوانین لابی خود را بنویسید..."
                      value={newLobby.rules}
                      onChange={(e) => setNewLobby({...newLobby, rules: e.target.value})}
                      className="text-right"
                      dir="rtl"
                    />
                  </div>

                  <Button onClick={handleCreateLobby} className="w-full">
                    ایجاد لابی
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {selectedLobby && (
              <Button variant="outline">
                <Settings className="h-4 w-4 ml-2" />
                مدیریت
              </Button>
            )}
          </div>

          <h1 className="text-2xl font-bold text-right" dir="rtl">لابی‌ها</h1>
        </div>

        {/* Filters */}
        <div className={`flex flex-col ${isMobile ? 'space-y-2' : 'lg:flex-row lg:space-y-0 lg:space-x-4'} items-end`}>
          <div className="flex space-x-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه</SelectItem>
                <SelectItem value="در انتظار">در انتظار</SelectItem>
                <SelectItem value="شروع شده">شروع شده</SelectItem>
                <SelectItem value="پر">پر</SelectItem>
              </SelectContent>
            </Select>

            <Select value={gameFilter} onValueChange={setGameFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="بازی" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه بازی‌ها</SelectItem>
                <SelectItem value="کالاف دیوتی">کالاف دیوتی</SelectItem>
                <SelectItem value="فیفا 24">فیفا 24</SelectItem>
                <SelectItem value="والورانت">والورانت</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="relative flex-1 max-w-md">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="جستجوی لابی..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 text-right"
              dir="rtl"
            />
          </div>
        </div>
      </div>

      {/* Lobbies Grid */}
      <div className={`grid ${isMobile ? 'grid-cols-1' : 'lg:grid-cols-2 xl:grid-cols-3'} gap-4`}>
        {filteredLobbies.map((lobby) => (
          <Card 
            key={lobby.id} 
            className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
              selectedLobby === lobby.id ? 'ring-2 ring-primary' : ''
            }`}
            onClick={() => setSelectedLobby(selectedLobby === lobby.id ? null : lobby.id)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex flex-col items-end space-y-1">
                  <Badge variant={getStatusColor(lobby.status) as any}>
                    {lobby.status}
                  </Badge>
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    <span>{lobby.capacity.current}/{lobby.capacity.max}</span>
                    <Users className="h-3 w-3" />
                  </div>
                </div>
                <div className="text-right space-y-1" dir="rtl">
                  <CardTitle className="text-lg leading-tight">{lobby.title}</CardTitle>
                  <p className="text-sm text-primary">{lobby.game}</p>
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <CardDescription className="text-right text-sm" dir="rtl">
                {lobby.description}
              </CardDescription>

              {/* Host Info */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span>{lobby.createdAt}</span>
                </div>
                <div className="flex items-center space-x-2" dir="rtl">
                  <div className="text-right">
                    <p className="text-sm font-medium">{lobby.host.name}</p>
                    <p className="text-xs text-muted-foreground">میزبان</p>
                  </div>
                  <div className="relative">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">{lobby.host.name[0]}</AvatarFallback>
                    </Avatar>
                    {lobby.host.trustBadge && (
                      <div className="absolute -top-1 -right-1 h-3 w-3 bg-green-500 rounded-full border border-background"></div>
                    )}
                  </div>
                </div>
              </div>

              {/* Members Preview */}
              {lobby.members.length > 0 && (
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">اعضا:</span>
                  <div className="flex -space-x-2">
                    {lobby.members.slice(0, 3).map((member, index) => (
                      <Avatar key={index} className="h-6 w-6 border border-background">
                        <AvatarFallback className="text-xs">{member.name[0]}</AvatarFallback>
                      </Avatar>
                    ))}
                    {lobby.members.length > 3 && (
                      <div className="h-6 w-6 rounded-full bg-muted border border-background flex items-center justify-center">
                        <span className="text-xs">+{lobby.members.length - 3}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex space-x-2 pt-2">
                {lobby.status === 'در انتظار' && lobby.capacity.current < lobby.capacity.max && (
                  <Button size="sm" className="flex-1">
                    <Play className="h-3 w-3 ml-1" />
                    پیوستن
                  </Button>
                )}
                
                {selectedLobby === lobby.id && (
                  <>
                    <Button variant="outline" size="sm">
                      <MessageCircle className="h-3 w-3 ml-1" />
                      چت
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setViewingLobbyId(lobby.id.toString());
                      }}
                    >
                      جزییات
                    </Button>
                  </>
                )}
              </div>

              {/* Rules Preview */}
              {selectedLobby === lobby.id && lobby.rules && (
                <div className="mt-3 p-2 bg-muted rounded-lg">
                  <p className="text-xs text-muted-foreground text-right" dir="rtl">
                    <strong>قوانین:</strong> {lobby.rules}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredLobbies.length === 0 && (
        <Card className="p-12 text-center">
          <div className="space-y-4">
            <Users className="h-12 w-12 text-muted-foreground mx-auto" />
            <div>
              <h3 className="text-lg font-medium">لابی‌ای یافت نشد</h3>
              <p className="text-muted-foreground">فیلترهای خود را تغییر دهید یا لابی جدید ایجاد کنید</p>
            </div>
            <Button onClick={() => setIsCreateModalOpen(true)}>
              <Plus className="h-4 w-4 ml-2" />
              ایجاد لابی جدید
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}