import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { PremiumScrollArea } from '../ui/premium-scroll-area';
import { Badge } from '../ui/badge';
import { Button } from '../ui/mz-button';
import { 
  Sparkles, Gamepad2, Trophy, Users, Star, Play, 
  Clock, MapPin, Heart, Eye, Volume2 
} from 'lucide-react';

export function ScrollbarShowcase() {
  const mockContent = Array.from({ length: 50 }, (_, i) => ({
    id: i + 1,
    title: `آیتم ${i + 1}`,
    subtitle: `توضیحات آیتم شماره ${i + 1} که کمی طولانی است`,
    icon: [Sparkles, Gamepad2, Trophy, Users, Star, Play][i % 6],
    color: ['bg-brand-primary', 'bg-brand-secondary', 'bg-brand-accent', 'bg-purple-500', 'bg-red-500', 'bg-green-500'][i % 6]
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-bg-primary via-bg-secondary to-bg-primary p-6" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-brand-primary via-brand-accent to-brand-secondary bg-clip-text text-transparent mb-4">
            ✨ نمایش Scrollbar های خفن ✨
          </h1>
          <p className="text-text-secondary text-lg">
            مجموعه‌ای از scrollbarهای مدرن و گیمینگ برای Matchzone
          </p>
        </div>

        {/* Scrollbar Examples Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          
          {/* Default Gaming Scrollbar */}
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gamepad2 className="h-5 w-5 text-brand-primary" />
                Gaming Style (پیش‌فرض)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 overflow-y-auto gaming-scroll bg-surface-secondary/30 rounded-lg p-4 space-y-3">
                {mockContent.slice(0, 20).map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.id} className="flex items-center gap-3 p-3 bg-surface-primary/50 rounded-lg hover:bg-surface-secondary/70 transition-colors">
                      <div className={`w-10 h-10 ${item.color} rounded-lg flex items-center justify-center`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{item.title}</h4>
                        <p className="text-sm text-text-secondary">{item.subtitle}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Premium Scroll Area - Gaming */}
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-brand-accent" />
                Premium Gaming
              </CardTitle>
            </CardHeader>
            <CardContent>
              <PremiumScrollArea variant="gaming" maxHeight={256} showIndicator className="bg-surface-secondary/30 rounded-lg p-4 space-y-3">
                {mockContent.slice(0, 15).map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.id} className="flex items-center gap-3 p-3 bg-gradient-to-r from-surface-primary/50 to-surface-secondary/30 rounded-lg hover:from-surface-secondary/70 hover:to-surface-tertiary/50 transition-all">
                      <div className={`w-10 h-10 bg-gradient-to-br ${item.color.replace('bg-', 'from-')} to-purple-600 rounded-lg flex items-center justify-center shadow-lg`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{item.title}</h4>
                        <p className="text-sm text-text-secondary">{item.subtitle}</p>
                        <Badge className="mt-1 text-xs">VIP</Badge>
                      </div>
                    </div>
                  );
                })}
              </PremiumScrollArea>
            </CardContent>
          </Card>

          {/* Fade Scrollbar */}
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-brand-secondary" />
                Fade on Hover
              </CardTitle>
            </CardHeader>
            <CardContent>
              <PremiumScrollArea variant="fade" maxHeight={256} className="bg-surface-secondary/30 rounded-lg p-4 space-y-3">
                {mockContent.slice(0, 18).map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.id} className="flex items-center gap-3 p-2 bg-surface-primary/30 rounded-lg hover:bg-surface-secondary/50 transition-colors border border-border-secondary/30">
                      <div className={`w-8 h-8 ${item.color} rounded-full flex items-center justify-center`}>
                        <Icon className="h-4 w-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{item.title}</h4>
                        <p className="text-xs text-text-secondary">{item.subtitle}</p>
                      </div>
                    </div>
                  );
                })}
              </PremiumScrollArea>
            </CardContent>
          </Card>

          {/* Horizontal Scroll Example */}
          <Card className="lg:col-span-2 xl:col-span-3 overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="h-5 w-5 text-red-500" />
                اسکرول افقی - Live Streams
              </CardTitle>
            </CardHeader>
            <CardContent>
              <PremiumScrollArea orientation="horizontal" variant="gaming" className="pb-4">
                <div className="flex gap-4 min-w-max">
                  {Array.from({ length: 15 }, (_, i) => ({
                    id: i + 1,
                    creator: `استریمر_${i + 1}`,
                    game: ['Valorant', 'CS2', 'FIFA', 'PUBG', 'Fortnite'][i % 5],
                    viewers: `${Math.floor(Math.random() * 5000 + 100)}`,
                    thumbnail: `https://images.unsplash.com/photo-${1500000000000 + i}?w=200&h=120&fit=crop`,
                    isLive: true
                  })).map((stream) => (
                    <Card key={stream.id} className="w-48 flex-shrink-0 bg-surface-primary/60 hover:bg-surface-secondary/70 transition-all cursor-pointer border border-border-secondary/50">
                      <CardContent className="p-3">
                        <div className="relative mb-3">
                          <div className="w-full h-24 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg flex items-center justify-center">
                            <Play className="h-8 w-8 text-white" />
                          </div>
                          <Badge className="absolute top-2 right-2 bg-state-danger text-white text-xs">زنده</Badge>
                        </div>
                        <h4 className="font-medium text-sm mb-1 truncate">{stream.creator}</h4>
                        <p className="text-xs text-text-secondary mb-2 truncate">{stream.game}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            <span className="text-xs">{stream.viewers}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Volume2 className="h-3 w-3" />
                            <span className="text-xs">فارسی</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </PremiumScrollArea>
            </CardContent>
          </Card>

          {/* Both Directions */}
          <Card className="lg:col-span-2 xl:col-span-3 overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-purple-500" />
                اسکرول دوطرفه - نقشه گیمینگ
              </CardTitle>
            </CardHeader>
            <CardContent>
              <PremiumScrollArea 
                orientation="both" 
                variant="gaming" 
                maxHeight={300}
                className="bg-gradient-to-br from-surface-secondary/30 to-surface-tertiary/20 rounded-lg p-4"
              >
                <div className="w-[800px] h-[600px] relative bg-gradient-to-br from-gray-800 to-gray-900 rounded-lg overflow-hidden">
                  {/* Mock Gaming Map Background */}
                  <div 
                    className="absolute inset-0 opacity-50" 
                    style={{
                      backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.02) 10px, rgba(255,255,255,0.02) 20px), repeating-linear-gradient(-45deg, transparent, transparent 10px, rgba(255,255,255,0.01) 10px, rgba(255,255,255,0.01) 20px)'
                    }}
                  />
                  
                  {/* Gaming Elements */}
                  {Array.from({ length: 20 }, (_, i) => (
                    <div
                      key={i}
                      className="absolute w-12 h-12 bg-gradient-to-br from-brand-primary to-brand-secondary rounded-lg flex items-center justify-center shadow-lg hover:scale-110 transition-transform cursor-pointer"
                      style={{
                        left: `${Math.random() * 700 + 50}px`,
                        top: `${Math.random() * 500 + 50}px`,
                      }}
                    >
                      <Gamepad2 className="h-6 w-6 text-white" />
                    </div>
                  ))}
                  
                  {/* Map Labels */}
                  <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-3">
                    <h3 className="text-white font-bold mb-2">🗺️ نقشه Dust2</h3>
                    <p className="text-white/80 text-sm">Counter-Strike 2</p>
                  </div>
                  
                  <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-sm rounded-lg p-3">
                    <div className="flex items-center gap-2 text-white">
                      <Users className="h-4 w-4" />
                      <span className="text-sm">10/10 بازیکن</span>
                    </div>
                  </div>
                </div>
              </PremiumScrollArea>
            </CardContent>
          </Card>

        </div>

        {/* Action Buttons */}
        <div className="text-center space-y-4">
          <div className="flex justify-center gap-4">
            <Button className="bg-gradient-to-r from-brand-primary to-brand-secondary">
              <Heart className="h-4 w-4 mr-2" />
              عاشق این طراحی‌ام!
            </Button>
            <Button variant="outline">
              <Star className="h-4 w-4 mr-2" />
              به صفحه اصلی برگرد
            </Button>
          </div>
          
          <p className="text-text-secondary text-sm">
            🎮 ساخته شده با عشق برای گیمرهای ایرانی
          </p>
        </div>

      </div>
    </div>
  );
}