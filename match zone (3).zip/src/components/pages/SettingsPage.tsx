import React, { useState } from 'react';
import { useNotificationService } from '../system/NotificationService';
import { NotificationSettingsSection } from '../system/NotificationSettingsSection';
import { 
  Settings, User, Eye, EyeOff, Bell, BellOff, Gamepad2, Shield, Wallet, 
  Monitor, Volume2, Mic, Camera, Users, Lock, CreditCard, Globe, 
  Smartphone, Mail, MessageCircle, Heart, Star, Download, Upload,
  Moon, Sun, Languages, Accessibility, HelpCircle, Info, LogOut,
  Edit3, Save, X, Check, AlertTriangle, Trash2, RefreshCw
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Switch } from '../ui/switch';
import { Slider } from '../ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Separator } from '../ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../ui/alert-dialog';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Progress } from '../ui/progress';

interface UserSettings {
  // Account
  username: string;
  email: string;
  bio: string;
  isVerified: boolean;
  
  // Display
  theme: 'dark' | 'light' | 'auto';
  language: string;
  fontSize: number;
  animations: boolean;
  reducedMotion: boolean;
  
  // Notifications
  emailNotifications: boolean;
  pushNotifications: boolean;
  gameInvites: boolean;
  tournamentUpdates: boolean;
  socialUpdates: boolean;
  streamNotifications: boolean;
  
  // Gaming
  crossplay: boolean;
  voiceChat: boolean;
  gameOverlay: boolean;
  performanceMode: boolean;
  autoRecord: boolean;
  
  // Privacy
  profileVisibility: 'public' | 'friends' | 'private';
  showOnlineStatus: boolean;
  allowDirectMessages: boolean;
  allowGameInvites: boolean;
  shareStats: boolean;
  
  // Streaming
  streamQuality: string;
  micVolume: number;
  cameraEnabled: boolean;
  chatModeration: boolean;
  
  // Financial
  autoTopUp: boolean;
  spendingLimit: number;
  transactionNotifications: boolean;
}

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState('account');
  const [isEditing, setIsEditing] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  const [settings, setSettings] = useState<UserSettings>({
    // Account
    username: 'گیمر_پرو',
    email: 'gamer@example.com',
    bio: 'گیمر حرفه‌ای و استریمر محتوای گیمینگ',
    isVerified: true,
    
    // Display
    theme: 'dark',
    language: 'fa',
    fontSize: 14,
    animations: true,
    reducedMotion: false,
    
    // Notifications
    emailNotifications: true,
    pushNotifications: true,
    gameInvites: true,
    tournamentUpdates: true,
    socialUpdates: false,
    streamNotifications: true,
    
    // Gaming
    crossplay: true,
    voiceChat: true,
    gameOverlay: true,
    performanceMode: false,
    autoRecord: true,
    
    // Privacy
    profileVisibility: 'public',
    showOnlineStatus: true,
    allowDirectMessages: true,
    allowGameInvites: true,
    shareStats: true,
    
    // Streaming
    streamQuality: '1080p',
    micVolume: 80,
    cameraEnabled: true,
    chatModeration: true,
    
    // Financial
    autoTopUp: false,
    spendingLimit: 1000000,
    transactionNotifications: true,
  });

  const updateSetting = (key: keyof UserSettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const saveSettings = () => {
    // Save settings logic here
    setHasChanges(false);
    setIsEditing(false);
  };

  const resetSettings = () => {
    // Reset to defaults logic here
    setHasChanges(false);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fa-IR').format(amount) + ' تومان';
  };

  const settingsTabs = [
    { id: 'account', label: 'حساب کاربری', icon: User },
    { id: 'display', label: 'نمایش', icon: Monitor },
    { id: 'notifications', label: 'اعلان‌ها', icon: Bell },
    { id: 'gaming', label: 'گیمینگ', icon: Gamepad2 },
    { id: 'privacy', label: 'حریم خصوصی', icon: Shield },
    { id: 'streaming', label: 'استریم', icon: Camera },
    { id: 'financial', label: 'مالی', icon: Wallet },
    { id: 'accessibility', label: 'دسترسی', icon: Accessibility },
    { id: 'about', label: 'درباره', icon: Info },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">تنظیمات</h1>
          <p className="text-muted-foreground">مدیریت تنظیمات حساب و برنامه</p>
        </div>
        
        <div className="flex items-center space-x-2">
          {hasChanges && (
            <div className="flex items-center space-x-2 text-gaming-warning">
              <AlertTriangle className="h-4 w-4" />
              <span className="text-sm">تغییرات ذخیره نشده</span>
            </div>
          )}
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={resetSettings}
            disabled={!hasChanges}
          >
            <RefreshCw className="h-4 w-4 ml-2" />
            بازنشانی
          </Button>
          
          <Button 
            size="sm"
            onClick={saveSettings}
            disabled={!hasChanges}
          >
            <Save className="h-4 w-4 ml-2" />
            ذخیره تغییرات
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 w-full">
          {settingsTabs.map(tab => {
            const Icon = tab.icon;
            return (
              <TabsTrigger key={tab.id} value={tab.id} className="flex items-center space-x-2">
                <Icon className="h-4 w-4" />
                <span className="hidden md:inline">{tab.label}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {/* Account Settings */}
        <TabsContent value="account" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>اطلاعات حساب کاربری</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Profile Section */}
              <div className="flex items-center space-x-4" dir="rtl">
                <Avatar className="h-20 w-20">
                  <AvatarImage src="https://images.unsplash.com/photo-1622349851524-890cc3641b87?w=150&h=150&fit=crop&crop=face" />
                  <AvatarFallback>GP</AvatarFallback>
                </Avatar>
                
                <div className="flex-1 space-y-2">
                  <div className="flex items-center space-x-2" dir="rtl">
                    <h3 className="text-lg font-medium">{settings.username}</h3>
                    {settings.isVerified && (
                      <Badge variant="secondary" className="text-xs">
                        <Check className="h-3 w-3 ml-1" />
                        تایید شده
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{settings.email}</p>
                  
                  <div className="flex space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Edit3 className="h-4 w-4 ml-2" />
                          ویرایش پروفایل
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>ویرایش پروفایل</DialogTitle>
                          <DialogDescription>
                            اطلاعات پروفایل خود را ویرایش کنید
                          </DialogDescription>
                        </DialogHeader>
                        
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="username">نام کاربری</Label>
                            <Input
                              id="username"
                              value={settings.username}
                              onChange={(e) => updateSetting('username', e.target.value)}
                              dir="rtl"
                              className="text-right"
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="bio">بیوگرافی</Label>
                            <Textarea
                              id="bio"
                              value={settings.bio}
                              onChange={(e) => updateSetting('bio', e.target.value)}
                              placeholder="درباره خود بنویسید..."
                              dir="rtl"
                              className="text-right"
                            />
                          </div>
                        </div>
                        
                        <DialogFooter>
                          <Button onClick={saveSettings}>ذخیره</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                    
                    <Button variant="outline" size="sm">
                      <Camera className="h-4 w-4 ml-2" />
                      تغییر عکس
                    </Button>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              {/* Bio */}
              <div>
                <Label>بیوگرافی</Label>
                <p className="text-sm text-muted-foreground mt-1">{settings.bio}</p>
              </div>
              
              {/* Account Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-card rounded-lg">
                  <div className="text-2xl font-bold text-primary">156</div>
                  <div className="text-sm text-muted-foreground">دنبال‌کننده</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <div className="text-2xl font-bold text-accent">42</div>
                  <div className="text-sm text-muted-foreground">دنبال شده</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <div className="text-2xl font-bold text-gaming-warning">28</div>
                  <div className="text-sm text-muted-foreground">بازی</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <div className="text-2xl font-bold text-gaming-error">12</div>
                  <div className="text-sm text-muted-foreground">مسابقه</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Security */}
          <Card>
            <CardHeader>
              <CardTitle>امنیت حساب</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>تایید دو مرحله‌ای</Label>
                  <p className="text-sm text-muted-foreground">افزایش امنیت حساب</p>
                </div>
                <Switch />
              </div>
              
              <Button variant="outline" className="w-full">
                <Lock className="h-4 w-4 ml-2" />
                تغییر رمز عبور
              </Button>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full">
                    <Trash2 className="h-4 w-4 ml-2" />
                    حذف حساب کاربری
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>حذف حساب کاربری</AlertDialogTitle>
                    <AlertDialogDescription>
                      آیا مطمئن هستید؟ این عمل قابل بازگشت نیست و تمام اطلاعات شما حذف خواهد شد.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>انصراف</AlertDialogCancel>
                    <AlertDialogAction className="bg-destructive">حذف حساب</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Display Settings */}
        <TabsContent value="display" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات نمایش</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Theme */}
              <div className="space-y-3">
                <Label>تم</Label>
                <Select value={settings.theme} onValueChange={(value) => updateSetting('theme', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dark">
                      <div className="flex items-center space-x-2">
                        <Moon className="h-4 w-4" />
                        <span>تاریک</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="light">
                      <div className="flex items-center space-x-2">
                        <Sun className="h-4 w-4" />
                        <span>روشن</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="auto">
                      <div className="flex items-center space-x-2">
                        <Monitor className="h-4 w-4" />
                        <span>خودکار</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Language */}
              <div className="space-y-3">
                <Label>زبان</Label>
                <Select value={settings.language} onValueChange={(value) => updateSetting('language', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fa">فارسی</SelectItem>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="ar">العربية</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Font Size */}
              <div className="space-y-3">
                <Label>اندازه متن: {settings.fontSize}px</Label>
                <Slider
                  value={[settings.fontSize]}
                  onValueChange={(value) => updateSetting('fontSize', value[0])}
                  min={12}
                  max={18}
                  step={1}
                  className="w-full"
                />
              </div>
              
              {/* Animations */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>انیمیشن‌ها</Label>
                  <p className="text-sm text-muted-foreground">نمایش انیمیشن‌ها و جلوه‌های بصری</p>
                </div>
                <Switch 
                  checked={settings.animations} 
                  onCheckedChange={(checked) => updateSetting('animations', checked)}
                />
              </div>
              
              {/* Reduced Motion */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>کاهش حرکت</Label>
                  <p className="text-sm text-muted-foreground">کاهش انیمیشن‌ها برای بهبود عملکرد</p>
                </div>
                <Switch 
                  checked={settings.reducedMotion} 
                  onCheckedChange={(checked) => updateSetting('reducedMotion', checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications" className="space-y-6">
          <NotificationSettingsSection />
        </TabsContent>

        {/* Gaming Settings */}
        <TabsContent value="gaming" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات گیمینگ</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label>بازی متقابل</Label>
                  <p className="text-sm text-muted-foreground">بازی با سایر پلتفرم‌ها</p>
                </div>
                <Switch 
                  checked={settings.crossplay} 
                  onCheckedChange={(checked) => updateSetting('crossplay', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>چت صوتی</Label>
                  <p className="text-sm text-muted-foreground">فعال‌سازی میکروفون در بازی</p>
                </div>
                <Switch 
                  checked={settings.voiceChat} 
                  onCheckedChange={(checked) => updateSetting('voiceChat', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Game Overlay</Label>
                  <p className="text-sm text-muted-foreground">نمایش اطلاعات حین بازی</p>
                </div>
                <Switch 
                  checked={settings.gameOverlay} 
                  onCheckedChange={(checked) => updateSetting('gameOverlay', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>حالت کارایی</Label>
                  <p className="text-sm text-muted-foreground">بهینه‌سازی برای عملکرد بهتر</p>
                </div>
                <Switch 
                  checked={settings.performanceMode} 
                  onCheckedChange={(checked) => updateSetting('performanceMode', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>ضبط خودکار</Label>
                  <p className="text-sm text-muted-foreground">ضبط خودکار بهترین لحظات</p>
                </div>
                <Switch 
                  checked={settings.autoRecord} 
                  onCheckedChange={(checked) => updateSetting('autoRecord', checked)}
                />
              </div>
            </CardContent>
          </Card>
          
          {/* Gaming Stats */}
          <Card>
            <CardHeader>
              <CardTitle>آمار گیمینگ</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-card rounded-lg">
                  <div className="text-2xl font-bold text-primary">124</div>
                  <div className="text-sm text-muted-foreground">ساعت بازی</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <div className="text-2xl font-bold text-accent">87%</div>
                  <div className="text-sm text-muted-foreground">نرخ برد</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <div className="text-2xl font-bold text-gaming-warning">1847</div>
                  <div className="text-sm text-muted-foreground">امتیاز</div>
                </div>
                <div className="text-center p-4 bg-card rounded-lg">
                  <div className="text-2xl font-bold text-gaming-error">15</div>
                  <div className="text-sm text-muted-foreground">رتبه</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Privacy Settings */}
        <TabsContent value="privacy" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات حریم خصوصی</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>قابلیت مشاهده پروفایل</Label>
                <Select 
                  value={settings.profileVisibility} 
                  onValueChange={(value) => updateSetting('profileVisibility', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">عمومی</SelectItem>
                    <SelectItem value="friends">فقط دوستان</SelectItem>
                    <SelectItem value="private">خصوصی</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>نمایش وضعیت آنلاین</Label>
                  <p className="text-sm text-muted-foreground">نمایش آنلاین بودن به دیگران</p>
                </div>
                <Switch 
                  checked={settings.showOnlineStatus} 
                  onCheckedChange={(checked) => updateSetting('showOnlineStatus', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>اجازه پیام مستقیم</Label>
                  <p className="text-sm text-muted-foreground">دریافت پیام از سایر کاربران</p>
                </div>
                <Switch 
                  checked={settings.allowDirectMessages} 
                  onCheckedChange={(checked) => updateSetting('allowDirectMessages', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>اجازه دعوت به بازی</Label>
                  <p className="text-sm text-muted-foreground">دریافت دعوت به لابی و مسابقات</p>
                </div>
                <Switch 
                  checked={settings.allowGameInvites} 
                  onCheckedChange={(checked) => updateSetting('allowGameInvites', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>اشتراک‌گذاری آمار</Label>
                  <p className="text-sm text-muted-foreground">نمایش آمار بازی به دیگران</p>
                </div>
                <Switch 
                  checked={settings.shareStats} 
                  onCheckedChange={(checked) => updateSetting('shareStats', checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Streaming Settings */}
        <TabsContent value="streaming" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات استریم</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>کیفیت استریم</Label>
                <Select 
                  value={settings.streamQuality} 
                  onValueChange={(value) => updateSetting('streamQuality', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="720p">HD (720p)</SelectItem>
                    <SelectItem value="1080p">Full HD (1080p)</SelectItem>
                    <SelectItem value="1440p">2K (1440p)</SelectItem>
                    <SelectItem value="4k">4K</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-3">
                <Label>صدای میکروفون: {settings.micVolume}%</Label>
                <Slider
                  value={[settings.micVolume]}
                  onValueChange={(value) => updateSetting('micVolume', value[0])}
                  min={0}
                  max={100}
                  step={5}
                  className="w-full"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>دوربین</Label>
                  <p className="text-sm text-muted-foreground">فعال‌سازی دوربین در استریم</p>
                </div>
                <Switch 
                  checked={settings.cameraEnabled} 
                  onCheckedChange={(checked) => updateSetting('cameraEnabled', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>مدیریت چت</Label>
                  <p className="text-sm text-muted-foreground">فیلتر خودکار پیام‌های نامناسب</p>
                </div>
                <Switch 
                  checked={settings.chatModeration} 
                  onCheckedChange={(checked) => updateSetting('chatModeration', checked)}
                />
              </div>
              
              <Button className="w-full">
                <Camera className="h-4 w-4 ml-2" />
                تست دوربین و میکروفون
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Financial Settings */}
        <TabsContent value="financial" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات مالی</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Wallet Balance */}
              <div className="p-4 bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">موجودی کیف پول</span>
                  <Wallet className="h-5 w-5 text-primary" />
                </div>
                <div className="text-2xl font-bold">{formatCurrency(2450000)}</div>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>شارژ خودکار</Label>
                  <p className="text-sm text-muted-foreground">شارژ خودکار کیف پول در صورت کم بودن موجودی</p>
                </div>
                <Switch 
                  checked={settings.autoTopUp} 
                  onCheckedChange={(checked) => updateSetting('autoTopUp', checked)}
                />
              </div>
              
              <div className="space-y-3">
                <Label>حد خرج روزانه: {formatCurrency(settings.spendingLimit)}</Label>
                <Slider
                  value={[settings.spendingLimit]}
                  onValueChange={(value) => updateSetting('spendingLimit', value[0])}
                  min={100000}
                  max={5000000}
                  step={100000}
                  className="w-full"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>اعلان تراکنش‌ها</Label>
                  <p className="text-sm text-muted-foreground">اطلاع‌رسانی خرید و فروش</p>
                </div>
                <Switch 
                  checked={settings.transactionNotifications} 
                  onCheckedChange={(checked) => updateSetting('transactionNotifications', checked)}
                />
              </div>
              
              <div className="flex space-x-2">
                <Button variant="outline" className="flex-1">
                  <Download className="h-4 w-4 ml-2" />
                  گزارش تراکنش‌ها
                </Button>
                <Button variant="outline" className="flex-1">
                  <CreditCard className="h-4 w-4 ml-2" />
                  کارت‌های بانکی
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Accessibility */}
        <TabsContent value="accessibility" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات دسترسی</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>اندازه متن: {settings.fontSize}px</Label>
                <Slider
                  value={[settings.fontSize]}
                  onValueChange={(value) => updateSetting('fontSize', value[0])}
                  min={12}
                  max={24}
                  step={2}
                  className="w-full"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>کاهش حرکت</Label>
                  <p className="text-sm text-muted-foreground">کاهش انیمیشن‌ها و جلوه‌های بصری</p>
                </div>
                <Switch 
                  checked={settings.reducedMotion} 
                  onCheckedChange={(checked) => updateSetting('reducedMotion', checked)}
                />
              </div>
              
              <Button variant="outline" className="w-full">
                <Volume2 className="h-4 w-4 ml-2" />
                تنظیمات صوتی
              </Button>
              
              <Button variant="outline" className="w-full">
                <Eye className="h-4 w-4 ml-2" />
                تنظیمات بصری
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* About */}
        <TabsContent value="about" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>درباره گیم‌هاب</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center space-y-4">
                <div className="text-6xl font-bold text-primary">GH</div>
                <div>
                  <h3 className="text-xl font-bold">گیم‌هاب</h3>
                  <p className="text-muted-foreground">نسخه 1.0.0</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <Button variant="outline" className="w-full">
                  <HelpCircle className="h-4 w-4 ml-2" />
                  راهنما و پشتیبانی
                </Button>
                
                <Button variant="outline" className="w-full">
                  <Info className="h-4 w-4 ml-2" />
                  شرایط استفاده
                </Button>
                
                <Button variant="outline" className="w-full">
                  <Shield className="h-4 w-4 ml-2" />
                  حریم خصوصی
                </Button>
                
                <Button variant="outline" className="w-full">
                  <Globe className="h-4 w-4 ml-2" />
                  وب‌سایت رسمی
                </Button>
              </div>
              
              <Separator />
              
              <Button variant="destructive" className="w-full">
                <LogOut className="h-4 w-4 ml-2" />
                خروج از حساب
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}