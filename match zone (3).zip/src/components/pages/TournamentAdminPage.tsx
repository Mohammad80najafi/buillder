/**
 * Tournament Admin Page - مرحله 4 سیستم طراحی
 * صفحه مدیریت پیشرفته تورنومنت‌ها برای ادمین‌ها
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Alert, AlertDescription } from '../ui/alert';
import { Progress } from '../ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  Settings, Trophy, Users, Calendar, DollarSign, BarChart3,
  Play, Pause, Square, Eye, Edit3, Trash2, Plus, Search,
  Filter, Download, Share2, AlertTriangle, CheckCircle,
  XCircle, Crown, Target, Zap, TrendingUp, TrendingDown,
  Clock, Globe, Shield, Flag, Award, Star, Gamepad2,
  Camera, Mic, MessageSquare, Headphones, Volume2,
  RefreshCw, ExternalLink, Copy, Mail, Bell, Activity
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion, AnimatePresence } from 'motion/react';

// Import tournament components
import { TournamentCreation, TournamentCreationData } from '../tournaments/TournamentCreation';
import { TournamentManagement, TournamentManagementData } from '../tournaments/TournamentManagement';
import { TournamentAnalytics, TournamentAnalyticsData } from '../tournaments/TournamentAnalytics';
import { TournamentStream } from '../tournaments/TournamentStream';

export interface TournamentSummary {
  id: string;
  title: string;
  game: string;
  status: 'registration' | 'starting' | 'live' | 'paused' | 'finished' | 'cancelled';
  participants: number;
  maxParticipants: number;
  entryFee: number;
  prizePool: number;
  startTime: string;
  organizer: string;
  priority: 'high' | 'medium' | 'low';
  featured: boolean;
  revenue: number;
  viewers: number;
  issues: number;
}

export interface AdminStats {
  totalTournaments: number;
  activeTournaments: number;
  totalParticipants: number;
  totalRevenue: number;
  averageParticipants: number;
  completionRate: number;
  issuesResolved: number;
  customerSatisfaction: number;
  growthRate: number;
  platformHealth: number;
}

export interface SystemNotification {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title: string;
  message: string;
  tournamentId?: string;
  timestamp: string;
  resolved: boolean;
  priority: 'high' | 'medium' | 'low';
}

const MOCK_TOURNAMENTS: TournamentSummary[] = [
  {
    id: '1',
    title: 'کاپ طلایی کالاف دیوتی',
    game: 'Call of Duty',
    status: 'live',
    participants: 128,
    maxParticipants: 128,
    entryFee: 50000,
    prizePool: 5000000,
    startTime: '1403/09/15 20:00',
    organizer: 'MatchZone Pro',
    priority: 'high',
    featured: true,
    revenue: 6400000,
    viewers: 2840,
    issues: 0
  },
  {
    id: '2',
    title: 'لیگ والورانت نوآوران',
    game: 'Valorant',
    status: 'registration',
    participants: 45,
    maxParticipants: 64,
    entryFee: 25000,
    prizePool: 1500000,
    startTime: '1403/09/20 19:00',
    organizer: 'Gaming Elite',
    priority: 'medium',
    featured: false,
    revenue: 1125000,
    viewers: 0,
    issues: 1
  },
  {
    id: '3',
    title: 'چمپیونشیپ فیفا ایران',
    game: 'FIFA 24',
    status: 'finished',
    participants: 32,
    maxParticipants: 32,
    entryFee: 100000,
    prizePool: 3000000,
    startTime: '1403/09/10 16:00',
    organizer: 'Iran Esports',
    priority: 'high',
    featured: true,
    revenue: 3200000,
    viewers: 1650,
    issues: 2
  }
];

const MOCK_ADMIN_STATS: AdminStats = {
  totalTournaments: 147,
  activeTournaments: 12,
  totalParticipants: 8432,
  totalRevenue: 890000000,
  averageParticipants: 57,
  completionRate: 94.2,
  issuesResolved: 98,
  customerSatisfaction: 4.7,
  growthRate: 23.5,
  platformHealth: 96
};

const MOCK_NOTIFICATIONS: SystemNotification[] = [
  {
    id: '1',
    type: 'error',
    title: 'خطای پرداخت',
    message: 'مشکل در پردازش پرداخت تورنومنت "لیگ والورانت نوآوران"',
    tournamentId: '2',
    timestamp: '10 دقیقه پیش',
    resolved: false,
    priority: 'high'
  },
  {
    id: '2',
    type: 'warning',
    title: 'کمبود ظرفیت سرور',
    message: 'سرورهای بازی در حال رسیدن به حد ظرفیت',
    timestamp: '25 دقیقه پیش',
    resolved: false,
    priority: 'medium'
  },
  {
    id: '3',
    type: 'info',
    title: 'تورنومنت جدید ثبت شد',
    message: 'تورنومنت "کاپ نقره‌ای پابجی" منتظر تایید',
    timestamp: '1 ساعت پیش',
    resolved: true,
    priority: 'low'
  }
];

export function TournamentAdminPage() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedTournament, setSelectedTournament] = useState<TournamentSummary | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [notifications, setNotifications] = useState<SystemNotification[]>(MOCK_NOTIFICATIONS);
  const [adminStats, setAdminStats] = useState<AdminStats>(MOCK_ADMIN_STATS);
  const [tournaments, setTournaments] = useState<TournamentSummary[]>(MOCK_TOURNAMENTS);
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Auto refresh data
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      // Simulate real-time updates
      setAdminStats(prev => ({
        ...prev,
        activeTournaments: prev.activeTournaments + Math.floor(Math.random() * 3) - 1,
        totalParticipants: prev.totalParticipants + Math.floor(Math.random() * 10) - 5
      }));
    }, 10000);

    return () => clearInterval(interval);
  }, [autoRefresh]);

  const filteredTournaments = tournaments.filter(tournament => {
    const matchesSearch = tournament.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         tournament.game.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || tournament.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || tournament.priority === priorityFilter;
    
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'registration': return 'bg-blue-500/20 text-blue-400 border-blue-500/50';
      case 'starting': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      case 'live': return 'bg-green-500/20 text-green-400 border-green-500/50';
      case 'paused': return 'bg-orange-500/20 text-orange-400 border-orange-500/50';
      case 'finished': return 'bg-purple-500/20 text-purple-400 border-purple-500/50';
      case 'cancelled': return 'bg-red-500/20 text-red-400 border-red-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500/20 text-red-400 border-red-500/50';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      case 'low': return 'bg-green-500/20 text-green-400 border-green-500/50';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/50';
    }
  };

  const handleTournamentAction = async (tournamentId: string, action: string) => {
    try {
      switch (action) {
        case 'start':
          toast.success('تورنومنت شروع شد');
          break;
        case 'pause':
          toast.success('تورنومنت متوقف شد');
          break;
        case 'cancel':
          toast.success('تورنومنت لغو شد');
          break;
        case 'feature':
          toast.success('تورنومنت به لیست ویژه اضافه شد');
          break;
        case 'delete':
          toast.success('تورنومنت حذف شد');
          setTournaments(prev => prev.filter(t => t.id !== tournamentId));
          break;
        default:
          break;
      }
    } catch (error) {
      toast.error('خطا در انجام عملیات');
    }
  };

  const resolveNotification = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === notificationId ? { ...notif, resolved: true } : notif
      )
    );
    toast.success('اعلان حل شد');
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-500/20 rounded-lg">
                <Crown className="w-8 h-8 text-purple-400" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">پنل مدیریت تورنومنت‌ها</h1>
                <p className="text-muted-foreground">
                  مدیریت پیشرفته و نظارت بر تمام تورنومنت‌های پلتفرم
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={autoRefresh ? 'bg-green-500/10' : ''}
              >
                <RefreshCw className={`w-4 h-4 ml-2 ${autoRefresh ? 'animate-spin' : ''}`} />
                تازه‌سازی خودکار
              </Button>
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="w-4 h-4 ml-2" />
                تورنومنت جدید
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* System Alerts */}
      {notifications.filter(n => !n.resolved && n.priority === 'high').length > 0 && (
        <Alert className="border-red-500/50 bg-red-500/10">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {notifications.filter(n => !n.resolved && n.priority === 'high').length} اعلان فوری نیاز به توجه دارد
          </AlertDescription>
        </Alert>
      )}

      {/* Main Dashboard */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="dashboard">داشبورد</TabsTrigger>
          <TabsTrigger value="tournaments">تورنومنت‌ها</TabsTrigger>
          <TabsTrigger value="analytics">آنالیز</TabsTrigger>
          <TabsTrigger value="notifications">اعلان‌ها</TabsTrigger>
          <TabsTrigger value="settings">تنظیمات</TabsTrigger>
          <TabsTrigger value="reports">گزارشات</TabsTrigger>
        </TabsList>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Key Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {adminStats.totalTournaments.toLocaleString()}
                  </div>
                  <div className="text-sm text-muted-foreground">کل تورنومنت‌ها</div>
                  <div className="text-xs text-green-500 flex items-center justify-center gap-1 mt-1">
                    <TrendingUp className="w-3 h-3" />
                    +{adminStats.growthRate}%
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {adminStats.activeTournaments}
                  </div>
                  <div className="text-sm text-muted-foreground">تورنومنت‌های فعال</div>
                  <div className="text-xs text-blue-500 mt-1">
                    در حال اجرا
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-purple-500">
                    {adminStats.totalParticipants.toLocaleString()}
                  </div>
                  <div className="text-sm text-muted-foreground">شرکت‌کنندگان</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    میانگین: {adminStats.averageParticipants}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-500">
                    {(adminStats.totalRevenue / 1000000).toFixed(1)}M
                  </div>
                  <div className="text-sm text-muted-foreground">درآمد (تومان)</div>
                  <div className="text-xs text-green-500 flex items-center justify-center gap-1 mt-1">
                    <TrendingUp className="w-3 h-3" />
                    +15.2%
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-red-500">
                    {adminStats.platformHealth}%
                  </div>
                  <div className="text-sm text-muted-foreground">سلامت پلتفرم</div>
                  <div className="text-xs text-green-500 mt-1">
                    وضعیت عالی
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Live Tournaments */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-red-500" />
                    تورنومنت‌های زنده
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {tournaments.filter(t => t.status === 'live').map((tournament) => (
                    <div key={tournament.id} className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{tournament.title}</div>
                          <div className="text-sm text-muted-foreground flex items-center gap-2">
                            <Users className="w-3 h-3" />
                            {tournament.participants} نفر
                            <Eye className="w-3 h-3" />
                            {tournament.viewers} تماشاگر
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 ml-1" />
                            مدیریت
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* System Notifications */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5" />
                    اعلان‌های سیستم
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {notifications.filter(n => !n.resolved).slice(0, 4).map((notification) => (
                    <div key={notification.id} className={`p-3 rounded-lg border ${
                      notification.type === 'error' ? 'bg-red-500/10 border-red-500/20' :
                      notification.type === 'warning' ? 'bg-yellow-500/10 border-yellow-500/20' :
                      'bg-blue-500/10 border-blue-500/20'
                    }`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="font-medium text-sm">{notification.title}</div>
                          <div className="text-xs text-muted-foreground">{notification.message}</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {notification.timestamp}
                          </div>
                        </div>
                        <Button size="sm" variant="ghost" onClick={() => resolveNotification(notification.id)}>
                          <CheckCircle className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-muted-foreground">نرخ تکمیل</div>
                      <div className="text-2xl font-bold">{adminStats.completionRate}%</div>
                    </div>
                    <Trophy className="w-8 h-8 text-yellow-500" />
                  </div>
                  <Progress value={adminStats.completionRate} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-muted-foreground">رضایت کاربران</div>
                      <div className="text-2xl font-bold">{adminStats.customerSatisfaction}/5</div>
                    </div>
                    <Star className="w-8 h-8 text-yellow-500" />
                  </div>
                  <Progress value={adminStats.customerSatisfaction * 20} className="mt-2" />
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm text-muted-foreground">مسائل حل شده</div>
                      <div className="text-2xl font-bold">{adminStats.issuesResolved}</div>
                    </div>
                    <Shield className="w-8 h-8 text-green-500" />
                  </div>
                  <div className="text-xs text-green-500 mt-1">98.5% نرخ حل</div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        </TabsContent>

        {/* Tournaments Management Tab */}
        <TabsContent value="tournaments" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="w-5 h-5" />
                    مدیریت تورنومنت‌ها ({filteredTournaments.length})
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 ml-2" />
                      خروجی
                    </Button>
                    <Button onClick={() => setShowCreateDialog(true)}>
                      <Plus className="w-4 h-4 ml-2" />
                      تورنومنت جدید
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Filters */}
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="جستجوی نام تورنومنت یا بازی..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                      <SelectItem value="registration">ثبت‌نام</SelectItem>
                      <SelectItem value="live">زنده</SelectItem>
                      <SelectItem value="finished">تمام شده</SelectItem>
                      <SelectItem value="cancelled">لغو شده</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">همه اولویت‌ها</SelectItem>
                      <SelectItem value="high">بالا</SelectItem>
                      <SelectItem value="medium">متوسط</SelectItem>
                      <SelectItem value="low">پایین</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Tournaments List */}
                <div className="space-y-3">
                  {filteredTournaments.map((tournament) => (
                    <Card key={tournament.id} className="border">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="p-2 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-lg">
                              <Gamepad2 className="w-6 h-6 text-purple-400" />
                            </div>
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <h3 className="font-semibold">{tournament.title}</h3>
                                {tournament.featured && (
                                  <Badge className="bg-yellow-500/20 text-yellow-400">
                                    <Star className="w-3 h-3 ml-1" />
                                    ویژه
                                  </Badge>
                                )}
                                <Badge className={getPriorityColor(tournament.priority)}>
                                  {tournament.priority === 'high' ? 'بالا' : 
                                   tournament.priority === 'medium' ? 'متوسط' : 'پایین'}
                                </Badge>
                              </div>
                              <div className="text-sm text-muted-foreground flex items-center gap-4">
                                <span>{tournament.game}</span>
                                <span className="flex items-center gap-1">
                                  <Users className="w-3 h-3" />
                                  {tournament.participants}/{tournament.maxParticipants}
                                </span>
                                <span className="flex items-center gap-1">
                                  <DollarSign className="w-3 h-3" />
                                  {tournament.prizePool.toLocaleString()} تومان
                                </span>
                                <span className="flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  {tournament.startTime}
                                </span>
                                {tournament.issues > 0 && (
                                  <span className="flex items-center gap-1 text-red-500">
                                    <AlertTriangle className="w-3 h-3" />
                                    {tournament.issues} مسئله
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <Badge className={getStatusColor(tournament.status)}>
                              {tournament.status === 'registration' ? 'ثبت‌نام' :
                               tournament.status === 'starting' ? 'شروع' :
                               tournament.status === 'live' ? 'زنده' :
                               tournament.status === 'paused' ? 'متوقف' :
                               tournament.status === 'finished' ? 'تمام' : 'لغو'}
                            </Badge>

                            <div className="flex gap-1">
                              {tournament.status === 'live' && (
                                <Button size="sm" variant="outline">
                                  <Eye className="w-3 h-3 ml-1" />
                                  مشاهده زنده
                                </Button>
                              )}
                              
                              <Button size="sm" variant="outline">
                                <Edit3 className="w-3 h-3" />
                              </Button>

                              {tournament.status !== 'finished' && (
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => handleTournamentAction(tournament.id, 'feature')}
                                >
                                  <Star className="w-3 h-3" />
                                </Button>
                              )}

                              <Button 
                                size="sm" 
                                variant="destructive"
                                onClick={() => handleTournamentAction(tournament.id, 'delete')}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </div>

                        {/* Tournament metrics */}
                        <div className="mt-3 pt-3 border-t border-border/50">
                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-4">
                              <span className="flex items-center gap-1">
                                <Eye className="w-3 h-3" />
                                {tournament.viewers.toLocaleString()} تماشاگر
                              </span>
                              <span className="flex items-center gap-1">
                                <DollarSign className="w-3 h-3" />
                                درآمد: {tournament.revenue.toLocaleString()} تومان
                              </span>
                              <span className="text-muted-foreground">
                                برگزار کننده: {tournament.organizer}
                              </span>
                            </div>
                            <div className="text-xs text-muted-foreground">
                              آخرین بروزرسانی: 2 دقیقه پیش
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Analytics Tab - Placeholder */}
        <TabsContent value="analytics" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  آنالیز پلتفرم
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center py-12">
                <div className="space-y-2">
                  <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto" />
                  <p className="text-muted-foreground">
                    صفحه آنالیز جامع در حال توسعه است
                  </p>
                  <p className="text-sm text-muted-foreground">
                    نمودارهای تعاملی، گزارشات تفصیلی، و تحلیل‌های پیشرفته
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  مدیریت اعلان‌ها
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {notifications.map((notification) => (
                  <div key={notification.id} className={`p-4 rounded-lg border ${
                    notification.type === 'error' ? 'bg-red-500/10 border-red-500/20' :
                    notification.type === 'warning' ? 'bg-yellow-500/10 border-yellow-500/20' :
                    notification.type === 'success' ? 'bg-green-500/10 border-green-500/20' :
                    'bg-blue-500/10 border-blue-500/20'
                  } ${notification.resolved ? 'opacity-50' : ''}`}>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${
                          notification.type === 'error' ? 'bg-red-500/20' :
                          notification.type === 'warning' ? 'bg-yellow-500/20' :
                          notification.type === 'success' ? 'bg-green-500/20' :
                          'bg-blue-500/20'
                        }`}>
                          {notification.type === 'error' && <XCircle className="w-4 h-4 text-red-400" />}
                          {notification.type === 'warning' && <AlertTriangle className="w-4 h-4 text-yellow-400" />}
                          {notification.type === 'success' && <CheckCircle className="w-4 h-4 text-green-400" />}
                          {notification.type === 'info' && <Bell className="w-4 h-4 text-blue-400" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{notification.title}</h3>
                            <Badge className={getPriorityColor(notification.priority)}>
                              {notification.priority === 'high' ? 'فوری' :
                               notification.priority === 'medium' ? 'عادی' : 'کم اهمیت'}
                            </Badge>
                            {notification.resolved && (
                              <Badge className="bg-green-500/20 text-green-400">
                                حل شده
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{notification.message}</p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                            <span>{notification.timestamp}</span>
                            {notification.tournamentId && (
                              <span>تورنومنت #{notification.tournamentId}</span>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      {!notification.resolved && (
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => resolveNotification(notification.id)}>
                            <CheckCircle className="w-3 h-3 ml-1" />
                            حل شد
                          </Button>
                          {notification.tournamentId && (
                            <Button size="sm" variant="outline">
                              <ExternalLink className="w-3 h-3 ml-1" />
                              مشاهده
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* Settings & Reports tabs - Placeholder */}
        <TabsContent value="settings">
          <Card>
            <CardContent className="text-center py-12">
              <Settings className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">تنظیمات سیستم در حال توسعه است</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardContent className="text-center py-12">
              <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">سیستم گزارشات در حال توسعه است</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Create Tournament Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>ایجاد تورنومنت جدید</DialogTitle>
          </DialogHeader>
          <TournamentCreation
            onSubmit={async (data) => {
              // Handle tournament creation
              toast.success('تورنومنت با موفقیت ایجاد شد');
              setShowCreateDialog(false);
            }}
            onDraft={(data) => {
              toast.success('پیش‌نویس ذخیره شد');
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default TournamentAdminPage;