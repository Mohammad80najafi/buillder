/**
 * Component Test Page
 * صفحه تست کامپوننت‌های اصلی
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { 
  Calendar as CalendarIcon,
  Users,
  Bell,
  CheckCircle,
  AlertTriangle,
  TestTube,
  Timer,
  MessageCircle,
  Shield
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export const ComponentTestPage: React.FC = () => {
  const [testResults, setTestResults] = useState<string[]>([]);

  const addTestResult = (result: string) => {
    setTestResults(prev => [...prev, `${new Date().toLocaleTimeString('fa-IR')}: ${result}`]);
  };

  const testPersianCalendar = async () => {
    try {
      // Import and test Persian Calendar
      const { PersianCalendar } = await import('../calendar/PersianCalendar');
      addTestResult('✅ PersianCalendar import موفق');
      toast.success('تست تقویم جلالی موفق');
    } catch (error) {
      addTestResult(`❌ PersianCalendar import ناموفق: ${error.message}`);
      toast.error('خطا در تست تقویم جلالی');
      console.error('PersianCalendar test error:', error);
    }
  };

  const testFriendInviteSystem = async () => {
    try {
      // Import and test Friend Invite System
      const { FriendInviteSystem } = await import('../friends/FriendInviteSystem');
      addTestResult('✅ FriendInviteSystem import موفق');
      toast.success('تست سیستم دعوت دوستان موفق');
    } catch (error) {
      addTestResult(`❌ FriendInviteSystem import ناموفق: ${error.message}`);
      toast.error('خطا در تست سیستم دعوت دوستان');
      console.error('FriendInviteSystem test error:', error);
    }
  };

  const testLobbyInviteNotifications = async () => {
    try {
      // Import and test Lobby Invite Notifications
      const { LobbyInviteNotifications } = await import('../notifications/LobbyInviteNotifications');
      addTestResult('✅ LobbyInviteNotifications import موفق');
      toast.success('تست سیستم اعلان‌ها موفق');
    } catch (error) {
      addTestResult(`❌ LobbyInviteNotifications import ناموفق: ${error.message}`);
      toast.error('خطا در تست سیستم اعلان‌ها');
      console.error('LobbyInviteNotifications test error:', error);
    }
  };

  const testCountdownTimer = async () => {
    try {
      // Import and test Countdown Timer
      const { LobbyCountdownTimer } = await import('../gaming/LobbyCountdownTimer');
      addTestResult('✅ LobbyCountdownTimer import موفق');
      toast.success('تست تایمر لابی موفق');
    } catch (error) {
      addTestResult(`❌ LobbyCountdownTimer import ناموفق: ${error.message}`);
      toast.error('خطا در تست تایمر لابی');
      console.error('LobbyCountdownTimer test error:', error);
    }
  };

  const testLobbyChatSystem = async () => {
    try {
      // Import and test Lobby Chat System
      const { LobbyChatSystem } = await import('../gaming/LobbyChatSystem');
      addTestResult('✅ LobbyChatSystem import موفق');
      toast.success('تست سیستم چت لابی موفق');
    } catch (error) {
      addTestResult(`❌ LobbyChatSystem import ناموفق: ${error.message}`);
      toast.error('خطا در تست سیستم چت لابی');
      console.error('LobbyChatSystem test error:', error);
    }
  };

  const testClanChatSystem = async () => {
    try {
      // Import and test Clan Chat System
      const { ClanChatSystem } = await import('../clans/ClanChatSystem');
      addTestResult('✅ ClanChatSystem import موفق');
      toast.success('تست سیستم چت کلن موفق');
    } catch (error) {
      addTestResult(`❌ ClanChatSystem import ناموفق: ${error.message}`);
      toast.error('خطا در تست سیستم چت کلن');
      console.error('ClanChatSystem test error:', error);
    }
  };

  const testPersianUtils = async () => {
    try {
      // Import and test Persian utils
      const utils = await import('../../utils/persianCalendar');
      const { PersianDate, formatPersianDate, isToday, isTomorrow } = utils;
      
      // Test PersianDate
      const today = new PersianDate();
      addTestResult(`✅ PersianDate ایجاد شد: ${today.format()}`);
      
      // Test utilities
      const todayTest = isToday(new Date());
      addTestResult(`✅ isToday test: ${todayTest}`);
      
      const formatted = formatPersianDate(new Date());
      addTestResult(`✅ formatPersianDate: ${formatted}`);
      
      toast.success('تست یونیت‌های تقویم جلالی موفق');
    } catch (error) {
      addTestResult(`❌ Persian utils test ناموفق: ${error.message}`);
      toast.error('خطا در تست یونیت‌های تقویم جلالی');
      console.error('Persian utils test error:', error);
    }
  };

  const runAllTests = async () => {
    setTestResults([]);
    addTestResult('شروع تست‌های کامپوننت...');
    
    await testPersianUtils();
    await testPersianCalendar();
    await testFriendInviteSystem();
    await testLobbyInviteNotifications();
    await testCountdownTimer();
    await testLobbyChatSystem();
    await testClanChatSystem();
    
    addTestResult('پایان تست‌ها');
    toast.info('تمام تست‌ها اجرا شد');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-slate-800">
              <TestTube className="w-8 h-8 text-blue-400" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent">
              تست کامپوننت‌ها
            </h1>
          </div>
          <p className="text-slate-400">
            تست imports و عملکرد کامپوننت‌های اصلی
          </p>
        </motion.div>

        {/* Test Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TestTube className="w-5 h-5 text-brand-primary" />
              عملیات تست
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button
                onClick={testPersianUtils}
                variant="outline"
                className="flex items-center gap-2"
              >
                <CalendarIcon className="w-4 h-4" />
                تست یونیت‌های تقویم
              </Button>

              <Button
                onClick={testPersianCalendar}
                variant="outline"
                className="flex items-center gap-2"
              >
                <CalendarIcon className="w-4 h-4" />
                تست تقویم جلالی
              </Button>

              <Button
                onClick={testFriendInviteSystem}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Users className="w-4 h-4" />
                تست سیستم دعوت
              </Button>

              <Button
                onClick={testLobbyInviteNotifications}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Bell className="w-4 h-4" />
                تست اعلان‌ها
              </Button>

              <Button
                onClick={testCountdownTimer}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Timer className="w-4 h-4" />
                تست تایمر لابی
              </Button>

              <Button
                onClick={testLobbyChatSystem}
                variant="outline"
                className="flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                تست چت لابی
              </Button>

              <Button
                onClick={testClanChatSystem}
                variant="outline"
                className="flex items-center gap-2"
              >
                <Shield className="w-4 h-4" />
                تست چت کلن
              </Button>
            </div>

            <div className="mt-4 pt-4 border-t">
              <Button
                onClick={runAllTests}
                className="w-full flex items-center gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                اجرای تمام تست‌ها
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Test Results */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-state-warning" />
              نتایج تست
              {testResults.length > 0 && (
                <Badge variant="secondary" className="mr-auto">
                  {testResults.length} نتیجه
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {testResults.length === 0 ? (
              <div className="text-center py-8 text-text-secondary">
                <TestTube className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>هنوز تستی اجرا نشده است</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {testResults.map((result, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`p-3 rounded-lg text-sm font-mono ${
                      result.includes('✅') 
                        ? 'bg-state-success/10 text-state-success border border-state-success/20'
                        : result.includes('❌')
                        ? 'bg-state-danger/10 text-state-danger border border-state-danger/20'
                        : 'bg-surface-secondary text-text-secondary'
                    }`}
                  >
                    {result}
                  </motion.div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* System Info */}
        <Card>
          <CardHeader>
            <CardTitle>اطلاعات سیستم</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-text-secondary">تاریخ فعلی:</span>
                <p className="font-mono">{new Date().toLocaleString('fa-IR')}</p>
              </div>
              <div>
                <span className="text-text-secondary">User Agent:</span>
                <p className="font-mono text-xs truncate">{navigator.userAgent}</p>
              </div>
              <div>
                <span className="text-text-secondary">زبان مرورگر:</span>
                <p className="font-mono">{navigator.language}</p>
              </div>
              <div>
                <span className="text-text-secondary">پلتفرم:</span>
                <p className="font-mono">{navigator.platform}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};