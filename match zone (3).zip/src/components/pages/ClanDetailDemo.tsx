import React from 'react';
import { ClanDetailPage } from '../clans/ClanDetailPage';
import { Clan } from '../providers/ClanProvider';

export function ClanDetailDemo() {
  const mockClan: Clan = {
    id: 'demo-clan-1',
    name: 'شیران طلایی',
    tag: 'GOLD',
    description: 'کلن حرفه‌ای بازیکنان ایرانی با تمرکز بر رشد مهارت‌ها و کار تیمی. ما در تمام بازی‌های محبوب فعال هستیم و همیشه به دنبال اعضای جدید و با انگیزه می‌گردیم.',
    logo: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=100',
    banner: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800',
    level: 15,
    xp: 45000,
    maxXp: 50000,
    type: 'public',
    region: 'تهران',
    language: 'فارسی',
    founded: '۱۴۰۲/۰۵/۱۲',
    members: {
      current: 28,
      max: 30
    },
    requirements: {
      minLevel: 10,
      minTrophies: 1000,
      requiresApproval: false
    },
    stats: {
      rank: 15,
      totalTrophies: 125000,
      weeklyTrophies: 8500,
      wins: 342,
      losses: 89,
      winRate: 79,
      weeklyXp: 12500
    },
    leader: {
      id: 'leader-1',
      name: 'شیر_طلایی',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
      level: 67
    },
    activities: {
      activeMembers: 22,
      lastActive: '۲ ساعت پیش',
      weeklyMatches: 156,
      weeklyDonations: 890
    },
    achievements: [
      { id: 'ace', name: 'قهرمان کلن', icon: '🏆' },
      { id: 'streak', name: 'برد متوالی', icon: '🔥' },
      { id: 'social', name: 'کلن اجتماعی', icon: '👥' },
      { id: 'veteran', name: 'کهنه‌کار', icon: '⭐' }
    ],
    isJoined: false,
    createdByUser: false
  };

  const handleJoin = (clanId: string) => {
    console.log('Joining clan:', clanId);
  };

  const handleLeave = (clanId: string) => {
    console.log('Leaving clan:', clanId);
  };

  const handleBack = () => {
    console.log('Going back to clans list');
  };

  return (
    <ClanDetailPage
      clan={mockClan}
      onJoin={handleJoin}
      onLeave={handleLeave}
      onBack={handleBack}
    />
  );
}