import React, { useState, useRef, useCallback } from 'react';
import { motion } from 'motion/react';
import { 
  Send, 
  Smile, 
  Search,
  Hash,
  Users,
  ArrowLeft,
  Info,
  Phone,
  Video,
  Plus,
  Settings,
  Crown,
  Shield
} from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { useNavigation } from '../navigation/NavigationProvider';
import { useResponsive } from '../../hooks/useResponsive';

// Simple interfaces to avoid complexity
interface ChatRoom {
  id: string;
  name: string;
  type: 'lobby' | 'tournament' | 'clan' | 'dm';
  onlineCount: number;
  unreadCount?: number;
}

interface Message {
  id: string;
  content: string;
  sender: string;
  timestamp: string;
  isOwn?: boolean;
  type?: 'text' | 'system';
}

interface Member {
  id: string;
  name: string;
  role: 'admin' | 'moderator' | 'member';
  status: 'online' | 'away' | 'busy';
}

export function ResponsiveDesktopChatPage() {
  const { navigate } = useNavigation();
  const { isMobile } = useResponsive();
  const [selectedRoom, setSelectedRoom] = useState('lobby-1');
  const [message, setMessage] = useState('');
  const [showMembers, setShowMembers] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Simple static data to avoid complexity
  const rooms: ChatRoom[] = [
    { id: 'lobby-1', name: 'لابی PUBG Mobile', type: 'lobby', onlineCount: 156, unreadCount: 5 },
    { id: 'tournament-1', name: 'تورنومنت Free Fire', type: 'tournament', onlineCount: 89, unreadCount: 12 },
    { id: 'clan-1', name: 'Persian Warriors', type: 'clan', onlineCount: 23 },
    { id: 'dm-1', name: 'Shadow_Master', type: 'dm', onlineCount: 1 }
  ];

  const messages: Message[] = [
    { id: '1', content: 'سلام دوستان! لابی آماده است', sender: 'Persian_Gamer', timestamp: '14:25' },
    { id: '2', content: 'منتظر یک نفر دیگه هستیم', sender: 'Elite_Player', timestamp: '14:26' },
    { id: '3', content: 'من آمادم! الان جوین می‌کنم', sender: 'Pro_Sniper', timestamp: '14:27' },
    { id: '4', content: 'لابی پر شد - بازی شروع می‌شود', sender: 'System', timestamp: '14:28', type: 'system' },
    { id: '5', content: 'بازی عالی بود! دور بعدی؟', sender: 'خودم', timestamp: '14:35', isOwn: true }
  ];

  const members: Member[] = [
    { id: '1', name: 'Persian_Gamer', role: 'admin', status: 'online' },
    { id: '2', name: 'Elite_Player', role: 'moderator', status: 'online' },
    { id: '3', name: 'Pro_Sniper', role: 'member', status: 'online' },
    { id: '4', name: 'Shadow_Master', role: 'member', status: 'away' }
  ];

  const currentRoom = rooms.find(room => room.id === selectedRoom) || rooms[0];

  const handleSendMessage = useCallback(() => {
    if (message.trim()) {
      console.log('پیام ارسال شد:', message);
      setMessage('');
      // Auto scroll to bottom
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, [message]);

  const handleKeyPress = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  }, [handleSendMessage]);

  // Mobile Layout
  if (isMobile) {
    return (
      <div className="h-screen w-full flex flex-col bg-background">
        {/* Mobile Header */}
        <div className="flex-shrink-0 bg-card/95 backdrop-blur border-b border-border/50 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarFallback><Hash className="w-5 h-5" /></AvatarFallback>
              </Avatar>
              <div className="text-right">
                <h2 className="font-medium">{currentRoom.name}</h2>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>{currentRoom.onlineCount}</span>
                </div>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('chat-list')}
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div key={msg.id}>
                {msg.type === 'system' ? (
                  <div className="flex justify-center">
                    <div className="bg-muted/50 text-muted-foreground text-sm px-4 py-2 rounded-full">
                      {msg.content}
                    </div>
                  </div>
                ) : (
                  <div className={`flex gap-3 ${msg.isOwn ? 'justify-start flex-row-reverse' : 'justify-end'}`} dir="rtl">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="text-xs">{msg.sender.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className={`flex-1 ${msg.isOwn ? 'text-left' : 'text-right'}`}>
                      <div className={`flex items-center gap-2 mb-1 ${msg.isOwn ? 'justify-start' : 'justify-end'}`}>
                        <span className="text-xs text-muted-foreground">{msg.timestamp}</span>
                        <span className="text-sm font-medium">{msg.sender}</span>
                      </div>
                      <div className={`
                        inline-block p-3 rounded-lg max-w-xs break-words
                        ${msg.isOwn ? 'bg-primary text-primary-foreground' : 'bg-muted'}
                      `}>
                        {msg.content}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="flex-shrink-0 border-t border-border/50 bg-card/95 p-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm">
              <Smile className="w-5 h-5" />
            </Button>
            <Input 
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="پیام خود را بنویسید..."
              className="flex-1"
              dir="rtl"
              onKeyPress={handleKeyPress}
            />
            <Button 
              onClick={handleSendMessage}
              disabled={!message.trim()}
              size="sm"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Desktop Layout - Simplified
  return (
    <div className="h-screen w-full flex bg-background">
      {/* Left Sidebar */}
      <div className="w-80 flex-shrink-0 bg-card/30 border-r border-border/50 flex flex-col">
        <div className="p-4 border-b border-border/50">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">چت‌ها</h2>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm">
                <Plus className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="جستجو..." className="pr-10" dir="rtl" />
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-2">
            {rooms.map((room) => (
              <button
                key={room.id}
                onClick={() => setSelectedRoom(room.id)}
                className={`
                  w-full p-3 rounded-lg flex items-center gap-3 transition-colors text-right
                  ${selectedRoom === room.id ? 'bg-primary/20 border border-primary/30' : 'hover:bg-muted/50'}
                `}
              >
                <Avatar className="w-12 h-12">
                  <AvatarFallback>
                    {room.type === 'dm' ? room.name.charAt(0) : <Hash className="w-6 h-6" />}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 text-right">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      {room.unreadCount && (
                        <Badge variant="destructive" className="text-xs px-2 py-0">
                          {room.unreadCount}
                        </Badge>
                      )}
                    </div>
                    <h3 className="font-medium truncate">{room.name}</h3>
                  </div>
                  <div className="flex items-center gap-1 justify-end">
                    <Users className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{room.onlineCount}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </ScrollArea>
      </div>

      {/* Center Chat */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="flex-shrink-0 bg-card/95 border-b border-border/50 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarFallback><Hash className="w-5 h-5" /></AvatarFallback>
              </Avatar>
              <div className="text-right">
                <h2 className="font-semibold">{currentRoom.name}</h2>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>{currentRoom.onlineCount} نفر آنلاین</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm">
                <Phone className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Video className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowMembers(!showMembers)}
                className={showMembers ? 'bg-primary/20' : ''}
              >
                <Users className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Info className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-6">
          <div className="space-y-4 max-w-4xl">
            {messages.map((msg) => (
              <motion.div 
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
              >
                {msg.type === 'system' ? (
                  <div className="flex justify-center">
                    <div className="bg-muted/50 text-muted-foreground px-4 py-2 rounded-full">
                      {msg.content}
                    </div>
                  </div>
                ) : (
                  <div className={`flex gap-3 ${msg.isOwn ? 'flex-row-reverse' : ''}`} dir="rtl">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback>{msg.sender.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className={`flex-1 max-w-2xl ${msg.isOwn ? 'text-left' : 'text-right'}`}>
                      <div className={`flex items-center gap-2 mb-2 ${msg.isOwn ? 'justify-start' : 'justify-end'}`}>
                        <span className="text-xs text-muted-foreground">{msg.timestamp}</span>
                        <span className="font-medium">{msg.sender}</span>
                      </div>
                      <div className={`
                        p-3 rounded-lg inline-block break-words
                        ${msg.isOwn ? 'bg-primary text-primary-foreground' : 'bg-muted'}
                      `}>
                        {msg.content}
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="flex-shrink-0 border-t border-border/50 bg-card/95 p-4">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm">
              <Smile className="w-5 h-5" />
            </Button>
            <Input 
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="پیام خود را بنویسید..."
              className="flex-1 h-12"
              dir="rtl"
              onKeyPress={handleKeyPress}
            />
            <Button 
              onClick={handleSendMessage}
              disabled={!message.trim()}
              className="px-6 h-12"
            >
              <Send className="w-5 h-5 mr-2" />
              ارسال
            </Button>
          </div>
        </div>
      </div>

      {/* Right Sidebar - Members */}
      {showMembers && (
        <motion.div
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: 280, opacity: 1 }}
          exit={{ width: 0, opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="flex-shrink-0 bg-card/30 border-l border-border/50"
        >
          <div className="w-70 p-4">
            <h3 className="font-medium mb-4 text-right">
              اعضای آنلاین ({members.filter(m => m.status === 'online').length})
            </h3>
            <div className="space-y-2">
              {members.map((member) => (
                <div key={member.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/30">
                  <div className="relative">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="text-xs">{member.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className={`
                      absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-background
                      ${member.status === 'online' ? 'bg-green-500' : 
                        member.status === 'away' ? 'bg-yellow-500' : 'bg-red-500'}
                    `} />
                  </div>
                  <div className="flex-1 text-right">
                    <div className="flex items-center gap-2 justify-end">
                      <span className="text-sm font-medium">{member.name}</span>
                      {member.role === 'admin' && <Crown className="w-4 h-4 text-yellow-500" />}
                      {member.role === 'moderator' && <Shield className="w-4 h-4 text-blue-500" />}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}