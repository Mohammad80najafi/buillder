/**
 * Modern Social Page - Revolutionary Chat Experience (Fixed Version)
 * صفحه اجتماعی مدرن: تجربه انقلابی چت (نسخه برطرف شده)
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageCircle, 
  Users, 
  User, 
  Search, 
  Plus, 
  Settings, 
  Bell, 
  Star,
  Shield, 
  Hash, 
  Zap,
  Flame,
  Crown,
  Heart,
  Eye,
  Volume2,
  Mic,
  Video,
  Share2,
  ArrowLeft,
  Filter,
  SortAsc,
  Grid3X3,
  List,
  Sparkles,
  Gamepad2,
  Trophy,
  Clock,
  ChevronDown,
  X,
  Pin,
  MoreHorizontal,
  Archive,
  Trash2
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../ui/dropdown-menu';
import { Switch } from '../ui/switch';
import { Separator } from '../ui/separator';
import { ScrollArea } from '../ui/scroll-area';
import { AdvancedChatSystem } from '../chat/AdvancedChatSystem';
import { ClanChatSystem } from '../clans/ClanChatSystem';
import { useClan } from '../providers/ClanProvider';

interface ModernChatRoom {
  id: string;
  name: string;
  type: 'group' | 'direct' | 'support' | 'clan' | 'gaming' | 'tournament';
  avatar?: string;
  coverImage?: string;
  gradient?: string;
  lastMessage: {
    content: string;
    timestamp: string;
    sender: string;
    type: 'text' | 'image' | 'voice' | 'game' | 'system';
  };
  unreadCount: number;
  isOnline?: boolean;
  members?: number;
  isPinned?: boolean;
  isActive?: boolean;
  status?: 'active' | 'resolved' | 'pending' | 'live' | 'scheduled';
  clanTag?: string;
  clanId?: string;
  gameTitle?: string;
  liveUsers?: number;
  priority?: 'high' | 'medium' | 'low';
  lastSeen?: string;
  mood?: 'happy' | 'focused' | 'competitive' | 'chill';
  voiceChannelActive?: boolean;
  isTyping?: boolean;
}

type ViewMode = 'grid' | 'list' | 'compact';
type FilterType = 'all' | 'unread' | 'pinned' | 'active' | 'archived';
type SortType = 'recent' | 'name' | 'unread' | 'members';

export function ModernSocialPageFixed() {
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [sortType, setSortType] = useState<SortType>('recent');
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showQuickActions, setShowQuickActions] = useState(false);
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const { clanChats, markClanChatAsRead, clans } = useClan();

  // Enhanced mock data with gaming focus
  const modernChats: ModernChatRoom[] = [
    {
      id: '1',
      name: 'Fire Dragons Elite',
      type: 'clan',
      avatar: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=150&h=150&fit=crop',
      coverImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&h=200&fit=crop',
      gradient: 'from-red-500 via-orange-500 to-yellow-500',
      lastMessage: {
        content: '🏆 آماده برای تورنومنت شب؟',
        timestamp: '2 دقیقه پیش',
        sender: 'Captain Phoenix',
        type: 'text'
      },
      unreadCount: 7,
      members: 24,
      isPinned: true,
      isActive: true,
      status: 'live',
      clanTag: 'FDG',
      liveUsers: 12,
      priority: 'high',
      mood: 'competitive',
      voiceChannelActive: true
    },
    {
      id: '2',
      name: 'Sarah Pro Gamer',
      type: 'direct',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop',
      gradient: 'from-purple-500 via-pink-500 to-rose-500',
      lastMessage: {
        content: '🎮 بازی جدید رو امتحان کردی?',
        timestamp: '5 دقیقه پیش',
        sender: 'Sarah Pro Gamer',
        type: 'text'
      },
      unreadCount: 2,
      isOnline: true,
      mood: 'happy',
      isTyping: true,
      lastSeen: 'آنلاین'
    },
    {
      id: '3',
      name: 'Valorant Masters Cup',
      type: 'tournament',
      avatar: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=150&h=150&fit=crop',
      coverImage: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=400&h=200&fit=crop',
      gradient: 'from-blue-500 via-cyan-500 to-teal-500',
      lastMessage: {
        content: '🏅 مسابقات امشب ساعت 8 شروع میشه',
        timestamp: '10 دقیقه پیش',
        sender: 'Tournament Admin',
        type: 'system'
      },
      unreadCount: 15,
      members: 128,
      status: 'scheduled',
      priority: 'high',
      gameTitle: 'Valorant',
      liveUsers: 89
    },
    {
      id: '4',
      name: 'Night Owl Squad',
      type: 'gaming',
      avatar: 'https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?w=150&h=150&fit=crop',
      gradient: 'from-indigo-500 via-purple-500 to-pink-500',
      lastMessage: {
        content: '🌙 شب‌های بازی کی شروع میشه؟',
        timestamp: '15 دقیقه پیش',
        sender: 'NightHunter',
        type: 'text'
      },
      unreadCount: 4,
      members: 16,
      mood: 'chill',
      gameTitle: 'Among Us',
      liveUsers: 6
    },
    {
      id: '5',
      name: 'Alex Streamer',
      type: 'direct',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
      gradient: 'from-green-500 via-emerald-500 to-teal-500',
      lastMessage: {
        content: '📺 استریم امشب رو از دست نده!',
        timestamp: '1 ساعت پیش',
        sender: 'Alex Streamer',
        type: 'text'
      },
      unreadCount: 1,
      isOnline: true,
      mood: 'focused',
      lastSeen: 'آنلاین'
    }
  ];

  // Add clan chats to modern chats
  const allChats = [...clanChats.map(clanChat => ({
    ...clanChat,
    type: 'clan' as const,
    gradient: 'from-blue-500 via-indigo-500 to-purple-500',
    mood: 'competitive' as const,
    priority: 'medium' as const
  })), ...modernChats];

  // Filter and sort chats
  const filteredChats = allChats
    .filter(chat => {
      if (filterType === 'unread' && chat.unreadCount === 0) return false;
      if (filterType === 'pinned' && !chat.isPinned) return false;
      if (filterType === 'active' && !chat.isActive) return false;
      if (searchQuery && !chat.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    })
    .sort((a, b) => {
      switch (sortType) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'unread':
          return b.unreadCount - a.unreadCount;
        case 'members':
          return (b.members || 0) - (a.members || 0);
        default:
          return 0; // recent - mock sorting
      }
    });

  const getMoodEmoji = (mood?: string) => {
    switch (mood) {
      case 'happy': return '😊';
      case 'focused': return '🎯';
      case 'competitive': return '🔥';
      case 'chill': return '😎';
      default: return '💬';
    }
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'live': return 'text-red-400 animate-pulse';
      case 'scheduled': return 'text-blue-400';
      case 'active': return 'text-green-400';
      default: return 'text-muted-foreground';
    }
  };

  const renderChatCard = (chat: ModernChatRoom) => {
    const cardVariants = {
      hidden: { opacity: 0, y: 20 },
      visible: { opacity: 1, y: 0 },
      hover: { 
        scale: 1.02, 
        transition: { duration: 0.2 } 
      }
    };

    if (viewMode === 'list' || viewMode === 'compact') {
      return (
        <motion.div
          key={chat.id}
          variants={cardVariants}
          initial="hidden"
          animate="visible"
          whileHover="hover"
          className="group"
        >
          <Card 
            className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-0 ${
              selectedChat === chat.id 
                ? 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-l-4 border-l-blue-500' 
                : 'hover:bg-surface-secondary/50'
            }`}
            onClick={() => setSelectedChat(chat.id)}
          >
            <CardContent className={`p-4 ${viewMode === 'compact' ? 'py-2' : ''}`}>
              <div className="flex items-center space-x-3 rtl:space-x-reverse">
                <div className="relative">
                  <div className={`p-0.5 rounded-full bg-gradient-to-br ${chat.gradient || 'from-gray-500 to-gray-600'}`}>
                    <Avatar className={`${viewMode === 'compact' ? 'h-8 w-8' : 'h-12 w-12'} bg-background`}>
                      <AvatarImage src={chat.avatar} alt={chat.name} />
                      <AvatarFallback className="text-white bg-gradient-to-br from-blue-500 to-purple-500">
                        {chat.name[0]}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  
                  {chat.isOnline && (
                    <div className="absolute -bottom-1 -left-1 h-3 w-3 bg-green-500 rounded-full border-2 border-background animate-pulse" />
                  )}
                  
                  {chat.voiceChannelActive && (
                    <div className="absolute -top-1 -right-1 h-4 w-4 bg-blue-500 rounded-full flex items-center justify-center">
                      <Volume2 className="h-2 w-2 text-white" />
                    </div>
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <h3 className="font-semibold truncate flex items-center space-x-1 rtl:space-x-reverse">
                        <span>{chat.name}</span>
                        {chat.isPinned && <Pin className="h-3 w-3 text-yellow-400" />}
                        {chat.status === 'live' && <div className="h-2 w-2 bg-red-500 rounded-full animate-pulse" />}
                      </h3>
                      
                      <span className="text-lg">{getMoodEmoji(chat.mood)}</span>
                      
                      {chat.clanTag && (
                        <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400 border-blue-500/30">
                          <Hash className="w-2 h-2 ml-1" />
                          {chat.clanTag}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs text-muted-foreground">
                      <span>{chat.lastMessage.timestamp}</span>
                      {chat.unreadCount > 0 && (
                        <Badge className="h-5 w-5 p-0 text-xs rounded-full bg-gradient-to-r from-blue-500 to-purple-500">
                          {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  {viewMode !== 'compact' && (
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-muted-foreground truncate flex items-center space-x-1 rtl:space-x-reverse">
                        {chat.isTyping && (
                          <motion.span
                            animate={{ opacity: [1, 0.5, 1] }}
                            transition={{ repeat: Infinity, duration: 1.5 }}
                            className="text-blue-400"
                          >
                            در حال تایپ...
                          </motion.span>
                        )}
                        {!chat.isTyping && (
                          <>
                            {chat.type !== 'direct' && (
                              <span className="font-medium">{chat.lastMessage.sender}:</span>
                            )}
                            <span>{chat.lastMessage.content}</span>
                          </>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-1 rtl:space-x-reverse opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                          <MoreHorizontal className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      );
    }

    // Grid view
    return (
      <motion.div
        key={chat.id}
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        whileHover="hover"
        className="group"
      >
        <Card 
          className={`cursor-pointer transition-all duration-300 hover:shadow-2xl overflow-hidden border-0 ${
            selectedChat === chat.id 
              ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-background' 
              : ''
          }`}
          onClick={() => setSelectedChat(chat.id)}
        >
          {/* Cover Image */}
          <div className={`relative h-24 bg-gradient-to-br ${chat.gradient || 'from-gray-500 to-gray-600'} overflow-hidden`}>
            {chat.coverImage && (
              <img 
                src={chat.coverImage} 
                alt={chat.name}
                className="w-full h-full object-cover opacity-80"
              />
            )}
            
            <div className="absolute inset-0 bg-black/20" />
            
            {/* Status indicators */}
            <div className="absolute top-2 right-2 flex space-x-1 rtl:space-x-reverse">
              {chat.status === 'live' && (
                <Badge className="bg-red-500 text-white text-xs animate-pulse">
                  <div className="h-1 w-1 bg-white rounded-full mr-1 animate-pulse" />
                  LIVE
                </Badge>
              )}
              {chat.isPinned && (
                <div className="h-6 w-6 bg-yellow-500 rounded-full flex items-center justify-center">
                  <Pin className="h-3 w-3 text-white" />
                </div>
              )}
            </div>
            
            {/* Voice channel indicator */}
            {chat.voiceChannelActive && (
              <div className="absolute top-2 left-2 bg-blue-500 rounded-full p-1">
                <Volume2 className="h-3 w-3 text-white" />
              </div>
            )}
            
            {/* Live users count */}
            {chat.liveUsers && (
              <div className="absolute bottom-2 left-2 bg-black/50 backdrop-blur-sm rounded-full px-2 py-1 text-xs text-white flex items-center space-x-1 rtl:space-x-reverse">
                <Eye className="h-3 w-3" />
                <span>{chat.liveUsers}</span>
              </div>
            )}
          </div>
          
          <CardContent className="p-4">
            {/* Avatar and Title */}
            <div className="flex items-center space-x-3 rtl:space-x-reverse mb-3">
              <div className="relative">
                <div className={`p-0.5 rounded-full bg-gradient-to-br ${chat.gradient || 'from-gray-500 to-gray-600'}`}>
                  <Avatar className="h-10 w-10 bg-background">
                    <AvatarImage src={chat.avatar} alt={chat.name} />
                    <AvatarFallback className="text-white bg-gradient-to-br from-blue-500 to-purple-500">
                      {chat.name[0]}
                    </AvatarFallback>
                  </Avatar>
                </div>
                
                {chat.isOnline && (
                  <div className="absolute -bottom-1 -left-1 h-3 w-3 bg-green-500 rounded-full border-2 border-background animate-pulse" />
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold truncate flex items-center space-x-1 rtl:space-x-reverse">
                  <span>{chat.name}</span>
                  <span className="text-lg">{getMoodEmoji(chat.mood)}</span>
                </h3>
                
                <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs text-muted-foreground">
                  {chat.members && (
                    <span className="flex items-center space-x-1 rtl:space-x-reverse">
                      <Users className="h-3 w-3" />
                      <span>{chat.members}</span>
                    </span>
                  )}
                  
                  {chat.clanTag && (
                    <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400 border-blue-500/30">
                      <Hash className="w-2 h-2 ml-1" />
                      {chat.clanTag}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            
            {/* Last Message */}
            <div className="space-y-2">
              {chat.isTyping ? (
                <motion.div
                  animate={{ opacity: [1, 0.5, 1] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                  className="text-sm text-blue-400 flex items-center space-x-1 rtl:space-x-reverse"
                >
                  <div className="flex space-x-1">
                    <div className="h-1 w-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="h-1 w-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="h-1 w-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <span>در حال تایپ...</span>
                </motion.div>
              ) : (
                <div className="text-sm text-muted-foreground line-clamp-2">
                  {chat.type !== 'direct' && (
                    <span className="font-medium">{chat.lastMessage.sender}: </span>
                  )}
                  {chat.lastMessage.content}
                </div>
              )}
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {chat.lastMessage.timestamp}
                </span>
                
                {chat.unreadCount > 0 && (
                  <Badge className="h-5 w-5 p-0 text-xs rounded-full bg-gradient-to-r from-blue-500 to-purple-500">
                    {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  };

  // If a chat is selected, show the chat interface
  if (selectedChat) {
    const selectedChatData = allChats.find(chat => chat.id === selectedChat);
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900">
        <div className="flex items-center justify-between p-4 border-b border-border/50 backdrop-blur-sm">
          <Button 
            variant="ghost" 
            onClick={() => setSelectedChat(null)}
            className="flex items-center space-x-2 rtl:space-x-reverse"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>بازگشت</span>
          </Button>
          
          {selectedChatData && (
            <div className="flex items-center space-x-3 rtl:space-x-reverse">
              <div className={`p-0.5 rounded-full bg-gradient-to-br ${selectedChatData.gradient || 'from-gray-500 to-gray-600'}`}>
                <Avatar className="h-8 w-8 bg-background">
                  <AvatarImage src={selectedChatData.avatar} alt={selectedChatData.name} />
                  <AvatarFallback className="text-white bg-gradient-to-br from-blue-500 to-purple-500">
                    {selectedChatData.name[0]}
                  </AvatarFallback>
                </Avatar>
              </div>
              <div>
                <h2 className="font-semibold">{selectedChatData.name}</h2>
                <p className="text-xs text-muted-foreground">
                  {selectedChatData.members ? `${selectedChatData.members} عضو` : selectedChatData.lastSeen}
                </p>
              </div>
            </div>
          )}
          
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <Button variant="ghost" size="sm">
              <Video className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Mic className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="flex-1 p-4">
          {selectedChatData?.type === 'clan' && selectedChatData.clanId ? (
            <ClanChatSystem
              clan={clans.find(c => c.id === selectedChatData.clanId)!}
              currentUserId="current-user-id"
              currentUserRole="member"
              onClose={() => {
                setSelectedChat(null);
                if (selectedChatData.clanId) {
                  markClanChatAsRead(selectedChatData.clanId);
                }
              }}
              className="w-full max-w-4xl mx-auto"
            />
          ) : (
            <AdvancedChatSystem />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Modern Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500">
              <MessageCircle className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                مرکز ارتباطات
              </h1>
              <p className="text-muted-foreground">
                {filteredChats.length} چت فعال • {filteredChats.reduce((acc, chat) => acc + chat.unreadCount, 0)} پیام جدید
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            {/* Focus Mode Toggle */}
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <span className="text-sm text-muted-foreground">حالت تمرکز</span>
              <Switch 
                checked={focusMode} 
                onCheckedChange={setFocusMode}
              />
            </div>
            
            {/* Voice Mode Toggle */}
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <span className="text-sm text-muted-foreground">صدا</span>
              <Switch 
                checked={isVoiceMode} 
                onCheckedChange={setIsVoiceMode}
              />
            </div>
            
            <Separator orientation="vertical" className="h-8" />
            
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4 ml-2" />
              تنظیمات
            </Button>
            
            <Button 
              size="sm"
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              onClick={() => setShowQuickActions(!showQuickActions)}
            >
              <Plus className="h-4 w-4 ml-2" />
              جدید
            </Button>
          </div>
        </motion.div>

        {/* Quick Actions Panel */}
        <AnimatePresence>
          {showQuickActions && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden"
            >
              <Card className="p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/30">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Button variant="ghost" className="flex items-center space-x-2 rtl:space-x-reverse h-auto p-3">
                    <User className="h-5 w-5 text-blue-400" />
                    <span>چت خصوصی</span>
                  </Button>
                  <Button variant="ghost" className="flex items-center space-x-2 rtl:space-x-reverse h-auto p-3">
                    <Users className="h-5 w-5 text-green-400" />
                    <span>گروه جدید</span>
                  </Button>
                  <Button variant="ghost" className="flex items-center space-x-2 rtl:space-x-reverse h-auto p-3">
                    <Shield className="h-5 w-5 text-purple-400" />
                    <span>کلن</span>
                  </Button>
                  <Button variant="ghost" className="flex items-center space-x-2 rtl:space-x-reverse h-auto p-3">
                    <Trophy className="h-5 w-5 text-yellow-400" />
                    <span>تورنومنت</span>
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Modern Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-col md:flex-row gap-4"
        >
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="جستجو در چت‌ها، کاربران، پیام‌ها..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 bg-surface-secondary/50 border-border/50 focus:border-blue-500/50 text-right"
              dir="rtl"
            />
          </div>
          
          {/* Filters */}
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="flex items-center space-x-2 rtl:space-x-reverse">
                  <Filter className="h-4 w-4" />
                  <span>فیلتر</span>
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setFilterType('all')}>
                  همه چت‌ها
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('unread')}>
                  خوانده نشده
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('pinned')}>
                  پین شده
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('active')}>
                  فعال
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="flex items-center space-x-2 rtl:space-x-reverse">
                  <SortAsc className="h-4 w-4" />
                  <span>مرتب‌سازی</span>
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setSortType('recent')}>
                  آخرین فعالیت
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortType('name')}>
                  نام
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortType('unread')}>
                  پیام‌های جدید
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortType('members')}>
                  تعداد اعضا
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <div className="flex items-center bg-surface-secondary/50 rounded-lg p-1">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="h-8 w-8 p-0"
              >
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="h-8 w-8 p-0"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Chats Grid/List */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <ScrollArea className="h-[calc(100vh-300px)]">
            {filteredChats.length > 0 ? (
              <div className={`
                ${viewMode === 'grid' 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4' 
                  : 'space-y-2'
                }
                pb-4
              `}>
                <AnimatePresence>
                  {filteredChats.map((chat, index) => (
                    <motion.div
                      key={chat.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      {renderChatCard(chat)}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/10 to-purple-500/10 w-fit mx-auto mb-4">
                  <MessageCircle className="h-16 w-16 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">هیچ چتی یافت نشد</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  {searchQuery 
                    ? 'نتیجه‌ای برای جستجوی شما پیدا نشد. کلمات کلیدی مختلفی امتحان کنید.' 
                    : 'هنوز چتی ندارید. برای شروع یک چت جدید دکمه زیر را کلیک کنید.'
                  }
                </p>
                <Button 
                  className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                  onClick={() => setShowQuickActions(true)}
                >
                  <Plus className="h-4 w-4 ml-2" />
                  شروع چت جدید
                </Button>
              </div>
            )}
          </ScrollArea>
        </motion.div>
      </div>
    </div>
  );
}