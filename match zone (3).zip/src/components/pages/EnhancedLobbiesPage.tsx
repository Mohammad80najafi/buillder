/**
 * Enhanced Matchzone Lobbies Page
 * Integrated with user levels, game definitions, and platform separation
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/mz-button';
import { Input } from '../ui/mz-input';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, Filter, Plus, Users, Clock, MapPin, Gamepad2, Monitor, 
  Smartphone, Globe, Lock, Crown, Shield, Zap, Star, Play, 
  Copy, ExternalLink, Wifi, Signal, Trophy, Target, Flame,
  Settings, RefreshCw, CheckCircle, AlertCircle, XCircle, Info,
  DollarSign, QrCode, X
} from 'lucide-react';
import { useMobile } from '../ui/use-mobile';
import { LobbyCardAdapter, EnhancedLobby } from '../gaming/LobbyCardAdapter';
import { useNavigation } from '../navigation/NavigationProvider';
import { useLobby } from '../gaming/LobbyContext';
import { useGames } from '../providers/GameProvider';
import { useUser } from '../providers/UserProvider';
import { JoinByCodeDialog } from '../gaming/JoinByCodeDialog';

interface FilterState {
  search: string;
  platform: 'all' | 'desktop' | 'mobile';
  gameId: string; // 'all' for all games, or specific gameId
  showPaidOnly: boolean;
  showTournamentOnly: boolean;
  minLevel: number;
}

export function EnhancedLobbiesPage() {
  const isMobile = useMobile();
  const { navigate, navigateToLobby } = useNavigation();
  const { joinedLobbies, joinLobby, leaveLobby } = useLobby();
  const { allGames, desktopGames, mobileGames, tournamentGames } = useGames();
  const { user, currentLevelInfo, canCreatePaidLobbies } = useUser();

  const [filters, setFilters] = useState<FilterState>({
    search: '',
    platform: 'all',
    gameId: 'all',
    showPaidOnly: false,
    showTournamentOnly: false,
    minLevel: 0
  });

  const [activeTab, setActiveTab] = useState<'all' | 'desktop' | 'mobile'>('all');
  const [showJoinByCodeDialog, setShowJoinByCodeDialog] = useState(false);

  // Mock lobby data - در پروژه واقعی از API می‌آید
  const mockLobbies: EnhancedLobby[] = [
    {
      id: 'lobby-1',
      name: 'لابی CS2 حرفه‌ای',
      gameId: 'cs2',
      host: {
        name: 'علی رضایی',
        avatar: 'https://images.unsplash.com/photo-1699524826369-57870e627c43?w=64',
        level: 'host'
      },
      currentPlayers: 8,
      maxPlayers: 10,
      status: 'waiting',
      gameMode: 'Competitive',
      isPrivate: false,
      isPaidLobby: true,
      entryFee: 5000,
      platform: 'desktop',
      isTournamentGame: true,
      requiredLevel: 10,
      estimatedDuration: 90,
      region: 'ایران',
      ageRestriction: 'all',
      genderRestriction: 'all',
      createdAt: new Date()
    },
    {
      id: 'lobby-2',
      name: 'PUBG Mobile Squad',
      gameId: 'pubgm',
      host: {
        name: 'مریم احمدی',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
        level: 'player'
      },
      currentPlayers: 3,
      maxPlayers: 4,
      status: 'waiting',
      gameMode: 'Squad',
      isPrivate: false,
      isPaidLobby: false,
      platform: 'mobile',
      isTournamentGame: true,
      estimatedDuration: 30,
      region: 'آسیا',
      ageRestriction: 'all',
      genderRestriction: 'all',
      createdAt: new Date()
    },
    {
      id: 'lobby-3',
      name: 'FIFA تورنومنت',
      gameId: 'fifam',
      host: {
        name: 'حسین کریمی',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64',
        level: 'manager'
      },
      currentPlayers: 16,
      maxPlayers: 32,
      status: 'starting',
      gameMode: 'Tournament',
      isPrivate: false,
      isPaidLobby: true,
      entryFee: 10000,
      platform: 'mobile',
      isTournamentGame: true,
      requiredLevel: 15,
      estimatedDuration: 120,
      region: 'جهانی',
      ageRestriction: 'all',
      genderRestriction: 'all',
      createdAt: new Date()
    }
  ];

  // Filter lobbies based on current filters
  const filteredLobbies = mockLobbies.filter(lobby => {
    if (filters.search && !lobby.name.toLowerCase().includes(filters.search.toLowerCase())) {
      return false;
    }
    if (filters.platform !== 'all' && lobby.platform !== filters.platform) {
      return false;
    }
    if (filters.gameId && filters.gameId !== 'all' && lobby.gameId !== filters.gameId) {
      return false;
    }
    if (filters.showPaidOnly && !lobby.isPaidLobby) {
      return false;
    }
    if (filters.showTournamentOnly && !lobby.isTournamentGame) {
      return false;
    }
    if (filters.minLevel > 0 && (lobby.requiredLevel || 0) < filters.minLevel) {
      return false;
    }
    return true;
  });

  const handleJoinLobby = (lobbyId: string) => {
    joinLobby(lobbyId);
    console.log('Joined lobby:', lobbyId);
  };

  const handleLeaveLobby = (lobbyId: string) => {
    leaveLobby(lobbyId);
    console.log('Left lobby:', lobbyId);
  };

  const handleViewLobby = (lobbyId: string) => {
    navigateToLobby(lobbyId);
  };

  const handleLobbyFoundByCode = (lobbyId: string) => {
    navigateToLobby(lobbyId);
  };

  const isJoinedLobby = (lobbyId: string) => {
    return joinedLobbies?.includes(lobbyId) || false;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6" dir="rtl">
        {/* Header Content */}
        <div className="flex-1 text-right">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl border border-blue-500/30">
              <Gamepad2 className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h1 className="font-bold bg-gradient-to-l from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                لابی‌های بازی
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <p className="text-muted-foreground">
                  {filteredLobbies.length} لابی فعال • آنلاین الان
                </p>
              </div>
            </div>
          </div>
          
          <p className="text-muted-foreground max-w-md">
            به لابی‌های مختلف بپیوندید، دوستان خود را دعوت کنید و تجربه بازی شگفت‌انگیزی را آغاز کنید
          </p>
        </div>
        
        {/* Actions & Level Badge */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full lg:w-auto">
          {/* User Level Badge */}
          <div className="flex items-center justify-between sm:justify-center bg-gradient-to-r from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-3 sm:p-4 min-w-[160px]">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${currentLevelInfo.bgColor}`}>
                <Shield className={`w-4 h-4 ${currentLevelInfo.color}`} />
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400 mb-1">سطح شما</div>
                <div className={`font-semibold ${currentLevelInfo.color}`}>
                  {currentLevelInfo.name}
                </div>
              </div>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button 
              variant="outline"
              onClick={() => setShowJoinByCodeDialog(true)}
              className="flex-1 sm:flex-none h-11 px-4 border-blue-500/30 bg-blue-500/10 hover:bg-blue-500/20 hover:border-blue-400/40 transition-all group"
            >
              <QrCode className="w-4 h-4 text-blue-400 group-hover:text-blue-300 transition-colors mr-2" />
              <span className="text-blue-200 group-hover:text-blue-100">
                <span className="hidden sm:inline">پیوستن با کد</span>
                <span className="sm:hidden">کد لابی</span>
              </span>
            </Button>
            
            <Button 
              onClick={() => navigate('create-lobby')}
              className="flex-1 sm:flex-none h-11 px-4 bg-gradient-to-l from-blue-500 via-purple-500 to-pink-500 hover:from-blue-600 hover:via-purple-600 hover:to-pink-600 border-0 shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              <Plus className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
              <span className="font-semibold">
                <span className="hidden sm:inline">ایجاد لابی جدید</span>
                <span className="sm:hidden">ایجاد لابی</span>
              </span>
            </Button>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-gradient-to-r from-slate-900/40 via-slate-800/40 to-slate-900/40 rounded-2xl border border-slate-700/50 backdrop-blur-sm">
        <div className="p-6 space-y-6">
          {/* Header Section */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Filter className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">فیلترهای پیشرفته</h3>
                <p className="text-sm text-muted-foreground">
                  {filteredLobbies.length} لابی از {mockLobbies.length} لابی
                </p>
              </div>
            </div>
            
            {/* Clear Filters */}
            {(filters.search || filters.platform !== 'all' || filters.gameId !== 'all' || filters.showPaidOnly || filters.showTournamentOnly) && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setFilters({
                  search: '',
                  platform: 'all',
                  gameId: 'all',
                  showPaidOnly: false,
                  showTournamentOnly: false
                })}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4 ml-1" />
                پاک کردن
              </Button>
            )}
          </div>

          {/* Search Section */}
          <div className="relative">
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2 z-10">
              <Search className="w-5 h-5 text-slate-400" />
            </div>
            <Input
              placeholder="جستجو بر اساس نام لابی، بازی، میزبان..."
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
              className="pr-12 pl-4 h-12 bg-slate-800/50 border-slate-600/50 rounded-xl focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 transition-all"
              dir="rtl"
            />
            {filters.search && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setFilters(prev => ({ ...prev, search: '' }))}
                className="absolute left-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0 hover:bg-slate-700"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>

          {/* Filter Categories */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Platform & Type Filters */}
            <div className="space-y-4">
              <h4 className="font-medium text-slate-300 flex items-center gap-2">
                <Monitor className="w-4 h-4" />
                پلتفرم و نوع
              </h4>
              
              <div className="space-y-3">
                {/* Platform Toggle */}
                <div className="flex items-center gap-2 p-1 bg-slate-800/50 rounded-lg">
                  <Button
                    variant={filters.platform === 'all' ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setFilters(prev => ({ ...prev, platform: 'all' }))}
                    className="flex-1 text-xs h-8"
                  >
                    <Globe className="w-3 h-3 ml-1" />
                    همه
                  </Button>
                  <Button
                    variant={filters.platform === 'desktop' ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setFilters(prev => ({ ...prev, platform: 'desktop' }))}
                    className="flex-1 text-xs h-8"
                  >
                    <Monitor className="w-3 h-3 ml-1" />
                    دسکتاپ
                  </Button>
                  <Button
                    variant={filters.platform === 'mobile' ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setFilters(prev => ({ ...prev, platform: 'mobile' }))}
                    className="flex-1 text-xs h-8"
                  >
                    <Smartphone className="w-3 h-3 ml-1" />
                    موبایل
                  </Button>
                </div>

                {/* Lobby Type */}
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={filters.showPaidOnly ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilters(prev => ({ ...prev, showPaidOnly: !prev.showPaidOnly }))}
                    className="text-xs h-8"
                  >
                    <DollarSign className="w-3 h-3 ml-1" />
                    لابی‌های پولی
                  </Button>
                  <Button
                    variant={filters.showTournamentOnly ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilters(prev => ({ ...prev, showTournamentOnly: !prev.showTournamentOnly }))}
                    className="text-xs h-8"
                  >
                    <Trophy className="w-3 h-3 ml-1" />
                    تورنومنت‌ها
                  </Button>
                </div>
              </div>
            </div>

            {/* Game Selection */}
            <div className="space-y-4">
              <h4 className="font-medium text-slate-300 flex items-center gap-2">
                <Gamepad2 className="w-4 h-4" />
                انتخاب بازی
              </h4>
              
              <Select value={filters.gameId} onValueChange={(value) => setFilters(prev => ({ ...prev, gameId: value }))}>
                <SelectTrigger className="bg-slate-800/50 border-slate-600/50 h-10">
                  <SelectValue placeholder="انتخاب بازی" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      <span>همه بازی‌ها</span>
                    </div>
                  </SelectItem>
                  {Object.values(allGames).map(game => (
                    <SelectItem key={game.id} value={game.id}>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{game.emoji}</span>
                        <span>{game.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Popular Games Quick Access */}
              <div className="flex flex-wrap gap-2">
                {Object.values(allGames).slice(0, 3).map(game => (
                  <Button
                    key={game.id}
                    variant={filters.gameId === game.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFilters(prev => ({ ...prev, gameId: game.id }))}
                    className="text-xs h-8"
                  >
                    <span className="text-sm ml-1">{game.emoji}</span>
                    {game.name.split(' ')[0]}
                  </Button>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-4">
              <h4 className="font-medium text-slate-300 flex items-center gap-2">
                <Zap className="w-4 h-4" />
                دسترسی سریع
              </h4>
              
              <div className="space-y-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowJoinByCodeDialog(true)}
                  className="w-full justify-start text-xs h-10 border-blue-500/30 hover:border-blue-500/50 hover:bg-blue-500/10 transition-all duration-200 group"
                >
                  <QrCode className="w-4 h-4 ml-2 group-hover:scale-110 transition-transform" />
                  پیوستن با کد
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    // Refresh lobbies با انیمیشن
                    const refreshButton = document.querySelector('.refresh-lobbies-btn');
                    if (refreshButton) {
                      refreshButton.classList.add('animate-spin');
                      setTimeout(() => {
                        refreshButton.classList.remove('animate-spin');
                      }, 1000);
                    }
                    // در پروژه واقعی اینجا API کال می‌شود
                    console.log('🔄 بروزرسانی لابی‌ها...');
                    
                    // Mock notification برای نشان دادن موفقیت
                    setTimeout(() => {
                      console.log('✅ لابی‌ها بروزرسانی شدند');
                    }, 1000);
                  }}
                  className="w-full justify-start text-xs h-10 border-green-500/30 hover:border-green-500/50 hover:bg-green-500/10 transition-all duration-200 group"
                >
                  <RefreshCw className="refresh-lobbies-btn w-4 h-4 ml-2 group-hover:scale-110 transition-transform" />
                  به‌روزرسانی لابی‌ها
                </Button>
              </div>
            </div>
          </div>

          {/* Active Filters Summary */}
          {(filters.search || filters.platform !== 'all' || filters.gameId !== 'all' || filters.showPaidOnly || filters.showTournamentOnly) && (
            <div className="pt-4 border-t border-slate-700/50">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm text-slate-400">فیلترهای فعال:</span>
                
                {filters.search && (
                  <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 hover:bg-blue-500/30">
                    جستجو: "{filters.search}"
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setFilters(prev => ({ ...prev, search: '' }))}
                      className="h-4 w-4 p-0 ml-1 hover:bg-blue-500/40"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                )}
                
                {filters.platform !== 'all' && (
                  <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 hover:bg-purple-500/30">
                    {filters.platform === 'desktop' ? 'دسکتاپ' : 'موبایل'}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setFilters(prev => ({ ...prev, platform: 'all' }))}
                      className="h-4 w-4 p-0 ml-1 hover:bg-purple-500/40"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                )}
                
                {filters.gameId !== 'all' && (
                  <Badge variant="secondary" className="bg-green-500/20 text-green-300 hover:bg-green-500/30">
                    {allGames[filters.gameId]?.name}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setFilters(prev => ({ ...prev, gameId: 'all' }))}
                      className="h-4 w-4 p-0 ml-1 hover:bg-green-500/40"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                )}
                
                {filters.showPaidOnly && (
                  <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 hover:bg-yellow-500/30">
                    پولی
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setFilters(prev => ({ ...prev, showPaidOnly: false }))}
                      className="h-4 w-4 p-0 ml-1 hover:bg-yellow-500/40"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                )}
                
                {filters.showTournamentOnly && (
                  <Badge variant="secondary" className="bg-red-500/20 text-red-300 hover:bg-red-500/30">
                    تورنومنت
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setFilters(prev => ({ ...prev, showTournamentOnly: false }))}
                      className="h-4 w-4 p-0 ml-1 hover:bg-red-500/40"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Platform Tabs */}
      <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            همه
          </TabsTrigger>
          <TabsTrigger value="desktop" className="flex items-center gap-2">
            <Monitor className="w-4 h-4" />
            دسکتاپ
          </TabsTrigger>
          <TabsTrigger value="mobile" className="flex items-center gap-2">
            <Smartphone className="w-4 h-4" />
            موبایل
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredLobbies.map(lobby => (
                <motion.div
                  key={lobby.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.2 }}
                >
                  <LobbyCardAdapter
                    lobby={lobby}
                    onJoin={() => handleJoinLobby(lobby.id)}
                    onLeave={() => handleLeaveLobby(lobby.id)}
                    onView={() => handleViewLobby(lobby.id)}
                    isJoined={isJoinedLobby(lobby.id)}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </TabsContent>

        <TabsContent value="desktop" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredLobbies.filter(lobby => lobby.platform === 'desktop').map(lobby => (
                <motion.div
                  key={lobby.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.2 }}
                >
                  <LobbyCardAdapter
                    lobby={lobby}
                    onJoin={() => handleJoinLobby(lobby.id)}
                    onLeave={() => handleLeaveLobby(lobby.id)}
                    onView={() => handleViewLobby(lobby.id)}
                    isJoined={isJoinedLobby(lobby.id)}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </TabsContent>

        <TabsContent value="mobile" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredLobbies.filter(lobby => lobby.platform === 'mobile').map(lobby => (
                <motion.div
                  key={lobby.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.2 }}
                >
                  <LobbyCardAdapter
                    lobby={lobby}
                    onJoin={() => handleJoinLobby(lobby.id)}
                    onLeave={() => handleLeaveLobby(lobby.id)}
                    onView={() => handleViewLobby(lobby.id)}
                    isJoined={isJoinedLobby(lobby.id)}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </TabsContent>
      </Tabs>

      {/* Empty State */}
      {filteredLobbies.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <Gamepad2 className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">لابی‌ای یافت نشد</h3>
            <p className="text-muted-foreground mb-6">
              با فیلترهای انتخاب شده لابی‌ای وجود ندارد. فیلترها را تغییر دهید یا لابی جدید ایجاد کنید.
            </p>
            <Button onClick={() => navigate('create-lobby')}>
              <Plus className="w-4 h-4 ml-2" />
              ایجاد لابی جدید
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-primary">{filteredLobbies.length}</div>
          <div className="text-sm text-muted-foreground">لابی فعال</div>
        </Card>
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-green-500">{filteredLobbies.filter(l => l.status === 'waiting').length}</div>
          <div className="text-sm text-muted-foreground">در انتظار</div>
        </Card>
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-yellow-500">{filteredLobbies.filter(l => l.isPaidLobby).length}</div>
          <div className="text-sm text-muted-foreground">پولی</div>
        </Card>
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-purple-500">{filteredLobbies.filter(l => l.isTournamentGame).length}</div>
          <div className="text-sm text-muted-foreground">مسابقه‌ای</div>
        </Card>
      </div>

      {/* Join by Code Dialog */}
      <JoinByCodeDialog
        open={showJoinByCodeDialog}
        onOpenChange={setShowJoinByCodeDialog}
        onLobbyFound={handleLobbyFoundByCode}
      />
    </div>
  );
}