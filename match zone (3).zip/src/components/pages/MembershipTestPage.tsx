/**
 * Membership Test Page
 * Complete testing interface for lobby membership and team management
 */

import React from 'react';
import { MembershipTestDemo } from '../gaming/MembershipTestDemo';
import { LobbyProvider } from '../gaming/LobbyContext';
import { Button } from '../ui/button';
import { ArrowRight } from 'lucide-react';

interface MembershipTestPageProps {
  onBack?: () => void;
}

export function MembershipTestPage({ onBack }: MembershipTestPageProps) {
  return (
    <div className="min-h-screen bg-background">
      {onBack && (
        <div className="p-4">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowRight className="w-4 h-4 ml-2" />
            بازگشت
          </Button>
        </div>
      )}
      
      <LobbyProvider>
        <MembershipTestDemo />
      </LobbyProvider>
    </div>
  );
}