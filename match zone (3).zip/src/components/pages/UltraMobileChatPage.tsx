/**
 * Ultra Mobile Chat Page - کاملاً موبایل محور
 * طراحی شده برای صفحات کوچک موبایل
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Smile, 
  Mic, 
  ArrowLeft,
  MoreVertical,
  Crown,
  Shield,
  Star,
  Zap,
  Users,
  Hash,
  X
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { useNavigation } from '../navigation/NavigationProvider';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  isOwn: boolean;
  type: 'text' | 'gift' | 'join';
  role: 'player' | 'admin' | 'vip' | 'moderator';
  avatar?: string;
  reactions?: { emoji: string; count: number }[];
}

interface ChatRoom {
  id: string;
  name: string;
  memberCount: number;
  onlineCount: number;
  type: 'public' | 'lobby' | 'tournament';
}

export function UltraMobileChatPage() {
  const { navigate } = useNavigation();
  const [message, setMessage] = useState('');
  const [showRoomInfo, setShowRoomInfo] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [showEmojis, setShowEmojis] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  // Helper function to scroll to bottom
  const scrollToBottom = (smooth = true) => {
    requestAnimationFrame(() => {
      // Method 1: scrollIntoView on end element
      if (messagesEndRef.current) {
        try {
          messagesEndRef.current.scrollIntoView({ 
            behavior: smooth ? 'smooth' : 'auto',
            block: 'end',
            inline: 'nearest'
          });
        } catch (e) {
          console.log('ScrollIntoView failed:', e);
        }
      }
      
      // Method 2: Direct container scroll (fallback)
      if (messagesContainerRef.current) {
        try {
          const container = messagesContainerRef.current;
          const scrollTop = container.scrollHeight - container.clientHeight;
          
          if (smooth) {
            container.scrollTo({
              top: scrollTop,
              behavior: 'smooth'
            });
          } else {
            container.scrollTop = scrollTop;
          }
        } catch (e) {
          console.log('Container scroll failed:', e);
        }
      }
    });
  };

  const quickEmojis = ['😀', '😍', '🤔', '😮', '🔥', '💎', '🎯', '👏', '💪', '❤️', '👍', '😂'];

  const currentRoom: ChatRoom = {
    id: 'main',
    name: 'لابی اصلی',
    memberCount: 127,
    onlineCount: 89,
    type: 'lobby'
  };

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      username: 'گیمر طلایی',
      message: 'سلام! کسی برای Valorant آماده است؟ 🎮',
      timestamp: new Date(Date.now() - 300000),
      isOwn: false,
      type: 'text',
      role: 'admin',
      avatar: '👑',
      reactions: [{ emoji: '🔥', count: 3 }]
    },
    {
      id: '2',
      username: 'سارا پرو گیمر',
      message: 'آره! من Jett main هستم',
      timestamp: new Date(Date.now() - 240000),
      isOwn: false,
      type: 'text',
      role: 'vip',
      avatar: '⭐'
    },
    {
      id: '3',
      username: 'شما',
      message: 'عالی! من هم آماده‌ام 💪',
      timestamp: new Date(Date.now() - 180000),
      isOwn: true,
      type: 'text',
      role: 'player',
      avatar: '🎯'
    },
    {
      id: '4',
      username: 'علی چمپیون',
      message: '',
      timestamp: new Date(Date.now() - 120000),
      isOwn: false,
      type: 'gift',
      role: 'player',
      avatar: '🏆'
    },
    {
      id: '5',
      username: 'تیم لیدر',
      message: 'بیاین VC بزنیم 🎧',
      timestamp: new Date(Date.now() - 60000),
      isOwn: false,
      type: 'text',
      role: 'moderator',
      avatar: '🛡️'
    }
  ]);

  // Auto scroll to bottom when messages change
  useEffect(() => {
    // Small delay to ensure DOM is updated
    const timeoutId = setTimeout(() => scrollToBottom(true), 100);
    
    return () => clearTimeout(timeoutId);
  }, [messages]);

  const handleSendMessage = async () => {
    if (!message.trim() || isSending) return;

    setIsSending(true);
    
    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      username: 'شما',
      message: message.trim(),
      timestamp: new Date(),
      isOwn: true,
      type: 'text',
      role: 'player',
      avatar: '🎯'
    };

    // Clear input immediately for better UX
    const messageText = message.trim();
    setMessage('');
    setShowEmojis(false);
    
    // Add message with small delay to simulate sending
    setTimeout(() => {
      setMessages(prev => [...prev, newMessage]);
      setIsSending(false);
      
      // Force scroll to bottom after message is added
      setTimeout(() => scrollToBottom(true), 100);
    }, 200);
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const existingReaction = msg.reactions?.find(r => r.emoji === emoji);
        if (existingReaction) {
          return {
            ...msg,
            reactions: msg.reactions?.map(r => 
              r.emoji === emoji ? { ...r, count: r.count + 1 } : r
            )
          };
        } else {
          return {
            ...msg,
            reactions: [...(msg.reactions || []), { emoji, count: 1 }]
          };
        }
      }
      return msg;
    }));
  };



  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'moderator': return <Shield className="w-4 h-4 text-blue-400" />;
      case 'vip': return <Star className="w-4 h-4 text-purple-400" />;
      default: return null;
    }
  };

  const MessageComponent = ({ message: msg }: { message: ChatMessage }) => (
    <div className={`mb-3 max-w-full overflow-hidden ${msg.isOwn ? 'text-left' : 'text-right'}`} dir={msg.isOwn ? 'ltr' : 'rtl'}>
      <div className={`flex items-start gap-2 max-w-full ${msg.isOwn ? 'flex-row' : 'flex-row-reverse'}`}>
        {!msg.isOwn && (
          <Avatar className="w-8 h-8 flex-shrink-0">
            <AvatarFallback className="bg-gradient-to-br from-primary/30 to-accent/30">
              {msg.avatar || msg.username[0]}
            </AvatarFallback>
          </Avatar>
        )}
        
        <div className={`flex-1 min-w-0 max-w-full overflow-hidden ${msg.isOwn ? 'text-left' : 'text-right'}`}>
          {!msg.isOwn && (
            <div className="flex items-center gap-2 mb-1">
              {getRoleIcon(msg.role)}
              <span className="font-medium truncate max-w-24">{msg.username}</span>
              <span className="text-sm text-muted-foreground">
                {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          )}
          
          <div className={`max-w-[70%] min-w-0 overflow-hidden ${msg.isOwn ? 'ml-auto' : 'mr-auto'}`} style={{ maxWidth: 'calc(100% - 40px)' }}>
            {msg.type === 'gift' ? (
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 p-3 rounded-lg border border-yellow-500/30 break-words">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  <span className="break-words">هدیه فرستاد! 🎁</span>
                </div>
              </div>
            ) : (
              <div className={`py-3 px-4 rounded-xl leading-relaxed break-words overflow-wrap-anywhere ${
                msg.isOwn 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-card border border-border/50'
              }`}>
                {msg.message}
                {msg.isOwn && (
                  <div className="text-sm opacity-70 mt-1 break-words">
                    {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                )}
              </div>
            )}
            
            {/* Reactions */}
            {msg.reactions && msg.reactions.length > 0 && (
              <div className="flex gap-2 mt-2">
                {msg.reactions.map((reaction, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleReaction(msg.id, reaction.emoji)}
                    className="flex items-center gap-1 bg-muted/50 px-2 py-1 rounded-full border border-border/30 active:scale-95 transition-transform"
                  >
                    <span>{reaction.emoji}</span>
                    <span>{reaction.count}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-screen w-full flex flex-col bg-background overflow-hidden max-w-full" style={{ maxWidth: '100vw' }}>
      {/* Ultra Compact Header */}
      <div className="flex-shrink-0 bg-card/95 backdrop-blur border-b border-border/50 max-w-full overflow-hidden">
        <div className="flex items-center justify-between p-4 max-w-full overflow-hidden">
          <div className="flex items-center gap-3 flex-1 min-w-0 overflow-hidden">
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-2 h-10 w-10 flex-shrink-0 hover:bg-muted/20 transition-colors"
              onClick={() => setShowRoomInfo(true)}
              aria-label="اطلاعات روم و اعضا"
            >
              <MoreVertical className="w-6 h-6" />
            </Button>
            
            <div className="flex items-center gap-3 flex-1 min-w-0 overflow-hidden">
              <div className="relative flex-shrink-0">
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-gradient-to-br from-primary/30 to-accent/30">
                    <Hash className="w-6 h-6" />
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
              </div>
              
              <div className="flex-1 min-w-0 text-right overflow-hidden" dir="rtl">
                <h2 className="font-medium truncate">{currentRoom.name}</h2>
                <div className="flex items-center gap-2 text-sm text-muted-foreground justify-end">
                  <Users className="w-4 h-4 flex-shrink-0" />
                  <span className="whitespace-nowrap">{currentRoom.onlineCount}</span>
                </div>
              </div>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-3 h-12 w-12 flex-shrink-0 hover:bg-muted/20 transition-colors" 
            onClick={() => navigate('chat-list')}
            aria-label="برگشت به لیست چت‌ها"
          >
            <ArrowLeft className="w-8 h-8" />
          </Button>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-hidden max-w-full">
        <div className="h-full flex flex-col px-4 py-3 max-w-full overflow-x-hidden">
          <div ref={messagesContainerRef} className="flex-1 space-y-4 overflow-y-auto overflow-x-hidden max-w-full fade-scrollbar">
            {messages.map((msg) => (
              <MessageComponent key={msg.id} message={msg} />
            ))}
            <div ref={messagesEndRef} className="h-1" />
          </div>
        </div>
      </div>

      {/* Emoji Picker - Ultra Compact */}
      <AnimatePresence>
        {showEmojis && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="flex-shrink-0 p-2 bg-card/95 border-t border-border/50 max-w-full overflow-hidden"
          >
            <div className="flex items-center justify-between mb-1 max-w-full overflow-hidden">
              <span className="text-xs font-medium">Emoji</span>
              <Button 
                variant="ghost" 
                size="sm"
                className="p-0.5 h-4 w-4 flex-shrink-0"
                onClick={() => setShowEmojis(false)}
              >
                <X className="w-2.5 h-2.5" />
              </Button>
            </div>
            <div className="grid grid-cols-6 gap-1 max-w-full overflow-hidden">
              {quickEmojis.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => {
                    setMessage(prev => prev + emoji);
                    setShowEmojis(false);
                  }}
                  className="w-6 h-6 flex items-center justify-center hover:bg-muted/50 rounded text-sm active:scale-90 transition-transform"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Enhanced Mobile Input */}
      <div className="flex-shrink-0 p-4 bg-card/95 backdrop-blur border-t border-border/50 max-w-full">
        <div className="flex items-center gap-3 max-w-full overflow-hidden">
          <Button 
            variant="ghost" 
            size="sm"
            className="p-2 h-10 w-10 flex-shrink-0"
            onClick={() => setShowEmojis(!showEmojis)}
          >
            <Smile className="w-5 h-5" />
          </Button>
          
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder="پیام بنویس..."
            className="flex-1 h-12 bg-muted/30 border-border/50 rounded-xl px-4 min-w-0 max-w-full"
            dir="rtl"
          />
          
          <Button 
            variant="ghost" 
            size="sm"
            className={`p-2 h-10 w-10 flex-shrink-0 ${isRecording ? 'text-red-500' : ''}`}
            onClick={() => setIsRecording(!isRecording)}
          >
            <Mic className="w-5 h-5" />
          </Button>
          
          <Button 
            onClick={handleSendMessage}
            disabled={!message.trim() || isSending}
            size="sm"
            className={`p-2 h-10 w-10 flex-shrink-0 transition-all duration-200 ${
              isSending ? 'scale-95 opacity-50' : 'scale-100 opacity-100'
            } ${
              message.trim() ? 'bg-primary/20 text-primary hover:bg-primary/30' : ''
            }`}
          >
            {isSending ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              >
                <Send className="w-5 h-5" />
              </motion.div>
            ) : (
              <Send className="w-5 h-5" />
            )}
          </Button>
        </div>
      </div>

      {/* Room Info Dialog */}
      <Dialog open={showRoomInfo} onOpenChange={setShowRoomInfo}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-right">اطلاعات روم</DialogTitle>
            <DialogDescription className="text-right">
              مشاهده اطلاعات کامل روم، اعضای آنلاین و تنظیمات سریع چت
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Room Info */}
            <div className="flex items-center gap-4">
              <Avatar className="w-16 h-16">
                <AvatarFallback className="bg-gradient-to-br from-primary/30 to-accent/30">
                  <Hash className="w-8 h-8" />
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 text-right">
                <h3 className="font-medium">{currentRoom.name}</h3>
                <p className="text-sm text-muted-foreground">{currentRoom.type === 'lobby' ? 'لابی بازی' : currentRoom.type === 'tournament' ? 'تورنومنت' : 'چت عمومی'}</p>
                <div className="flex items-center gap-2 mt-1 justify-end">
                  <Users className="w-4 h-4" />
                  <span className="text-sm">{currentRoom.onlineCount} نفر آنلاین</span>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-3">
              <h4 className="font-medium text-right">تنظیمات سریع</h4>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" size="sm" className="gap-2">
                  <Users className="w-4 h-4" />
                  اعضای آنلاین
                </Button>
                <Button variant="outline" size="sm" className="gap-2">
                  <Crown className="w-4 h-4" />
                  ادمین‌ها
                </Button>
                <Button variant="outline" size="sm" className="gap-2">
                  <Zap className="w-4 h-4" />
                  اعلان‌ها
                </Button>
                <Button variant="outline" size="sm" className="gap-2">
                  <Shield className="w-4 h-4" />
                  گزارش
                </Button>
              </div>
            </div>

            {/* Online Members Preview */}
            <div className="space-y-3">
              <h4 className="font-medium text-right">اعضای آنلاین</h4>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {[
                  { name: 'GamerPro_89', role: 'admin', status: 'online' },
                  { name: 'Shadow_Hunter', role: 'member', status: 'online' },
                  { name: 'Elite_Player', role: 'member', status: 'online' },
                  { name: 'Persian_Warrior', role: 'member', status: 'online' },
                ].map((member, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-2 rounded-lg bg-muted/30">
                    <div className="flex items-center gap-2 flex-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="text-xs">
                          {member.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 text-right">
                        <p className="text-sm font-medium">{member.name}</p>
                      </div>
                      {member.role === 'admin' && (
                        <Crown className="w-4 h-4 text-yellow-500" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
}