import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { 
  Trophy, Users, Clock, DollarSign, Calendar, Search, Filter, 
  Medal, Crown, Star, Target, Gamepad2, Plus, Eye, Play,
  TrendingUp, Award, Globe, MapPin, AlertCircle, CheckCircle
} from 'lucide-react';
import { useMobile } from '../ui/use-mobile';
import { TournamentBracket, BracketMatch } from '../tournaments/TournamentBracket';
import { TournamentRegistration, Tournament } from '../tournaments/TournamentRegistration';
import { TournamentLeaderboard, LeaderboardPlayer, TournamentStats } from '../tournaments/TournamentLeaderboard';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';

export function EnhancedTournamentsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [gameFilter, setGameFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedTournament, setSelectedTournament] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<'list' | 'bracket' | 'leaderboard'>('list');
  const isMobile = useMobile();

  // Mock user data
  const userBalance = 250000;
  const userRank = 'الماسی';

  const tournaments: Tournament[] = [
    {
      id: 'tournament-1',
      title: 'کاپ طلایی کالاف دیوتی',
      game: 'کالاف دیوتی',
      description: 'بزرگترین تورنومنت ماه با جوایز نقدی عالی و حضور بهترین تیم‌های کشور',
      prize: '۱۰۰,۰۰۰ تومان',
      prizePool: '۵۰۰,۰۰۰ تومان',
      entryFee: 10000,
      participants: { current: 45, max: 64 },
      status: 'registration',
      startTime: '۲ ساعت دیگر',
      startDate: '۱۴۰۳/۰۸/۱۵',
      organizer: { 
        name: 'گیم‌هاب پرو', 
        verified: true, 
        avatar: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=64'
      },
      format: 'حذفی تک‌مرحله‌ای',
      rules: [
        'تمام بازیکنان باید رنک الماسی یا بالاتر داشته باشند',
        'هرگونه تقلب یا استفاده از هک منجر به حذف دائمی می‌شود',
        'پرداخت هزینه ثبت‌نام قبل از شروع مسابقه الزامی است',
        'شرکت‌کنندگان باید در چت و ارتباطات مودب و محترم باشند',
        'تاخیر بیش از 10 دقیقه منجر به شکست خودکار می‌شود'
      ],
      requirements: {
        minRank: 'الماسی',
        region: 'ایران',
        age: '16+'
      },
      paymentMethods: ['wallet', 'card'],
      earlyBirdDiscount: 15,
      teamSize: 1
    },
    {
      id: 'tournament-2',
      title: 'لیگ فیفا ماهانه',
      game: 'فیفا 24',
      description: 'مسابقات ماهانه فیفا با سیستم لیگی و امکان صعود به لیگ‌های بالاتر',
      prize: '۵۰,۰۰۰ تومان',
      prizePool: '۲۰۰,۰۰۰ تومان',
      entryFee: 5000,
      participants: { current: 28, max: 32 },
      status: 'registration',
      startTime: 'فردا ۲۰:۰۰',
      startDate: '۱۴۰۳/۰۸/۱۶',
      organizer: { 
        name: 'تیم_فیفا_ایران', 
        verified: true,
        avatar: 'https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=64'
      },
      format: 'سیستم لیگی',
      rules: [
        'بازی‌ها باید در حالت آنلاین انجام شود',
        'تنظیمات بازی طبق استاندارد FIFA eWorld Cup',
        'هر بازیکن حق 3 بازی در روز دارد',
        'نتایج باید با عکس‌گیری از صفحه تایید شود'
      ],
      requirements: {
        minRank: 'طلایی',
        region: 'ایران'
      },
      paymentMethods: ['wallet', 'card'],
      teamSize: 1
    },
    {
      id: 'tournament-3',
      title: 'مسابقات والورانت حرفه‌ای',
      game: 'والورانت',
      description: 'تورنومنت سطح بالا برای تیم‌های حرفه‌ای و بازیکنان با تجربه',
      prize: '۷۵,۰۰۰ تومان',
      prizePool: '۳۰۰,۰۰۰ تومان',
      entryFee: 15000,
      participants: { current: 16, max: 16 },
      status: 'started',
      startTime: 'شروع شده',
      startDate: '۱۴۰۳/۰۸/۱۴',
      organizer: { 
        name: 'والورانت_پرو_لیگ', 
        verified: false,
        avatar: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=64'
      },
      format: 'حذفی تیمی',
      rules: [
        'هر تیم 5 بازیکن اصلی + 1 بازیکن ذخیره',
        'بازی‌ها Best of 3 انجام می‌شود',
        'استفاده از برنامه‌های ثالث ممنوع',
        'تمام اعضای تیم باید در دیسکورد حضور داشته باشند'
      ],
      requirements: {
        minRank: 'الماسی',
        region: 'ایران',
        age: '18+'
      },
      paymentMethods: ['wallet', 'card'],
      teamSize: 5
    }
  ];

  // Mock bracket data
  const mockBracketMatches: BracketMatch[] = [
    {
      id: 'match-1',
      team1: { name: 'تیم الماس', seed: 1, score: 2, rank: 'الماسی' },
      team2: { name: 'شیرهای طلایی', seed: 8, score: 1, rank: 'طلایی' },
      winner: 'team1',
      status: 'finished',
      round: 'یک‌چهارم نهایی',
      startTime: '20:00'
    },
    {
      id: 'match-2',
      team1: { name: 'گیمرهای ایران', seed: 4, score: 0, rank: 'الماسی' },
      team2: { name: 'پروگیمرز', seed: 5, score: 2, rank: 'الماسی' },
      winner: 'team2',
      status: 'finished',
      round: 'یک‌چهارم نهایی',
      startTime: '20:30'
    },
    {
      id: 'match-3',
      team1: { name: 'تیم الماس', seed: 1 },
      team2: { name: 'پروگیمرز', seed: 5 },
      status: 'live',
      round: 'نیمه‌نهایی',
      startTime: 'الان',
      streamUrl: 'https://twitch.tv/tournament'
    },
    {
      id: 'match-4',
      team1: { name: 'TBD', seed: 0 },
      team2: { name: 'TBD', seed: 0 },
      status: 'upcoming',
      round: 'فینال',
      startTime: 'فردا 21:00'
    }
  ];

  // Mock leaderboard data
  const mockLeaderboardPlayers: LeaderboardPlayer[] = [
    {
      id: 'player-1',
      name: 'علی_پرو_گیمر',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=64',
      rank: 1,
      previousRank: 3,
      points: 2340,
      wins: 28,
      losses: 5,
      winRate: 85,
      tournamentsPlayed: 12,
      totalEarnings: 450000,
      currentStreak: 8,
      bestFinish: 1,
      gameRank: 'الماسی',
      country: 'ایران',
      team: 'تیم الماس',
      status: 'online',
      lastActive: '2 دقیقه پیش',
      achievements: ['مقام اول تورنومنت', 'رکورد برد پیاپی']
    },
    {
      id: 'player-2',
      name: 'سارا_والورانت',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
      rank: 2,
      previousRank: 1,
      points: 2280,
      wins: 25,
      losses: 7,
      winRate: 78,
      tournamentsPlayed: 10,
      totalEarnings: 320000,
      currentStreak: 5,
      bestFinish: 1,
      gameRank: 'الماسی',
      country: 'ایران',
      team: 'شیرهای طلایی',
      status: 'in-game',
      lastActive: 'در حال بازی',
      achievements: ['برترین بازیکن ماه']
    },
    {
      id: 'player-3',
      name: 'محمد_استریمر',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64',
      rank: 3,
      previousRank: 4,
      points: 2150,
      wins: 22,
      losses: 8,
      winRate: 73,
      tournamentsPlayed: 15,
      totalEarnings: 280000,
      currentStreak: 3,
      bestFinish: 2,
      gameRank: 'طلایی',
      country: 'ایران',
      status: 'offline',
      lastActive: '1 ساعت پیش',
      achievements: ['محبوب‌ترین استریمر']
    }
  ];

  const mockTournamentStats: TournamentStats = {
    totalPlayers: 64,
    totalPrizePool: 500000,
    averageSkill: 'الماسی',
    topCountries: [
      { name: 'ایران', count: 45 },
      { name: 'افغانستان', count: 8 },
      { name: 'عراق', count: 6 },
      { name: 'آذربایجان', count: 3 },
      { name: 'ترکیه', count: 2 }
    ],
    recentWinners: mockLeaderboardPlayers.slice(0, 3)
  };

  const filteredTournaments = tournaments.filter(tournament => {
    const matchesSearch = tournament.title.includes(searchQuery) || tournament.game.includes(searchQuery);
    const matchesGame = gameFilter === 'all' || tournament.game === gameFilter;
    const matchesStatus = statusFilter === 'all' || tournament.status === statusFilter;
    return matchesSearch && matchesGame && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'registration': return 'default';
      case 'started': return 'secondary';
      case 'finished': return 'destructive';
      default: return 'default';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'registration': return 'ثبت‌نام';
      case 'started': return 'در حال برگزاری';
      case 'finished': return 'تمام شده';
      default: return status;
    }
  };

  const getRegistrationProgress = (current: number, max: number) => {
    return (current / max) * 100;
  };

  const handleRegister = (registrationData: any) => {
    console.log('Tournament Registration:', registrationData);
    toast.success('ثبت‌نام موفق!', {
      description: 'شما با موفقیت در تورنومنت ثبت‌نام شدید.'
    });
  };

  const selectedTournamentData = tournaments.find(t => t.id === selectedTournament);

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="flex-1 text-right">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 rounded-xl border border-yellow-500/30">
              <Trophy className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <h1 className="font-bold bg-gradient-to-l from-yellow-400 via-orange-400 to-red-400 bg-clip-text text-transparent">
                تورنومنت‌ها
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <p className="text-muted-foreground">
                  {filteredTournaments.length} تورنومنت فعال • {mockTournamentStats.totalPlayers} بازیکن
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Plus className="w-4 h-4 ml-2" />
            برگزاری تورنومنت
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="text-center p-4 bg-gradient-to-br from-blue-500/5 to-blue-600/10 border-blue-500/20">
          <div className="text-2xl font-bold text-blue-500">{filteredTournaments.filter(t => t.status === 'registration').length}</div>
          <div className="text-sm text-muted-foreground">باز برای ثبت‌نام</div>
        </Card>
        
        <Card className="text-center p-4 bg-gradient-to-br from-green-500/5 to-green-600/10 border-green-500/20">
          <div className="text-2xl font-bold text-green-500">{filteredTournaments.filter(t => t.status === 'started').length}</div>
          <div className="text-sm text-muted-foreground">در حال برگزاری</div>
        </Card>
        
        <Card className="text-center p-4 bg-gradient-to-br from-yellow-500/5 to-yellow-600/10 border-yellow-500/20">
          <div className="text-2xl font-bold text-yellow-500">
            {filteredTournaments.reduce((sum, t) => sum + parseInt(t.prizePool.replace(/[,۰-۹]/g, match => match === ',' ? '' : String('۰۱۲۳۴۵۶۷۸۹'.indexOf(match)))), 0).toLocaleString()}
          </div>
          <div className="text-sm text-muted-foreground">تومان جایزه کل</div>
        </Card>
        
        <Card className="text-center p-4 bg-gradient-to-br from-purple-500/5 to-purple-600/10 border-purple-500/20">
          <div className="text-2xl font-bold text-purple-500">{mockTournamentStats.totalPlayers}</div>
          <div className="text-sm text-muted-foreground">بازیکن فعال</div>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="جستجوی تورنومنت..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
                dir="rtl"
              />
            </div>

            {/* Filter Controls */}
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="وضعیت" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  <SelectItem value="registration">ثبت‌نام</SelectItem>
                  <SelectItem value="started">در حال برگزاری</SelectItem>
                  <SelectItem value="finished">تمام شده</SelectItem>
                </SelectContent>
              </Select>

              <Select value={gameFilter} onValueChange={setGameFilter}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="بازی" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه بازی‌ها</SelectItem>
                  <SelectItem value="کالاف دیوتی">کالاف دیوتی</SelectItem>
                  <SelectItem value="فیفا 24">فیفا 24</SelectItem>
                  <SelectItem value="والورانت">والورانت</SelectItem>
                  <SelectItem value="لیگ آف لجندز">لیگ آف لجندز</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* View Toggle */}
      <Tabs value={activeView} onValueChange={(value: any) => setActiveView(value)} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="list">لیست تورنومنت‌ها</TabsTrigger>
          <TabsTrigger value="bracket">جدول مسابقات</TabsTrigger>
          <TabsTrigger value="leaderboard">جدول امتیازات</TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-4">
          <AnimatePresence>
            {filteredTournaments.map((tournament) => (
              <motion.div
                key={tournament.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <Card className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                  selectedTournament === tournament.id ? 'ring-2 ring-primary' : ''
                }`}>
                  <CardContent className="p-6">
                    <div className={`grid ${isMobile ? 'grid-cols-1 space-y-4' : 'grid-cols-4 gap-6'} items-start`}>
                      {/* Tournament Info */}
                      <div className={`${isMobile ? 'col-span-1' : 'col-span-2'} space-y-3`}>
                        <div className="flex items-start justify-between">
                          <div className="flex flex-col items-end space-y-2">
                            <Badge variant={getStatusColor(tournament.status) as any}>
                              {getStatusText(tournament.status)}
                            </Badge>
                            {tournament.organizer.verified && (
                              <Badge variant="secondary" className="text-xs">
                                <Crown className="w-3 h-3 ml-1" />
                                معتبر
                              </Badge>
                            )}
                            {tournament.earlyBirdDiscount && (
                              <Badge variant="outline" className="text-xs bg-green-500/10 border-green-500/30 text-green-400">
                                تخفیف {tournament.earlyBirdDiscount}%
                              </Badge>
                            )}
                          </div>
                          <div className="text-right space-y-1 flex-1">
                            <h3 className="font-bold text-xl">{tournament.title}</h3>
                            <div className="flex items-center gap-2 justify-end">
                              <span className="text-primary font-medium">{tournament.game}</span>
                              <Gamepad2 className="w-4 h-4 text-muted-foreground" />
                            </div>
                            <p className="text-sm text-muted-foreground">{tournament.description}</p>
                          </div>
                        </div>

                        {/* Tournament Details */}
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="text-right">
                            <div className="flex justify-between">
                              <span>{tournament.format}</span>
                              <span className="text-muted-foreground">فرمت:</span>
                            </div>
                            <div className="flex justify-between">
                              <span>{tournament.organizer.name}</span>
                              <span className="text-muted-foreground">برگزارکننده:</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex justify-between">
                              <span>{tournament.teamSize === 1 ? 'انفرادی' : `${tournament.teamSize} نفره`}</span>
                              <span className="text-muted-foreground">نوع:</span>
                            </div>
                            <div className="flex justify-between">
                              <span>{tournament.requirements.minRank || 'آزاد'}</span>
                              <span className="text-muted-foreground">حداقل رنک:</span>
                            </div>
                          </div>
                        </div>

                        {/* Registration Progress */}
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>{tournament.participants.current}/{tournament.participants.max}</span>
                            <span>شرکت‌کنندگان</span>
                          </div>
                          <Progress value={getRegistrationProgress(tournament.participants.current, tournament.participants.max)} />
                        </div>
                      </div>

                      {/* Prize & Timing */}
                      <div className="space-y-4 text-right">
                        <div className="space-y-3">
                          <div className="text-center p-4 bg-gradient-to-br from-yellow-500/10 to-orange-500/10 rounded-lg border border-yellow-500/20">
                            <div className="flex items-center justify-center gap-2 mb-2">
                              <Trophy className="w-5 h-5 text-yellow-500" />
                              <span className="text-sm text-muted-foreground">جایزه اول</span>
                            </div>
                            <div className="font-bold text-xl text-yellow-600">{tournament.prize}</div>
                            <div className="text-xs text-muted-foreground mt-1">
                              از کل {tournament.prizePool}
                            </div>
                          </div>

                          <div className="text-center p-3 bg-muted/50 rounded-lg">
                            <div className="flex items-center justify-center gap-2 mb-1">
                              <DollarSign className="w-4 h-4 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">هزینه ثبت‌نام</span>
                            </div>
                            <div className="font-bold text-lg">
                              {tournament.earlyBirdDiscount ? (
                                <div className="space-y-1">
                                  <div className="text-green-600">
                                    {(tournament.entryFee * (1 - tournament.earlyBirdDiscount / 100)).toLocaleString()} تومان
                                  </div>
                                  <div className="text-xs text-muted-foreground line-through">
                                    {tournament.entryFee.toLocaleString()} تومان
                                  </div>
                                </div>
                              ) : (
                                <span>{tournament.entryFee.toLocaleString()} تومان</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="space-y-3">
                        <div className="text-center space-y-2">
                          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                            <Clock className="w-4 h-4" />
                            <span>{tournament.startTime}</span>
                          </div>
                          <div className="flex items-center justify-center gap-2 text-sm">
                            <Calendar className="w-4 h-4" />
                            <span>{tournament.startDate}</span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {tournament.status === 'registration' && (
                            <TournamentRegistration
                              tournament={tournament}
                              onRegister={handleRegister}
                              userBalance={userBalance}
                              userRank={userRank}
                            />
                          )}

                          {tournament.status === 'started' && (
                            <div className="space-y-2">
                              <Button variant="default" className="w-full">
                                <Play className="w-4 h-4 ml-2" />
                                مشاهده زنده
                              </Button>
                              <Button variant="outline" className="w-full" size="sm">
                                <Target className="w-4 h-4 ml-2" />
                                جدول مسابقات
                              </Button>
                            </div>
                          )}

                          {tournament.status === 'finished' && (
                            <div className="space-y-2">
                              <Button variant="outline" className="w-full">
                                <Trophy className="w-4 h-4 ml-2" />
                                نتایج نهایی
                              </Button>
                              <Button variant="ghost" className="w-full" size="sm">
                                <Award className="w-4 h-4 ml-2" />
                                برندگان
                              </Button>
                            </div>
                          )}

                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="w-full"
                            onClick={() => setSelectedTournament(selectedTournament === tournament.id ? null : tournament.id)}
                          >
                            <Eye className="w-4 h-4 ml-2" />
                            جزئیات بیشتر
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Expanded Details */}
                    <AnimatePresence>
                      {selectedTournament === tournament.id && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="mt-6 pt-6 border-t overflow-hidden"
                        >
                          <div className="space-y-6">
                            {/* Tournament Rules */}
                            <div className="grid md:grid-cols-2 gap-6">
                              <Card>
                                <CardHeader>
                                  <CardTitle className="text-sm">قوانین و مقررات</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <ul className="space-y-2 text-sm">
                                    {tournament.rules.map((rule, index) => (
                                      <li key={index} className="flex items-start gap-2">
                                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                        <span>{rule}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </CardContent>
                              </Card>

                              <Card>
                                <CardHeader>
                                  <CardTitle className="text-sm">شرایط شرکت</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-3">
                                  <div className="grid grid-cols-2 gap-4 text-sm">
                                    <div className="space-y-2">
                                      <div className="flex justify-between">
                                        <span>{tournament.requirements.minRank || 'آزاد'}</span>
                                        <span className="text-muted-foreground">حداقل رنک:</span>
                                      </div>
                                      <div className="flex justify-between">
                                        <span>{tournament.requirements.region || 'جهانی'}</span>
                                        <span className="text-muted-foreground">منطقه:</span>
                                      </div>
                                    </div>
                                    <div className="space-y-2">
                                      <div className="flex justify-between">
                                        <span>{tournament.requirements.age || 'آزاد'}</span>
                                        <span className="text-muted-foreground">محدودیت سنی:</span>
                                      </div>
                                      <div className="flex justify-between">
                                        <span>{tournament.teamSize === 1 ? 'انفرادی' : `${tournament.teamSize} نفره`}</span>
                                        <span className="text-muted-foreground">اندازه تیم:</span>
                                      </div>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </div>

                            {/* Payment Methods */}
                            <Card>
                              <CardHeader>
                                <CardTitle className="text-sm">روش‌های پرداخت قابل قبول</CardTitle>
                              </CardHeader>
                              <CardContent>
                                <div className="flex gap-2">
                                  {tournament.paymentMethods.map((method) => (
                                    <Badge key={method} variant="outline">
                                      {method === 'wallet' && 'کیف پول'}
                                      {method === 'card' && 'کارت بانکی'}
                                    </Badge>
                                  ))}
                                </div>
                              </CardContent>
                            </Card>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </TabsContent>

        <TabsContent value="bracket" className="space-y-4">
          <TournamentBracket
            matches={mockBracketMatches}
            format="single-elimination"
            currentRound="نیمه‌نهایی"
            isLive={true}
          />
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-4">
          <TournamentLeaderboard
            players={mockLeaderboardPlayers}
            stats={mockTournamentStats}
            tournamentTitle="کاپ طلایی کالاف دیوتی"
            isLive={true}
            showGlobalRanking={true}
          />
        </TabsContent>
      </Tabs>

      {/* Empty State */}
      {filteredTournaments.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <Trophy className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-medium mb-2">تورنومنتی یافت نشد</h3>
            <p className="text-muted-foreground mb-6">
              با فیلترهای انتخاب شده تورنومنتی وجود ندارد. فیلترها را تغییر دهید یا تورنومنت جدید ایجاد کنید.
            </p>
            <Button>
              <Plus className="w-4 h-4 ml-2" />
              برگزاری تورنومنت جدید
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}