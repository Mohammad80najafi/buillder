/**
 * Videos Page
 * صفحه اصلی ویدیوها و سری بازی‌ها
 */

import React, { useState, useMemo, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { GameSeriesGrid } from '../gaming/GameSeriesGrid';
import { GameSeriesCard } from '../gaming/GameSeriesCard';
import { 
  Play, Search, Filter, TrendingUp, Clock, Star,
  Users, Trophy, Crown, Video, Gamepad2, Eye,
  Calendar, Flame, PlayCircle, Grid, List
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useMobile } from '../ui/use-mobile';
import { 
  mockGameSeries, 
  getFeaturedGameSeries, 
  getPopularGameSeries, 
  getNewGameSeries,
  getGameSeriesByCategory 
} from '../../data/mockGameSeries';

interface VideosPageProps {
  onNavigateToSeries?: (seriesId: string) => void;
  onNavigateToEpisode?: (episodeId: string) => void;
  onNavigateToVideo?: (videoId: string) => void;
}

export function VideosPage({ 
  onNavigateToSeries, 
  onNavigateToEpisode,
  onNavigateToVideo 
}: VideosPageProps) {
  const isMobile = useMobile();
  const [activeTab, setActiveTab] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('همه');

  // Memoize expensive calculations
  const featuredSeries = useMemo(() => getFeaturedGameSeries(), []);
  const popularSeries = useMemo(() => getPopularGameSeries(), []);
  const newSeries = useMemo(() => getNewGameSeries(), []);
  const allSeries = useMemo(() => mockGameSeries, []);

  const categories = useMemo(() => 
    ['همه', 'بقا و تاکتیک', 'اکشن و مبارزه', 'ورزشی و مسابقه‌ای', 'پازل و فکری', 'علمی تخیلی'],
    []
  );

  const getSeriesForCategory = useCallback((category: string) => {
    return getGameSeriesByCategory(category);
  }, []);

  const getTotalStats = useMemo(() => {
    const totalSeries = allSeries.length;
    const totalEpisodes = allSeries.reduce((sum, series) => sum + series.totalEpisodes, 0);
    const totalViews = allSeries.reduce((sum, series) => sum + series.stats.totalViews, 0);
    const totalParticipants = allSeries.reduce((sum, series) => sum + series.stats.totalParticipants, 0);

    return { totalSeries, totalEpisodes, totalViews, totalParticipants };
  }, [allSeries]);

  const categoryBasedSeries = useMemo(() => 
    getSeriesForCategory(selectedCategory),
    [selectedCategory, getSeriesForCategory]
  );

  return (
    <div className="space-y-8" dir="rtl">
      {/* Header with Hero Stats */}
      <div className="relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-gradient-to-br from-primary/20 via-purple-500/10 to-blue-500/20 rounded-2xl"
          style={{
            backgroundImage: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(147, 51, 234, 0.1) 50%, rgba(236, 72, 153, 0.1) 100%)'
          }}
        />
        
        <div className="relative p-8 space-y-6">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-2">
              <Video className="h-8 w-8 text-primary" />
              <h1 className="text-3xl font-bold">مرکز ویدیو و سری بازی‌ها</h1>
            </div>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              مجموعه کاملی از آموزش‌ها، مسابقات و سری بازی‌های هیجان‌انگیز را کاوش کنید
            </p>
          </div>

          {/* Stats Grid */}
          <div className={`grid ${isMobile ? 'grid-cols-2' : 'grid-cols-4'} gap-4 max-w-4xl mx-auto`}>
            <Card className="text-center bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm border-primary/20">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="h-12 w-12 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto">
                    <PlayCircle className="h-6 w-6 text-blue-500" />
                  </div>
                  <div className="text-2xl font-bold text-blue-500">
                    {getTotalStats.totalSeries}
                  </div>
                  <div className="text-sm text-muted-foreground">سری بازی</div>
                </div>
              </CardContent>
            </Card>

            <Card className="text-center bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm border-green-500/20">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="h-12 w-12 bg-green-500/10 rounded-full flex items-center justify-center mx-auto">
                    <Video className="h-6 w-6 text-green-500" />
                  </div>
                  <div className="text-2xl font-bold text-green-500">
                    {getTotalStats.totalEpisodes}
                  </div>
                  <div className="text-sm text-muted-foreground">قسمت</div>
                </div>
              </CardContent>
            </Card>

            <Card className="text-center bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm border-purple-500/20">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="h-12 w-12 bg-purple-500/10 rounded-full flex items-center justify-center mx-auto">
                    <Eye className="h-6 w-6 text-purple-500" />
                  </div>
                  <div className="text-2xl font-bold text-purple-500">
                    {(getTotalStats.totalViews / 1000000).toFixed(1)}M
                  </div>
                  <div className="text-sm text-muted-foreground">بازدید</div>
                </div>
              </CardContent>
            </Card>

            <Card className="text-center bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm border-yellow-500/20">
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="h-12 w-12 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto">
                    <Users className="h-6 w-6 text-yellow-500" />
                  </div>
                  <div className="text-2xl font-bold text-yellow-500">
                    {(getTotalStats.totalParticipants / 1000).toFixed(0)}K
                  </div>
                  <div className="text-sm text-muted-foreground">شرکت‌کننده</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Quick Access Cards */}
      <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-3'} gap-4`}>
        <Card className="group cursor-pointer hover:shadow-lg transition-all duration-300 bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-500/20">
          <CardContent className="p-6 text-center space-y-4">
            <div className="h-16 w-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
              <Crown className="h-8 w-8 text-blue-500" />
            </div>
            <div>
              <h3 className="font-semibold">سری‌های برگزیده</h3>
              <p className="text-sm text-muted-foreground">بهترین و با کیفیت‌ترین محتوا</p>
            </div>
            <Badge className="bg-blue-500 text-white">
              {featuredSeries.length} سری
            </Badge>
          </CardContent>
        </Card>

        <Card className="group cursor-pointer hover:shadow-lg transition-all duration-300 bg-gradient-to-br from-green-500/10 to-teal-500/10 border-green-500/20">
          <CardContent className="p-6 text-center space-y-4">
            <div className="h-16 w-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
            <div>
              <h3 className="font-semibold">محبوب‌ترین‌ها</h3>
              <p className="text-sm text-muted-foreground">پربازدیدترین سری بازی‌ها</p>
            </div>
            <Badge className="bg-green-500 text-white">
              {popularSeries.length} سری
            </Badge>
          </CardContent>
        </Card>

        <Card className="group cursor-pointer hover:shadow-lg transition-all duration-300 bg-gradient-to-br from-orange-500/10 to-red-500/10 border-orange-500/20">
          <CardContent className="p-6 text-center space-y-4">
            <div className="h-16 w-16 bg-orange-500/20 rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
              <Flame className="h-8 w-8 text-orange-500" />
            </div>
            <div>
              <h3 className="font-semibold">جدیدترین‌ها</h3>
              <p className="text-sm text-muted-foreground">تازه‌ترین قسمت‌ها و سری‌ها</p>
            </div>
            <Badge className="bg-orange-500 text-white">
              {newSeries.length} سری
            </Badge>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">همه سری‌ها</TabsTrigger>
          <TabsTrigger value="featured">برگزیده‌ها</TabsTrigger>
          <TabsTrigger value="popular">محبوب</TabsTrigger>
          <TabsTrigger value="categories">دسته‌بندی‌ها</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6 mt-6">
          <GameSeriesGrid
            title="همه سری‌های بازی"
            description="مجموعه کامل سری بازی‌ها و آموزش‌ها"
            series={allSeries}
            onSeriesSelect={onNavigateToSeries}
            onEpisodeSelect={onNavigateToEpisode}
            showSearch={true}
            showFilters={true}
            showCategories={true}
            itemsPerPage={isMobile ? 2 : 6}
          />
        </TabsContent>

        <TabsContent value="featured" className="space-y-6 mt-6">
          <GameSeriesGrid
            title="سری‌های برگزیده"
            description="بهترین و با کیفیت‌ترین سری بازی‌ها"
            series={featuredSeries}
            onSeriesSelect={onNavigateToSeries}
            onEpisodeSelect={onNavigateToEpisode}
            showSearch={false}
            showFilters={true}
            showCategories={false}
            itemsPerPage={isMobile ? 2 : 6}
          />
        </TabsContent>

        <TabsContent value="popular" className="space-y-6 mt-6">
          <GameSeriesGrid
            title="محبوب‌ترین سری‌ها"
            description="پربازدیدترین و محبوب‌ترین سری بازی‌ها"
            series={popularSeries}
            onSeriesSelect={onNavigateToSeries}
            onEpisodeSelect={onNavigateToEpisode}
            showSearch={false}
            showFilters={true}
            showCategories={false}
            itemsPerPage={isMobile ? 2 : 6}
          />
        </TabsContent>

        <TabsContent value="categories" className="space-y-6 mt-6">
          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">مرور بر اساس دسته‌بندی</h3>
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <Button
                    key={category}
                    size="sm"
                    variant={selectedCategory === category ? 'default' : 'outline'}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>

            <GameSeriesGrid
              title={`دسته ${selectedCategory}`}
              description={`سری بازی‌های مربوط به ${selectedCategory}`}
              series={categoryBasedSeries}
              onSeriesSelect={onNavigateToSeries}
              onEpisodeSelect={onNavigateToEpisode}
              showSearch={false}
              showFilters={false}
              showCategories={false}
              itemsPerPage={isMobile ? 2 : 6}
            />
          </div>
        </TabsContent>
      </Tabs>

      {/* Featured Series Showcase */}
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold">سری‌های ویژه این هفته</h2>
          <p className="text-muted-foreground">محبوب‌ترین و جدیدترین سری بازی‌های هفته</p>
        </div>
        
        <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-2'} gap-8`}>
          {featuredSeries.slice(0, 2).map((series) => (
            <motion.div
              key={series.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <GameSeriesCard
                series={series}
                onSeriesSelect={onNavigateToSeries}
                onEpisodeSelect={onNavigateToEpisode}
                showEpisodes={true}
                compact={false}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default VideosPage;