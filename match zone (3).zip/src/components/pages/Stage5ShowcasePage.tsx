/**
 * Stage 5 Showcase Page - Display all advanced features
 * صفحه نمایش مرحله 5: نمایش تمام ویژگی‌های پیشرفته
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

// Import Stage 5 Components
import { ProfessionalLeagueSystem } from '../leagues/ProfessionalLeagueSystem';
import { AdvancedEconomySystem } from '../economy/AdvancedEconomySystem';
import { MentorshipSystem } from '../coaching/MentorshipSystem';
import { AdvancedSocialFeatures } from '../social/AdvancedSocialFeatures';

import { 
  Trophy,
  Wallet,
  GraduationCap,
  Users,
  Star,
  Crown,
  Zap,
  Target,
  Award,
  Gem,
  BookOpen,
  MessageSquare,
  TrendingUp,
  Shield,
  Heart,
  CheckCircle,
  Sparkles,
  Rocket,
  Brain,
  Globe,
  BarChart3,
  Clock,
  ArrowRight
} from 'lucide-react';

interface FeatureCard {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  status: 'completed' | 'in-progress' | 'planned';
  category: string;
  highlights: string[];
  component?: React.ComponentType;
}

const stage5Features: FeatureCard[] = [
  {
    id: 'professional-leagues',
    title: 'سیستم لیگ حرفه‌ای',
    description: 'سیستم رتبه‌بندی پیشرفته با ۷ سطح مختلف از برنز تا استاد بزرگ',
    icon: <Trophy className="w-6 h-6" />,
    status: 'completed',
    category: 'رقابتی',
    highlights: [
      'رتبه‌بندی حرفه‌ای ۷ سطحه',
      'سیستم پاداش فصلی',
      'جدول امتیازات زنده',
      'نشان‌ها و عناوین ویژه',
      'آمار عملکرد تفصیلی'
    ],
    component: ProfessionalLeagueSystem
  },
  {
    id: 'advanced-economy',
    title: 'سیستم اقتصادی پیشرفته',
    description: 'کیف پول جامع، فروشگاه، و سیستم سرمایه‌گذاری',
    icon: <Wallet className="w-6 h-6" />,
    status: 'completed',
    category: 'اقتصادی',
    highlights: [
      'کیف پول چند ارزی',
      'فروشگاه آیتم‌های پیشرفته',
      'صندوق‌های سرمایه‌گذاری',
      'تحلیل‌های اقتصادی',
      'سیستم پاداش هوشمند'
    ],
    component: AdvancedEconomySystem
  },
  {
    id: 'mentorship-system',
    title: 'سیستم مربیگری و آموزش',
    description: 'پلتفرم یادگیری با مربیان حرفه‌ای و مسیرهای آموزشی',
    icon: <GraduationCap className="w-6 h-6" />,
    status: 'completed',
    category: 'آموزشی',
    highlights: [
      'مربیان حرفه‌ای تایید شده',
      'جلسات آموزشی زنده',
      'مسیرهای یادگیری تخصصی',
      'آمارگیری پیشرفت',
      'گواهی‌نامه‌های معتبر'
    ],
    component: MentorshipSystem
  },
  {
    id: 'advanced-social',
    title: 'ویژگی‌های اجتماعی پیشرفته',
    description: 'شبکه اجتماعی کامل با استریم، انجمن‌ها و محتوا',
    icon: <Users className="w-6 h-6" />,
    status: 'completed',
    category: 'اجتماعی',
    highlights: [
      'خبرخوان هوشمند',
      'استریم‌های زنده',
      'انجمن‌های تخصصی',
      'سیستم دستاوردها',
      'رویدادهای اجتماعی'
    ],
    component: AdvancedSocialFeatures
  }
];

const additionalFeatures = [
  {
    title: 'سیستم آمارگیری پیشرفته',
    description: 'تحلیل‌های عمیق از عملکرد و رفتار کاربران',
    icon: <BarChart3 className="w-5 h-5" />,
    status: 'integrated'
  },
  {
    title: 'سیستم نوتیفیکیشن پیشرفته',
    description: 'اعلان‌های هوشمند و شخصی‌سازی شده',
    icon: <Sparkles className="w-5 h-5" />,
    status: 'enhanced'
  },
  {
    title: 'سیستم امنیتی چندلایه',
    description: 'حفاظت از کاربران و داده‌های حساس',
    icon: <Shield className="w-5 h-5" />,
    status: 'integrated'
  },
  {
    title: 'بهینه‌سازی عملکرد',
    description: 'سرعت و کیفیت بالا در تمام بخش‌ها',
    icon: <Rocket className="w-5 h-5" />,
    status: 'optimized'
  }
];

const roadmapItems = [
  { phase: 'مرحله 1', title: 'طراحی بنیادی', status: 'completed', date: 'تکمیل شده' },
  { phase: 'مرحله 2', title: 'کامپوننت‌های پایه', status: 'completed', date: 'تکمیل شده' },
  { phase: 'مرحله 3', title: 'سیستم‌های اصلی', status: 'completed', date: 'تکمیل شده' },
  { phase: 'مرحله 4', title: 'مدیریت و آنالیز', status: 'completed', date: 'تکمیل شده' },
  { phase: 'مرحله 5', title: 'ویژگی‌های پیشرفته', status: 'current', date: 'در حال تکمیل' },
  { phase: 'مرحله 6', title: 'تست و بهینه‌سازی', status: 'planned', date: 'برنامه‌ریزی شده' }
];

export function Stage5ShowcasePage() {
  const [selectedFeature, setSelectedFeature] = useState<string>('professional-leagues');
  const [showFullSystem, setShowFullSystem] = useState(false);

  const currentFeature = stage5Features.find(f => f.id === selectedFeature);
  const CurrentComponent = currentFeature?.component;

  if (showFullSystem && CurrentComponent) {
    return (
      <div className="min-h-screen bg-background">
        <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-sm border-b p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="outline" onClick={() => setShowFullSystem(false)}>
                بازگشت
              </Button>
              <h1 className="text-xl font-semibold">{currentFeature?.title}</h1>
            </div>
            <Badge variant="secondary">مرحله 5</Badge>
          </div>
        </div>
        <CurrentComponent />
      </div>
    );
  }

  return (
    <div className="space-y-8 p-6 max-w-7xl mx-auto" dir="rtl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center gap-3">
          <div className="p-3 rounded-full bg-gradient-to-r from-purple-500 to-pink-500">
            <Star className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            مرحله 5: ویژگی‌های پیشرفته
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          تکمیل سیستم طراحی Matchzone با پیشرفته‌ترین ویژگی‌های حرفه‌ای
        </p>
      </motion.div>

      {/* Progress Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border-green-500/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-6 h-6 text-green-500" />
              وضعیت پروژه
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <p className="text-3xl font-bold text-green-500">5</p>
                <p className="text-sm text-muted-foreground">مرحله تکمیل شده</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-blue-500">150+</p>
                <p className="text-sm text-muted-foreground">کامپوننت ساخته شده</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-500">50+</p>
                <p className="text-sm text-muted-foreground">صفحه و ویژگی</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-orange-500">100%</p>
                <p className="text-sm text-muted-foreground">پشتیبانی RTL</p>
              </div>
            </div>

            {/* Roadmap */}
            <div className="space-y-3">
              <h3 className="font-semibold mb-3">نقشه راه پروژه</h3>
              <div className="grid grid-cols-1 md:grid-cols-6 gap-2">
                {roadmapItems.map((item, index) => (
                  <div key={index} className="relative">
                    <div className={`p-3 rounded-lg text-center border-2 transition-all ${
                      item.status === 'completed' ? 'bg-green-100 dark:bg-green-900/20 border-green-500' :
                      item.status === 'current' ? 'bg-blue-100 dark:bg-blue-900/20 border-blue-500 ring-2 ring-blue-500/20' :
                      'bg-gray-100 dark:bg-gray-900/20 border-gray-300'
                    }`}>
                      <p className="font-medium text-sm">{item.phase}</p>
                      <p className="text-xs text-muted-foreground mt-1">{item.title}</p>
                      <p className="text-xs mt-1">{item.date}</p>
                    </div>
                    {index < roadmapItems.length - 1 && (
                      <ArrowRight className="w-4 h-4 text-muted-foreground absolute top-1/2 -left-2 transform -translate-y-1/2 hidden md:block" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Main Features Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2">ویژگی‌های اصلی مرحله 5</h2>
          <p className="text-muted-foreground">
            چهار بخش کلیدی که Matchzone را به پلتفرم گیمینگ کاملی تبدیل می‌کند
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {stage5Features.map((feature, index) => (
            <motion.div
              key={feature.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className={`h-full cursor-pointer transition-all hover:shadow-lg border-2 ${
                selectedFeature === feature.id 
                  ? 'border-blue-500 ring-2 ring-blue-500/20' 
                  : 'border-border hover:border-blue-300'
              }`}>
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-full bg-gradient-to-r from-blue-500 to-purple-500">
                        {feature.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg mb-1">{feature.title}</CardTitle>
                        <Badge variant="outline">{feature.category}</Badge>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                      <CheckCircle className="w-3 h-3 ml-1" />
                      تکمیل شده
                    </Badge>
                  </div>
                  
                  <p className="text-muted-foreground mb-4">
                    {feature.description}
                  </p>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">ویژگی‌های کلیدی:</h4>
                    {feature.highlights.map((highlight, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <Sparkles className="w-4 h-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{highlight}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-2 pt-4 border-t">
                    <Button
                      size="sm"
                      variant={selectedFeature === feature.id ? "default" : "outline"}
                      onClick={() => setSelectedFeature(feature.id)}
                      className="flex-1"
                    >
                      {selectedFeature === feature.id ? 'انتخاب شده' : 'انتخاب'}
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => {
                        setSelectedFeature(feature.id);
                        setShowFullSystem(true);
                      }}
                    >
                      <Globe className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Additional Features */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-6 h-6 text-yellow-500" />
              ویژگی‌های تکمیلی
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {additionalFeatures.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="text-center p-4 border rounded-lg hover:shadow-sm transition-all"
                >
                  <div className="flex items-center justify-center mb-3">
                    <div className="p-2 rounded-full bg-muted">
                      {feature.icon}
                    </div>
                  </div>
                  <h3 className="font-medium mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    {feature.description}
                  </p>
                  <Badge variant="secondary" className="text-xs">
                    {feature.status === 'integrated' ? 'ادغام شده' :
                     feature.status === 'enhanced' ? 'تقویت شده' :
                     feature.status === 'optimized' ? 'بهینه شده' : feature.status}
                  </Badge>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Live Demo */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="bg-gradient-to-r from-purple-500/5 to-blue-500/5">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 mb-2">
              <Crown className="w-6 h-6 text-purple-500" />
              نمایش زنده ویژگی انتخاب شده
            </CardTitle>
            <p className="text-muted-foreground">
              {currentFeature ? currentFeature.description : 'لطفاً یک ویژگی را انتخاب کنید'}
            </p>
          </CardHeader>
          <CardContent>
            {currentFeature ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-background">
                      {currentFeature.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold">{currentFeature.title}</h3>
                      <p className="text-sm text-muted-foreground">{currentFeature.category}</p>
                    </div>
                  </div>
                  <Button
                    onClick={() => setShowFullSystem(true)}
                    className="bg-gradient-to-r from-purple-500 to-blue-500 text-white"
                  >
                    <Globe className="w-4 h-4 ml-2" />
                    مشاهده کامل
                  </Button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {currentFeature.highlights.map((highlight, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-3 bg-background rounded border">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Target className="w-12 h-12 mx-auto mb-3" />
                <p>یکی از ویژگی‌های بالا را برای مشاهده جزئیات انتخاب کنید</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="text-center">آمار کلی پروژه</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-6 gap-6 text-center">
              <div>
                <p className="text-2xl font-bold text-blue-500">4</p>
                <p className="text-xs text-muted-foreground">سیستم اصلی</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-500">25+</p>
                <p className="text-xs text-muted-foreground">صفحه جدید</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-500">40+</p>
                <p className="text-xs text-muted-foreground">کامپوننت پیشرفته</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-orange-500">100%</p>
                <p className="text-xs text-muted-foreground">RTL سازگار</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-red-500">7</p>
                <p className="text-xs text-muted-foreground">سطح رتبه‌بندی</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-yellow-500">∞</p>
                <p className="text-xs text-muted-foreground">امکانات</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}