import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { GameButton } from '../ui/game-button';
import { GameInput } from '../ui/game-input';
import { TrustBadge } from '../ui/trust-badge';
import { StatusIndicator } from '../ui/status-indicator';
import { ProfileCard } from '../profile/ProfileCard';
import { BadgeShowcase } from '../profile/BadgeShowcase';
import { LobbyCard } from '../gaming/LobbyCard';
import { TournamentCard } from '../gaming/TournamentCard';
import { CountdownTimer } from '../gaming/CountdownTimer';
import { ChatWindow } from '../social/ChatWindow';
import { ActivityFeed } from '../social/ActivityFeed';
import { ProductCard } from '../store/ProductCard';
import { VideoCard } from '../creator/VideoCard';
import { TipModal } from '../creator/TipModal';
import { ClanCard } from '../clan/ClanCard';
import { ClanPoll } from '../clan/ClanPoll';
import { LeaderboardTable } from '../leaderboard/LeaderboardTable';
import { DiscoverFeed } from '../discovery/DiscoverFeed';
import { XPProgress } from '../gamification/XPProgress';
import { MissionCard } from '../gamification/MissionCard';
import { EmptyState } from '../system/EmptyState';
import { LoadingSkeleton } from '../system/LoadingSkeleton';
import { Search, Heart } from 'lucide-react';

export const ComponentShowcase: React.FC = () => {
  const [tipModalOpen, setTipModalOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    {
      id: '1',
      content: 'سلام بچه‌ها! آماده‌اید برای مسابقه؟',
      senderId: 'user1',
      senderName: 'علی احمدی',
      timestamp: new Date(Date.now() - 1000 * 60 * 5),
      type: 'text' as const,
    },
    {
      id: '2',
      content: 'آره! بیایید شروع کنیم',
      senderId: 'current',
      senderName: 'شما',
      timestamp: new Date(Date.now() - 1000 * 60 * 3),
      type: 'text' as const,
    },
  ]);

  // Sample data
  const sampleUser = {
    id: 'user1',
    name: 'علی احمدی',
    username: 'ali_gamer',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    trustLevel: 'gold' as const,
    status: 'online' as const,
    role: 'player' as const,
    level: 25,
    xp: 12500,
    coins: 5000,
  };

  const sampleAchievements = [
    {
      id: '1',
      name: 'برنده اول',
      description: 'اولین مقام در تورنومنت',
      icon: '🏆',
      rarity: 'legendary' as const,
      unlockedAt: new Date('2024-01-15'),
    },
    {
      id: '2',
      name: 'استاد بازی',
      description: '100 برد متوالی',
      icon: '⭐',
      rarity: 'epic' as const,
      unlockedAt: new Date('2024-01-10'),
    },
  ];

  const sampleLobby = {
    id: 'lobby1',
    name: 'لابی تفریحی شب',
    game: 'Counter-Strike 2',
    host: { name: 'حسن محمدی', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150' },
    currentPlayers: 8,
    maxPlayers: 10,
    status: 'waiting' as const,
    gameMode: 'Competitive',
    isPrivate: false,
    estimatedDuration: 45,
    region: 'ایران',
    createdAt: new Date(),
  };

  const sampleTournament = {
    id: 'tournament1',
    title: 'جام زمستانی CS2',
    game: 'Counter-Strike 2',
    organizer: { name: 'گیم‌هاب', avatar: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=150' },
    entryFee: 1000,
    prizePool: 50000,
    maxParticipants: 32,
    currentParticipants: 24,
    format: 'single-elimination' as const,
    status: 'registration' as const,
    startDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2),
    registrationDeadline: new Date(Date.now() + 1000 * 60 * 60 * 12),
    estimatedDuration: 4,
  };

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">نمایش کامپوننت‌های گیم‌هاب</h1>
        <p className="text-muted-foreground">
          مجموعه کاملی از کامپوننت‌های UI برای پلتفرم بازی
        </p>
      </div>

      <Tabs defaultValue="base" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="base">پایه</TabsTrigger>
          <TabsTrigger value="gaming">بازی</TabsTrigger>
          <TabsTrigger value="social">اجتماعی</TabsTrigger>
          <TabsTrigger value="other">سایر</TabsTrigger>
        </TabsList>

        <TabsContent value="base" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>کامپوننت‌های پایه</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium">دکمه‌ها</h4>
                  <div className="space-y-2">
                    <GameButton variant="primary">اصلی</GameButton>
                    <GameButton variant="secondary">ثانویه</GameButton>
                    <GameButton variant="danger">خطر</GameButton>
                    <GameButton variant="success">موفقیت</GameButton>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">ورودی‌ها</h4>
                  <GameInput label="نام کاربری" placeholder="نام خود را وارد کنید" />
                  <GameInput 
                    label="جستجو" 
                    placeholder="جستجو کنید..." 
                    variant="search"
                    icon={<Search className="w-4 h-4" />}
                  />
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">نشان‌ها و وضعیت</h4>
                  <div className="space-y-2">
                    <TrustBadge level="bronze" />
                    <TrustBadge level="gold" />
                    <TrustBadge level="diamond" />
                    <StatusIndicator status="online" showLabel />
                    <StatusIndicator status="in-game" showLabel />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <ProfileCard user={sampleUser} variant="full" showStats />
                <BadgeShowcase achievements={sampleAchievements} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gaming" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <LobbyCard lobby={sampleLobby} onJoin={() => console.log('Join lobby')} />
            <TournamentCard tournament={sampleTournament} onRegister={() => console.log('Register')} />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>شمارش معکوس</CardTitle>
            </CardHeader>
            <CardContent>
              <CountdownTimer 
                targetDate={new Date(Date.now() + 1000 * 60 * 60 * 2)} 
                onComplete={() => console.log('Countdown complete')}
              />
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <XPProgress
              currentLevel={25}
              currentXP={12500}
              xpToNextLevel={15000}
              totalXPForCurrentLevel={15000}
              showDetails
            />
            <MissionCard
              mission={{
                id: 'mission1',
                title: 'برنده شو',
                description: 'در 5 بازی پیاپی برنده شوید',
                category: 'daily',
                difficulty: 'medium',
                progress: { current: 3, target: 5, unit: 'بازی' },
                rewards: { xp: 500, coins: 100 },
                isCompleted: false,
                isClaimed: false,
              }}
              onClaim={() => console.log('Claim mission')}
            />
          </div>
        </TabsContent>

        <TabsContent value="social" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ChatWindow
              messages={chatMessages}
              onSendMessage={(content) => {
                const newMessage = {
                  id: Date.now().toString(),
                  content,
                  senderId: 'current',
                  senderName: 'شما',
                  timestamp: new Date(),
                  type: 'text' as const,
                };
                setChatMessages([...chatMessages, newMessage]);
              }}
              currentUserId="current"
            />
            
            <ActivityFeed
              activities={[
                {
                  id: '1',
                  type: 'tournament_won',
                  user: { id: 'user1', name: 'علی احمدی', avatar: sampleUser.avatar },
                  timestamp: new Date(Date.now() - 1000 * 60 * 30),
                  content: 'در تورنومنت CS2 مقام اول را کسب کرد!',
                  metadata: { game: 'Counter-Strike 2' },
                  interactions: { likes: 15, comments: 3, shares: 2, isLiked: false },
                },
              ]}
              onLike={(id) => console.log('Like activity:', id)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ClanCard
              clan={{
                id: 'clan1',
                name: 'گردانگان طلایی',
                tag: 'GOLD',
                description: 'کلن حرفه‌ای CS2 با بازیکنان ماهر',
                leader: { id: 'leader1', name: 'محمد رضایی' },
                memberCount: 15,
                maxMembers: 20,
                level: 12,
                xp: 25000,
                xpToNextLevel: 30000,
                isPrivate: false,
                wins: 45,
                losses: 12,
                treasury: 125000,
                status: 'recruiting',
              }}
              onJoin={() => console.log('Join clan')}
            />

            <ClanPoll
              poll={{
                id: 'poll1',
                title: 'بازی بعدی کلن چه باشد؟',
                description: 'برای انتخاب بازی هفته آینده رأی دهید',
                options: [
                  { id: 'cs2', text: 'Counter-Strike 2', votes: 8, voters: [] },
                  { id: 'valorant', text: 'Valorant', votes: 5, voters: [] },
                  { id: 'apex', text: 'Apex Legends', votes: 2, voters: [] },
                ],
                creator: {
                  id: 'leader1',
                  name: 'محمد رضایی',
                  role: 'leader',
                },
                totalVotes: 15,
                deadline: new Date(Date.now() + 1000 * 60 * 60 * 24),
                isActive: true,
                allowMultiple: false,
              }}
              canVote
              onVote={(options) => console.log('Vote:', options)}
            />
          </div>
        </TabsContent>

        <TabsContent value="other" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ProductCard
              product={{
                id: 'product1',
                name: 'بسته ۱۰۰۰ سکه',
                description: 'بسته سکه برای خریدهای درون‌برنامه‌ای',
                image: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?w=300',
                type: 'coin-pack',
                price: { irr: 50000 },
                isPopular: true,
              }}
              onPurchase={() => console.log('Purchase product')}
            />

            <VideoCard
              video={{
                id: 'video1',
                title: 'راهنمای کامل CS2 برای مبتدیان',
                thumbnail: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400',
                creator: {
                  id: 'creator1',
                  name: 'گیمر حرفه‌ای',
                  isVerified: true,
                },
                duration: 1245,
                views: 15000,
                likes: 890,
                comments: 156,
                createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12),
                game: 'Counter-Strike 2',
                category: 'tutorial',
              }}
              onPlay={() => setTipModalOpen(true)}
            />

            <div className="space-y-4">
              <EmptyState type="search" />
              <LoadingSkeleton type="card" />
            </div>
          </div>

          <LeaderboardTable
            entries={[
              {
                id: '1',
                rank: 1,
                name: 'علی احمدی',
                avatar: sampleUser.avatar,
                score: 2580,
                change: 2,
                trustLevel: 'diamond',
                type: 'player',
                metadata: { level: 45, winRate: 87.5, gamesPlayed: 128 },
              },
              {
                id: '2',
                rank: 2,
                name: 'محمد رضایی',
                score: 2450,
                change: -1,
                trustLevel: 'gold',
                type: 'player',
                metadata: { level: 42, winRate: 82.3, gamesPlayed: 156 },
              },
            ]}
            title="برترین بازیکنان"
            scoreLabel="امتیاز"
            onEntryClick={(entry) => console.log('View player:', entry)}
          />

          <DiscoverFeed
            items={[
              {
                id: 'discover1',
                type: 'tournament',
                title: 'مسابقه بزرگ CS2',
                description: 'بزرگترین تورنومنت سال با جوایز نقدی',
                image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400',
                game: 'Counter-Strike 2',
                metadata: {
                  playerCount: 64,
                  maxPlayers: 128,
                  prizePool: 1000000,
                  entryFee: 5000,
                },
                tags: ['مسابقه', 'CS2', 'جایزه'],
                isPopular: true,
              },
            ]}
            onItemClick={(item) => console.log('View item:', item)}
            onActionClick={(item, action) => console.log('Action:', action, item)}
          />
        </TabsContent>
      </Tabs>

      <TipModal
        isOpen={tipModalOpen}
        onClose={() => setTipModalOpen(false)}
        creator={{
          id: 'creator1',
          name: 'گیمر حرفه‌ای',
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        }}
        onSendTip={async (amount, message) => {
          console.log('Send tip:', amount, message);
          // Simulate API call
          await new Promise(resolve => setTimeout(resolve, 1000));
        }}
        userBalance={10000}
      />
    </div>
  );
};