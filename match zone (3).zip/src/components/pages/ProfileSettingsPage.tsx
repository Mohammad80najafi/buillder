import React, { useState } from 'react';
import { 
  Settings, User, Eye, EyeOff, Lock, Globe, 
  BarChart3, Video, Trophy, Users, Star, Crown,
  Gamepad2, Calendar, MessageCircle, Heart,
  DollarSign, Shield, Camera, Edit3, Save,
  CheckCircle, XCircle, AlertCircle, Info
} from 'lucide-react';
import { Button } from '../ui/mz-button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Switch } from '../ui/switch';
import { Separator } from '../ui/separator';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Alert, AlertDescription } from '../ui/alert';

interface ProfileSettingsPageProps {
  onNavigate?: (page: string) => void;
  onSave?: (settings: ProfileSettings) => void;
}

export interface ProfileSettings {
  // نمایش بخش‌ها
  visibility: {
    showStats: boolean;
    showVideos: boolean;
    showAchievements: boolean;
    showGames: boolean;
    showClans: boolean;
    showFriends: boolean;
    showActivity: boolean;
    showEarnings: boolean;
    showRank: boolean;
    showBadges: boolean;
  };
  
  // حریم خصوصی
  privacy: {
    profilePublic: boolean;
    showOnlineStatus: boolean;
    allowFriendRequests: boolean;
    allowClanInvites: boolean;
    allowDirectMessages: boolean;
    showGameHistory: boolean;
  };
  
  // اطلاعات پروفایل
  profile: {
    displayName: string;
    bio: string;
    favoriteGames: string[];
    availability: 'online' | 'away' | 'busy' | 'offline';
    profileTheme: 'default' | 'gaming' | 'minimal' | 'pro';
  };
  
  // تنظیمات محتوا
  content: {
    autoUploadClips: boolean;
    allowTipping: boolean;
    monetization: boolean;
    showViewerCount: boolean;
    moderateComments: boolean;
  };
}

export function ProfileSettingsPage({ 
  onNavigate, 
  onSave 
}: ProfileSettingsPageProps) {
  const [settings, setSettings] = useState<ProfileSettings>({
    visibility: {
      showStats: true,
      showVideos: true,
      showAchievements: true,
      showGames: true,
      showClans: true,
      showFriends: true,
      showActivity: false,
      showEarnings: false,
      showRank: true,
      showBadges: true,
    },
    privacy: {
      profilePublic: true,
      showOnlineStatus: true,
      allowFriendRequests: true,
      allowClanInvites: true,
      allowDirectMessages: true,
      showGameHistory: false,
    },
    profile: {
      displayName: 'KEOXER GAMING',
      bio: 'کریتور حرفه‌ای گیمینگ 🎮 | تولید محتوای آموزشی و سرگرمی | تخصص در FPS و Strategy Games',
      favoriteGames: ['VALORANT', 'CS2', 'League of Legends'],
      availability: 'online',
      profileTheme: 'gaming',
    },
    content: {
      autoUploadClips: true,
      allowTipping: true,
      monetization: false,
      showViewerCount: true,
      moderateComments: true,
    }
  });

  const [hasChanges, setHasChanges] = useState(false);
  const [selectedTab, setSelectedTab] = useState('visibility');

  const updateSettings = (section: keyof ProfileSettings, key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value
      }
    }));
    setHasChanges(true);
  };

  const handleSave = () => {
    onSave?.(settings);
    setHasChanges(false);
  };

  const currentUser = {
    name: 'KEOXER GAMING',
    username: '@keoxer_pro',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    verified: true,
    level: 'Diamond II',
    followers: 12500
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-safe" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
        <div className="max-w-4xl mx-auto px-3 md:px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => onNavigate?.('profile')}
                className="p-2"
              >
                ←
              </Button>
              <div>
                <h1 className="font-semibold">تنظیمات پروفایل</h1>
                <p className="text-sm text-muted-foreground">شخصی‌سازی صفحه عمومی شما</p>
              </div>
            </div>
            
            {hasChanges && (
              <Button onClick={handleSave} size="sm" className="flex items-center gap-2">
                <Save className="h-4 w-4" />
                ذخیره تغییرات
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-3 md:px-4 py-6 space-y-6">
        {/* Profile Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" />
              پیش‌نمایش پروفایل
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
              <Avatar className="h-16 w-16">
                <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
                <AvatarFallback>{currentUser.name.charAt(0)}</AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold">{settings.profile.displayName}</h3>
                  {currentUser.verified && (
                    <CheckCircle className="h-4 w-4 text-blue-500" />
                  )}
                  <Badge variant="secondary">{currentUser.level}</Badge>
                </div>
                
                <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                  {settings.profile.bio}
                </p>
                
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>{currentUser.followers.toLocaleString('fa-IR')} دنبال‌کننده</span>
                  <span>•</span>
                  <span>فعال</span>
                </div>
              </div>
              
              <Button variant="outline" size="sm">
                مشاهده پروفایل
              </Button>
            </div>

            {!settings.privacy.profilePublic && (
              <Alert className="mt-4">
                <Lock className="h-4 w-4" />
                <AlertDescription>
                  پروفایل شما خصوصی است و فقط دوستان شما می‌توانند آن را مشاهده کنند.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Settings Tabs */}
        <Card>
          <Tabs value={selectedTab} onValueChange={setSelectedTab}>
            <CardHeader>
              <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full">
                <TabsTrigger value="visibility" className="text-xs md:text-sm">نمایش</TabsTrigger>
                <TabsTrigger value="privacy" className="text-xs md:text-sm">حریم خصوصی</TabsTrigger>
                <TabsTrigger value="profile" className="text-xs md:text-sm">اطلاعات</TabsTrigger>
                <TabsTrigger value="content" className="text-xs md:text-sm">محتوا</TabsTrigger>
              </TabsList>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Visibility Settings */}
              <TabsContent value="visibility" className="space-y-6 mt-0">
                <div>
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Eye className="h-5 w-5" />
                    بخش‌های نمایشی در پروفایل
                  </h3>
                  
                  <div className="space-y-4">
                    {[
                      { key: 'showStats', label: 'آمار کلی', description: 'نمایش آمار بازدید، دنبال‌کننده و غیره', icon: BarChart3 },
                      { key: 'showVideos', label: 'ویدیوها و کلیپ‌ها', description: 'نمایش ویدیوهای آپلود شده', icon: Video },
                      { key: 'showAchievements', label: 'دستاوردها', description: 'نمایش جوایز و مدال‌ها', icon: Trophy },
                      { key: 'showGames', label: 'بازی‌های مورد علاقه', description: 'نمایش لیست بازی‌ها', icon: Gamepad2 },
                      { key: 'showClans', label: 'کلن و تیم‌ها', description: 'نمایش عضویت در کلن‌ها', icon: Users },
                      { key: 'showFriends', label: 'دوستان', description: 'نمایش لیست دوستان', icon: Heart },
                      { key: 'showActivity', label: 'فعالیت‌های اخیر', description: 'نمایش آخرین فعالیت‌ها', icon: Calendar },
                      { key: 'showEarnings', label: 'درآمد', description: 'نمایش درآمد از محتوا', icon: DollarSign },
                      { key: 'showRank', label: 'رنک و سطح', description: 'نمایش سطح فعلی', icon: Crown },
                      { key: 'showBadges', label: 'نشان‌ها', description: 'نمایش نشان‌های کسب شده', icon: Star },
                    ].map((item) => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                        <div className="flex items-center gap-3">
                          <item.icon className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{item.label}</p>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                        </div>
                        <Switch
                          checked={settings.visibility[item.key as keyof typeof settings.visibility]}
                          onCheckedChange={(checked) => updateSettings('visibility', item.key, checked)}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Privacy Settings */}
              <TabsContent value="privacy" className="space-y-6 mt-0">
                <div>
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    تنظیمات حریم خصوصی
                  </h3>
                  
                  <div className="space-y-4">
                    {[
                      { key: 'profilePublic', label: 'پروفایل عمومی', description: 'همه می‌توانند پروفایل شما را ببینند', icon: Globe },
                      { key: 'showOnlineStatus', label: 'نمایش وضعیت آنلاین', description: 'نمایش وضعیت حضور شما', icon: User },
                      { key: 'allowFriendRequests', label: 'درخواست دوستی', description: 'اجازه ارسال درخواست دوستی', icon: Users },
                      { key: 'allowClanInvites', label: 'دعوت به کلن', description: 'اجازه دعوت به کلن‌ها', icon: Shield },
                      { key: 'allowDirectMessages', label: 'پیام مستقیم', description: 'اجازه ارسال پیام خصوصی', icon: MessageCircle },
                      { key: 'showGameHistory', label: 'تاریخچه بازی‌ها', description: 'نمایش آمار بازی‌ها', icon: BarChart3 },
                    ].map((item) => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                        <div className="flex items-center gap-3">
                          <item.icon className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{item.label}</p>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                        </div>
                        <Switch
                          checked={settings.privacy[item.key as keyof typeof settings.privacy]}
                          onCheckedChange={(checked) => updateSettings('privacy', item.key, checked)}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              {/* Profile Settings */}
              <TabsContent value="profile" className="space-y-6 mt-0">
                <div>
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Edit3 className="h-5 w-5" />
                    اطلاعات پروفایل
                  </h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block font-medium mb-2">نام نمایشی</label>
                      <Input
                        value={settings.profile.displayName}
                        onChange={(e) => updateSettings('profile', 'displayName', e.target.value)}
                        placeholder="نام نمایشی خود را وارد کنید"
                      />
                    </div>

                    <div>
                      <label className="block font-medium mb-2">بیوگرافی</label>
                      <Textarea
                        value={settings.profile.bio}
                        onChange={(e) => updateSettings('profile', 'bio', e.target.value)}
                        placeholder="توضیحی در مورد خود بنویسید..."
                        rows={3}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        {settings.profile.bio.length}/200 کاراکتر
                      </p>
                    </div>

                    <div>
                      <label className="block font-medium mb-2">وضعیت فعالیت</label>
                      <Select
                        value={settings.profile.availability}
                        onValueChange={(value) => updateSettings('profile', 'availability', value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="online">🟢 آنلاین</SelectItem>
                          <SelectItem value="away">🟡 غیر حضور</SelectItem>
                          <SelectItem value="busy">🔴 مشغول</SelectItem>
                          <SelectItem value="offline">⚫ آفلاین</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="block font-medium mb-2">تم پروفایل</label>
                      <Select
                        value={settings.profile.profileTheme}
                        onValueChange={(value) => updateSettings('profile', 'profileTheme', value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="default">پیش‌فرض</SelectItem>
                          <SelectItem value="gaming">گیمینگ</SelectItem>
                          <SelectItem value="minimal">مینیمال</SelectItem>
                          <SelectItem value="pro">حرفه‌ای</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Content Settings */}
              <TabsContent value="content" className="space-y-6 mt-0">
                <div>
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Video className="h-5 w-5" />
                    تنظیمات محتوا
                  </h3>
                  
                  <div className="space-y-4">
                    {[
                      { key: 'autoUploadClips', label: 'آپلود خودکار کلیپ‌ها', description: 'کلیپ‌های بازی به طور خودکار آپلود شود', icon: Video },
                      { key: 'allowTipping', label: 'اجازه انعام', description: 'بینندگان بتوانند برای شما انعام بفرستند', icon: DollarSign },
                      { key: 'monetization', label: 'درآمدزایی', description: 'فعال‌سازی درآمد از محتوا', icon: DollarSign },
                      { key: 'showViewerCount', label: 'نمایش تعداد بیننده', description: 'تعداد بازدیدکنندگان نمایش داده شود', icon: Eye },
                      { key: 'moderateComments', label: 'مدیریت نظرات', description: 'نظرات قبل از نمایش بررسی شوند', icon: Shield },
                    ].map((item) => (
                      <div key={item.key} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                        <div className="flex items-center gap-3">
                          <item.icon className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="font-medium">{item.label}</p>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                          </div>
                        </div>
                        <Switch
                          checked={settings.content[item.key as keyof typeof settings.content]}
                          onCheckedChange={(checked) => updateSettings('content', item.key, checked)}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>

        {/* Save Changes */}
        {hasChanges && (
          <Card className="border-green-200 bg-green-50/50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="font-medium text-green-800">تغییرات ذخیره نشده</p>
                    <p className="text-sm text-green-600">تنظیمات شما تغییر کرده است.</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => window.location.reload()}>
                    لغو تغییرات
                  </Button>
                  <Button onClick={handleSave}>
                    <Save className="h-4 w-4 ml-2" />
                    ذخیره
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

export default ProfileSettingsPage;