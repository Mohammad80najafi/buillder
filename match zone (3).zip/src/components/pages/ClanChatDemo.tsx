import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { ClanChatSystem } from '../clans/ClanChatSystem';
import { useClan, Clan } from '../providers/ClanProvider';
import { toast } from 'sonner@2.0.3';

export function ClanChatDemo() {
  const { joinClan, clanChats, clans } = useClan();
  const [selectedClan, setSelectedClan] = useState<Clan | null>(null);

  const mockClan: Clan = {
    id: 'demo-clan',
    name: 'شیران طلایی',
    tag: 'GOLD',
    description: 'کلن دمو برای تست چت',
    logo: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=100',
    level: 15,
    xp: 45000,
    maxXp: 50000,
    type: 'public',
    region: 'تهران',
    language: 'فارسی',
    founded: '۱۴۰۲/۰۵/۱۲',
    members: {
      current: 28,
      max: 30
    },
    requirements: {
      minLevel: 10,
      minTrophies: 1000,
      requiresApproval: false
    },
    stats: {
      rank: 15,
      totalTrophies: 125000,
      weeklyTrophies: 8500,
      wins: 342,
      losses: 89,
      winRate: 79,
      weeklyXp: 12500
    },
    leader: {
      id: 'leader-1',
      name: 'شیر_طلایی',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
      level: 67
    },
    activities: {
      activeMembers: 22,
      lastActive: '۲ ساعت پیش',
      weeklyMatches: 156,
      weeklyDonations: 890
    },
    achievements: [
      { id: 'ace', name: 'قهرمان کلن', icon: '🏆' },
      { id: 'streak', name: 'برد متوالی', icon: '🔥' }
    ],
    isJoined: false,
    createdByUser: false
  };

  const handleJoinClan = () => {
    joinClan(mockClan.id);
    toast.success('به کلن پیوستید! چت کلن به لیست اضافه شد');
  };

  const handleOpenChat = (clan: Clan) => {
    setSelectedClan(clan);
  };

  const handleCloseChat = () => {
    setSelectedClan(null);
  };

  if (selectedClan) {
    return (
      <div className="min-h-screen bg-background p-4">
        <ClanChatSystem
          clan={selectedClan}
          currentUserId="demo-user"
          currentUserRole="member"
          onClose={handleCloseChat}
          className="max-w-4xl mx-auto"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 space-y-6" dir="rtl">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">دمو سیستم چت کلن</h1>
        
        {/* Demo Clan Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>کلن دمو</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold">[{mockClan.tag}] {mockClan.name}</h3>
                <p className="text-muted-foreground text-sm">{mockClan.description}</p>
              </div>
              <Button onClick={handleJoinClan}>
                پیوستن به کلن
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Active Clan Chats */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              چت‌های کلن فعال
              <Badge variant="outline">
                {clanChats.length} چت
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {clanChats.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <p>هنوز به هیچ کلنی نپیوسته‌اید</p>
                <p className="text-sm">برای مشاهده چت کلن، ابتدا به کلن بپیوندید</p>
              </div>
            ) : (
              <div className="space-y-3">
                {clanChats.map((clanChat) => {
                  const clan = clans.find(c => c.id === clanChat.clanId);
                  if (!clan) return null;
                  
                  return (
                    <div
                      key={clanChat.id}
                      className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                          {clanChat.clanTag}
                        </div>
                        <div>
                          <h4 className="font-medium">{clanChat.clanName}</h4>
                          <p className="text-sm text-muted-foreground">
                            {clanChat.lastMessage?.content || 'هنوز پیامی نیست'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {clanChat.unreadCount > 0 && (
                          <Badge variant="destructive" className="h-5 w-5 p-0 text-xs rounded-full">
                            {clanChat.unreadCount}
                          </Badge>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenChat(clan)}
                        >
                          باز کردن چت
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>نحوه استفاده</CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal list-inside space-y-2 text-sm">
              <li>ابتدا روی "پیوستن به کلن" کلیک کنید</li>
              <li>پس از پیوستن، چت کلن به لیست اضافه می‌شود</li>
              <li>روی "باز کردن چت" کلیک کنید تا وارد چت کلن شوید</li>
              <li>می‌تونید پیام ارسال کنید، ری‌اکت بدید و پاسخ دهید</li>
              <li>برای بازگشت به لیست، روی دکمه بستن کلیک کنید</li>
            </ol>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}