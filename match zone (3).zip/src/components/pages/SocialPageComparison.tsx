/**
 * Social Page Comparison - Old vs New Design
 * مقایسه صفحه اجتماعی: طراحی قدیم در مقابل جدید
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  ArrowRight, 
  Zap, 
  Sparkles, 
  Eye, 
  Users, 
  MessageCircle,
  Grid3X3,
  List,
  Palette,
  Layers,
  MousePointer,
  Star
} from 'lucide-react';
import { SocialPage } from './SocialPage';
import { ModernSocialPageFixed } from './ModernSocialPageFixed';

interface FeatureComparison {
  feature: string;
  old: string;
  new: string;
  improvement: string;
}

export function SocialPageComparison() {
  const [activeTab, setActiveTab] = useState('comparison');
  const [selectedDesign, setSelectedDesign] = useState<'old' | 'new'>('new');

  const improvements: FeatureComparison[] = [
    {
      feature: 'طراحی بصری',
      old: 'ساده و مینیمال',
      new: 'گرادیانت‌های رنگی و انیمیشن‌های پیشرفته',
      improvement: 'جذابیت بصری ۳ برابر بیشتر'
    },
    {
      feature: 'حالت نمایش',
      old: 'فقط لیست ساده',
      new: 'Grid، List، و Compact با انیمیشن',
      improvement: 'انعطاف‌پذیری ۵ برابر بیشتر'
    },
    {
      feature: 'اطلاعات چت',
      old: 'اطلاعات پایه',
      new: 'وضعیت آنلاین، mood، voice channel، typing indicator',
      improvement: 'اطلاعات جامع و real-time'
    },
    {
      feature: 'فیلترها و جستجو',
      old: 'جستجوی ساده با تب‌ها',
      new: 'فیلترهای پیشرفته، مرتب‌سازی، Quick Actions',
      improvement: 'قابلیت جستجوی ۴ برابر بهتر'
    },
    {
      feature: 'تعامل کاربری',
      old: 'کلیک ساده',
      new: 'Hover effects، انیمیشن‌ها، Micro-interactions',
      improvement: 'تجربه کاربری premium'
    },
    {
      feature: 'نمایش وضعیت',
      old: 'نقطه سبز/خاکستری',
      new: 'نشانگرهای رنگی، Badge‌های متحرک، Mood indicators',
      improvement: 'اطلاعات بصری ۶ برابر بیشتر'
    }
  ];

  const features = {
    old: [
      'رابط کاربری ساده',
      'نمایش لیستی استاندارد',
      'جستجوی پایه',
      'تب‌های معمولی',
      'کارت‌های ساده'
    ],
    new: [
      'رابط کاربری Ultra-Modern',
      'نمایش Grid/List/Compact',
      'جستجوی پیشرفته با فیلتر',
      'Quick Actions Panel',
      'انیمیشن‌های Micro-interaction',
      'Gradient Effects',
      'Real-time Status',
      'Voice Channel Indicators',
      'Mood & Gaming Status',
      'Focus Mode & Voice Mode',
      'Smart Sorting & Filtering'
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <div className="flex items-center justify-center space-x-3 rtl:space-x-reverse">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              مقایسه طراحی صفحه اجتماعی
            </h1>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            تفاوت‌های کلیدی بین طراحی قدیم و جدید صفحه چت و ارتباطات اجتماعی
          </p>
        </motion.div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="comparison" className="flex items-center space-x-2 rtl:space-x-reverse">
              <Eye className="w-4 h-4" />
              <span>مقایسه ویژگی‌ها</span>
            </TabsTrigger>
            <TabsTrigger value="preview" className="flex items-center space-x-2 rtl:space-x-reverse">
              <Grid3X3 className="w-4 h-4" />
              <span>پیش‌نمایش</span>
            </TabsTrigger>
            <TabsTrigger value="live" className="flex items-center space-x-2 rtl:space-x-reverse">
              <Zap className="w-4 h-4" />
              <span>تست زنده</span>
            </TabsTrigger>
          </TabsList>

          {/* Comparison Tab */}
          <TabsContent value="comparison" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Old Design Features */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
                      <List className="w-5 h-5 text-gray-400" />
                      <span>طراحی قدیم</span>
                      <Badge variant="outline">Classic</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {features.old.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2 rtl:space-x-reverse text-sm">
                        <div className="w-2 h-2 bg-gray-400 rounded-full" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>

              {/* New Design Features */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="h-full border-2 border-blue-500/30 bg-gradient-to-br from-blue-500/5 to-purple-500/5">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
                      <Sparkles className="w-5 h-5 text-blue-400" />
                      <span>طراحی جدید</span>
                      <Badge className="bg-gradient-to-r from-blue-500 to-purple-500">Modern</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {features.new.map((feature, index) => (
                      <motion.div 
                        key={index} 
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 + 0.3 }}
                        className="flex items-center space-x-2 rtl:space-x-reverse text-sm"
                      >
                        <div className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full" />
                        <span>{feature}</span>
                      </motion.div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Detailed Improvements */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="space-y-4"
            >
              <h2 className="text-2xl font-bold text-center mb-6">بهبودهای کلیدی</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {improvements.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 + 0.5 }}
                  >
                    <Card className="hover:shadow-lg transition-shadow">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <h3 className="font-semibold text-blue-400">{item.feature}</h3>
                          
                          <div className="space-y-2 text-sm">
                            <div className="flex items-start space-x-2 rtl:space-x-reverse">
                              <span className="text-red-400 font-medium">قدیم:</span>
                              <span className="text-muted-foreground">{item.old}</span>
                            </div>
                            
                            <div className="flex items-start space-x-2 rtl:space-x-reverse">
                              <span className="text-green-400 font-medium">جدید:</span>
                              <span>{item.new}</span>
                            </div>
                          </div>
                          
                          <div className="pt-2 border-t border-border/50">
                            <Badge variant="secondary" className="text-xs">
                              <Star className="w-3 h-3 ml-1" />
                              {item.improvement}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </TabsContent>

          {/* Preview Tab */}
          <TabsContent value="preview" className="space-y-6">
            <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse">
              <Button
                variant={selectedDesign === 'old' ? 'default' : 'outline'}
                onClick={() => setSelectedDesign('old')}
                className="flex items-center space-x-2 rtl:space-x-reverse"
              >
                <List className="w-4 h-4" />
                <span>طراحی قدیم</span>
              </Button>
              
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
              
              <Button
                variant={selectedDesign === 'new' ? 'default' : 'outline'}
                onClick={() => setSelectedDesign('new')}
                className="flex items-center space-x-2 rtl:space-x-reverse bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              >
                <Sparkles className="w-4 h-4" />
                <span>طراحی جدید</span>
              </Button>
            </div>

            <Card className="p-4">
              <div className="aspect-video bg-surface-secondary rounded-lg overflow-hidden">
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                  <div className="text-center space-y-2">
                    <Palette className="w-12 h-12 mx-auto" />
                    <p>پیش‌نمایش {selectedDesign === 'old' ? 'طراحی قدیم' : 'طراحی جدید'}</p>
                    <p className="text-sm">برای مشاهده کامل از تب "تست زنده" استفاده کنید</p>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Live Test Tab */}
          <TabsContent value="live" className="space-y-6">
            <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse">
              <Button
                variant={selectedDesign === 'old' ? 'default' : 'outline'}
                onClick={() => setSelectedDesign('old')}
                className="flex items-center space-x-2 rtl:space-x-reverse"
              >
                <List className="w-4 h-4" />
                <span>نسخه قدیم</span>
              </Button>
              
              <Button
                variant={selectedDesign === 'new' ? 'default' : 'outline'}
                onClick={() => setSelectedDesign('new')}
                className="flex items-center space-x-2 rtl:space-x-reverse bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              >
                <Sparkles className="w-4 h-4" />
                <span>نسخه جدید (پیشنهادی)</span>
              </Button>
            </div>

            <div className="border-2 border-border/50 rounded-xl overflow-hidden">
              {selectedDesign === 'old' ? <SocialPage /> : <ModernSocialPageFixed />}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}