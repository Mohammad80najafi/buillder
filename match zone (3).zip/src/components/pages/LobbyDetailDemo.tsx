/**
 * Lobby Detail Demo Page
 * Shows the advanced lobby detail functionality
 */

import React from 'react';
import { LobbyDetailPageAdvanced } from '../gaming/LobbyDetailPageAdvanced';
import { useNavigation } from '../navigation/NavigationProvider';
import { useLobby } from '../gaming/LobbyContext';

export function LobbyDetailDemo() {
  const { navigate } = useNavigation();
  const { selectedLobbyId } = useLobby();
  
  return (
    <LobbyDetailPageAdvanced 
      lobbyId={selectedLobbyId || "lobby-demo-1"}
      onBack={() => navigate('lobbies')}
    />
  );
}

export default LobbyDetailDemo;