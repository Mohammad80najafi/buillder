import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '../ui/input-otp';
import { Eye, EyeOff } from 'lucide-react';

interface AuthPageProps {
  onAuth: (success: boolean) => void;
}

export function AuthPage({ onAuth }: AuthPageProps) {
  const [authMethod, setAuthMethod] = useState<'phone' | 'email'>('phone');
  const [step, setStep] = useState<'login' | 'register' | 'otp' | 'forgot'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    phone: '',
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
    username: '',
    otp: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 'otp') {
      // Simulate OTP verification
      onAuth(true);
    } else if (step === 'login') {
      setStep('otp');
    } else if (step === 'register') {
      setStep('otp');
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted/20 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="bg-primary text-primary-foreground px-6 py-3 rounded-lg mx-auto mb-4 w-fit">
            <span className="text-2xl font-bold">گیم‌هاب</span>
          </div>
          <CardTitle className="text-2xl" dir="rtl">
            {step === 'login' && 'ورود به حساب'}
            {step === 'register' && 'ایجاد حساب جدید'}
            {step === 'otp' && 'تایید کد'}
            {step === 'forgot' && 'بازیابی رمز عبور'}
          </CardTitle>
          <CardDescription className="text-center" dir="rtl">
            {step === 'login' && 'برای ادامه وارد حساب کاربری خود شوید'}
            {step === 'register' && 'برای شروع حساب جدید ایجاد کنید'}
            {step === 'otp' && `کد تایید ارسال شده به ${authMethod === 'phone' ? formData.phone : formData.email} را وارد کنید`}
            {step === 'forgot' && 'ایمیل یا شماره تلفن خود را وارد کنید'}
          </CardDescription>
        </CardHeader>

        <CardContent>
          {step === 'otp' ? (
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="space-y-6 text-center">
                <div className="space-y-3">
                  <Label htmlFor="otp" className="text-base font-semibold block" dir="rtl">
                    کد تایید 6 رقمی
                  </Label>
                  <p className="text-sm text-muted-foreground" dir="rtl">
                    کد تایید ارسال شده را در کادرهای زیر وارد کنید
                  </p>
                </div>
                
                <div className="flex justify-center py-4" dir="ltr">
                  <InputOTP
                    maxLength={6}
                    value={formData.otp}
                    onChange={(value) => handleInputChange('otp', value)}
                    containerClassName="gap-3"
                  >
                    <InputOTPGroup className="gap-3">
                      <InputOTPSlot 
                        index={0} 
                        className="h-14 w-12 text-lg font-semibold border-2 rounded-xl bg-muted/50 
                                   hover:bg-muted/70 transition-colors duration-200
                                   data-[active=true]:border-primary data-[active=true]:bg-primary/5
                                   data-[active=true]:ring-2 data-[active=true]:ring-primary/30" 
                      />
                      <InputOTPSlot 
                        index={1} 
                        className="h-14 w-12 text-lg font-semibold border-2 rounded-xl bg-muted/50 
                                   hover:bg-muted/70 transition-colors duration-200
                                   data-[active=true]:border-primary data-[active=true]:bg-primary/5
                                   data-[active=true]:ring-2 data-[active=true]:ring-primary/30" 
                      />
                      <InputOTPSlot 
                        index={2} 
                        className="h-14 w-12 text-lg font-semibold border-2 rounded-xl bg-muted/50 
                                   hover:bg-muted/70 transition-colors duration-200
                                   data-[active=true]:border-primary data-[active=true]:bg-primary/5
                                   data-[active=true]:ring-2 data-[active=true]:ring-primary/30" 
                      />
                      <InputOTPSlot 
                        index={3} 
                        className="h-14 w-12 text-lg font-semibold border-2 rounded-xl bg-muted/50 
                                   hover:bg-muted/70 transition-colors duration-200
                                   data-[active=true]:border-primary data-[active=true]:bg-primary/5
                                   data-[active=true]:ring-2 data-[active=true]:ring-primary/30" 
                      />
                      <InputOTPSlot 
                        index={4} 
                        className="h-14 w-12 text-lg font-semibold border-2 rounded-xl bg-muted/50 
                                   hover:bg-muted/70 transition-colors duration-200
                                   data-[active=true]:border-primary data-[active=true]:bg-primary/5
                                   data-[active=true]:ring-2 data-[active=true]:ring-primary/30" 
                      />
                      <InputOTPSlot 
                        index={5} 
                        className="h-14 w-12 text-lg font-semibold border-2 rounded-xl bg-muted/50 
                                   hover:bg-muted/70 transition-colors duration-200
                                   data-[active=true]:border-primary data-[active=true]:bg-primary/5
                                   data-[active=true]:ring-2 data-[active=true]:ring-primary/30" 
                      />
                    </InputOTPGroup>
                  </InputOTP>
                </div>

                {/* Progress indicator */}
                <div className="flex justify-center space-x-1 rtl:space-x-reverse">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-1 w-6 rounded-full transition-colors duration-300 ${
                        i < formData.otp.length 
                          ? 'bg-primary' 
                          : 'bg-muted'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full h-12 text-base font-semibold" 
                disabled={formData.otp.length !== 6}
              >
                {formData.otp.length === 6 ? 'تایید و ورود' : `${6 - formData.otp.length} رقم باقی مانده`}
              </Button>

              <div className="space-y-3">
                <div className="text-center">
                  <Button 
                    variant="ghost" 
                    className="text-sm text-muted-foreground hover:text-primary" 
                    dir="rtl"
                    onClick={() => {
                      // Simulate resend OTP
                      setFormData(prev => ({ ...prev, otp: '' }));
                    }}
                  >
                    ارسال مجدد کد (2:30)
                  </Button>
                </div>
                <div className="text-center">
                  <Button variant="link" onClick={() => setStep('login')} className="text-sm" dir="rtl">
                    بازگشت به ورود
                  </Button>
                </div>
              </div>
            </form>
          ) : step === 'forgot' ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <Tabs value={authMethod} onValueChange={(value) => setAuthMethod(value as 'phone' | 'email')}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="phone">شماره تلفن</TabsTrigger>
                  <TabsTrigger value="email">ایمیل</TabsTrigger>
                </TabsList>

                <TabsContent value="phone" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-right" dir="rtl">شماره تلفن</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="09123456789"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className="text-right"
                      dir="rtl"
                      required
                    />
                  </div>
                </TabsContent>

                <TabsContent value="email" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-right" dir="rtl">ایمیل</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="example@email.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      required
                    />
                  </div>
                </TabsContent>
              </Tabs>

              <Button type="submit" className="w-full">
                ارسال کد بازیابی
              </Button>

              <div className="text-center">
                <Button variant="link" onClick={() => setStep('login')} className="text-sm" dir="rtl">
                  بازگشت به ورود
                </Button>
              </div>
            </form>
          ) : (
            <Tabs value={step} onValueChange={(value) => setStep(value as 'login' | 'register')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">ورود</TabsTrigger>
                <TabsTrigger value="register">ثبت‌نام</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <Tabs value={authMethod} onValueChange={(value) => setAuthMethod(value as 'phone' | 'email')}>
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="phone">شماره تلفن</TabsTrigger>
                      <TabsTrigger value="email">ایمیل</TabsTrigger>
                    </TabsList>

                    <TabsContent value="phone" className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-right" dir="rtl">شماره تلفن</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="09123456789"
                          value={formData.phone}
                          onChange={(e) => handleInputChange('phone', e.target.value)}
                          className="text-right"
                          dir="rtl"
                          required
                        />
                      </div>
                    </TabsContent>

                    <TabsContent value="email" className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-right" dir="rtl">ایمیل</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="example@email.com"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                          required
                        />
                      </div>
                    </TabsContent>
                  </Tabs>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-right" dir="rtl">رمز عبور</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="رمز عبور خود را وارد کنید"
                        value={formData.password}
                        onChange={(e) => handleInputChange('password', e.target.value)}
                        className="text-right pr-10"
                        dir="rtl"
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <div className="text-left">
                    <Button variant="link" onClick={() => setStep('forgot')} className="text-sm p-0" dir="rtl">
                      رمز عبور را فراموش کرده‌اید؟
                    </Button>
                  </div>

                  <Button type="submit" className="w-full">
                    ورود
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-right" dir="rtl">نام</Label>
                      <Input
                        id="name"
                        placeholder="علی"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="text-right"
                        dir="rtl"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-right" dir="rtl">نام کاربری</Label>
                      <Input
                        id="username"
                        placeholder="@username"
                        value={formData.username}
                        onChange={(e) => handleInputChange('username', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <Tabs value={authMethod} onValueChange={(value) => setAuthMethod(value as 'phone' | 'email')}>
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="phone">شماره تلفن</TabsTrigger>
                      <TabsTrigger value="email">ایمیل</TabsTrigger>
                    </TabsList>

                    <TabsContent value="phone" className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-right" dir="rtl">شماره تلفن</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="09123456789"
                          value={formData.phone}
                          onChange={(e) => handleInputChange('phone', e.target.value)}
                          className="text-right"
                          dir="rtl"
                          required
                        />
                      </div>
                    </TabsContent>

                    <TabsContent value="email" className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-right" dir="rtl">ایمیل</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="example@email.com"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                          required
                        />
                      </div>
                    </TabsContent>
                  </Tabs>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-right" dir="rtl">رمز عبور</Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        placeholder="رمز عبور قوی انتخاب کنید"
                        value={formData.password}
                        onChange={(e) => handleInputChange('password', e.target.value)}
                        className="text-right pr-10"
                        dir="rtl"
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  <Button type="submit" className="w-full">
                    ایجاد حساب
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>
    </div>
  );
}