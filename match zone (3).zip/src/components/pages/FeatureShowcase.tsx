import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Trophy, Users, Play, MessageCircle, Store, Video, 
  Coins, Crown, Shield, Star, Gift, Zap, Target,
  Activity, TrendingUp, Calendar, Heart, Share,
  Gamepad2, Settings, Award, Medal
} from 'lucide-react';
import { useMobile } from '../ui/use-mobile';

export function FeatureShowcase() {
  const isMobile = useMobile();
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);

  const features = [
    {
      id: 'dashboard',
      title: 'Dashboard Real-time',
      description: 'مشاهده آمار زنده و فعالیت‌های جاری پلتفرم',
      icon: Activity,
      color: 'bg-blue-500',
      stats: ['۲,۸۴۷ کاربر آنلاین', '۱۵۶ لابی فعال', '۱۲ تورنومنت جاری'],
      features: ['آمار زنده', 'لیدربورد', 'مسابقات جاری', 'فعالیت‌های اخیر']
    },
    {
      id: 'lobbies',
      title: 'سیستم لابی پیشرفته',
      description: 'ایجاد و مدیریت لابی‌های بازی با امکانات کامل',
      icon: Users,
      color: 'bg-green-500',
      stats: ['۲۴۷ لابی کل', '۸۹ لابی فعال', '۱۵۶ بازیکن منتظر'],
      features: ['ایجاد لابی', 'فیلتر پیشرفته', 'مدیریت اعضا', 'چت لابی']
    },
    {
      id: 'tournaments',
      title: 'تورنومنت‌های حرفه‌ای',
      description: 'سازماندهی و شرکت در مسابقات با جوایز نقدی',
      icon: Trophy,
      color: 'bg-yellow-500',
      stats: ['۴۵ تورنومنت فعال', '۱,۲۳۴ شرکت‌کننده', '۲.۵ میلیون جایزه'],
      features: ['براکت مسابقات', 'پرداخت آنلاین', 'جوایز نقدی', 'لایو استریم']
    },
    {
      id: 'social',
      title: 'شبکه اجتماعی گیمرها',
      description: 'چت real-time، دوستی، و تعامل با جامعه گیمرها',
      icon: MessageCircle,
      color: 'bg-purple-500',
      stats: ['۵,۶۷۸ پیام امروز', '۱,۲۳۴ دوستی جدید', '۹۸۹ گروه فعال'],
      features: ['چت چندگانه', 'ری‌اکشن', 'صدا/ویدیو', 'فایل‌شیرینگ']
    },
    {
      id: 'store',
      title: 'فروشگاه دیجیتال',
      description: 'خرید کوین، پاس، و آیتم‌های ویژه',
      icon: Store,
      color: 'bg-pink-500',
      stats: ['۱۲۳ محصول', '۴۵,۶۷۸ خرید امروز', '۹۸% رضایت'],
      features: ['کیف پول دیجیتال', 'پرداخت امن', 'پاس VIP', 'آیتم‌های نادر']
    },
    {
      id: 'creator',
      title: 'پلتفرم کریتور',
      description: 'آپلود ویدیو، استریم زنده، و کسب درآمد',
      icon: Video,
      color: 'bg-red-500',
      stats: ['۲,۳۴۵ کریتور', '۱۵,۶۷۸ ویدیو', '۵۰ میلیون بازدید'],
      features: ['آپلود ویدیو', 'لایو استریم', 'سیستم انعام', 'آنالیتیکس']
    }
  ];

  const technologies = [
    { name: 'React 18', description: 'فریمورک مدرن UI', icon: '⚛️' },
    { name: 'TypeScript', description: 'تایپ‌سیف جاوااسکریپت', icon: '📝' },
    { name: 'Tailwind CSS v4', description: 'استایل مدرن', icon: '🎨' },
    { name: 'Supabase', description: 'بک‌اند و دیتابیس', icon: '🚀' },
    { name: 'Real-time', description: 'به‌روزرسانی زنده', icon: '⚡' },
    { name: 'PWA', description: 'اپلیکیشن وب پیشرفته', icon: '📱' }
  ];

  const stats = [
    { label: 'کاربران فعال', value: '12,500+', icon: Users },
    { label: 'بازی‌های پشتیبانی شده', value: '25+', icon: Gamepad2 },
    { label: 'تورنومنت‌های برگزار شده', value: '500+', icon: Trophy },
    { label: 'ساعت استریم', value: '10,000+', icon: Play },
    { label: 'کریتورهای فعال', value: '2,000+', icon: Star },
    { label: 'لابی‌های ایجاد شده', value: '50,000+', icon: Shield }
  ];

  const roadmap = [
    {
      quarter: 'Q1 2024',
      title: 'MVP اولیه',
      status: 'completed',
      items: ['لابی سیستم', 'چت پایه', 'پروفایل کاربر']
    },
    {
      quarter: 'Q2 2024',
      title: 'ویژگی‌های پیشرفته',
      status: 'completed',
      items: ['تورنومنت‌ها', 'فروشگاه', 'سیستم امتیاز']
    },
    {
      quarter: 'Q3 2024',
      title: 'پلتفرم کریتور',
      status: 'current',
      items: ['آپلود ویدیو', 'لایو استریم', 'سیستم انعام']
    },
    {
      quarter: 'Q4 2024',
      title: 'هوش مصنوعی',
      status: 'planned',
      items: ['پیشنهاد هوشمند', 'تحلیل بازی', 'چت‌بات']
    }
  ];

  return (
    <div className="space-y-8 w-full" dir="rtl">
      {/* Hero Section */}
      <div className="text-center space-y-6 py-12">
        <div className="space-y-4">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            گیم‌هاب MVP
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            پلتفرم جامع گیمینگ با تمام ویژگی‌های حرفه‌ای برای جامعه گیمرهای ایران
          </p>
        </div>
        
        <div className="flex justify-center space-x-4">
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            <Play className="h-5 w-5 ml-2" />
            مشاهده دمو
          </Button>
          <Button variant="outline" size="lg">
            <Settings className="h-5 w-5 ml-2" />
            مطالعه مستندات
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="text-center p-4">
              <div className="space-y-2">
                <Icon className="h-8 w-8 mx-auto text-primary" />
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Main Features */}
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold">ویژگی‌های کلیدی</h2>
          <p className="text-muted-foreground">تمام قابلیت‌هایی که یک پلتفرم گیمینگ حرفه‌ای نیاز دارد</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <Card 
                key={feature.id} 
                className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
                  selectedFeature === feature.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedFeature(selectedFeature === feature.id ? null : feature.id)}
              >
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="text-right flex-1">
                      <CardTitle className="text-lg">{feature.title}</CardTitle>
                      <CardDescription>{feature.description}</CardDescription>
                    </div>
                    <div className={`p-3 rounded-full ${feature.color}`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Stats */}
                  <div className="space-y-2">
                    {feature.stats.map((stat, index) => (
                      <div key={index} className="text-sm text-muted-foreground text-right">
                        • {stat}
                      </div>
                    ))}
                  </div>
                  
                  {/* Expanded Features */}
                  {selectedFeature === feature.id && (
                    <div className="space-y-3 border-t pt-4">
                      <h4 className="font-semibold text-right">قابلیت‌ها:</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {feature.features.map((feat, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {feat}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Technology Stack */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center">تکنولوژی‌های استفاده شده</CardTitle>
          <CardDescription className="text-center">
            پلتفرم با جدیدترین و بهترین تکنولوژی‌ها ساخته شده است
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {technologies.map((tech, index) => (
              <div key={index} className="text-center space-y-2 p-4 rounded-lg hover:bg-muted transition-colors">
                <div className="text-2xl">{tech.icon}</div>
                <div className="font-semibold">{tech.name}</div>
                <div className="text-xs text-muted-foreground">{tech.description}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Roadmap */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center">نقشه راه توسعه</CardTitle>
          <CardDescription className="text-center">
            برنامه توسعه و ویژگی‌های آینده پلتفرم
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {roadmap.map((phase, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className="text-right flex-1">
                  <div className="flex items-center justify-end space-x-2 mb-2">
                    <Badge 
                      variant={
                        phase.status === 'completed' ? 'default' :
                        phase.status === 'current' ? 'secondary' : 'outline'
                      }
                      className="text-xs"
                    >
                      {phase.status === 'completed' && 'تکمیل شده'}
                      {phase.status === 'current' && 'در حال توسعه'}
                      {phase.status === 'planned' && 'برنامه‌ریزی شده'}
                    </Badge>
                    <h3 className="font-semibold">{phase.title}</h3>
                  </div>
                  <div className="space-y-1">
                    {phase.items.map((item, itemIndex) => (
                      <div key={itemIndex} className="text-sm text-muted-foreground text-right">
                        • {item}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col items-center">
                  <div className={`w-4 h-4 rounded-full ${
                    phase.status === 'completed' ? 'bg-green-500' :
                    phase.status === 'current' ? 'bg-blue-500' : 'bg-gray-300'
                  }`} />
                  <div className="text-sm font-medium mt-2">{phase.quarter}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Call to Action */}
      <Card className="bg-gradient-to-r from-primary/10 to-accent/10">
        <CardContent className="text-center py-12 space-y-6">
          <h2 className="text-3xl font-bold">آماده برای شروع؟</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            به جامعه گیمرهای ایران بپیوندید و تجربه بازی خود را به سطح بعدی ببرید
          </p>
          <div className="flex justify-center space-x-4">
            <Button size="lg">
              <Users className="h-5 w-5 ml-2" />
              عضویت رایگان
            </Button>
            <Button variant="outline" size="lg">
              <Heart className="h-5 w-5 ml-2" />
              حمایت از پروژه
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}