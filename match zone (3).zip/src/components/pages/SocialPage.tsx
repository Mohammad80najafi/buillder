import React, { useState } from 'react';
import { MessageCircle, Users, User, Headphones, Search, Plus, Settings, Bell, Star, MoreVertical, Shield, Hash, ArrowLeft } from 'lucide-react';
import { useMobile } from '../ui/use-mobile';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Card, CardContent, CardHeader } from '../ui/card';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '../ui/dropdown-menu';
import { Separator } from '../ui/separator';
import { AdvancedChatSystem } from '../chat/AdvancedChatSystem';
import { ClanChatSystem } from '../clans/ClanChatSystem';
import { useClan } from '../providers/ClanProvider';

type ChatType = 'all' | 'groups' | 'direct' | 'support' | 'clans';

interface ChatRoom {
  id: string;
  name: string;
  type: 'group' | 'direct' | 'support' | 'clan';
  avatar?: string;
  lastMessage: {
    content: string;
    timestamp: string;
    sender: string;
  };
  unreadCount: number;
  isOnline?: boolean;
  members?: number;
  isPinned?: boolean;
  status?: 'active' | 'resolved' | 'pending';
  clanTag?: string;
  clanId?: string;
}

export function SocialPage() {
  const [activeTab, setActiveTab] = useState<ChatType>('all');
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const { clanChats, markClanChatAsRead, clans } = useClan();
  const isMobile = useMobile();

  // Convert clan chats to chat rooms
  const clanChatRooms: ChatRoom[] = clanChats.map(clanChat => ({
    id: clanChat.id,
    name: clanChat.clanName,
    type: 'clan' as const,
    avatar: clanChat.clanLogo,
    lastMessage: clanChat.lastMessage || {
      content: 'هنوز پیامی نیست',
      timestamp: 'الان',
      sender: 'سیستم'
    },
    unreadCount: clanChat.unreadCount,
    members: clans.find(c => c.id === clanChat.clanId)?.members.current || 0,
    clanTag: clanChat.clanTag,
    clanId: clanChat.clanId
  }));

  // Mock chat data
  const regularChats: ChatRoom[] = [
    {
      id: '1',
      name: 'تیم PUBG Pro',
      type: 'group',
      avatar: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=150&h=150&fit=crop',
      lastMessage: {
        content: 'آماده برای مسابقه فردا؟',
        timestamp: '10:30',
        sender: 'علی'
      },
      unreadCount: 3,
      members: 8,
      isPinned: true
    },
    {
      id: '2',
      name: 'محمد گیمر',
      type: 'direct',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      lastMessage: {
        content: 'سلام، چطوری؟',
        timestamp: '09:45',
        sender: 'محمد گیمر'
      },
      unreadCount: 1,
      isOnline: true
    },
    {
      id: '3',
      name: 'پشتیبانی فنی',
      type: 'support',
      lastMessage: {
        content: 'مشکل شما حل شد',
        timestamp: 'دیروز',
        sender: 'تیم پشتیبانی'
      },
      unreadCount: 0,
      status: 'resolved'
    },
    {
      id: '4',
      name: 'گروه Valorant',
      type: 'group',
      avatar: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=150&h=150&fit=crop',
      lastMessage: {
        content: 'جلسه تمرین امشب 8',
        timestamp: 'یکشنبه',
        sender: 'کاپیتان'
      },
      unreadCount: 0,
      members: 5
    },
    {
      id: '5',
      name: 'سارا استریمر',
      type: 'direct',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      lastMessage: {
        content: 'ممنون از ساب! 💜',
        timestamp: 'یکشنبه',
        sender: 'سارا استریمر'
      },
      unreadCount: 0,
      isOnline: false
    },
    {
      id: '6',
      name: 'مشکل اتصال',
      type: 'support',
      lastMessage: {
        content: 'در حال بررسی مشکل شما هستیم',
        timestamp: '2 روز پیش',
        sender: 'تیم پشتیبانی'
      },
      unreadCount: 1,
      status: 'pending'
    }
  ];

  // Combine clan chats with regular chats
  const chats: ChatRoom[] = [...clanChatRooms, ...regularChats];

  const filteredChats = chats.filter(chat => {
    if (activeTab === 'clans' && chat.type !== 'clan') return false;
    if (activeTab !== 'all' && activeTab !== 'clans' && chat.type !== activeTab.slice(0, -1)) return false;
    if (searchQuery && !chat.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const getTabCount = (type: ChatType) => {
    if (type === 'all') return chats.length;
    if (type === 'clans') return chats.filter(chat => chat.type === 'clan').length;
    return chats.filter(chat => chat.type === type.slice(0, -1)).length;
  };

  const getChatIcon = (type: 'group' | 'direct' | 'support' | 'clan') => {
    switch (type) {
      case 'group':
        return Users;
      case 'direct':
        return User;
      case 'support':
        return Headphones;
      case 'clan':
        return Shield;
    }
  };

  const getStatusColor = (status?: 'active' | 'resolved' | 'pending') => {
    switch (status) {
      case 'active':
        return 'text-gaming-success';
      case 'resolved':
        return 'text-muted-foreground';
      case 'pending':
        return 'text-gaming-warning';
      default:
        return 'text-foreground';
    }
  };

  const renderChatItem = (chat: ChatRoom) => {
    const Icon = getChatIcon(chat.type);
    
    return (
      <Card 
        key={chat.id} 
        className={`cursor-pointer transition-colors hover:bg-card/80 ${
          selectedChat === chat.id ? 'border-destructive' : ''
        }`}
        onClick={() => setSelectedChat(chat.id)}
      >
        <CardContent className="p-4">
          <div className="flex items-center space-x-3" dir="rtl">
            <div className="relative">
              {chat.avatar ? (
                <Avatar className="h-12 w-12">
                  <AvatarImage src={chat.avatar} alt={chat.name} />
                  <AvatarFallback>{chat.name[0]}</AvatarFallback>
                </Avatar>
              ) : (
                <div className="h-12 w-12 rounded-full bg-card flex items-center justify-center">
                  <Icon className="h-6 w-6 text-muted-foreground" />
                </div>
              )}
              
              {chat.type === 'direct' && chat.isOnline !== undefined && (
                <div className={`absolute bottom-0 left-0 h-3 w-3 rounded-full border-2 border-background ${
                  chat.isOnline ? 'bg-gaming-success' : 'bg-muted-foreground'
                }`} />
              )}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center space-x-2" dir="rtl">
                  <h3 className={`font-medium truncate ${getStatusColor(chat.status)}`}>
                    {chat.name}
                  </h3>
                  
                  {chat.isPinned && (
                    <Star className="h-4 w-4 text-gaming-warning fill-current" />
                  )}
                  
                  {(chat.type === 'group' || chat.type === 'clan') && chat.members && (
                    <Badge variant="outline" className="text-xs">
                      {chat.members} عضو
                    </Badge>
                  )}
                  
                  {chat.type === 'clan' && chat.clanTag && (
                    <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400 border-blue-500/30">
                      <Hash className="w-2 h-2 ml-1" />
                      {chat.clanTag}
                    </Badge>
                  )}
                  
                  {chat.type === 'support' && chat.status && (
                    <Badge 
                      variant={chat.status === 'resolved' ? 'secondary' : 'outline'}
                      className="text-xs"
                    >
                      {chat.status === 'active' ? 'فعال' : 
                       chat.status === 'resolved' ? 'حل شده' : 'در انتظار'}
                    </Badge>
                  )}
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-muted-foreground">
                    {chat.lastMessage.timestamp}
                  </span>
                  
                  {chat.unreadCount > 0 && (
                    <Badge className="h-5 w-5 p-0 text-xs rounded-full bg-primary text-primary-foreground">
                      {chat.unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground truncate">
                  {chat.type !== 'direct' && (
                    <span className="font-medium">{chat.lastMessage.sender}: </span>
                  )}
                  {chat.lastMessage.content}
                </p>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      {chat.isPinned ? 'حذف از پین' : 'پین کردن'}
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      {chat.unreadCount > 0 ? 'علامت‌گذاری به عنوان خوانده شده' : 'علامت‌گذاری به عنوان خوانده نشده'}
                    </DropdownMenuItem>
                    {chat.type === 'support' && (
                      <DropdownMenuItem>
                        بستن تیکت
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem className="text-destructive">
                      حذف چت
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  // If a chat is selected, show the chat interface
  if (selectedChat) {
    const selectedChatData = chats.find(chat => chat.id === selectedChat);
    
    // Mobile full-screen chat interface
    if (isMobile) {
      return (
        <div className={`flex flex-col bg-background h-[calc(100vh-76px)]`}>
          {/* Chat Header */}
          <div className="flex-shrink-0 flex items-center justify-between p-4 border-b border-border/50 bg-background/95 backdrop-blur-sm">
            <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0 flex-1">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setSelectedChat(null)}
                className="flex-shrink-0"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              
              {selectedChatData && (
                <>
                  <div className="relative flex-shrink-0">
                    {selectedChatData.avatar ? (
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={selectedChatData.avatar} alt={selectedChatData.name} />
                        <AvatarFallback>{selectedChatData.name[0]}</AvatarFallback>
                      </Avatar>
                    ) : (
                      <div className="h-8 w-8 rounded-full bg-card flex items-center justify-center">
                        {React.createElement(getChatIcon(selectedChatData.type), { className: "h-4 w-4 text-muted-foreground" })}
                      </div>
                    )}
                    {selectedChatData.type === 'direct' && selectedChatData.isOnline !== undefined && (
                      <div className={`absolute bottom-0 left-0 h-2 w-2 rounded-full border border-background ${
                        selectedChatData.isOnline ? 'bg-green-500' : 'bg-muted-foreground'
                      }`} />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h2 className="font-semibold truncate">{selectedChatData.name}</h2>
                    <p className="text-xs text-muted-foreground">
                      {selectedChatData.type === 'direct' 
                        ? (selectedChatData.isOnline ? 'آنلاین' : 'آفلاین')
                        : selectedChatData.members ? `${selectedChatData.members} عضو` : 'گروه'
                      }
                    </p>
                  </div>
                </>
              )}
            </div>
          </div>
          
          {/* Chat Content */}
          <div className="flex-1 overflow-hidden">
            {selectedChatData?.type === 'clan' && selectedChatData.clanId ? (
              <ClanChatSystem
                clan={clans.find(c => c.id === selectedChatData.clanId)!}
                currentUserId="current-user-id"
                currentUserRole="member"
                onClose={() => {
                  setSelectedChat(null);
                  if (selectedChatData.clanId) {
                    markClanChatAsRead(selectedChatData.clanId);
                  }
                }}
                className="h-full"
              />
            ) : (
              <AdvancedChatSystem />
            )}
          </div>
        </div>
      );
    }
    
    // Desktop chat interface
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => setSelectedChat(null)}>
          <ArrowLeft className="h-4 w-4 ml-2" />
          بازگشت به لیست چت‌ها
        </Button>
        
        {selectedChatData?.type === 'clan' && selectedChatData.clanId ? (
          <ClanChatSystem
            clan={clans.find(c => c.id === selectedChatData.clanId)!}
            currentUserId="current-user-id"
            currentUserRole="member"
            onClose={() => {
              setSelectedChat(null);
              if (selectedChatData.clanId) {
                markClanChatAsRead(selectedChatData.clanId);
              }
            }}
            className="w-full max-w-4xl mx-auto"
          />
        ) : (
          <AdvancedChatSystem />
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">پیام‌ها</h1>
          <p className="text-muted-foreground">مدیریت چت‌های گروهی، خصوصی و پشتیبانی</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 ml-2" />
            تنظیمات
          </Button>
          <Button size="sm">
            <Plus className="h-4 w-4 ml-2" />
            چت جدید
          </Button>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="جستجو در چت‌ها..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pr-10 text-right"
          dir="rtl"
        />
      </div>

      {/* Filter Tabs */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as ChatType)}>
        <TabsList className="w-full justify-start">
          <TabsTrigger value="all" className="flex items-center space-x-2">
            <MessageCircle className="h-4 w-4" />
            <span>همه ({getTabCount('all')})</span>
          </TabsTrigger>
          <TabsTrigger value="groups" className="flex items-center space-x-2">
            <Users className="h-4 w-4" />
            <span>گروه‌ها ({getTabCount('groups')})</span>
          </TabsTrigger>
          <TabsTrigger value="direct" className="flex items-center space-x-2">
            <User className="h-4 w-4" />
            <span>خصوصی ({getTabCount('direct')})</span>
          </TabsTrigger>
          <TabsTrigger value="support" className="flex items-center space-x-2">
            <Headphones className="h-4 w-4" />
            <span>پشتیبانی ({getTabCount('support')})</span>
          </TabsTrigger>
          <TabsTrigger value="clans" className="flex items-center space-x-2">
            <Shield className="h-4 w-4" />
            <span>کلن‌ها ({getTabCount('clans')})</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {/* Chats List */}
          <div className="space-y-2">
            {filteredChats.length > 0 ? (
              filteredChats.map(renderChatItem)
            ) : (
              <div className="text-center py-12">
                <MessageCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">هیچ چتی یافت نشد</h3>
                <p className="text-muted-foreground mb-4">
                  {searchQuery ? 'نتیجه‌ای برای جستجوی شما پیدا نشد' : 'هنوز چتی ندارید'}
                </p>
                <Button>
                  <Plus className="h-4 w-4 ml-2" />
                  شروع چت جدید
                </Button>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

    </div>
  );
}