/**
 * Final Showcase Page - Matchzone Complete Platform
 * نمایش نهایی پلتفرم کامل Matchzone
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Gamepad2, 
  Calendar as CalendarIcon,
  Users,
  Bell,
  Trophy,
  Settings,
  Star,
  Zap,
  Crown,
  Shield,
  Globe,
  Clock,
  Play,
  Award,
  Target,
  Flame,
  CheckCircle2,
  ArrowRight,
  Eye,
  TrendingUp,
  Heart,
  X,
  Timer,
  MessageCircle,
  Sparkles
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

// Import all our components
// Persian calendar component removed
import { FriendInviteSystem } from '../friends/FriendInviteSystem';
import { LobbyInviteNotifications } from '../notifications/LobbyInviteNotifications';
// LobbySchedulingMainPage removed
import { LobbiesPageAdvanced } from './LobbiesPageAdvanced';
import { ComponentTestPage } from './ComponentTestPage';
// Persian calendar utility removed

interface FeatureCard {
  icon: React.ReactNode;
  title: string;
  description: string;
  status: 'completed' | 'active' | 'testing';
  component?: string;
  metrics?: {
    users?: number;
    satisfaction?: number;
    performance?: number;
  };
}

const features: FeatureCard[] = [
  {
    icon: <CalendarIcon className="w-6 h-6" />,
    title: "تقویم جلالی",
    description: "تقویم کامل فارسی با پشتیبانی از برنامه‌ریزی لابی‌ها",
    status: 'completed',
    component: 'PersianCalendar',
    metrics: { users: 1250, satisfaction: 98, performance: 95 }
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: "سیستم دعوت دوستان",
    description: "دعوت دوستان به لابی‌ها با اعلان‌های real-time",
    status: 'completed',
    component: 'FriendInviteSystem',
    metrics: { users: 890, satisfaction: 96, performance: 92 }
  },
  {
    icon: <Bell className="w-6 h-6" />,
    title: "سیستم اعلان‌ها",
    description: "مدیریت اعلان‌ها و دعوتنامه‌ها با پاسخ سریع",
    status: 'completed',
    component: 'LobbyInviteNotifications',
    metrics: { users: 1100, satisfaction: 94, performance: 98 }
  },
  {
    icon: <Gamepad2 className="w-6 h-6" />,
    title: "مدیریت لابی‌ها",
    description: "سیستم پیشرفته لابی‌ها با پشتیبانی multi-platform",
    status: 'completed',
    component: 'LobbiesPageAdvanced',
    metrics: { users: 2100, satisfaction: 97, performance: 94 }
  },
  {
    icon: <Trophy className="w-6 h-6" />,
    title: "سیستم تورنومنت",
    description: "برگزاری تورنومنت‌های حرفه‌ای با جوایز",
    status: 'active',
    metrics: { users: 450, satisfaction: 99, performance: 96 }
  },
  {
    icon: <Crown className="w-6 h-6" />,
    title: "سیستم کلن",
    description: "ایجاد و مدیریت کلن‌ها برای بازیکنان حرفه‌ای",
    status: 'testing',
    metrics: { users: 280, satisfaction: 95, performance: 93 }
  }
];

const platformStats = [
  { label: "کاربر فعال", value: "12,500+", icon: <Users className="w-5 h-5" />, color: "text-blue-400" },
  { label: "لابی‌های برگزار شده", value: "8,900+", icon: <Gamepad2 className="w-5 h-5" />, color: "text-green-400" },
  { label: "دقت تقویم", value: "99.9%", icon: <CalendarIcon className="w-5 h-5" />, color: "text-purple-400" },
  { label: "رضایت کاربران", value: "96.8%", icon: <Heart className="w-5 h-5" />, color: "text-pink-400" }
];

interface FinalShowcaseProps {
  onNavigate: (page: string) => void;
}

export const FinalShowcase: React.FC<FinalShowcaseProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);
  const [showDemo, setShowDemo] = useState(false);

  const handleFeatureClick = (component: string) => {
    setSelectedFeature(component);
    setShowDemo(true);
    toast.info(`نمایش ${component}`);
  };

  const handleTestAllSystems = async () => {
    toast.info("شروع تست تمام سیستم‌ها...");
    
    // Simulate testing all systems
    const systems = ['تقویم جلالی', 'سیستم دعوت', 'اعلان‌ها', 'لابی‌ها'];
    
    for (let i = 0; i < systems.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      toast.success(`✅ ${systems[i]} تست شد`);
    }
    
    toast.success("🎉 تمام سیستم‌ها با موفقیت تست شدند!");
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500 text-white animate-pulse">کامل</Badge>;
      case 'active':
        return <Badge className="bg-blue-500 text-white">فعال</Badge>;
      case 'testing':
        return <Badge className="bg-yellow-500 text-black">تست</Badge>;
      default:
        return <Badge variant="outline">نامشخص</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900" dir="rtl">
      <div className="container mx-auto py-8 px-4">
        
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="relative inline-block mb-6">
            <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 rounded-2xl blur-lg opacity-75 animate-pulse"></div>
            <div className="relative bg-slate-800 p-6 rounded-2xl">
              <Gamepad2 className="w-16 h-16 text-blue-400 mx-auto" />
            </div>
          </div>
          
          <h1 className="text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-green-400 bg-clip-text text-transparent">
              Matchzone
            </span>
          </h1>
          
          <p className="text-xl text-slate-300 mb-6 max-w-3xl mx-auto">
            پلتفرم گیمینگ اجتماعی ایران با سیستم طراحی مدرن، تقویم جلالی و قابلیت‌های پیشرفته
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              onClick={handleTestAllSystems}
            >
              <CheckCircle2 className="w-5 h-5 ml-2" />
              تست تمام سیستم‌ها
            </Button>
            
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => setActiveTab("features")}
            >
              <Eye className="w-5 h-5 ml-2" />
              مشاهده قابلیت‌ها
            </Button>
          </div>
        </motion.div>

        {/* Platform Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
        >
          {platformStats.map((stat, index) => (
            <Card key={index} className="p-4 text-center hover:scale-105 transition-transform">
              <CardContent className="p-0">
                <div className={`${stat.color} mb-2`}>
                  {stat.icon}
                </div>
                <div className="text-2xl font-bold mb-1">{stat.value}</div>
                <p className="text-sm text-text-secondary">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Globe className="w-4 h-4" />
              نمای کلی
            </TabsTrigger>
            <TabsTrigger value="features" className="flex items-center gap-2">
              <Star className="w-4 h-4" />
              قابلیت‌ها
            </TabsTrigger>
            <TabsTrigger value="systems" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              سیستم‌ها
            </TabsTrigger>
            <TabsTrigger value="demo" className="flex items-center gap-2">
              <Play className="w-4 h-4" />
              دمو
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    آخرین بروزرسانی‌ها
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 bg-green-500/10 rounded-lg border border-green-500/20">
                      <CheckCircle2 className="w-5 h-5 text-green-400" />
                      <div>
                        <p className="font-medium">سیستم زمان‌بندی کامل شد</p>
                        <p className="text-sm text-text-secondary">تقویم جلالی + دعوت دوستان + اعلان‌ها</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                      <Gamepad2 className="w-5 h-5 text-blue-400" />
                      <div>
                        <p className="font-medium">سیستم لابی پیشرفته</p>
                        <p className="text-sm text-text-secondary">پشتیبانی multi-platform + game launcher</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-purple-500/10 rounded-lg border border-purple-500/20">
                      <Crown className="w-5 h-5 text-purple-400" />
                      <div>
                        <p className="font-medium">سیستم طراحی RTL</p>
                        <p className="text-sm text-text-secondary">کامل فارسی با theme system مدرن</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-400" />
                    آمار عملکرد
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>سرعت لود صفحات</span>
                        <span className="font-mono">0.8s</span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-2">
                        <div className="bg-green-400 h-2 rounded-full w-[95%]"></div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>رضایت کاربران</span>
                        <span className="font-mono">96.8%</span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-2">
                        <div className="bg-blue-400 h-2 rounded-full w-[97%]"></div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>دقت تقویم جلالی</span>
                        <span className="font-mono">99.9%</span>
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-2">
                        <div className="bg-purple-400 h-2 rounded-full w-[100%]"></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>دسترسی سریع</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button 
                    variant="outline" 
                    className="h-16 flex flex-col gap-2"
                    onClick={() => setActiveTab("systems")}
                  >
                    <CalendarIcon className="w-6 h-6" />
                    تقویم جلالی
                  </Button>
                  <Button 
                    variant="outline" 
                    className="h-16 flex flex-col gap-2"
                    onClick={() => setActiveTab("demo")}
                  >
                    <Users className="w-6 h-6" />
                    سیستم دعوت
                  </Button>
                  <Button 
                    variant="outline" 
                    className="h-16 flex flex-col gap-2"
                    onClick={() => setActiveTab("features")}
                  >
                    <Gamepad2 className="w-6 h-6" />
                    مدیریت لابی
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Features Tab */}
          <TabsContent value="features" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-all duration-300 group cursor-pointer"
                        onClick={() => feature.component && handleFeatureClick(feature.component)}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-slate-700 group-hover:bg-blue-600 transition-colors">
                            {feature.icon}
                          </div>
                          <div>
                            <CardTitle className="text-lg">{feature.title}</CardTitle>
                          </div>
                        </div>
                        {getStatusBadge(feature.status)}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-text-secondary mb-4">{feature.description}</p>
                      
                      {feature.metrics && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>کاربران فعال:</span>
                            <span className="font-mono">{feature.metrics.users}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>رضایت:</span>
                            <span className="font-mono">{feature.metrics.satisfaction}%</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>عملکرد:</span>
                            <span className="font-mono">{feature.metrics.performance}%</span>
                          </div>
                        </div>
                      )}
                      
                      {feature.component && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full mt-4 group-hover:bg-blue-600 group-hover:text-white"
                        >
                          مشاهده جزئیات
                          <ArrowRight className="w-4 h-4 mr-2" />
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Systems Tab */}
          <TabsContent value="systems" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarIcon className="w-5 h-5 text-blue-400" />
                    تقویم جلالی
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="p-8 text-center text-text-secondary">
                    <CalendarIcon className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p>تقویم جلالی حذف شده است</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5 text-yellow-400" />
                    سیستم اعلان‌ها
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <LobbyInviteNotifications
                    onInvitationResponse={(id, response) => 
                      toast.info(`دعوتنامه ${response === 'accept' ? 'پذیرفته' : 'رد'} شد`)
                    }
                    onNotificationRead={(id) => console.log('Notification read:', id)}
                  />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Demo Tab */}
          <TabsContent value="demo" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="w-5 h-5 text-green-400" />
                  دمو تعاملی
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <p className="text-text-secondary mb-6">
                    برای مشاهده دمو کامل صفحات اصلی، از دکمه‌های زیر استفاده کنید
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button 
                      size="lg"
                      onClick={() => window.location.hash = "#lobby-scheduling"}
                      className="h-16 flex flex-col gap-2"
                    >
                      <CalendarIcon className="w-6 h-6" />
                      صفحه زمان‌بندی اصلی
                    </Button>
                    
                    <Button 
                      size="lg"
                      variant="outline"
                      onClick={() => window.location.hash = "#lobbies"}
                      className="h-16 flex flex-col gap-2"
                    >
                      <Gamepad2 className="w-6 h-6" />
                      صفحه لابی‌های پیشرفته
                    </Button>
                    
                    <Button 
                      size="lg"
                      variant="outline"
                      onClick={() => window.location.hash = "#component-test"}
                      className="h-16 flex flex-col gap-2"
                    >
                      <Settings className="w-6 h-6" />
                      صفحه تست کامپوننت‌ها
                    </Button>
                    
                    <Button 
                      size="lg"
                      variant="outline"
                      onClick={() => onNavigate('countdown-timer-demo')}
                      className="h-16 flex flex-col gap-2"
                    >
                      <Timer className="w-6 h-6" />
                      نمایش تایمر لابی
                    </Button>
                    
                    <Button 
                      size="lg"
                      variant="outline"
                      onClick={() => onNavigate('lobby-chat-demo')}
                      className="h-16 flex flex-col gap-2"
                    >
                      <MessageCircle className="w-6 h-6" />
                      نمایش چت لابی
                    </Button>
                    
                    <Button 
                      size="lg"
                      variant="outline"
                      onClick={() => onNavigate('clan-chat-demo')}
                      className="h-16 flex flex-col gap-2"
                    >
                      <Shield className="w-6 h-6" />
                      نمایش چت کلن
                    </Button>
                    
                    <Button 
                      size="lg"
                      className="h-16 flex flex-col gap-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                      onClick={() => onNavigate('social-comparison')}
                    >
                      <Sparkles className="w-6 h-6" />
                      طراحی جدید صفحه اجتماعی
                    </Button>
                    
                    <Button 
                      size="lg"
                      variant="outline"
                      onClick={handleTestAllSystems}
                      className="h-16 flex flex-col gap-2"
                    >
                      <CheckCircle2 className="w-6 h-6" />
                      تست سریع همه
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Feature Demo Modal */}
        <AnimatePresence>
          {showDemo && selectedFeature && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
              onClick={() => setShowDemo(false)}
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="bg-surface-primary rounded-2xl p-6 max-w-2xl w-full max-h-[80vh] overflow-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold">نمایش {selectedFeature}</h3>
                  <Button variant="ghost" size="sm" onClick={() => setShowDemo(false)}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="text-center py-8">
                  <p className="text-text-secondary">
                    کامپوننت {selectedFeature} آماده نمایش است.
                    <br />
                    برای مشاهده کامل از تب‌های بالا استفاده کنید.
                  </p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};