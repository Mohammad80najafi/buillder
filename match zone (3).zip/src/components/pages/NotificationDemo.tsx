import React, { useState } from 'react';
import { NotificationBanner, NotificationContainer, useNotifications } from '../system/NotificationBanner';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { useMobile } from '../ui/use-mobile';

export function NotificationDemo() {
  const [showBanner, setShowBanner] = useState(false);
  const [bannerType, setBannerType] = useState<'info' | 'success' | 'warning' | 'gaming'>('gaming');
  const { notifications, addNotification, removeNotification } = useNotifications();
  const isMobile = useMobile();

  const messages = {
    info: 'اطلاعات جدید در دسترس است',
    success: 'عملیات با موفقیت انجام شد!',
    warning: 'توجه: تنظیمات تغییر کرده است',
    gaming: 'Scrollbar فعال شد! تجربه گیمینگ بهتری داشته باشید ✨'
  };

  const handleShowBanner = (type: typeof bannerType) => {
    setBannerType(type);
    setShowBanner(true);
  };

  const handleShowMultiple = () => {
    addNotification({
      message: 'اعلان اول: سیستم به‌روزرسانی شد',
      type: 'success',
      autoHide: true,
      duration: 6000
    });
    
    setTimeout(() => {
      addNotification({
        message: 'اعلان دوم: ویژگی جدید اضافه شد',
        type: 'gaming',
        autoHide: true,
        duration: 7000
      });
    }, 300);
    
    setTimeout(() => {
      addNotification({
        message: 'اعلان سوم: بررسی تنظیمات را فراموش نکنید',
        type: 'warning',
        autoHide: true,
        duration: 8000
      });
    }, 600);
    
    setTimeout(() => {
      addNotification({
        message: 'اعلان چهارم: پروفایل شما کامل شد',
        type: 'info',
        autoHide: true,
        duration: 9000
      });
    }, 900);
    
    setTimeout(() => {
      addNotification({
        message: 'اعلان پنجم: مسابقه جدید شروع شد! 🎮',
        type: 'gaming',
        autoHide: true,
        duration: 10000
      });
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto pt-20">
        <Card className="p-6 bg-slate-800/50 backdrop-blur-lg border-slate-700">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">
              نمایش سیستم اعلانات
            </h1>
            <p className="text-slate-300">
              {isMobile 
                ? 'برای بستن اعلان، آن را به چپ یا راست بکشید'
                : 'برای بستن اعلان، روی دکمه ضربدر کلیک کنید'
              }
            </p>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
            <Button
              onClick={() => handleShowBanner('gaming')}
              className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
            >
              Gaming
            </Button>
            <Button
              onClick={() => handleShowBanner('success')}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
            >
              Success
            </Button>
            <Button
              onClick={() => handleShowBanner('warning')}
              className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700"
            >
              Warning
            </Button>
            <Button
              onClick={() => handleShowBanner('info')}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              Info
            </Button>
          </div>

          <div className="text-center mb-8 space-x-4 space-x-reverse">
            <Button
              onClick={handleShowMultiple}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
            >
              نمایش چندین اعلان
            </Button>
            {notifications.length > 0 && (
              <Button
                onClick={() => {
                  // Clear all notifications
                  notifications.forEach(n => removeNotification(n.id));
                }}
                variant="outline"
                className="border-red-500/50 text-red-400 hover:bg-red-500/10"
              >
                پاک کردن همه ({notifications.length})
              </Button>
            )}
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-white">ویژگی‌های اسکرولبار جدید:</h2>
            <ul className="list-disc list-inside text-slate-300 space-y-2">
              <li>طراحی گیمینگ با گرادیانت رنگارنگ</li>
              <li>انیمیشن‌های نرم و glow effect</li>
              <li>بهینه‌سازی برای موبایل (باریک‌تر و دارک‌تر)</li>
              <li>پشتیبانی کامل از RTL</li>
              <li>سازگاری با تم روشن و تاریک</li>
              <li>حالت fade برای hover</li>
            </ul>
          </div>

          {/* Demo Content for Scrolling */}
          <div className="mt-8 space-y-4 max-h-64 overflow-y-auto border border-slate-700 rounded-lg p-4 bg-slate-900/30">
            <h3 className="text-lg font-semibold text-white">محتوای تست اسکرولبار</h3>
            {Array.from({ length: 20 }, (_, i) => (
              <div key={i} className="p-3 bg-slate-800/50 rounded-lg">
                <p className="text-slate-200">
                  آیتم {i + 1}: این یک محتوای تست است برای نمایش اسکرولبار جدید. 
                  اسکرولبار با طراحی گیمینگ و انیمیشن‌های زیبا.
                </p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Single Banner */}
      {showBanner && (
        <NotificationBanner
          message={messages[bannerType]}
          type={bannerType}
          onDismiss={() => setShowBanner(false)}
        />
      )}

      {/* Multiple Notifications Container */}
      {notifications.length > 0 && (
        <NotificationContainer
          notifications={notifications}
          onRemove={removeNotification}
        />
      )}
    </div>
  );
}