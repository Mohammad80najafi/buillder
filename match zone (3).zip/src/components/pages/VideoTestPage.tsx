/**
 * Video Test Page - Direct access to VideoDetailPage for testing
 * صفحه تست ویدیو - دسترسی مستقیم به صفحه جزئیات ویدیو برای تست
 */

'use client';

import React from 'react';
import { VideoDetailPage } from './VideoDetailPage';
import { Button } from '../ui/button';
import { ArrowLeft } from 'lucide-react';

interface VideoTestPageProps {
  onBack?: () => void;
}

export function VideoTestPage({ onBack }: VideoTestPageProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Back Button */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-3 md:px-4 py-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="flex items-center gap-2" 
            dir="rtl"
          >
            <ArrowLeft className="h-4 w-4" />
            بازگشت
          </Button>
        </div>
      </div>

      {/* Video Detail Page */}
      <VideoDetailPage videoId="test-video" />
    </div>
  );
}