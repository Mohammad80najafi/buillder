import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, Heart, MessageCircle, Share2, Plus, Upload,
  Eye, TrendingUp, DollarSign, Users, Star, Trophy, Clock,
  ThumbsUp, ThumbsDown, Bookmark, Download, Edit3, Settings,
  Camera, Video, Mic, Grid, List, Filter, Search, Bell,
  ChevronDown, MoreHorizontal, Flag, Volume2, VolumeX,
  Maximize, RotateCcw, Calendar, BarChart3, Target, Zap,
  Crown, Shield, Gift, Sparkles, Award, Medal, Flame,
  ArrowUp, ArrowDown, TrendingDown, ExternalLink, Copy,
  CheckCircle, XCircle, AlertCircle, Info, Gamepad2,
  Monitor, Headphones, MousePointer, Hash, AtSign,
  Globe, MapPin, Link, Instagram, Youtube, Twitch, Discord
} from 'lucide-react';
import { Button } from '../ui/mz-button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { useMobile } from '../ui/use-mobile';

interface CreatorPlatformHomeProps {
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
  onVideoClick?: (videoId: string) => void;
}

interface VideoPost {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  duration: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  uploadDate: string;
  creator: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    verified: boolean;
    followers: number;
  };
  game?: string;
  tags: string[];
  earnings: number;
  monetized: boolean;
  trending: boolean;
}

interface CreatorStats {
  totalViews: number;
  totalEarnings: number;
  subscribers: number;
  totalVideos: number;
  avgViews: number;
  monthlyGrowth: number;
  engagementRate: number;
  topVideo: string;
}

export function CreatorPlatformHome({
  onNavigate,
  onLogout,
  onVideoClick,
}: CreatorPlatformHomeProps) {
  const [selectedTab, setSelectedTab] = useState<'feed' | 'upload' | 'analytics' | 'explore'>('feed');
  const [playingVideoId, setPlayingVideoId] = useState<string | null>(null);
  const [likedVideos, setLikedVideos] = useState<Set<string>>(new Set());
  const [followedCreators, setFollowedCreators] = useState<Set<string>>(new Set());
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const isMobile = useMobile();

  // Mock User Profile
  const currentUser = {
    id: 'user1',
    name: 'KEOXER GAMING',
    username: '@keoxer_pro',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    verified: true,
    followers: 12500,
    following: 89,
    level: 'Creator Pro',
    joinDate: 'عضو از مرداد ۱۴۰۲'
  };

  // Mock Creator Stats
  const creatorStats: CreatorStats = {
    totalViews: 2847650,
    totalEarnings: 45780,
    subscribers: 12500,
    totalVideos: 156,
    avgViews: 18254,
    monthlyGrowth: 23.5,
    engagementRate: 8.7,
    topVideo: 'نحوه Pro شدن در VALORANT'
  };

  // Mock Video Posts
  const videoPosts: VideoPost[] = [
    {
      id: 'video1',
      title: 'راهنمای کامل Aim Training در VALORANT',
      description: 'در این ویدیو تمام تکنیک‌های aim training که باعث شده من از Iron به Radiant برسم رو یاد می‌دم',
      thumbnail: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      videoUrl: '#',
      duration: '15:32',
      views: 45620,
      likes: 3420,
      comments: 186,
      shares: 89,
      uploadDate: '2 روز پیش',
      creator: {
        id: 'creator1',
        name: 'Phoenix Gaming',
        username: '@phoenix_pro',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        verified: true,
        followers: 25600
      },
      game: 'VALORANT',
      tags: ['aim', 'training', 'guide', 'valorant'],
      earnings: 1250,
      monetized: true,
      trending: true
    },
    {
      id: 'video2',
      title: 'بهترین Settings برای CS2 در 2024',
      description: 'تمام تنظیمات که pro playerها استفاده می‌کنن + config فایل رایگان',
      thumbnail: 'https://images.unsplash.com/photo-1617507171089-6cb9aa5add36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHN0cmVhbWluZ3xlbnwxfHx8fDE3NTczMzkxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      videoUrl: '#',
      duration: '12:45',
      views: 32180,
      likes: 2890,
      comments: 124,
      shares: 67,
      uploadDate: '5 روز پیش',
      creator: {
        id: 'creator2',
        name: 'ShadowGamer',
        username: '@shadow_cs2',
        avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        verified: true,
        followers: 18900
      },
      game: 'CS2',
      tags: ['cs2', 'settings', 'config', 'pro'],
      earnings: 890,
      monetized: true,
      trending: false
    },
    {
      id: 'video3',
      title: 'ریکت های جالب بازیکنان به کلیپ‌های من!',
      description: 'تعدادی از کلیپ‌های viral که توی شبکه‌های اجتماعی پخش شده + ریکت بازیکنان مشهور',
      thumbnail: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      videoUrl: '#',
      duration: '8:20',
      views: 67890,
      likes: 5670,
      comments: 334,
      shares: 145,
      uploadDate: '1 هفته پیش',
      creator: {
        id: 'creator3',
        name: 'IronWolf',
        username: '@ironwolf99',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        verified: false,
        followers: 8900
      },
      game: 'Mixed',
      tags: ['reaction', 'viral', 'funny', 'clips'],
      earnings: 2340,
      monetized: true,
      trending: true
    },
    {
      id: 'video4',
      title: 'نحوه بردن در Ranked Solo Queue',
      description: 'استراتژی‌هایی که من با اون‌ها تونستم بدون تیم ثابت Immortal بشم',
      thumbnail: 'https://images.unsplash.com/photo-1617507171089-6cb9aa5add36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHN0cmVhbWluZ3xlbnwxfHx8fDE3NTczMzkxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      videoUrl: '#',
      duration: '18:45',
      views: 28750,
      likes: 2156,
      comments: 89,
      shares: 34,
      uploadDate: '3 روز پیش',
      creator: {
        id: 'creator4',
        name: 'RankUp Gaming',
        username: '@rankup_guide',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        verified: true,
        followers: 15400
      },
      game: 'VALORANT',
      tags: ['ranked', 'solo', 'guide', 'strategy'],
      earnings: 756,
      monetized: true,
      trending: false
    }
  ];

  const handleVideoPlay = (videoId: string) => {
    if (onVideoClick) {
      onVideoClick(videoId);
    } else {
      // Fallback to in-page video play
      setPlayingVideoId(playingVideoId === videoId ? null : videoId);
    }
  };

  const handleLike = (videoId: string) => {
    setLikedVideos(prev => {
      const newSet = new Set(prev);
      if (newSet.has(videoId)) {
        newSet.delete(videoId);
      } else {
        newSet.add(videoId);
      }
      return newSet;
    });
  };

  const handleFollow = (creatorId: string) => {
    setFollowedCreators(prev => {
      const newSet = new Set(prev);
      if (newSet.has(creatorId)) {
        newSet.delete(creatorId);
      } else {
        newSet.add(creatorId);
      }
      return newSet;
    });
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  const formatCurrency = (amount: number): string => {
    return amount.toLocaleString('fa-IR') + ' تومان';
  };

  return (
    <div className="min-h-screen bg-background text-foreground" dir="rtl">
      {/* Header removed for headerless design */}

      {/* Channel Header - Mobile Responsive */}
      <div className="relative">
        {/* Channel Banner - Mobile Responsive Heights */}
        <div 
          className="h-24 sm:h-32 md:h-48 lg:h-56 bg-gradient-to-r from-blue-600 via-purple-600 to-cyan-600 relative overflow-hidden"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <div className="absolute inset-0 bg-black/30" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        </div>

        {/* Channel Info - Mobile First Design */}
        <div className="bg-background border-b border-border">
          <div className="max-w-7xl mx-auto px-3 md:px-4 py-3 md:py-4" dir="rtl">
            {/* Mobile Layout */}
            <div className="block md:hidden">
              {/* Mobile Avatar & Name */}
              <div className="flex items-start gap-3 mb-4">
                <Avatar className="h-16 w-16 border-4 border-background shadow-lg -mt-8">
                  <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
                  <AvatarFallback className="text-lg">{currentUser.name.charAt(0)}</AvatarFallback>
                </Avatar>
                
                <div className="flex-1 pt-2">
                  <div className="flex items-center gap-2 mb-1">
                    <h1 className="text-lg font-bold">{currentUser.name}</h1>
                    {currentUser.verified && (
                      <CheckCircle className="h-4 w-4 text-blue-500" />
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                    <span>@{currentUser.username.replace('@', '')}</span>
                    <span>•</span>
                    <span>{formatNumber(currentUser.followers)} دنبال‌کننده</span>
                  </div>
                  
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    کریتور حرفه‌ای گیمینگ 🎮 | تولید محتوای آموزشی و سرگرمی
                  </p>
                </div>
              </div>

              {/* Mobile Stats */}
              <div className="grid grid-cols-3 gap-2 mb-3">
                <div className="text-center p-2 bg-muted/50 rounded-lg">
                  <div className="font-bold text-sm">{formatNumber(creatorStats.totalViews)}</div>
                  <p className="text-xs text-muted-foreground">بازدید کل</p>
                </div>
                <div className="text-center p-2 bg-muted/50 rounded-lg">
                  <div className="font-bold text-sm text-green-600">{formatCurrency(creatorStats.totalEarnings)}</div>
                  <p className="text-xs text-muted-foreground">درآمد</p>
                </div>
                <div className="text-center p-2 bg-muted/50 rounded-lg">
                  <div className="font-bold text-sm">{creatorStats.engagementRate}%</div>
                  <p className="text-xs text-muted-foreground">تعامل</p>
                </div>
              </div>

              {/* Mobile Action Buttons */}
              <div className="flex gap-2">
                <Button className="bg-red-600 hover:bg-red-700 text-white flex-1 text-sm h-8">
                  <Users className="h-3 w-3 ml-1" />
                  دنبال کردن
                </Button>
                <Button variant="outline" size="sm" className="h-8">
                  <Bell className="h-3 w-3" />
                </Button>
                <Button variant="outline" size="sm" className="h-8" onClick={() => setSelectedTab('upload')}>
                  <Upload className="h-3 w-3" />
                </Button>
              </div>
            </div>

            {/* Desktop Layout */}
            <div className="hidden md:flex gap-4">
              {/* Desktop Avatar & Basic Info */}
              <div className="flex items-start gap-4">
                <Avatar className="h-24 lg:h-32 w-24 lg:w-32 border-4 border-background shadow-lg -mt-12 lg:-mt-16">
                  <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
                  <AvatarFallback className="text-xl lg:text-2xl">{currentUser.name.charAt(0)}</AvatarFallback>
                </Avatar>
                
                <div className="flex-1 pt-2">
                  <div className="flex items-center gap-3 mb-2">
                    <h1 className="text-xl lg:text-3xl font-bold">{currentUser.name}</h1>
                    {currentUser.verified && (
                      <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-blue-500" />
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                    <span className="font-medium">@{currentUser.username.replace('@', '')}</span>
                    <span>•</span>
                    <span>{formatNumber(currentUser.followers)} دنبال‌کننده</span>
                    <span>•</span>
                    <span>{creatorStats.totalVideos} ویدیو</span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground max-w-2xl">
                    کریتور حرفه‌ای گیمینگ 🎮 | تولید محتوای آموزشی و سرگرمی | 
                    تخصص در FPS و Strategy Games | ویدیو جدید هر روز!
                  </p>
                  
                  <div className="flex items-center gap-2 mt-3">
                    <Button className="bg-red-600 hover:bg-red-700 text-white">
                      <Users className="h-4 w-4 ml-2" />
                      دنبال کردن
                    </Button>
                    <Button variant="outline">
                      <Bell className="h-4 w-4 ml-2" />
                      اعلان‌ها
                    </Button>
                    <Button variant="outline" onClick={() => setSelectedTab('upload')}>
                      <Upload className="h-4 w-4 ml-2" />
                      مدیریت
                    </Button>
                  </div>
                </div>
              </div>

              {/* Desktop Stats */}
              <div className="grid grid-cols-3 gap-4 w-80">
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="font-bold text-lg">{formatNumber(creatorStats.totalViews)}</div>
                  <p className="text-xs text-muted-foreground">بازدید کل</p>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="font-bold text-lg text-green-600">{formatCurrency(creatorStats.totalEarnings)}</div>
                  <p className="text-xs text-muted-foreground">درآمد</p>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="font-bold text-lg">{creatorStats.engagementRate}%</div>
                  <p className="text-xs text-muted-foreground">تعامل</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Channel Navigation Tabs - Mobile Responsive */}
      <div className="bg-background border-b border-border">
        <div className="max-w-7xl mx-auto px-3 md:px-4" dir="rtl">
          <div className="flex items-center gap-4 md:gap-8 overflow-x-auto scrollbar-hide">
            {[
              { id: 'feed', label: 'خانه', active: selectedTab === 'feed' },
              { id: 'explore', label: 'ویدیوها', active: selectedTab === 'explore' },
              { id: 'upload', label: 'استودیو', active: selectedTab === 'upload' },
              { id: 'analytics', label: 'آنالیتیکس', active: selectedTab === 'analytics' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`py-2 md:py-3 px-1 md:px-2 whitespace-nowrap border-b-2 transition-colors text-sm md:text-base ${
                  tab.active 
                    ? 'border-foreground text-foreground font-medium' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content - Mobile Responsive */}
      <div className="max-w-7xl mx-auto px-3 md:px-4 py-3 md:py-6 pb-safe">
        {/* Feed Tab */}
        {selectedTab === 'feed' && (
          <div className="space-y-4 md:space-y-6">
            {/* Video Feed - Responsive Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-4">
              {videoPosts.map((video) => (
                <div key={video.id} className="group cursor-pointer" onClick={() => handleVideoPlay(video.id)}>
                  {/* Thumbnail - Mobile Responsive */}
                  <div className="relative aspect-video bg-muted rounded-lg md:rounded-xl overflow-hidden mb-2 md:mb-3">
                    <ImageWithFallback
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    />
                    
                    {/* Duration - Mobile Responsive */}
                    <div className="absolute bottom-1 md:bottom-2 left-1 md:left-2 bg-black/80 text-white text-xs px-1.5 md:px-2 py-0.5 md:py-1 rounded">
                      {video.duration}
                    </div>

                    {/* Trending Indicator - Mobile Responsive */}
                    {video.trending && (
                      <div className="absolute top-1 md:top-2 right-1 md:right-2 bg-red-500 text-white text-xs px-1.5 md:px-2 py-0.5 md:py-1 rounded flex items-center gap-1">
                        <TrendingUp className="h-2.5 w-2.5 md:h-3 md:w-3" />
                        <span className="hidden sm:inline">#ترند</span>
                      </div>
                    )}

                    {/* Hover Play Button - Desktop Only */}
                    <div className="absolute inset-0 bg-black/0 md:group-hover:bg-black/20 transition-colors flex items-center justify-center">
                      <Button 
                        size="lg" 
                        className="opacity-0 md:group-hover:opacity-100 transition-opacity rounded-full"
                        onClick={() => handleVideoPlay(video.id)}
                      >
                        <Play className="h-4 w-4 md:h-6 md:w-6" />
                      </Button>
                    </div>
                  </div>

                  {/* Video Info - Mobile Responsive */}
                  <div className="flex gap-2 md:gap-3">
                    {/* Channel Avatar - Mobile Responsive */}
                    <Avatar className="h-7 w-7 md:h-9 md:w-9 flex-shrink-0">
                      <AvatarImage src={video.creator.avatar} alt={video.creator.name} />
                      <AvatarFallback className="text-xs md:text-sm">{video.creator.name.charAt(0)}</AvatarFallback>
                    </Avatar>

                    {/* Video Details - Mobile Responsive */}
                    <div className="flex-1 min-w-0">
                      {/* Title - Mobile Responsive */}
                      <h3 className="font-medium line-clamp-2 text-xs md:text-sm leading-4 md:leading-5 mb-1 group-hover:text-primary transition-colors">
                        {video.title}
                      </h3>

                      {/* Channel Name - Mobile Responsive */}
                      <div className="flex items-center gap-1 mb-1">
                        <p className="text-xs md:text-sm text-muted-foreground hover:text-foreground cursor-pointer truncate">
                          {video.creator.name}
                        </p>
                        {video.creator.verified && (
                          <CheckCircle className="h-2.5 w-2.5 md:h-3 md:w-3 text-blue-500 flex-shrink-0" />
                        )}
                      </div>

                      {/* Stats - Mobile Responsive */}
                      <div className="flex items-center gap-1 text-xs md:text-sm text-muted-foreground">
                        <span>{formatNumber(video.views)} بازدید</span>
                        <span>•</span>
                        <span className="hidden sm:inline">{video.uploadDate}</span>
                        <span className="sm:hidden">{video.uploadDate.split(' ')[0]}</span>
                        {video.monetized && (
                          <>
                            <span className="hidden md:inline">•</span>
                            <span className="text-green-600 flex items-center gap-0.5 md:gap-1 hidden md:flex">
                              <DollarSign className="h-2.5 w-2.5 md:h-3 md:w-3" />
                              <span className="hidden lg:inline">{formatCurrency(video.earnings)}</span>
                            </span>
                          </>
                        )}
                      </div>

                      {/* Game Tag - Mobile Responsive */}
                      {video.game && (
                        <div className="mt-1 md:mt-2">
                          <Badge variant="secondary" className="text-xs px-1.5 py-0.5">
                            <Gamepad2 className="h-2.5 w-2.5 md:h-3 md:w-3 mr-0.5 md:mr-1" />
                            {video.game}
                          </Badge>
                        </div>
                      )}
                    </div>

                    {/* More Options - Desktop Only */}
                    <Button variant="ghost" size="sm" className="opacity-0 md:group-hover:opacity-100 transition-opacity h-6 w-6 md:h-8 md:w-8 p-0 flex-shrink-0 hidden md:flex">
                      <MoreHorizontal className="h-3 w-3 md:h-4 md:w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Upload Tab - Mobile Responsive Studio */}
        {selectedTab === 'upload' && (
          <div className="max-w-6xl mx-auto space-y-4 md:space-y-6">
            {/* Studio Header - Mobile Responsive */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl md:text-2xl font-semibold">استودیو کریتور</h2>
                <p className="text-sm md:text-base text-muted-foreground">مدیریت کامل محتوای شما</p>
              </div>
              
              {/* Quick Stats - Mobile Responsive */}
              <div className="grid grid-cols-3 md:flex md:items-center gap-3 md:gap-6">
                <div className="text-center">
                  <div className="text-sm md:text-lg font-semibold">{formatNumber(creatorStats.totalViews)}</div>
                  <p className="text-xs text-muted-foreground">بازدید کل</p>
                </div>
                <div className="text-center">
                  <div className="text-sm md:text-lg font-semibold text-green-600">{formatCurrency(creatorStats.totalEarnings)}</div>
                  <p className="text-xs text-muted-foreground">درآمد کل</p>
                </div>
                <div className="text-center">
                  <div className="text-sm md:text-lg font-semibold">{formatNumber(creatorStats.subscribers)}</div>
                  <p className="text-xs text-muted-foreground">دنبال‌کننده</p>
                </div>
              </div>
            </div>

            {/* Upload Form - Mobile Responsive */}
            <Card>
              <CardContent className="p-3 md:p-6 space-y-4 md:space-y-6">
                {/* Video Upload Area - Mobile Responsive */}
                <div className="border-2 border-dashed border-border rounded-lg p-4 md:p-8 text-center">
                  <Upload className="h-8 w-8 md:h-12 md:w-12 text-muted-foreground mx-auto mb-2 md:mb-4" />
                  <h3 className="font-semibold mb-1 md:mb-2 text-sm md:text-base">ویدیو خود را اینجا بکشید یا کلیک کنید</h3>
                  <p className="text-muted-foreground mb-3 md:mb-4 text-xs md:text-sm">فرمت‌های پشتیبانی شده: MP4, MOV, AVI (حداکثر 2GB)</p>
                  <Button variant="outline" size="sm" className="text-sm">
                    <Video className="h-3 w-3 md:h-4 md:w-4 ml-1 md:ml-2" />
                    انتخاب فایل
                  </Button>
                </div>

                {/* Video Details - Mobile Responsive */}
                <div className="space-y-3 md:space-y-4">
                  <div>
                    <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">عنوان ویدیو *</label>
                    <Input placeholder="عنوان جذاب برای ویدیو خود بنویسید..." className="text-sm" />
                  </div>

                  <div>
                    <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">توضیحات</label>
                    <Textarea 
                      placeholder="توضیح کاملی از ویدیو خود بنویسید..." 
                      rows={3}
                      className="text-sm"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                    <div>
                      <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">بازی</label>
                      <Input placeholder="نام بازی (مثل VALORANT)" className="text-sm" />
                    </div>

                    <div>
                      <label className="block text-xs md:text-sm font-medium mb-1 md:mb-2">تگ‌ها</label>
                      <Input placeholder="تگ‌ها را با کاما جدا کنید" className="text-sm" />
                    </div>
                  </div>

                  {/* Monetization Settings - Mobile Responsive */}
                  <Card className="border-green-200 bg-green-50/50">
                    <CardHeader className="p-3 md:p-6">
                      <CardTitle className="flex items-center gap-2 text-green-700 text-sm md:text-base">
                        <DollarSign className="h-4 w-4 md:h-5 md:w-5" />
                        تنظیمات درآمدزایی
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 md:p-6 pt-0 space-y-3 md:space-y-4">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                        <div>
                          <h4 className="font-medium text-sm md:text-base">فعال‌سازی درآمدزایی</h4>
                          <p className="text-xs md:text-sm text-muted-foreground">از ویدیو خود درآمد کسب کنید</p>
                        </div>
                        <Button variant="outline" size="sm" className="w-full md:w-auto">
                          فعال کردن
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4 text-center">
                        <div className="p-2 md:p-3 bg-white rounded-lg border">
                          <Eye className="h-4 w-4 md:h-6 md:w-6 text-blue-500 mx-auto mb-1 md:mb-2" />
                          <div className="font-semibold text-sm md:text-base">10 تومان</div>
                          <p className="text-xs text-muted-foreground">هر 1000 بازدید</p>
                        </div>
                        <div className="p-2 md:p-3 bg-white rounded-lg border">
                          <ThumbsUp className="h-4 w-4 md:h-6 md:w-6 text-green-500 mx-auto mb-1 md:mb-2" />
                          <div className="font-semibold text-sm md:text-base">5 تومان</div>
                          <p className="text-xs text-muted-foreground">هر لایک</p>
                        </div>
                        <div className="p-2 md:p-3 bg-white rounded-lg border">
                          <Share2 className="h-4 w-4 md:h-6 md:w-6 text-purple-500 mx-auto mb-1 md:mb-2" />
                          <div className="font-semibold text-sm md:text-base">20 تومان</div>
                          <p className="text-xs text-muted-foreground">هر اشتراک</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Upload Button - Mobile Responsive */}
                <div className="flex flex-col md:flex-row justify-end gap-2 md:gap-3">
                  <Button variant="outline" size="sm" className="w-full md:w-auto order-2 md:order-1">
                    ذخیره پیش‌نویس
                  </Button>
                  <Button size="sm" className="w-full md:w-auto order-1 md:order-2">
                    <Upload className="h-3 w-3 md:h-4 md:w-4 ml-1 md:ml-2" />
                    انتشار ویدیو
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Analytics Tab - Mobile Responsive */}
        {selectedTab === 'analytics' && (
          <div className="space-y-4 md:space-y-6">
            <div>
              <h2 className="text-xl md:text-2xl font-semibold mb-1 md:mb-2">آنالیتیکس و درآمد</h2>
              <p className="text-sm md:text-base text-muted-foreground">آمار کامل و تفصیلی کانال شما</p>
            </div>

            {/* Main Stats - Mobile Responsive */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
              <Card>
                <CardContent className="p-3 md:p-6">
                  <div className="flex items-center justify-between mb-2 md:mb-4">
                    <div>
                      <p className="text-xs md:text-sm text-muted-foreground">کل درآمد</p>
                      <div className="text-lg md:text-2xl font-bold text-green-600">
                        {formatCurrency(creatorStats.totalEarnings)}
                      </div>
                    </div>
                    <DollarSign className="h-6 w-6 md:h-8 md:w-8 text-green-500" />
                  </div>
                  <div className="flex items-center gap-1 text-xs md:text-sm">
                    <ArrowUp className="h-3 w-3 md:h-4 md:w-4 text-green-500" />
                    <span className="text-green-600">+23.5%</span>
                    <span className="text-muted-foreground hidden sm:inline">از ماه گذشته</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-3 md:p-6">
                  <div className="flex items-center justify-between mb-2 md:mb-4">
                    <div>
                      <p className="text-xs md:text-sm text-muted-foreground">کل بازدید</p>
                      <div className="text-lg md:text-2xl font-bold">
                        {formatNumber(creatorStats.totalViews)}
                      </div>
                    </div>
                    <Eye className="h-6 w-6 md:h-8 md:w-8 text-blue-500" />
                  </div>
                  <div className="flex items-center gap-1 text-xs md:text-sm">
                    <ArrowUp className="h-3 w-3 md:h-4 md:w-4 text-green-500" />
                    <span className="text-green-600">+18.2%</span>
                    <span className="text-muted-foreground hidden sm:inline">از ماه گذشته</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-3 md:p-6">
                  <div className="flex items-center justify-between mb-2 md:mb-4">
                    <div>
                      <p className="text-xs md:text-sm text-muted-foreground">دنبال‌کننده</p>
                      <div className="text-lg md:text-2xl font-bold">
                        {formatNumber(creatorStats.subscribers)}
                      </div>
                    </div>
                    <Users className="h-6 w-6 md:h-8 md:w-8 text-purple-500" />
                  </div>
                  <div className="flex items-center gap-1 text-xs md:text-sm">
                    <ArrowUp className="h-3 w-3 md:h-4 md:w-4 text-green-500" />
                    <span className="text-green-600">+892</span>
                    <span className="text-muted-foreground hidden sm:inline">این ماه</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-3 md:p-6">
                  <div className="flex items-center justify-between mb-2 md:mb-4">
                    <div>
                      <p className="text-xs md:text-sm text-muted-foreground">نرخ تعامل</p>
                      <div className="text-lg md:text-2xl font-bold">
                        {creatorStats.engagementRate}%
                      </div>
                    </div>
                    <Heart className="h-6 w-6 md:h-8 md:w-8 text-red-500" />
                  </div>
                  <div className="flex items-center gap-1 text-xs md:text-sm">
                    <ArrowUp className="h-3 w-3 md:h-4 md:w-4 text-green-500" />
                    <span className="text-green-600">+2.1%</span>
                    <span className="text-muted-foreground hidden sm:inline">از ماه گذشته</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Revenue Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  تفکیک درآمد ماهانه
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Eye className="h-5 w-5 text-blue-500" />
                      <span>درآمد از بازدید</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{formatCurrency(28450)}</div>
                      <div className="text-sm text-muted-foreground">62% از کل درآمد</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Heart className="h-5 w-5 text-red-500" />
                      <span>درآمد از لایک</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{formatCurrency(12680)}</div>
                      <div className="text-sm text-muted-foreground">28% از کل درآمد</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Share2 className="h-5 w-5 text-purple-500" />
                      <span>درآمد از اشتراک</span>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{formatCurrency(4650)}</div>
                      <div className="text-sm text-muted-foreground">10% از کل درآمد</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Top Performing Videos */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5" />
                  ویدیوهای پربازدید
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {videoPosts.slice(0, 3).map((video, index) => (
                    <div key={video.id} className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center justify-center w-8 h-8 bg-primary text-primary-foreground rounded-full font-semibold">
                        {index + 1}
                      </div>
                      
                      <img 
                        src={video.thumbnail} 
                        alt={video.title}
                        className="w-16 h-12 object-cover rounded"
                      />
                      
                      <div className="flex-1">
                        <h4 className="font-medium line-clamp-1">{video.title}</h4>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{formatNumber(video.views)} بازدید</span>
                          <span>{formatCurrency(video.earnings)} درآمد</span>
                        </div>
                      </div>
                      
                      <Badge variant={index === 0 ? 'default' : 'secondary'}>
                        {index === 0 ? 'برترین' : `#${index + 1}`}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Explore Tab - Mobile Responsive */}
        {selectedTab === 'explore' && (
          <div className="space-y-4 md:space-y-6">
            <div>
              <h2 className="text-xl md:text-2xl font-semibold mb-1 md:mb-2">اکتشاف محتوا</h2>
              <p className="text-sm md:text-base text-muted-foreground">ویدیوهای ترند و کریتورهای برتر را کشف کنید</p>
            </div>

            {/* Trending Categories - Mobile Responsive */}
            <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
              {['همه', 'VALORANT', 'CS2', 'LOL', 'Fortnite', 'Apex', 'COD', 'FIFA'].map((category) => (
                <Button
                  key={category}
                  variant={category === 'همه' ? 'default' : 'outline'}
                  size="sm"
                  className="whitespace-nowrap text-xs md:text-sm px-2 md:px-3 py-1 md:py-2"
                >
                  {category}
                </Button>
              ))}
            </div>

            {/* Trending Videos - Mobile Responsive */}
            <div>
              <h3 className="text-base md:text-lg font-semibold mb-3 md:mb-4 flex items-center gap-2">
                <TrendingUp className="h-4 w-4 md:h-5 md:w-5 text-red-500" />
                ویدیوهای ترند
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6">
                {videoPosts.map((video) => (
                  <Card key={video.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative aspect-video bg-muted">
                      <ImageWithFallback
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-full object-cover"
                      />
                      
                      <div className="absolute inset-0 bg-black/20 opacity-0 hover:opacity-100 transition-opacity cursor-pointer flex items-center justify-center">
                        <Button size="lg" className="rounded-full">
                          <Play className="h-6 w-6 mr-1" />
                        </Button>
                      </div>

                      <Badge className="absolute bottom-2 left-2 bg-black/80 text-white">
                        {video.duration}
                      </Badge>

                      <Badge className="absolute top-2 right-2 bg-red-500/90 text-white">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        #{Math.floor(Math.random() * 10) + 1}
                      </Badge>
                    </div>

                    <CardContent className="p-4">
                      <div className="flex items-start gap-3 mb-3">
                        <Avatar className="h-8 w-8 flex-shrink-0">
                          <AvatarImage src={video.creator.avatar} alt={video.creator.name} />
                          <AvatarFallback>{video.creator.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0 flex-1">
                          <h3 className="font-medium line-clamp-2 text-sm leading-5 mb-1 hover:text-primary transition-colors cursor-pointer">
                            {video.title}
                          </h3>
                          <p className="text-sm text-muted-foreground">{video.creator.name}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                            <span>{formatNumber(video.views)} بازدید</span>
                            <span>•</span>
                            <span>{video.uploadDate}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default CreatorPlatformHome;