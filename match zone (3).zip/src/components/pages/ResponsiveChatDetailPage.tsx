/**
 * Responsive Chat Detail Page
 * صفحه جزییات چت کاملاً responsive بدون آیکن‌های تماس
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Smile, 
  Paperclip, 
  Mic, 
  MicOff, 
  ArrowLeft,
  MoreVertical,
  Volume2,
  VolumeX,
  Crown,
  Shield,
  Star,
  Zap,
  Info,
  Users,
  Search,
  Settings
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { useMobile } from '../ui/use-mobile';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  isOwn: boolean;
  type: 'text' | 'gift' | 'system';
  role: 'player' | 'admin' | 'vip' | 'moderator';
  reactions?: { emoji: string; count: number; users: string[] }[];
  giftsData?: {
    type: string;
    value: number;
    from: string;
  };
}

interface ChatRoom {
  id: string;
  name: string;
  description?: string;
  memberCount: number;
  onlineCount: number;
  avatar?: string;
  status: 'online' | 'away' | 'busy';
  type: 'public' | 'private' | 'lobby' | 'tournament';
}

export function ResponsiveChatDetailPage() {
  const isMobile = useMobile();
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showChatInfo, setShowChatInfo] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const emojiReactions = ['❤️', '👍', '😂', '😮', '😢', '😡', '🔥', '⚡', '🎯', '💎'];

  // Mock data
  const currentRoom: ChatRoom = {
    id: 'general',
    name: 'چت عمومی MatchZone',
    description: 'مکان گپ و گفت‌وگوی عمومی بازیکنان',
    memberCount: 1847,
    onlineCount: 156,
    status: 'online',
    type: 'public'
  };

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      username: 'Captain Phoenix',
      message: 'سلام به همه! آماده برای بازی امشب؟ 🎮',
      timestamp: new Date(Date.now() - 300000),
      isOwn: false,
      type: 'text',
      role: 'admin',
      reactions: [
        { emoji: '🔥', count: 5, users: ['user1', 'user2'] },
        { emoji: '👍', count: 3, users: ['user3'] }
      ]
    },
    {
      id: '2',
      username: 'Sarah Pro Gamer',
      message: 'بله! چه بازی‌ای رو پیشنهاد می‌دی؟ من CS:GO و Valorant بازی می‌کنم',
      timestamp: new Date(Date.now() - 240000),
      isOwn: false,
      type: 'text',
      role: 'vip'
    },
    {
      id: '3',
      username: 'شما',
      message: 'من آماده‌ام، بزن بریم! 💪 Valorant عالیه',
      timestamp: new Date(Date.now() - 180000),
      isOwn: true,
      type: 'text',
      role: 'player'
    },
    {
      id: '4',
      username: 'Ali Champion',
      message: '',
      timestamp: new Date(Date.now() - 120000),
      isOwn: false,
      type: 'gift',
      role: 'player',
      giftsData: {
        type: 'جایزه طلایی',
        value: 100,
        from: 'Ali Champion'
      }
    },
    {
      id: '5',
      username: 'Team Leader',
      message: 'بچه‌ها واقعاً عالی بازی کردین! کسی می‌خواد برای تورنومنت فردا تمرین کنیم؟ 🏆',
      timestamp: new Date(Date.now() - 60000),
      isOwn: false,
      type: 'text',
      role: 'moderator'
    },
    {
      id: '6',
      username: 'شما',
      message: 'ممنون! تیم‌ورک فوق‌العاده بود. حتماً می‌آم تمرین',
      timestamp: new Date(Date.now() - 30000),
      isOwn: true,
      type: 'text',
      role: 'player'
    },
    {
      id: '7',
      username: 'Pro Player 2024',
      message: 'کسی می‌خواد امشب ساعت ۹ لابی بزنیم؟ رنک‌های بالا فقط',
      timestamp: new Date(Date.now() - 15000),
      isOwn: false,
      type: 'text',
      role: 'player'
    }
  ]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      username: 'شما',
      message: message.trim(),
      timestamp: new Date(),
      isOwn: true,
      type: 'text',
      role: 'player'
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const existingReaction = msg.reactions?.find(r => r.emoji === emoji);
        if (existingReaction) {
          return {
            ...msg,
            reactions: msg.reactions?.map(r => 
              r.emoji === emoji 
                ? { ...r, count: r.count + 1 }
                : r
            )
          };
        } else {
          return {
            ...msg,
            reactions: [
              ...(msg.reactions || []),
              { emoji, count: 1, users: ['current-user'] }
            ]
          };
        }
      }
      return msg;
    }));
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="h-3 w-3 text-yellow-400" />;
      case 'moderator': return <Shield className="h-3 w-3 text-blue-400" />;
      case 'vip': return <Star className="h-3 w-3 text-purple-400" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getRoomTypeColor = (type: string) => {
    switch (type) {
      case 'public': return 'bg-green-500/20 text-green-400';
      case 'private': return 'bg-purple-500/20 text-purple-400';
      case 'lobby': return 'bg-blue-500/20 text-blue-400';
      case 'tournament': return 'bg-yellow-500/20 text-yellow-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const MessageComponent = ({ message: msg }: { message: ChatMessage }) => (
    <div className={`group mb-3 ${msg.isOwn ? 'text-left' : 'text-right'}`} dir={msg.isOwn ? 'ltr' : 'rtl'}>
      <div className={`flex items-start gap-2 ${msg.isOwn ? 'flex-row' : 'flex-row-reverse'}`}>
        {!msg.isOwn && (
          <Avatar className={`${isMobile ? 'h-7 w-7' : 'h-8 w-8'} flex-shrink-0`}>
            <AvatarFallback className="text-xs">{msg.username[0]}</AvatarFallback>
          </Avatar>
        )}
        
        <div className={`flex-1 min-w-0 ${msg.isOwn ? 'text-left' : 'text-right'}`}>
          {!msg.isOwn && (
            <div className="flex items-center gap-1 mb-1">
              {getRoleIcon(msg.role)}
              <span className={`${isMobile ? 'text-xs' : 'text-sm'} font-medium`}>{msg.username}</span>
              <span className="text-xs text-muted-foreground">
                {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          )}
          
          <div className={`${isMobile ? 'max-w-[280px]' : 'max-w-[400px]'} ${msg.isOwn ? 'mr-auto' : 'ml-auto'}`}>
            {msg.type === 'system' ? (
              <div className="bg-muted/50 text-center p-2 rounded-lg text-xs text-muted-foreground">
                {msg.message}
              </div>
            ) : msg.type === 'gift' ? (
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 p-3 rounded-lg text-sm border border-yellow-500/30">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-yellow-400" />
                  <span>
                    {msg.giftsData?.from} یک {msg.giftsData?.type} به ارزش {msg.giftsData?.value} سکه فرستاد!
                  </span>
                </div>
              </div>
            ) : (
              <div className={`p-3 rounded-lg ${isMobile ? 'text-sm' : 'text-base'} ${
                msg.isOwn 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted'
              }`}>
                {msg.message}
                {msg.isOwn && (
                  <div className="text-xs opacity-70 mt-1">
                    {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                )}
              </div>
            )}
            
            {/* Message Reactions */}
            {msg.reactions && msg.reactions.length > 0 && (
              <div className="flex gap-1 mt-2">
                {msg.reactions.map((reaction, idx) => (
                  <Button
                    key={idx}
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-xs hover:bg-muted"
                    onClick={() => handleReaction(msg.id, reaction.emoji)}
                  >
                    {reaction.emoji} {reaction.count}
                  </Button>
                ))}
              </div>
            )}
            
            {/* Quick Reactions */}
            <div className="hidden group-hover:flex gap-1 mt-2">
              {emojiReactions.slice(0, isMobile ? 3 : 5).map((emoji) => (
                <Button
                  key={emoji}
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 hover:bg-muted"
                  onClick={() => handleReaction(msg.id, emoji)}
                >
                  {emoji}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      {/* Header - Responsive */}
      <div className="flex-shrink-0 border-b bg-card/95 backdrop-blur-sm">
        <div className={`flex items-center justify-between ${isMobile ? 'p-3' : 'p-4'}`}>
          {/* Left Side */}
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="p-1">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            
            <div className="flex items-center gap-3">
              <div className="relative">
                <Avatar className={isMobile ? 'h-9 w-9' : 'h-11 w-11'}>
                  <AvatarFallback>{currentRoom.name[0]}</AvatarFallback>
                </Avatar>
                <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-background ${getStatusColor(currentRoom.status)}`} />
              </div>
              
              <div className="text-right min-w-0" dir="rtl">
                <div className="flex items-center gap-2">
                  <h2 className={`font-medium truncate ${isMobile ? 'text-sm max-w-[120px]' : 'text-base max-w-[200px]'}`}>
                    {currentRoom.name}
                  </h2>
                  <Badge 
                    variant="secondary" 
                    className={`${getRoomTypeColor(currentRoom.type)} text-xs px-1.5 py-0.5`}
                  >
                    {currentRoom.type === 'public' ? 'عمومی' : 
                     currentRoom.type === 'private' ? 'خصوصی' : 
                     currentRoom.type === 'lobby' ? 'لابی' : 'تورنومنت'}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    {currentRoom.onlineCount.toLocaleString('fa-IR')} آنلاین
                  </span>
                  {!isMobile && (
                    <span>از {currentRoom.memberCount.toLocaleString('fa-IR')} عضو</span>
                  )}
                </div>
              </div>
            </div>
          </div>
          
          {/* Right Side */}
          <div className="flex items-center gap-1">
            {!isMobile && (
              <Button variant="ghost" size="sm" className="p-2">
                <Search className="h-4 w-4" />
              </Button>
            )}
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-2"
              onClick={() => setIsMuted(!isMuted)}
            >
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-2"
              onClick={() => setShowChatInfo(!showChatInfo)}
            >
              <Info className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="p-2">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages Area - Only This Scrolls */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto">
          <div className={`space-y-1 ${isMobile ? 'p-3' : 'p-4'}`}>
            {/* Chat Info Banner */}
            {showChatInfo && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-muted/50 rounded-lg p-3 mb-4 text-center"
              >
                <div className="text-sm font-medium mb-1">{currentRoom.name}</div>
                <div className="text-xs text-muted-foreground">
                  {currentRoom.description}
                </div>
                <div className="flex items-center justify-center gap-4 mt-2 text-xs">
                  <span className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    {currentRoom.memberCount.toLocaleString('fa-IR')} عضو
                  </span>
                  <span className="flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    {currentRoom.onlineCount.toLocaleString('fa-IR')} آنلاین
                  </span>
                </div>
              </motion.div>
            )}

            {messages.map((msg) => (
              <MessageComponent key={msg.id} message={msg} />
            ))}
            {isTyping && (
              <div className="text-muted-foreground text-xs text-right px-2" dir="rtl">
                <div className="flex items-center justify-end gap-2">
                  <span>کاربری در حال تایپ</span>
                  <div className="flex gap-0.5">
                    <div className="w-1 h-1 bg-current rounded-full animate-pulse" />
                    <div className="w-1 h-1 bg-current rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                    <div className="w-1 h-1 bg-current rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>
      </div>

      {/* Input Area - Fixed */}
      <div className="flex-shrink-0 border-t bg-card/95 backdrop-blur-sm">
        <div className={isMobile ? 'p-3' : 'p-4'}>
          <div className="flex items-center gap-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="پیام خود را بنویسید..."
              className={`flex-1 min-w-0 ${isMobile ? 'h-9' : 'h-10'}`}
              dir="rtl"
            />
            
            <Button variant="ghost" size="sm" className={`${isMobile ? 'p-1.5' : 'p-2'} flex-shrink-0`}>
              <Paperclip className="h-4 w-4" />
            </Button>
            
            <Button variant="ghost" size="sm" className={`${isMobile ? 'p-1.5' : 'p-2'} flex-shrink-0`}>
              <Smile className="h-4 w-4" />
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm"
              className={`${isMobile ? 'p-1.5' : 'p-2'} flex-shrink-0 ${isRecording ? 'text-red-500' : ''}`}
              onClick={() => setIsRecording(!isRecording)}
            >
              {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
            
            <Button 
              onClick={handleSendMessage}
              disabled={!message.trim()}
              size="sm"
              className={`${isMobile ? 'p-1.5' : 'p-2'} flex-shrink-0`}
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}