import React, { useState } from 'react';
import { 
  Search, Bell, Trophy, Users, Star, Radio, Play, 
  TrendingUp, Calendar, Zap, ChevronLeft
} from 'lucide-react';
import { Button } from '../ui/mz-button';
import { Input } from '../ui/mz-input';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { StoriesSection } from '../discovery/StoriesSection';

export function MobileHomePage() {
  const [searchQuery, setSearchQuery] = useState('');

  // Mock data
  const quickStats = [
    { value: '8.1K', label: 'مشاهده آنلاین', trend: '+12%' },
    { value: '1.4K', label: 'بازی جدید', trend: '+8%' },
    { value: '23', label: 'پخش زنده', trend: '+15%' },
    { value: '5', label: 'اجتماعی', trend: '+3%' }
  ];

  const mainStats = [
    { 
      icon: Radio, 
      value: '42', 
      label: 'لابی فعال',
      color: 'text-state-danger'
    },
    { 
      icon: Trophy, 
      value: '8', 
      label: 'مسابقه',
      color: 'text-brand-accent'
    },
    { 
      icon: Star, 
      value: '156', 
      label: 'کریتور',  
      color: 'text-brand-accent'
    },
    { 
      icon: Users, 
      value: '23', 
      label: 'دوست',
      color: 'text-brand-secondary'
    }
  ];

  return (
    <div className="w-full max-w-full overflow-x-hidden min-h-screen bg-bg-primary" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-bg-primary/95 backdrop-blur-sm border-b border-border-primary">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-brand-primary rounded-lg flex items-center justify-center">
              <span className="text-white text-sm font-bold">M</span>
            </div>
            <div>
              <h1 className="text-base font-semibold text-text-primary">کشف محتوا</h1>
              <p className="text-xs text-text-secondary">لابی‌ها و مسابقات</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <Search className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="pb-20 space-y-4">
        {/* Stories Section */}
        <div className="px-0">
          <StoriesSection 
            title="کشف محتوا"
            subtitle="بهترین لایو‌ها، مسابقات و بخش‌های زنده"
          />
        </div>

        {/* Quick Stats Grid */}
        <div className="px-4">
          <div className="grid grid-cols-2 gap-3">
            {quickStats.map((stat, index) => (
              <Card key={index} className="border-border-secondary">
                <CardContent className="p-3 text-center">
                  <div className="text-lg font-bold text-text-primary mb-1">
                    {stat.value}
                  </div>
                  <div className="text-xs text-text-secondary mb-1">
                    {stat.label}
                  </div>
                  <div className="text-xs text-state-success">
                    {stat.trend}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Search Bar */}
        <div className="px-4">
          <Input
            placeholder="جستجو..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            leftIcon={<Search className="h-4 w-4" />}
            className="bg-surface-secondary border-border-secondary"
          />
        </div>

        {/* Featured Tournament */}
        <div className="px-4">
          <Card className="bg-gradient-to-r from-brand-primary/20 to-brand-secondary/20 border-brand-primary/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Trophy className="h-4 w-4 text-brand-accent" />
                    <Badge className="bg-brand-accent text-black text-xs">ویژه</Badge>
                  </div>
                  <h3 className="font-bold text-base text-text-primary mb-1">
                    جام بزرگ Matchzone
                  </h3>
                  <p className="text-sm text-text-secondary">
                    تورنای آخرین ۵۰۰
                  </p>
                </div>
                <Button 
                  size="sm" 
                  className="bg-brand-primary hover:bg-brand-primary/90 text-white"
                >
                  جزئیات
                  <ChevronLeft className="h-3 w-3 mr-1" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Stats Grid */}
        <div className="px-4">
          <div className="grid grid-cols-2 gap-3">
            {mainStats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <Card key={index} className="border-border-secondary hover:bg-surface-secondary/50 transition-colors cursor-pointer">
                  <CardContent className="p-4 text-center">
                    <Icon className={`h-6 w-6 mx-auto mb-2 ${stat.color}`} />
                    <div className="text-xl font-bold text-text-primary mb-1">
                      {stat.value}
                    </div>
                    <div className="text-xs text-text-secondary">
                      {stat.label}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="px-4">
          <div className="grid grid-cols-2 gap-3">
            <Button 
              variant="outline" 
              className="h-12 flex flex-col items-center justify-center border-border-secondary"
            >
              <TrendingUp className="h-4 w-4 mb-1" />
              <span className="text-xs">مسابقات ترند</span>
            </Button>
            <Button 
              className="h-12 flex flex-col items-center justify-center bg-brand-primary hover:bg-brand-primary/90"
            >
              <Play className="h-4 w-4 mb-1" />
              <span className="text-xs">پیشنهاد سریع</span>
            </Button>
          </div>
        </div>

        {/* Recent Activity - Compact */}
        <div className="px-4">
          <Card className="border-border-secondary">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-sm text-text-primary">فعالیت اخیر</h4>
                <Button variant="ghost" size="sm" className="text-xs">
                  مشاهده همه
                </Button>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-state-success rounded-full animate-pulse" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-text-primary truncate">
                      لابی CS2 جدید ایجاد شد
                    </p>
                    <p className="text-xs text-text-secondary">۲ دقیقه پیش</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-brand-accent rounded-full" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-text-primary truncate">
                      مسابقه Valorant شروع شد
                    </p>
                    <p className="text-xs text-text-secondary">۵ دقیقه پیش</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-brand-secondary rounded-full" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-text-primary truncate">
                      ۳ دوست آنلاین شدند
                    </p>
                    <p className="text-xs text-text-secondary">۱۰ دقیقه پیش</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Extra Padding for Bottom Navigation */}
        <div className="h-4"></div>
      </div>
    </div>
  );
}