import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Edit, Camera, Shield, Trophy, Users, Gamepad2, Settings, Crown, Star } from 'lucide-react';
import { useMobile } from '../ui/use-mobile';
import { UserLevelSelector } from '../profile/UserLevelSelector';

export function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: 'علی محمدی',
    username: '@ali_gamer_pro',
    bio: 'گیمر حرفه‌ای با بیش از ۵ سال تجربه در بازی‌های رقابتی. علاقه‌مند به کالاف دیوتی و والورانت.',
    avatar: '/avatars/user.jpg',
    cover: '/covers/gaming.jpg',
    email: 'ali@example.com',
    phone: '09123456789',
    location: 'تهران، ایران',
    website: 'https://aligamer.ir'
  });
  
  const [preferences, setPreferences] = useState({
    publicProfile: true,
    showEmail: false,
    showPhone: false,
    allowMessages: true,
    allowFriendRequests: true,
    showOnlineStatus: true,
    showCurrentGame: true
  });

  const [gamePreferences, setGamePreferences] = useState([
    'کالاف دیوتی',
    'والورانت',
    'فیفا ۲۴'
  ]);

  const isMobile = useMobile();

  const stats = {
    totalMatches: 247,
    wins: 156,
    winRate: 63,
    tournaments: 8,
    achievements: 12,
    friends: 89,
    following: 45,
    followers: 123
  };

  const achievements = [
    { 
      id: 1, 
      title: 'قهرمان ماه', 
      description: 'برنده ۱۰ مسابقه پیاپی', 
      icon: Trophy, 
      date: '۱۴۰۳/۰۸/۱۰',
      rarity: 'rare'
    },
    { 
      id: 2, 
      title: 'استاد والورانت', 
      description: 'رسیدن به رنک الماسی', 
      icon: Crown, 
      date: '۱۴۰۳/۰۷/۲۵',
      rarity: 'legendary'
    },
    { 
      id: 3, 
      title: 'دوست‌یاب', 
      description: '۱۰۰ دوست در گیم‌هاب', 
      icon: Users, 
      date: '۱۴۰۳/۰۷/۱۵',
      rarity: 'common'
    },
    { 
      id: 4, 
      title: 'ستاره درخشان', 
      description: '۵ ستاره از کاربران', 
      icon: Star, 
      date: '۱۴۰۳/۰۷/۰۵',
      rarity: 'rare'
    }
  ];

  const recentMatches = [
    { 
      game: 'کالاف دیوتی', 
      result: 'برد', 
      score: '25-18', 
      date: '۲ ساعت پیش',
      mode: 'رنک',
      kd: 1.8
    },
    { 
      game: 'والورانت', 
      result: 'باخت', 
      score: '11-13', 
      date: '۱ روز پیش',
      mode: 'کامپتیتیو',
      kd: 1.2
    },
    { 
      game: 'فیفا ۲۴', 
      result: 'برد', 
      score: '3-1', 
      date: '۲ روز پیش',
      mode: 'آنلاین',
      kd: null
    }
  ];

  const handleSaveProfile = () => {
    console.log('Saving profile:', profileData);
    setIsEditing(false);
  };

  const handleInputChange = (field: string, value: string) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  const handlePreferenceChange = (field: string, value: boolean) => {
    setPreferences(prev => ({ ...prev, [field]: value }));
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-gray-500';
      case 'rare': return 'text-blue-500';
      case 'legendary': return 'text-yellow-500';
      default: return 'text-gray-500';
    }
  };

  const getResultColor = (result: string) => {
    return result === 'برد' ? 'text-green-600' : 'text-red-600';
  };

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <Card className="relative overflow-hidden">
        {/* Cover Image */}
        <div className="h-32 bg-gradient-to-r from-primary/20 to-secondary/20 relative">
          {isEditing && (
            <Button 
              variant="secondary" 
              size="sm" 
              className="absolute top-2 right-2 bg-black/50 hover:bg-black/70"
            >
              <Camera className="h-4 w-4 ml-2" />
              تغییر کاور
            </Button>
          )}
        </div>
        
        <CardContent className="relative -mt-16 pb-6">
          <div className={`flex ${isMobile ? 'flex-col items-center space-y-4' : 'items-end space-x-6'}`}>
            {/* Avatar */}
            <div className="relative">
              <Avatar className="h-32 w-32 border-4 border-background">
                <AvatarImage src={profileData.avatar} />
                <AvatarFallback className="text-2xl">{profileData.name[0]}</AvatarFallback>
              </Avatar>
              {isEditing && (
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="absolute bottom-0 right-0 rounded-full h-8 w-8 p-0"
                >
                  <Camera className="h-4 w-4" />
                </Button>
              )}
            </div>

            {/* Profile Info */}
            <div className={`flex-1 ${isMobile ? 'text-center' : 'text-right'} space-y-2`} dir="rtl">
              <div className="flex items-center justify-center lg:justify-end space-x-2">
                <Badge variant="secondary" className="text-xs">
                  <Shield className="h-3 w-3 ml-1" />
                  تایید شده
                </Badge>
                <h1 className="text-2xl font-bold">{profileData.name}</h1>
              </div>
              
              <p className="text-muted-foreground">{profileData.username}</p>
              <p className="text-sm max-w-md">{profileData.bio}</p>
              
              {/* Stats */}
              <div className="flex justify-center lg:justify-end space-x-6 pt-2">
                <div className="text-center">
                  <p className="text-lg font-bold">{stats.followers}</p>
                  <p className="text-xs text-muted-foreground">دنبال‌کننده</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold">{stats.following}</p>
                  <p className="text-xs text-muted-foreground">دنبال شده</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold">{stats.friends}</p>
                  <p className="text-xs text-muted-foreground">دوست</p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex space-x-2">
              {isEditing ? (
                <>
                  <Button variant="outline" onClick={() => setIsEditing(false)}>
                    لغو
                  </Button>
                  <Button onClick={handleSaveProfile}>
                    ذخیره
                  </Button>
                </>
              ) : (
                <Button onClick={() => setIsEditing(true)}>
                  <Edit className="h-4 w-4 ml-2" />
                  ویرایش پروفایل
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Content */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="overview">کلی</TabsTrigger>
          <TabsTrigger value="stats">آمار</TabsTrigger>
          <TabsTrigger value="achievements">دستاوردها</TabsTrigger>
          <TabsTrigger value="settings">تنظیمات</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-2'} gap-6`}>
            {/* Personal Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-right" dir="rtl">اطلاعات شخصی</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {isEditing ? (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-right" dir="rtl">نام</Label>
                      <Input
                        id="name"
                        value={profileData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="text-right"
                        dir="rtl"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="username" className="text-right" dir="rtl">نام کاربری</Label>
                      <Input
                        id="username"
                        value={profileData.username}
                        onChange={(e) => handleInputChange('username', e.target.value)}
                        className="text-right"
                        dir="rtl"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bio" className="text-right" dir="rtl">بیوگرافی</Label>
                      <Textarea
                        id="bio"
                        value={profileData.bio}
                        onChange={(e) => handleInputChange('bio', e.target.value)}
                        className="text-right"
                        dir="rtl"
                      />
                    </div>
                  </>
                ) : (
                  <div className="space-y-3 text-right" dir="rtl">
                    <div>
                      <Label className="text-sm text-muted-foreground">ایمیل</Label>
                      <p>{profileData.email}</p>
                    </div>
                    <div>
                      <Label className="text-sm text-muted-foreground">شماره تماس</Label>
                      <p>{profileData.phone}</p>
                    </div>
                    <div>
                      <Label className="text-sm text-muted-foreground">موقعیت</Label>
                      <p>{profileData.location}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Gaming Preferences */}
            <Card>
              <CardHeader>
                <CardTitle className="text-right" dir="rtl">بازی‌های مورد علاقه</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {gamePreferences.map((game, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                      <Gamepad2 className="h-4 w-4 text-muted-foreground" />
                      <span className="text-right" dir="rtl">{game}</span>
                    </div>
                  ))}
                  {isEditing && (
                    <Button variant="outline" size="sm" className="w-full">
                      افزودن بازی
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Matches */}
          <Card>
            <CardHeader>
              <CardTitle className="text-right" dir="rtl">بازی‌های اخیر</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentMatches.map((match, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-3">
                      <span className="text-sm text-muted-foreground">{match.date}</span>
                      {match.kd && (
                        <Badge variant="outline" className="text-xs">
                          K/D: {match.kd}
                        </Badge>
                      )}
                      <Badge variant="outline" className="text-xs">
                        {match.mode}
                      </Badge>
                      <span className={`font-medium ${getResultColor(match.result)}`}>
                        {match.result}
                      </span>
                      <span className="text-sm">{match.score}</span>
                    </div>
                    <div className="text-right" dir="rtl">
                      <span className="font-medium">{match.game}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats" className="space-y-6">
          <div className={`grid ${isMobile ? 'grid-cols-2' : 'grid-cols-4'} gap-4`}>
            <Card className="text-center p-6">
              <div className="space-y-2">
                <div className="text-2xl font-bold">{stats.totalMatches}</div>
                <div className="text-sm text-muted-foreground">کل بازی‌ها</div>
              </div>
            </Card>
            <Card className="text-center p-6">
              <div className="space-y-2">
                <div className="text-2xl font-bold text-green-600">{stats.wins}</div>
                <div className="text-sm text-muted-foreground">برد</div>
              </div>
            </Card>
            <Card className="text-center p-6">
              <div className="space-y-2">
                <div className="text-2xl font-bold">{stats.winRate}%</div>
                <div className="text-sm text-muted-foreground">درصد برد</div>
              </div>
            </Card>
            <Card className="text-center p-6">
              <div className="space-y-2">
                <div className="text-2xl font-bold text-yellow-600">{stats.tournaments}</div>
                <div className="text-sm text-muted-foreground">تورنومنت</div>
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-2'} gap-4`}>
            {achievements.map((achievement) => {
              const Icon = achievement.icon;
              return (
                <Card key={achievement.id} className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className="text-sm text-muted-foreground">
                      {achievement.date}
                    </div>
                    <div className="flex-1 text-right space-y-1" dir="rtl">
                      <div className="flex items-center justify-end space-x-2">
                        <span className={`text-xs ${getRarityColor(achievement.rarity)}`}>
                          {achievement.rarity === 'common' && 'معمولی'}
                          {achievement.rarity === 'rare' && 'نادر'}
                          {achievement.rarity === 'legendary' && 'افسانه‌ای'}
                        </span>
                        <h4 className="font-semibold">{achievement.title}</h4>
                      </div>
                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                    </div>
                    <div className={`p-3 rounded-full ${getRarityColor(achievement.rarity)} bg-muted`}>
                      <Icon className="h-6 w-6" />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          {/* User Level Selector */}
          <UserLevelSelector />
          
          <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-2'} gap-6`}>
            <Card>
              <CardHeader>
                <CardTitle className="text-right" dir="rtl">تنظیمات حریم خصوصی</CardTitle>
                <CardDescription className="text-right" dir="rtl">
                  کنترل اطلاعاتی که دیگران می‌توانند ببینند
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(preferences).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between">
                    <Switch
                      checked={value}
                      onCheckedChange={(checked) => handlePreferenceChange(key, checked)}
                    />
                    <Label className="text-right" dir="rtl">
                      {key === 'publicProfile' && 'پروفایل عمومی'}
                      {key === 'showEmail' && 'نمایش ایمیل'}
                      {key === 'showPhone' && 'نمایش شماره تماس'}
                      {key === 'allowMessages' && 'دریافت پیام'}
                      {key === 'allowFriendRequests' && 'درخواست دوستی'}
                      {key === 'showOnlineStatus' && 'نمایش وضعیت آنلاین'}
                      {key === 'showCurrentGame' && 'نمایش بازی فعلی'}
                    </Label>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-right" dir="rtl">تنظیمات حساب</CardTitle>
                <CardDescription className="text-right" dir="rtl">
                  مدیریت حساب کاربری شما
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button variant="outline" className="w-full">
                  تغییر رمز عبور
                </Button>
                <Button variant="outline" className="w-full">
                  تنظیمات اعلان‌ها
                </Button>
                <Button variant="outline" className="w-full">
                  دانلود اطلاعات
                </Button>
                <Button variant="destructive" className="w-full">
                  حذف حساب
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}