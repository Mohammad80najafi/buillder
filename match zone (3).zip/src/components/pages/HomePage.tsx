/**
 * Matchzone Home Page - Ultra Creative Gaming Design
 * Main dashboard with personalized content and striking visuals
 */

import React, { useMemo } from 'react';
import { RealTimeDashboard } from '../dashboard/RealTimeDashboard';
import { GameSeriesGrid } from '../gaming/GameSeriesGrid';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { ComponentProps } from '../ui/interfaces';
import { useMobile } from '../ui/use-mobile';
import { mockGameSeries, getFeaturedGameSeries, getPopularGameSeries, getNewGameSeries } from '../../data/mockGameSeries';
import { motion } from 'motion/react';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { 
  Gamepad2, Users, Trophy, Target, Star, Sparkles, 
  Play, Crown, Flame, Zap, Rocket, Gem
} from 'lucide-react';

export interface HomePageProps extends ComponentProps {
  /** Custom dashboard configuration */
  dashboardConfig?: {
    showRecentGames?: boolean;
    showFriendActivity?: boolean;
    showTournaments?: boolean;
    showNotifications?: boolean;
  };
  
  /** Event handlers */
  onNavigateToLobby?: (lobbyId: string) => void;
  onNavigateToTournament?: (tournamentId: string) => void;
  onNavigateToProfile?: (userId: string) => void;
  onNavigateToSeries?: (seriesId: string) => void;
  onNavigateToEpisode?: (episodeId: string) => void;
}

/**
 * Creative Hero Section with Animated Background
 */
function CreativeHeroSection() {
  const isMobile = useMobile();
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="relative overflow-hidden rounded-3xl mb-8 h-64 md:h-80"
    >
      {/* Animated Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-purple-600/20 to-pink-600/20 backdrop-blur-sm" />
      
      {/* Floating Gaming Elements */}
      <div className="absolute inset-0">
        {/* Animated Particles */}
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full"
            animate={{
              x: [0, 100, -50, 50, 0],
              y: [0, -50, 100, -25, 0],
              scale: [1, 1.5, 0.8, 1.2, 1],
              opacity: [0.3, 0.8, 0.4, 0.9, 0.3]
            }}
            transition={{
              duration: 8 + i * 0.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            style={{
              left: `${10 + i * 10}%`,
              top: `${20 + i * 8}%`
            }}
          />
        ))}
        
        {/* Gaming Icons */}
        <motion.div
          className="absolute top-8 right-8 text-blue-400/30"
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        >
          <Gamepad2 className="w-12 h-12" />
        </motion.div>
        
        <motion.div
          className="absolute bottom-8 left-8 text-purple-400/30"
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 10, -10, 0]
          }}
          transition={{ duration: 4, repeat: Infinity }}
        >
          <Trophy className="w-10 h-10" />
        </motion.div>
        
        <motion.div
          className="absolute top-1/2 left-1/4 text-pink-400/30"
          animate={{ 
            y: [0, -20, 0],
            opacity: [0.3, 0.8, 0.3]
          }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          <Target className="w-8 h-8" />
        </motion.div>
      </div>
      
      {/* Hero Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-6">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="space-y-4"
        >
          <div className="flex items-center justify-center space-x-2 mb-4">
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Crown className="w-8 h-8 text-yellow-400" />
            </motion.div>
            <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              MatchZone
            </h1>
            <motion.div
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            >
              <Sparkles className="w-8 h-8 text-purple-400" />
            </motion.div>
          </div>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl">
            پلتفرم گیمینگ اجتماعی ایران • جایی که قهرمانان متولد می‌شوند
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-4 mt-6">
            <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-500/30">
              <Users className="w-4 h-4 ml-1" />
              ۲۸۴۷ کاربر آنلاین
            </Badge>
            <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-500/30">
              <Play className="w-4 h-4 ml-1" />
              ۱۵۶ لابی فعال
            </Badge>
            <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
              <Trophy className="w-4 h-4 ml-1" />
              ۱۲ تورنومنت
            </Badge>
          </div>
        </motion.div>
      </div>
      
      {/* Bottom Glow Effect */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-background via-background/50 to-transparent" />
    </motion.div>
  );
}

/**
 * Creative Stats Cards
 */
function CreativeStatsCards() {
  const stats = [
    { 
      title: "قهرمانان امروز", 
      value: "۳۴", 
      icon: Crown, 
      color: "from-yellow-500 to-orange-500",
      bgColor: "bg-yellow-500/10",
      textColor: "text-yellow-400"
    },
    { 
      title: "نبردهای اپیک", 
      value: "۱۲۸", 
      icon: Flame, 
      color: "from-red-500 to-pink-500",
      bgColor: "bg-red-500/10",
      textColor: "text-red-400"
    },
    { 
      title: "کامبو‌های کامل", 
      value: "۸۹", 
      icon: Zap, 
      color: "from-blue-500 to-cyan-500",
      bgColor: "bg-blue-500/10",
      textColor: "text-blue-400"
    },
    { 
      title: "لحظات شگفت‌انگیز", 
      value: "۲۴۳", 
      icon: Gem, 
      color: "from-purple-500 to-pink-500",
      bgColor: "bg-purple-500/10",
      textColor: "text-purple-400"
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1, duration: 0.5 }}
          whileHover={{ scale: 1.05, y: -5 }}
          className="group"
        >
          <Card className="relative overflow-hidden border-2 border-transparent hover:border-primary/30 transition-all duration-300">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className={`text-2xl font-bold ${stat.textColor}`}>
                    {stat.value}
                  </p>
                </div>
                <div className={`h-12 w-12 ${stat.bgColor} rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <stat.icon className={`h-6 w-6 ${stat.textColor}`} />
                </div>
              </div>
              
              {/* Animated background effect */}
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
              
              {/* Glow effect */}
              <div className="absolute top-0 right-0 w-3 h-3 bg-primary rounded-full opacity-60 animate-pulse" />
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

/**
 * Creative Tab Section
 */
function CreativeTabSection({ 
  featuredSeries, 
  popularSeries, 
  newSeries, 
  allSeries,
  onNavigateToSeries,
  onNavigateToEpisode,
  isMobile 
}: any) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5, duration: 0.8 }}
      className="space-y-8"
    >
      <Tabs defaultValue="featured" className="w-full" dir="rtl">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.6 }}
        >
          <TabsList className="grid w-full grid-cols-3 p-1 bg-surface-secondary/50 backdrop-blur-sm border border-border-primary">
            <TabsTrigger 
              value="featured" 
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-purple-500 data-[state=active]:text-white transition-all duration-300"
            >
              <Star className="w-4 h-4 ml-1" />
              برگزیده‌ها
            </TabsTrigger>
            <TabsTrigger 
              value="popular"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-emerald-500 data-[state=active]:text-white transition-all duration-300"
            >
              <Flame className="w-4 h-4 ml-1" />
              محبوب‌ترین
            </TabsTrigger>
            <TabsTrigger 
              value="new"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-rose-500 data-[state=active]:text-white transition-all duration-300"
            >
              <Rocket className="w-4 h-4 ml-1" />
              جدیدترین
            </TabsTrigger>
          </TabsList>
        </motion.div>
        
        <TabsContent value="featured" className="space-y-4 mt-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.5 }}
          >
            <GameSeriesGrid
              title="سری‌های برگزیده"
              description="بهترین و با کیفیت‌ترین سری بازی‌ها ⭐"
              series={featuredSeries}
              onSeriesSelect={onNavigateToSeries}
              onEpisodeSelect={onNavigateToEpisode}
              showSearch={false}
              showFilters={false}
              showCategories={false}
              compact={true}
              itemsPerPage={isMobile ? 4 : 8}
            />
          </motion.div>
        </TabsContent>
        
        <TabsContent value="popular" className="space-y-4 mt-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.5 }}
          >
            <GameSeriesGrid
              title="محبوب‌ترین سری‌ها"
              description="پربازدیدترین و محبوب‌ترین سری بازی‌ها 🔥"
              series={popularSeries}
              onSeriesSelect={onNavigateToSeries}
              onEpisodeSelect={onNavigateToEpisode}
              showSearch={false}
              showFilters={false}
              showCategories={false}
              compact={true}
              itemsPerPage={isMobile ? 4 : 6}
            />
          </motion.div>
        </TabsContent>
        
        <TabsContent value="new" className="space-y-4 mt-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.5 }}
          >
            <GameSeriesGrid
              title="سری‌های جدید"
              description="تازه‌ترین قسمت‌ها و سری‌های منتشرشده 🚀"
              series={newSeries}
              onSeriesSelect={onNavigateToSeries}
              onEpisodeSelect={onNavigateToEpisode}
              showSearch={false}
              showFilters={false}
              showCategories={false}
              compact={true}
              itemsPerPage={isMobile ? 4 : 6}
            />
          </motion.div>
        </TabsContent>
      </Tabs>

      {/* All Series with Enhanced Design */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.8 }}
        className="relative"
      >
        {/* Background decoration */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 via-purple-500/5 to-pink-500/5 rounded-3xl -z-10" />
        
        <GameSeriesGrid
          title="🎮 همه سری‌های بازی"
          description="کاوش در کامل‌ترین مجموعه سری بازی‌ها با امکانات پیشرفته"
          series={allSeries}
          onSeriesSelect={onNavigateToSeries}
          onEpisodeSelect={onNavigateToEpisode}
          showSearch={true}
          showFilters={true}
          showCategories={true}
          compact={false}
          itemsPerPage={isMobile ? 2 : 4}
        />
      </motion.div>
    </motion.div>
  );
}

/**
 * Home Page Component - Ultra Creative Gaming Design
 * 
 * Displays the main dashboard with:
 * - Creative hero section with animations
 * - Enhanced real-time gaming statistics
 * - Creative stats cards with micro-interactions
 * - Enhanced tabs with gradient effects
 * - Game series collections with modern design
 * 
 * @param props - HomePage component props
 * @returns {JSX.Element} The rendered creative home page
 */
export function HomePage({
  dashboardConfig = {
    showRecentGames: true,
    showFriendActivity: true,
    showTournaments: true,
    showNotifications: true
  },
  onNavigateToLobby,
  onNavigateToTournament,
  onNavigateToProfile,
  onNavigateToSeries,
  onNavigateToEpisode,
  className,
  ...props
}: HomePageProps): JSX.Element {
  const isMobile = useMobile();

  // Memoize series data to prevent unnecessary recalculations
  const featuredSeries = useMemo(() => getFeaturedGameSeries(), []);
  const popularSeries = useMemo(() => getPopularGameSeries(), []);
  const newSeries = useMemo(() => getNewGameSeries(), []);
  const allSeries = useMemo(() => mockGameSeries, []);

  return (
    <div className={`space-y-8 ${className}`} {...props}>
      {/* Creative Hero Section */}
      <CreativeHeroSection />
      
      {/* Creative Stats Cards */}
      <CreativeStatsCards />

      {/* Enhanced Real-time Dashboard */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
      >
        <RealTimeDashboard 
          config={dashboardConfig}
          onNavigateToLobby={onNavigateToLobby}
          onNavigateToTournament={onNavigateToTournament}
          onNavigateToProfile={onNavigateToProfile}
        />
      </motion.div>

      {/* Creative Tab Section */}
      <CreativeTabSection
        featuredSeries={featuredSeries}
        popularSeries={popularSeries}
        newSeries={newSeries}
        allSeries={allSeries}
        onNavigateToSeries={onNavigateToSeries}
        onNavigateToEpisode={onNavigateToEpisode}
        isMobile={isMobile}
      />
    </div>
  );
}

export default HomePage;