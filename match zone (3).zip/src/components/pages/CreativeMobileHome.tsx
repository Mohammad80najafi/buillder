import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, Users, Trophy, Star, Zap, Target, Play, Pause,
  Headphones, Monitor, Wifi, Settings, User, Crown, Shield,
  Flame, Lightning, Rocket, Activity, BarChart3, Calendar,
  MessageCircle, Video, Radio, Eye, Heart, Share2, Plus,
  ChevronRight, ArrowUp, TrendingUp, Clock, MapPin, Globe,
  Cpu, HardDrive, MousePointer, Mic, Volume2, Camera,
  Edit3, MoreHorizontal, Bell, Search, Home, UserCheck,
  Award, Medal, Gift, Sparkles, Layers, Hexagon, Triangle,
  Square, Circle, Diamond, Swords, Crosshair, Joystick,
  GamepadIcon, Twitch, Youtube, Instagram, Discord
} from 'lucide-react';
import { Button } from '../ui/mz-button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Progress } from '../ui/progress';
import { motion, AnimatePresence } from 'motion/react';
import { useMobile } from '../ui/use-mobile';

interface CreativeMobileHomeProps {
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
}

interface GameSession {
  id: string;
  game: string;
  duration: string;
  score: number;
  rank: string;
  timestamp: string;
  highlight: boolean;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: any;
  progress: number;
  maxProgress: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlocked: boolean;
  category: string;
}

interface Friend {
  id: string;
  name: string;
  avatar: string;
  status: 'online' | 'playing' | 'away' | 'offline';
  currentGame?: string;
  lastSeen?: string;
}

export function CreativeMobileHome({
  onNavigate,
  onLogout,
}: CreativeMobileHomeProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedSection, setSelectedSection] = useState<'dashboard' | 'achievements' | 'friends' | 'sessions'>('dashboard');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Mock Gaming Profile Data
  const userProfile = {
    name: 'KEOXER',
    title: 'Elite Gamer',
    level: 47,
    xp: 12750,
    xpToNext: 15000,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rank: 'Diamond III',
    mainGame: 'VALORANT',
    playTime: '2847h',
    winRate: 73,
    currentStreak: 12,
    creditsBalance: 24750,
    status: 'در بازی',
    platforms: ['PC', 'PlayStation', 'Xbox'],
    specialties: ['FPS', 'Strategy', 'RPG']
  };

  const recentSessions: GameSession[] = [
    {
      id: '1',
      game: 'VALORANT',
      duration: '2h 35m',
      score: 28,
      rank: 'MVP',
      timestamp: '2 دقیقه پیش',
      highlight: true
    },
    {
      id: '2', 
      game: 'CS2',
      duration: '1h 42m',
      score: 31,
      rank: '2nd',
      timestamp: '5 ساعت پیش',
      highlight: false
    },
    {
      id: '3',
      game: 'Apex Legends',
      duration: '45m',
      score: 8,
      rank: 'Champion',
      timestamp: 'دیروز',
      highlight: true
    }
  ];

  const achievements: Achievement[] = [
    {
      id: '1',
      title: 'Headshot King',
      description: '100 headshot در یک بازی',
      icon: Crosshair,
      progress: 87,
      maxProgress: 100,
      rarity: 'epic',
      unlocked: false,
      category: 'Combat'
    },
    {
      id: '2',
      title: 'Win Streak Master',
      description: '15 برد متوالی',
      icon: Trophy,
      progress: 15,
      maxProgress: 15,
      rarity: 'legendary',
      unlocked: true,
      category: 'Victory'
    },
    {
      id: '3',
      title: 'Team Player',
      description: '50 assist در یک ماه',
      icon: Users,
      progress: 34,
      maxProgress: 50,
      rarity: 'rare',
      unlocked: false,
      category: 'Teamwork'
    },
    {
      id: '4',
      title: 'Speed Demon',
      description: 'کامل کردن مپ در کمتر از 5 دقیقه',
      icon: Zap,
      progress: 1,
      maxProgress: 1,
      rarity: 'epic',
      unlocked: true,
      category: 'Speed'
    }
  ];

  const friends: Friend[] = [
    {
      id: '1',
      name: 'Phoenix_Pro',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      status: 'playing',
      currentGame: 'VALORANT - Ranked'
    },
    {
      id: '2',
      name: 'ShadowNinja',
      avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      status: 'online'
    },
    {
      id: '3',
      name: 'IronWolf99',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      status: 'away',
      lastSeen: '30 دقیقه پیش'
    }
  ];

  const getRarityColor = (rarity: Achievement['rarity']) => {
    switch (rarity) {
      case 'common': return 'text-gray-400';
      case 'rare': return 'text-blue-400';
      case 'epic': return 'text-purple-400';
      case 'legendary': return 'text-yellow-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusColor = (status: Friend['status']) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'playing': return 'bg-blue-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-black text-white overflow-hidden">
      {/* Cyberpunk Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-cyan-500/5" />
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 left-0 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Header - Gaming HUD Style */}
      <div className="relative z-10 p-4 border-b border-cyan-500/20 bg-black/50 backdrop-blur-md">
        <div className="flex items-center justify-between" dir="rtl">
          {/* User Status */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <Avatar className="h-12 w-12 ring-2 ring-cyan-400 ring-offset-2 ring-offset-black">
                <AvatarImage src={userProfile.avatar} alt={userProfile.name} />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-cyan-500">
                  {userProfile.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1 bg-green-500 rounded-full p-1 border-2 border-black">
                <Gamepad2 className="h-3 w-3 text-white" />
              </div>
            </div>
            
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-lg">{userProfile.name}</h1>
                <Crown className="h-4 w-4 text-yellow-400" />
                <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-xs">
                  LVL {userProfile.level}
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-xs text-cyan-400">
                <span>{userProfile.rank}</span>
                <span>•</span>
                <span>{userProfile.status}</span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <Button size="sm" variant="ghost" className="p-2">
              <Bell className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="ghost" className="p-2">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* XP Progress */}
        <div className="mt-3">
          <div className="flex items-center justify-between text-xs text-cyan-400 mb-1">
            <span>XP Progress</span>
            <span>{userProfile.xp.toLocaleString()} / {userProfile.xpToNext.toLocaleString()}</span>
          </div>
          <Progress 
            value={(userProfile.xp / userProfile.xpToNext) * 100} 
            className="h-2 bg-gray-800"
          />
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="relative z-10 px-4 py-2 border-b border-gray-800/50 bg-black/30 backdrop-blur-sm">
        <div className="flex gap-1" dir="rtl">
          {[
            { id: 'dashboard', label: 'داشبورد', icon: BarChart3 },
            { id: 'achievements', label: 'دستاوردها', icon: Trophy },
            { id: 'friends', label: 'دوستان', icon: Users },
            { id: 'sessions', label: 'سشن‌ها', icon: Gamepad2 }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedSection(tab.id as any)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-all ${
                selectedSection === tab.id
                  ? 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 p-4 space-y-4">
        <AnimatePresence mode="wait">
          {/* Dashboard Section */}
          {selectedSection === 'dashboard' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
              dir="rtl"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-3">
                <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border-cyan-500/20">
                  <CardContent className="p-4 text-center">
                    <Clock className="h-6 w-6 text-cyan-400 mx-auto mb-2" />
                    <div className="text-lg font-bold">{userProfile.playTime}</div>
                    <p className="text-xs text-gray-400">زمان بازی</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
                  <CardContent className="p-4 text-center">
                    <TrendingUp className="h-6 w-6 text-green-400 mx-auto mb-2" />
                    <div className="text-lg font-bold">{userProfile.winRate}%</div>
                    <p className="text-xs text-gray-400">نرخ برد</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
                  <CardContent className="p-4 text-center">
                    <Flame className="h-6 w-6 text-yellow-400 mx-auto mb-2" />
                    <div className="text-lg font-bold">{userProfile.currentStreak}</div>
                    <p className="text-xs text-gray-400">برد متوالی</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
                  <CardContent className="p-4 text-center">
                    <Gift className="h-6 w-6 text-purple-400 mx-auto mb-2" />
                    <div className="text-lg font-bold">{userProfile.creditsBalance.toLocaleString()}</div>
                    <p className="text-xs text-gray-400">امتیاز</p>
                  </CardContent>
                </Card>
              </div>

              {/* Quick Actions */}
              <Card className="bg-black/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Rocket className="h-5 w-5 text-cyan-400" />
                    اکشن‌های سریع
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
                      <Play className="h-4 w-4 ml-2" />
                      شروع بازی
                    </Button>
                    <Button variant="outline" className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10">
                      <Users className="h-4 w-4 ml-2" />
                      پیوستن به لابی
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <Button variant="outline" className="border-green-500/50 text-green-400 hover:bg-green-500/10">
                      <Video className="h-4 w-4 ml-2" />
                      شروع استریم
                    </Button>
                    <Button variant="outline" className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10">
                      <Plus className="h-4 w-4 ml-2" />
                      لابی جدید
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Highlights */}
              <Card className="bg-black/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Star className="h-5 w-5 text-yellow-400" />
                    هایلایت‌های اخیر
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recentSessions.filter(s => s.highlight).map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-lg border border-yellow-500/20">
                        <div className="flex items-center gap-3">
                          <div className="bg-yellow-500/20 rounded-lg p-2">
                            <Trophy className="h-4 w-4 text-yellow-400" />
                          </div>
                          <div>
                            <p className="font-medium text-sm">{session.game}</p>
                            <p className="text-xs text-gray-400">{session.rank} • {session.score} امتیاز</p>
                          </div>
                        </div>
                        <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                          <Sparkles className="h-3 w-3 mr-1" />
                          هایلایت
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Achievements Section */}
          {selectedSection === 'achievements' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
              dir="rtl"
            >
              <div className="grid gap-3">
                {achievements.map((achievement) => (
                  <Card key={achievement.id} className={`bg-black/50 border-gray-700/50 ${achievement.unlocked ? 'ring-1 ring-cyan-500/30' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-3 rounded-lg ${
                          achievement.unlocked 
                            ? 'bg-gradient-to-br from-cyan-500/20 to-blue-500/20' 
                            : 'bg-gray-800/50'
                        }`}>
                          <achievement.icon className={`h-6 w-6 ${
                            achievement.unlocked ? getRarityColor(achievement.rarity) : 'text-gray-600'
                          }`} />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className={`font-medium ${achievement.unlocked ? 'text-white' : 'text-gray-400'}`}>
                              {achievement.title}
                            </h3>
                            {achievement.unlocked && (
                              <Badge className={`${getRarityColor(achievement.rarity)} bg-transparent border-current`}>
                                {achievement.rarity}
                              </Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-400 mb-2">{achievement.description}</p>
                          
                          {!achievement.unlocked && (
                            <div>
                              <div className="flex justify-between text-xs text-gray-400 mb-1">
                                <span>پیشرفت</span>
                                <span>{achievement.progress}/{achievement.maxProgress}</span>
                              </div>
                              <Progress 
                                value={(achievement.progress / achievement.maxProgress) * 100} 
                                className="h-1 bg-gray-800"
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {/* Friends Section */}
          {selectedSection === 'friends' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
              dir="rtl"
            >
              <div className="space-y-3">
                {friends.map((friend) => (
                  <Card key={friend.id} className="bg-black/50 border-gray-700/50">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={friend.avatar} alt={friend.name} />
                              <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className={`absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-black ${getStatusColor(friend.status)}`} />
                          </div>
                          
                          <div>
                            <h3 className="font-medium text-white">{friend.name}</h3>
                            <p className="text-xs text-gray-400">
                              {friend.status === 'playing' ? friend.currentGame :
                               friend.status === 'away' ? friend.lastSeen :
                               friend.status === 'online' ? 'آنلاین' : 'آفلاین'}
                            </p>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" className="p-2">
                            <MessageCircle className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" className="p-2">
                            <UserCheck className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}

          {/* Sessions Section */}
          {selectedSection === 'sessions' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
              dir="rtl"
            >
              <div className="space-y-3">
                {recentSessions.map((session) => (
                  <Card key={session.id} className="bg-black/50 border-gray-700/50">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-lg p-3">
                            <Gamepad2 className="h-6 w-6 text-cyan-400" />
                          </div>
                          
                          <div>
                            <h3 className="font-medium text-white">{session.game}</h3>
                            <div className="flex items-center gap-2 text-xs text-gray-400">
                              <span>{session.duration}</span>
                              <span>•</span>
                              <span>{session.score} امتیاز</span>
                              <span>•</span>
                              <span>{session.timestamp}</span>
                            </div>
                          </div>
                        </div>

                        <Badge className={`${
                          session.rank === 'MVP' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                          session.rank === 'Champion' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' :
                          'bg-blue-500/20 text-blue-400 border-blue-500/30'
                        }`}>
                          {session.rank}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Floating Quick Join Button */}
      <div className="fixed bottom-20 left-4 z-20">
        <Button 
          size="lg"
          className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 rounded-full shadow-2xl shadow-cyan-500/25"
          onClick={() => onNavigate?.('lobbies')}
        >
          <Gamepad2 className="h-5 w-5 ml-2" />
          پیوستن سریع
        </Button>
      </div>
    </div>
  );
}

export default CreativeMobileHome;