import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, Heart, MessageCircle, Share2, Plus, Upload,
  Eye, TrendingUp, DollarSign, Users, Star, Trophy, Clock,
  ThumbsUp, ThumbsDown, Bookmark, Download, Edit3, Settings,
  Camera, Video, Mic, Grid, List, Filter, Search, Bell,
  ChevronDown, MoreHorizontal, Flag, Volume2, VolumeX,
  Maximize, RotateCcw, Calendar, BarChart3, Target, Zap,
  Crown, Shield, Gift, Sparkles, Award, Medal, Flame,
  ArrowUp, ArrowDown, TrendingDown, ExternalLink, Copy,
  CheckCircle, XCircle, AlertCircle, Info, Gamepad2,
  Monitor, Headphones, MousePointer, Hash, AtSign,
  Globe, MapPin, Link, Instagram, Youtube, Twitch, Discord,
  UserPlus, UserX, MessageSquare, Send
} from 'lucide-react';
import { Button } from '../ui/mz-button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { useMobile } from '../ui/use-mobile';
import { ProfileSettings } from './ProfileSettingsPage';

interface UserProfilePageProps {
  userId?: string;
  isOwnProfile?: boolean;
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
}

interface UserStats {
  totalViews: number;
  totalEarnings: number;
  followers: number;
  following: number;
  totalVideos: number;
  totalClips: number;
  avgViews: number;
  monthlyGrowth: number;
  engagementRate: number;
  topVideo: string;
  gamesPlayed: number;
  hoursPlayed: number;
  winRate: number;
  currentStreak: number;
}

interface UserVideo {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  duration: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  uploadDate: string;
  game?: string;
  tags: string[];
  earnings: number;
  monetized: boolean;
  trending: boolean;
}

interface UserProfile {
  id: string;
  name: string;
  username: string;
  avatar: string;
  banner?: string;
  verified: boolean;
  level: string;
  bio: string;
  location?: string;
  joinDate: string;
  socialLinks: {
    youtube?: string;
    twitch?: string;
    discord?: string;
    instagram?: string;
  };
  favoriteGames: string[];
  achievements: Array<{
    id: string;
    name: string;
    description: string;
    icon: string;
    unlockedAt: string;
    rarity: 'common' | 'rare' | 'epic' | 'legendary';
  }>;
  badges: Array<{
    id: string;
    name: string;
    icon: string;
    color: string;
  }>;
}

export function UserProfilePage({
  userId = 'user1',
  isOwnProfile = true,
  onNavigate,
  onLogout,
}: UserProfilePageProps) {
  const [selectedTab, setSelectedTab] = useState<'videos' | 'clips' | 'about' | 'achievements'>('videos');
  const [playingVideoId, setPlayingVideoId] = useState<string | null>(null);
  const [likedVideos, setLikedVideos] = useState<Set<string>>(new Set());
  const [isFollowing, setIsFollowing] = useState(false);
  const [showAllAchievements, setShowAllAchievements] = useState(false);
  const isMobile = useMobile();

  // Mock Profile Settings - در حالت واقعی از localStorage یا API می‌آید
  const [profileSettings] = useState<ProfileSettings>({
    visibility: {
      showStats: true,
      showVideos: true,
      showAchievements: true,
      showGames: true,
      showClans: true,
      showFriends: true,
      showActivity: false,
      showEarnings: false,
      showRank: true,
      showBadges: true,
    },
    privacy: {
      profilePublic: true,
      showOnlineStatus: true,
      allowFriendRequests: true,
      allowClanInvites: true,
      allowDirectMessages: true,
      showGameHistory: true,
    },
    profile: {
      displayName: 'KEOXER GAMING',
      bio: 'کریتور حرفه‌ای گیمینگ 🎮 | تولید محتوای آموزشی و سرگرمی | تخصص در FPS و Strategy Games',
      favoriteGames: ['VALORANT', 'CS2', 'League of Legends'],
      availability: 'online',
      profileTheme: 'gaming',
    },
    content: {
      autoUploadClips: true,
      allowTipping: true,
      monetization: false,
      showViewerCount: true,
      moderateComments: true,
    }
  });

  // Mock User Profile
  const userProfile: UserProfile = {
    id: userId,
    name: profileSettings.profile.displayName,
    username: '@keoxer_pro',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    banner: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    verified: true,
    level: 'Diamond II',
    bio: profileSettings.profile.bio,
    location: 'تهران، ایران',
    joinDate: 'عضو از مرداد ۱۴۰۲',
    socialLinks: {
      youtube: 'https://youtube.com/@keoxer',
      twitch: 'https://twitch.tv/keoxer',
      discord: 'keoxer#1234',
      instagram: 'https://instagram.com/keoxer'
    },
    favoriteGames: profileSettings.profile.favoriteGames,
    achievements: [
      { id: '1', name: 'اولین پیروزی', description: 'اولین بازی برنده', icon: '🏆', unlockedAt: '۲ روز پیش', rarity: 'common' },
      { id: '2', name: 'استریک ۱۰ تایی', description: '۱۰ بازی پیاپی برنده', icon: '🔥', unlockedAt: '۱ هفته پیش', rarity: 'rare' },
      { id: '3', name: 'شکارچی', description: '۱۰۰ کیل در هفته', icon: '🎯', unlockedAt: '۳ هفته پیش', rarity: 'epic' },
      { id: '4', name: 'افسانه', description: 'رسیدن به رنک ایمورتال', icon: '⚡', unlockedAt: '۱ ماه پیش', rarity: 'legendary' },
    ],
    badges: [
      { id: '1', name: 'کریتور تایید شده', icon: '✅', color: 'blue' },
      { id: '2', name: 'اسپانسر شده', icon: '👑', color: 'gold' },
      { id: '3', name: 'استریمر', icon: '📺', color: 'purple' },
    ]
  };

  // Mock User Stats
  const userStats: UserStats = {
    totalViews: 2847650,
    totalEarnings: 45780,
    followers: 12500,
    following: 189,
    totalVideos: 156,
    totalClips: 89,
    avgViews: 18254,
    monthlyGrowth: 23.5,
    engagementRate: 8.7,
    topVideo: 'نحوه Pro شدن در VALORANT',
    gamesPlayed: 45,
    hoursPlayed: 2847,
    winRate: 73.2,
    currentStreak: 12
  };

  // Mock Videos
  const userVideos: UserVideo[] = [
    {
      id: 'video1',
      title: 'راهنمای کامل Aim Training در VALORANT',
      description: 'در این ویدیو تمام تکنیک‌های aim training که باعث شده من از Iron به Radiant برسم رو یاد می‌دم',
      thumbnail: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      videoUrl: '#',
      duration: '15:32',
      views: 45620,
      likes: 3420,
      comments: 186,
      shares: 89,
      uploadDate: '2 روز پیش',
      game: 'VALORANT',
      tags: ['aim', 'training', 'guide', 'valorant'],
      earnings: 1250,
      monetized: true,
      trending: true
    },
    {
      id: 'video2',
      title: 'بهترین Settings برای CS2 در 2024',
      description: 'تمام تنظیمات که pro playerها استفاده می‌کنن + config فایل رایگان',
      thumbnail: 'https://images.unsplash.com/photo-1617507171089-6cb9aa5add36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHN0cmVhbWluZ3xlbnwxfHx8fDE3NTczMzkxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      videoUrl: '#',
      duration: '12:45',
      views: 32180,
      likes: 2890,
      comments: 124,
      shares: 67,
      uploadDate: '5 روز پیش',
      game: 'CS2',
      tags: ['cs2', 'settings', 'config', 'pro'],
      earnings: 890,
      monetized: true,
      trending: false
    }
  ];

  const handleVideoPlay = (videoId: string) => {
    setPlayingVideoId(playingVideoId === videoId ? null : videoId);
  };

  const handleLike = (videoId: string) => {
    setLikedVideos(prev => {
      const newSet = new Set(prev);
      if (newSet.has(videoId)) {
        newSet.delete(videoId);
      } else {
        newSet.add(videoId);
      }
      return newSet;
    });
  };

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
  };

  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  const formatCurrency = (amount: number): string => {
    return amount.toLocaleString('fa-IR') + ' تومان';
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'legendary': return 'text-yellow-500 bg-yellow-500/10';
      case 'epic': return 'text-purple-500 bg-purple-500/10';
      case 'rare': return 'text-blue-500 bg-blue-500/10';
      default: return 'text-gray-500 bg-gray-500/10';
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground" dir="rtl">
      {/* Top Navigation */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-3 md:px-4 py-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              {!isOwnProfile && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => onNavigate?.('discover')}
                  className="p-2"
                >
                  ←
                </Button>
              )}
              <h1 className="font-semibold truncate">
                {isOwnProfile ? 'پروفایل من' : userProfile.name}
              </h1>
            </div>

            <div className="flex items-center gap-2">
              {isOwnProfile && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => onNavigate?.('profile-settings')}
                  className="h-8 w-8 p-0"
                >
                  <Settings className="h-4 w-4" />
                </Button>
              )}
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <Share2 className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Header */}
      <div className="relative">
        {/* Banner */}
        {userProfile.banner && (
          <div 
            className="h-24 sm:h-32 md:h-48 lg:h-56 bg-gradient-to-r from-blue-600 via-purple-600 to-cyan-600 relative overflow-hidden"
            style={{
              backgroundImage: `url('${userProfile.banner}')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className="absolute inset-0 bg-black/30" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          </div>
        )}

        {/* Profile Info */}
        <div className="bg-background border-b border-border">
          <div className="max-w-7xl mx-auto px-3 md:px-4 py-3 md:py-4" dir="rtl">
            {/* Mobile Layout */}
            <div className="block md:hidden">
              <div className="flex items-start gap-3 mb-4">
                <Avatar className="h-16 w-16 border-4 border-background shadow-lg -mt-8">
                  <AvatarImage src={userProfile.avatar} alt={userProfile.name} />
                  <AvatarFallback className="text-lg">{userProfile.name.charAt(0)}</AvatarFallback>
                </Avatar>
                
                <div className="flex-1 pt-2">
                  <div className="flex items-center gap-2 mb-1">
                    <h1 className="text-lg font-bold truncate">{userProfile.name}</h1>
                    {userProfile.verified && (
                      <CheckCircle className="h-4 w-4 text-blue-500 flex-shrink-0" />
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                    <span>{userProfile.username}</span>
                    {profileSettings.visibility.showRank && (
                      <>
                        <span>•</span>
                        <Badge variant="secondary" className="text-xs px-1">{userProfile.level}</Badge>
                      </>
                    )}
                  </div>
                  
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                    {userProfile.bio}
                  </p>
                  
                  {profileSettings.visibility.showStats && (
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{formatNumber(userStats.followers)} دنبال‌کننده</span>
                      <span>{formatNumber(userStats.following)} دنبال</span>
                      {profileSettings.visibility.showVideos && (
                        <span>{userStats.totalVideos} ویدیو</span>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Mobile Action Buttons */}
              <div className="flex gap-2 mb-3">
                {isOwnProfile ? (
                  <>
                    <Button 
                      variant="outline" 
                      className="flex-1 text-sm h-8"
                      onClick={() => onNavigate?.('profile-settings')}
                    >
                      <Edit3 className="h-3 w-3 ml-1" />
                      ویرایش پروفایل
                    </Button>
                    <Button 
                      variant="outline"
                      size="sm" 
                      className="h-8"
                      onClick={() => onNavigate?.('creator-upload')}
                    >
                      <Upload className="h-3 w-3" />
                    </Button>
                  </>
                ) : (
                  <>
                    <Button 
                      className={`flex-1 text-sm h-8 ${isFollowing ? 'bg-muted text-muted-foreground' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
                      onClick={handleFollow}
                    >
                      <UserPlus className="h-3 w-3 ml-1" />
                      {isFollowing ? 'دنبال می‌کنید' : 'دنبال کردن'}
                    </Button>
                    {profileSettings.privacy.allowDirectMessages && (
                      <Button variant="outline" size="sm" className="h-8">
                        <MessageSquare className="h-3 w-3" />
                      </Button>
                    )}
                    <Button variant="outline" size="sm" className="h-8">
                      <Send className="h-3 w-3" />
                    </Button>
                  </>
                )}
              </div>

              {/* Mobile Stats */}
              {profileSettings.visibility.showStats && (
                <div className="grid grid-cols-3 gap-2 mb-3">
                  <div className="text-center p-2 bg-muted/50 rounded-lg">
                    <div className="font-bold text-sm">{formatNumber(userStats.totalViews)}</div>
                    <p className="text-xs text-muted-foreground">بازدید</p>
                  </div>
                  {profileSettings.visibility.showEarnings && isOwnProfile && (
                    <div className="text-center p-2 bg-muted/50 rounded-lg">
                      <div className="font-bold text-sm text-green-600">{formatCurrency(userStats.totalEarnings)}</div>
                      <p className="text-xs text-muted-foreground">درآمد</p>
                    </div>
                  )}
                  <div className="text-center p-2 bg-muted/50 rounded-lg">
                    <div className="font-bold text-sm">{userStats.engagementRate}%</div>
                    <p className="text-xs text-muted-foreground">تعامل</p>
                  </div>
                  <div className="text-center p-2 bg-muted/50 rounded-lg">
                    <div className="font-bold text-sm">{userStats.winRate}%</div>
                    <p className="text-xs text-muted-foreground">برد</p>
                  </div>
                </div>
              )}
            </div>

            {/* Desktop Layout */}
            <div className="hidden md:flex gap-4">
              <div className="flex items-start gap-4">
                <Avatar className="h-24 lg:h-32 w-24 lg:w-32 border-4 border-background shadow-lg -mt-12 lg:-mt-16">
                  <AvatarImage src={userProfile.avatar} alt={userProfile.name} />
                  <AvatarFallback className="text-xl lg:text-2xl">{userProfile.name.charAt(0)}</AvatarFallback>
                </Avatar>
                
                <div className="flex-1 pt-2">
                  <div className="flex items-center gap-3 mb-2">
                    <h1 className="text-xl lg:text-3xl font-bold">{userProfile.name}</h1>
                    {userProfile.verified && (
                      <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-blue-500" />
                    )}
                    {profileSettings.visibility.showRank && (
                      <Badge variant="secondary">{userProfile.level}</Badge>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                    <span className="font-medium">{userProfile.username}</span>
                    {profileSettings.visibility.showStats && (
                      <>
                        <span>•</span>
                        <span>{formatNumber(userStats.followers)} دنبال‌کننده</span>
                        <span>•</span>
                        <span>{formatNumber(userStats.following)} دنبال</span>
                        {profileSettings.visibility.showVideos && (
                          <>
                            <span>•</span>
                            <span>{userStats.totalVideos} ویدیو</span>
                          </>
                        )}
                      </>
                    )}
                  </div>
                  
                  <p className="text-sm text-muted-foreground max-w-2xl mb-3">
                    {userProfile.bio}
                  </p>
                  
                  <div className="flex items-center gap-2">
                    {isOwnProfile ? (
                      <>
                        <Button 
                          variant="outline"
                          onClick={() => onNavigate?.('profile-settings')}
                        >
                          <Edit3 className="h-4 w-4 ml-2" />
                          ویرایش پروفایل
                        </Button>
                        <Button 
                          variant="outline"
                          onClick={() => onNavigate?.('creator-upload')}
                        >
                          <Upload className="h-4 w-4 ml-2" />
                          آپلود محتوا
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button 
                          className={`${isFollowing ? 'bg-muted text-muted-foreground' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
                          onClick={handleFollow}
                        >
                          <UserPlus className="h-4 w-4 ml-2" />
                          {isFollowing ? 'دنبال می‌کنید' : 'دنبال کردن'}
                        </Button>
                        {profileSettings.privacy.allowDirectMessages && (
                          <Button variant="outline">
                            <MessageSquare className="h-4 w-4 ml-2" />
                            پیام
                          </Button>
                        )}
                        <Button variant="outline">
                          <Send className="h-4 w-4 ml-2" />
                          دعوت به بازی
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Desktop Stats */}
              {profileSettings.visibility.showStats && (
                <div className="grid grid-cols-2 gap-4 w-80">
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <div className="font-bold text-lg">{formatNumber(userStats.totalViews)}</div>
                    <p className="text-xs text-muted-foreground">بازدید کل</p>
                  </div>
                  {profileSettings.visibility.showEarnings && isOwnProfile && (
                    <div className="text-center p-3 bg-muted/50 rounded-lg">
                      <div className="font-bold text-lg text-green-600">{formatCurrency(userStats.totalEarnings)}</div>
                      <p className="text-xs text-muted-foreground">درآمد</p>
                    </div>
                  )}
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <div className="font-bold text-lg">{userStats.engagementRate}%</div>
                    <p className="text-xs text-muted-foreground">تعامل</p>
                  </div>
                  <div className="text-center p-3 bg-muted/50 rounded-lg">
                    <div className="font-bold text-lg">{userStats.winRate}%</div>
                    <p className="text-xs text-muted-foreground">نرخ برد</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-background border-b border-border">
        <div className="max-w-7xl mx-auto px-3 md:px-4" dir="rtl">
          <div className="flex items-center gap-4 md:gap-8 overflow-x-auto scrollbar-hide">
            {profileSettings.visibility.showVideos && (
              <button
                onClick={() => setSelectedTab('videos')}
                className={`py-2 md:py-3 px-1 md:px-2 whitespace-nowrap border-b-2 transition-colors text-sm md:text-base ${
                  selectedTab === 'videos'
                    ? 'border-foreground text-foreground font-medium' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                ویدیوها ({userStats.totalVideos})
              </button>
            )}
            
            <button
              onClick={() => setSelectedTab('clips')}
              className={`py-2 md:py-3 px-1 md:px-2 whitespace-nowrap border-b-2 transition-colors text-sm md:text-base ${
                selectedTab === 'clips'
                  ? 'border-foreground text-foreground font-medium' 
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              کلیپ‌ها ({userStats.totalClips})
            </button>

            {profileSettings.visibility.showAchievements && (
              <button
                onClick={() => setSelectedTab('achievements')}
                className={`py-2 md:py-3 px-1 md:px-2 whitespace-nowrap border-b-2 transition-colors text-sm md:text-base ${
                  selectedTab === 'achievements'
                    ? 'border-foreground text-foreground font-medium' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                دستاوردها ({userProfile.achievements.length})
              </button>
            )}
            
            <button
              onClick={() => setSelectedTab('about')}
              className={`py-2 md:py-3 px-1 md:px-2 whitespace-nowrap border-b-2 transition-colors text-sm md:text-base ${
                selectedTab === 'about'
                  ? 'border-foreground text-foreground font-medium' 
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              درباره
            </button>
          </div>
        </div>
      </div>

      {/* Tab Content */}
      <div className="max-w-7xl mx-auto px-3 md:px-4 py-3 md:py-6 pb-safe">
        {/* Videos Tab */}
        {selectedTab === 'videos' && profileSettings.visibility.showVideos && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-4">
            {userVideos.map((video) => (
              <div key={video.id} className="group cursor-pointer">
                {/* Thumbnail */}
                <div className="relative aspect-video bg-muted rounded-lg md:rounded-xl overflow-hidden mb-2 md:mb-3">
                  <ImageWithFallback
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                  
                  <div className="absolute bottom-1 md:bottom-2 left-1 md:left-2 bg-black/80 text-white text-xs px-1.5 md:px-2 py-0.5 md:py-1 rounded">
                    {video.duration}
                  </div>

                  {video.trending && (
                    <div className="absolute top-1 md:top-2 right-1 md:right-2 bg-red-500 text-white text-xs px-1.5 md:px-2 py-0.5 md:py-1 rounded flex items-center gap-1">
                      <TrendingUp className="h-2.5 w-2.5 md:h-3 md:w-3" />
                      <span className="hidden sm:inline">#ترند</span>
                    </div>
                  )}

                  <div className="absolute inset-0 bg-black/0 md:group-hover:bg-black/20 transition-colors flex items-center justify-center">
                    <Button 
                      size="lg" 
                      className="opacity-0 md:group-hover:opacity-100 transition-opacity rounded-full"
                      onClick={() => handleVideoPlay(video.id)}
                    >
                      <Play className="h-4 w-4 md:h-6 md:w-6" />
                    </Button>
                  </div>
                </div>

                {/* Video Info */}
                <div className="space-y-1">
                  <h3 className="font-medium line-clamp-2 text-xs md:text-sm leading-4 md:leading-5 group-hover:text-primary transition-colors">
                    {video.title}
                  </h3>

                  <div className="flex items-center gap-1 text-xs md:text-sm text-muted-foreground">
                    <span>{formatNumber(video.views)} بازدید</span>
                    <span>•</span>
                    <span>{video.uploadDate}</span>
                    {video.monetized && profileSettings.visibility.showEarnings && isOwnProfile && (
                      <>
                        <span className="hidden md:inline">•</span>
                        <span className="text-green-600 hidden md:inline">
                          {formatCurrency(video.earnings)}
                        </span>
                      </>
                    )}
                  </div>

                  {video.game && profileSettings.visibility.showGames && (
                    <Badge variant="secondary" className="text-xs px-1.5 py-0.5">
                      <Gamepad2 className="h-2.5 w-2.5 md:h-3 md:w-3 mr-0.5 md:mr-1" />
                      {video.game}
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Clips Tab */}
        {selectedTab === 'clips' && (
          <div className="text-center py-12">
            <Video className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-semibold mb-2">هنوز کلیپی آپلود نشده</h3>
            <p className="text-muted-foreground mb-4">
              {isOwnProfile 
                ? 'اولین کلیپ خود را از بازی‌هایتان آپلود کنید' 
                : 'هنوز کلیپی در این پروفایل وجود ندارد'}
            </p>
            {isOwnProfile && (
              <Button>
                <Upload className="h-4 w-4 ml-2" />
                آپلود کلیپ
              </Button>
            )}
          </div>
        )}

        {/* Achievements Tab */}
        {selectedTab === 'achievements' && profileSettings.visibility.showAchievements && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {userProfile.achievements.slice(0, showAllAchievements ? undefined : 6).map((achievement) => (
                <Card key={achievement.id} className={`overflow-hidden ${getRarityColor(achievement.rarity)}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="text-2xl">{achievement.icon}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">{achievement.name}</h3>
                          <Badge variant="secondary" className="text-xs">
                            {achievement.rarity === 'legendary' ? 'افسانه‌ای' : 
                             achievement.rarity === 'epic' ? 'حماسی' :
                             achievement.rarity === 'rare' ? 'نادر' : 'معمولی'}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">{achievement.description}</p>
                        <p className="text-xs text-muted-foreground">{achievement.unlockedAt}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {userProfile.achievements.length > 6 && (
              <div className="text-center">
                <Button 
                  variant="outline" 
                  onClick={() => setShowAllAchievements(!showAllAchievements)}
                >
                  {showAllAchievements ? 'کمتر نشان بده' : `مشاهده ${userProfile.achievements.length - 6} دستاورد دیگر`}
                </Button>
              </div>
            )}
          </div>
        )}

        {/* About Tab */}
        {selectedTab === 'about' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>درباره {userProfile.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">بیوگرافی</h4>
                  <p className="text-muted-foreground">{userProfile.bio}</p>
                </div>
                
                {userProfile.location && (
                  <div>
                    <h4 className="font-medium mb-2">موقعیت</h4>
                    <p className="text-muted-foreground flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      {userProfile.location}
                    </p>
                  </div>
                )}

                <div>
                  <h4 className="font-medium mb-2">تاریخ عضویت</h4>
                  <p className="text-muted-foreground flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {userProfile.joinDate}
                  </p>
                </div>

                {profileSettings.visibility.showGames && userProfile.favoriteGames.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">بازی‌های مورد علاقه</h4>
                    <div className="flex flex-wrap gap-2">
                      {userProfile.favoriteGames.map((game) => (
                        <Badge key={game} variant="secondary">
                          <Gamepad2 className="h-3 w-3 mr-1" />
                          {game}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {profileSettings.visibility.showBadges && userProfile.badges.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">نشان‌ها</h4>
                    <div className="flex flex-wrap gap-2">
                      {userProfile.badges.map((badge) => (
                        <Badge key={badge.id} className={`bg-${badge.color}-500/10 text-${badge.color}-600`}>
                          <span className="mr-1">{badge.icon}</span>
                          {badge.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {Object.keys(userProfile.socialLinks).length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">شبکه‌های اجتماعی</h4>
                    <div className="flex gap-2">
                      {userProfile.socialLinks.youtube && (
                        <Button variant="outline" size="sm">
                          <Youtube className="h-4 w-4 ml-1 text-red-500" />
                          YouTube
                        </Button>
                      )}
                      {userProfile.socialLinks.twitch && (
                        <Button variant="outline" size="sm">
                          <Twitch className="h-4 w-4 ml-1 text-purple-500" />
                          Twitch
                        </Button>
                      )}
                      {userProfile.socialLinks.discord && (
                        <Button variant="outline" size="sm">
                          <Discord className="h-4 w-4 ml-1 text-blue-500" />
                          Discord
                        </Button>
                      )}
                      {userProfile.socialLinks.instagram && (
                        <Button variant="outline" size="sm">
                          <Instagram className="h-4 w-4 ml-1 text-pink-500" />
                          Instagram
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

export default UserProfilePage;