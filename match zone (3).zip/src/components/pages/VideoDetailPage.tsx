/**
 * Video Detail Page - YouTube-style for Matchzone Gaming Platform
 * صفحه جزئیات ویدیو - مشابه یوتیوب برای پلتفرم گیمینگ
 */

'use client';

import React, { useState, useRef, useEffect } from 'react';
import { 
  Play, Pause, Volume2, VolumeX, Maximize, Settings, 
  ThumbsUp, ThumbsDown, Share2, Download, Flag, 
  MoreHorizontal, Bell, BellOff, Heart, Eye, Clock,
  Users, Star, Award, Gift, Coins, Gamepad2, TrendingUp,
  MessageCircle, Send, Smile, Pin, Reply, ChevronDown,
  CheckCircle, DollarSign, Crown, Zap, Video
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '../ui/avatar';
import { Separator } from '../ui/separator';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Slider } from '../ui/slider';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { formatNumber, formatCurrency } from '../../utils/dateHelpers';

interface VideoDetailPageProps {
  videoId?: string;
}

interface VideoData {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  videoUrl: string;
  duration: string;
  views: number;
  likes: number;
  dislikes: number;
  comments: number;
  uploadDate: string;
  game: string;
  tags: string[];
  creator: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    verified: boolean;
    subscribers: number;
    isLive: boolean;
  };
  monetization: {
    enabled: boolean;
    tips: number;
    earnings: number;
    supporters: number;
  };
  stats: {
    shares: number;
    saves: number;
    avgWatchTime: string;
    engagement: number;
  };
}

interface Comment {
  id: string;
  user: {
    name: string;
    avatar: string;
    verified: boolean;
    level: number;
  };
  content: string;
  timestamp: string;
  likes: number;
  replies: number;
  isPinned?: boolean;
}

export function VideoDetailPage({ videoId = 'v123' }: VideoDetailPageProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [showDescription, setShowDescription] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [tipAmount, setTipAmount] = useState(0);
  const [showTipModal, setShowTipModal] = useState(false);

  // Mock video data
  const videoData: VideoData = {
    id: videoId,
    title: '🔥 VALORANT ACE CLUTCH | نحوه انجام کلاچ حرفه‌ای در ولورنت',
    description: `در این ویدیو یاد می‌گیرید که چطور در شرایط 1 در مقابل 5 کلاچ کنید و تیم دشمن را شکست دهید.

📈 نکات کلیدی این ویدیو:
✅ موقعیت‌گیری درست
✅ مدیریت اقتصاد
✅ استفاده از utility ها
✅ تایمینگ درست
✅ کنترل اعصاب

🎮 بازی: VALORANT
🏆 رنک: Immortal 3
⏱️ مدت زمان بازی: 45 دقیقه
💎 Agent: Jett

#VALORANT #Gaming #Clutch #Esports #Persian`,
    thumbnail: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwZ2FtaW5nfGVufDB8fHx8MTY5ODM3MTIwMHww&ixlib=rb-4.1.0&q=80&w=1080',
    videoUrl: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
    duration: '12:34',
    views: 125439,
    likes: 8932,
    dislikes: 167,
    comments: 1247,
    uploadDate: '2 روز پیش',
    game: 'VALORANT',
    tags: ['VALORANT', 'ACE', 'Clutch', 'Gaming', 'Tutorial'],
    creator: {
      id: 'creator1',
      name: 'کیانوش گیمر',
      username: '@kianush_gamer',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMG1hbnxlbnwwfHx8fDE2OTgzNzEyMDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      verified: true,
      subscribers: 89234,
      isLive: false
    },
    monetization: {
      enabled: true,
      tips: 45600,
      earnings: 230000,
      supporters: 342
    },
    stats: {
      shares: 2847,
      saves: 5632,
      avgWatchTime: '8:23',
      engagement: 94.2
    }
  };

  // Mock comments
  const comments: Comment[] = [
    {
      id: '1',
      user: {
        name: 'علی محمدی',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdHxlbnwwfHx8fDE2OTgzNzEyMDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
        verified: false,
        level: 25
      },
      content: 'واقعاً عالی بود! نحوه کلاچ کردنت رو دیدم و خیلی یاد گرفتم. ممنون از آموزش عالی 🔥',
      timestamp: '2 ساعت پیش',
      likes: 234,
      replies: 12,
      isPinned: true
    },
    {
      id: '2',
      user: {
        name: 'مریم رضایی',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdHxlbnwwfHx8fDE2OTgzNzEyMDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
        verified: true,
        level: 42
      },
      content: 'من هم تونستم با این روش کلاچ کنم! خیلی کاربردی بود',
      timestamp: '5 ساعت پیش',
      likes: 89,
      replies: 3
    },
    {
      id: '3',
      user: {
        name: 'امیرحسین',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdHxlbnwwfHx8fDE2OTgzNzEyMDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
        verified: false,
        level: 18
      },
      content: 'ویدیو بعدی رو کی میذاری؟',
      timestamp: '1 روز پیش',
      likes: 45,
      replies: 1
    }
  ];

  // Related videos
  const relatedVideos = [
    {
      id: 'v2',
      title: 'راهنمای کامل اسکین‌های VALORANT',
      thumbnail: 'https://images.unsplash.com/photo-1560253023-3ec5d502959f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cHxlbnwwfHx8fDE2OTgzNzEyMDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      creator: 'کیانوش گیمر',
      views: 98234,
      duration: '15:23',
      uploadDate: '4 روز پیش'
    },
    {
      id: 'v3',
      title: 'بهترین تنظیمات VALORANT 2024',
      thumbnail: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBkZXNrdG9wfGVufDB8fHx8MTY5ODM3MTIwMHww&ixlib=rb-4.1.0&q=80&w=1080',
      creator: 'تکنو گیمر',
      views: 156789,
      duration: '8:45',
      uploadDate: '1 هفته پیش'
    },
    {
      id: 'v4',
      title: 'CS2 vs VALORANT - کدام بهتر است؟',
      thumbnail: 'https://images.unsplash.com/photo-1552820728-8b83bb6b773f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmcfGVufDB8fHx8MTY5ODM3MTIwMHww&ixlib=rb-4.1.0&q=80&w=1080',
      creator: 'پرو گیمرز',
      views: 234567,
      duration: '22:16',
      uploadDate: '3 روز پیش'
    }
  ];

  // Video player functions
  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    if (videoRef.current) {
      videoRef.current.volume = value[0] / 100;
      setVolume(value[0] / 100);
      setIsMuted(value[0] === 0);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    if (isDisliked) setIsDisliked(false);
  };

  const handleDislike = () => {
    setIsDisliked(!isDisliked);
    if (isLiked) setIsLiked(false);
  };

  const handleSubscribe = () => {
    setIsSubscribed(!isSubscribed);
  };

  const handleTip = () => {
    if (tipAmount > 0) {
      // Here you would send the tip
      console.log(`Tipping ${tipAmount} coins`);
      setShowTipModal(false);
      setTipAmount(0);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-safe">
      {/* Video Player Section */}
      <div className="relative bg-black">
        <div className="max-w-6xl mx-auto">
          {/* Video Player */}
          <div className="relative aspect-video bg-black group">
            <video
              ref={videoRef}
              className="w-full h-full"
              poster={videoData.thumbnail}
              onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
              onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            >
              <source src={videoData.videoUrl} type="video/mp4" />
            </video>

            {/* Video Controls Overlay */}
            <div className={`absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
              {/* Play Button Overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <Button
                  size="lg"
                  onClick={togglePlay}
                  className="bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full h-16 w-16 p-0"
                >
                  {isPlaying ? (
                    <Pause className="h-8 w-8 text-white" />
                  ) : (
                    <Play className="h-8 w-8 text-white ml-1" />
                  )}
                </Button>
              </div>

              {/* Bottom Controls */}
              <div className="absolute bottom-0 left-0 right-0 p-4 space-y-2">
                {/* Progress Bar */}
                <div className="flex items-center gap-2 text-white text-sm">
                  <span>{formatTime(currentTime)}</span>
                  <Progress 
                    value={(currentTime / duration) * 100} 
                    className="flex-1 h-1 bg-white/20"
                  />
                  <span>{formatTime(duration)}</span>
                </div>

                {/* Control Buttons */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={togglePlay}
                      className="text-white hover:bg-white/20"
                    >
                      {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </Button>

                    <div className="flex items-center gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={toggleMute}
                        className="text-white hover:bg-white/20"
                      >
                        {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                      </Button>
                      <Slider
                        value={[isMuted ? 0 : volume * 100]}
                        onValueChange={handleVolumeChange}
                        max={100}
                        step={1}
                        className="w-20 hidden md:block"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-white hover:bg-white/20"
                    >
                      <Settings className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-white hover:bg-white/20"
                    >
                      <Maximize className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-6xl mx-auto px-3 md:px-4 py-4 md:py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-4 md:space-y-6">
            {/* Video Info */}
            <div className="space-y-3 md:space-y-4" dir="rtl">
              {/* Title & Game Badge */}
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <Badge variant="secondary" className="bg-red-500/10 text-red-500 flex-shrink-0">
                    <Gamepad2 className="h-3 w-3 mr-1" />
                    {videoData.game}
                  </Badge>
                  {videoData.tags.includes('Trending') && (
                    <Badge variant="secondary" className="bg-orange-500/10 text-orange-500">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      ترند
                    </Badge>
                  )}
                </div>
                
                <h1 className="text-lg md:text-xl font-bold leading-tight">
                  {videoData.title}
                </h1>
              </div>

              {/* Stats & Actions */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                {/* Views & Date */}
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    {formatNumber(videoData.views)} بازدید
                  </span>
                  <span>•</span>
                  <span>{videoData.uploadDate}</span>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2">
                  {/* Like/Dislike */}
                  <div className="flex items-center bg-muted rounded-full">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={handleLike}
                      className={`rounded-r-none px-3 ${isLiked ? 'text-blue-500' : ''}`}
                    >
                      <ThumbsUp className="h-4 w-4 ml-1" />
                      {formatNumber(videoData.likes + (isLiked ? 1 : 0))}
                    </Button>
                    <Separator orientation="vertical" className="h-8" />
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={handleDislike}
                      className={`rounded-l-none px-3 ${isDisliked ? 'text-red-500' : ''}`}
                    >
                      <ThumbsDown className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* Share */}
                  <Button size="sm" variant="outline">
                    <Share2 className="h-4 w-4 ml-1" />
                    اشتراک
                  </Button>

                  {/* Download */}
                  <Button size="sm" variant="outline">
                    <Download className="h-4 w-4 ml-1" />
                    دانلود
                  </Button>

                  {/* More */}
                  <Button size="sm" variant="outline" className="px-2">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Creator Info */}
            <Card>
              <CardContent className="p-4" dir="rtl">
                <div className="flex items-start gap-3">
                  {/* Creator Avatar */}
                  <Avatar className="h-10 w-10 md:h-12 md:w-12 flex-shrink-0">
                    <AvatarImage src={videoData.creator.avatar} />
                    <AvatarFallback>{videoData.creator.name.charAt(0)}</AvatarFallback>
                  </Avatar>

                  {/* Creator Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-sm md:text-base">{videoData.creator.name}</h3>
                      {videoData.creator.verified && (
                        <CheckCircle className="h-4 w-4 text-blue-500" />
                      )}
                      {videoData.creator.isLive && (
                        <Badge variant="destructive" className="text-xs">
                          زنده
                        </Badge>
                      )}
                    </div>
                    
                    <p className="text-xs md:text-sm text-muted-foreground mb-2">
                      {formatNumber(videoData.creator.subscribers)} دنبال‌کننده
                    </p>

                    {/* Description Preview */}
                    <div className={`text-sm ${!showDescription ? 'line-clamp-2' : ''}`}>
                      {videoData.description.split('\n').map((line, index) => (
                        <p key={index} className="mb-1">{line}</p>
                      ))}
                    </div>
                    
                    {videoData.description.length > 150 && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setShowDescription(!showDescription)}
                        className="p-0 h-auto text-blue-500 hover:text-blue-600 text-sm"
                      >
                        {showDescription ? 'کمتر نشان بده' : 'بیشتر نشان بده'}
                      </Button>
                    )}
                  </div>

                  {/* Subscribe & Tip */}
                  <div className="flex flex-col gap-2 flex-shrink-0">
                    <Button
                      onClick={handleSubscribe}
                      className={`${
                        isSubscribed 
                          ? 'bg-muted text-foreground hover:bg-muted/80' 
                          : 'bg-red-600 hover:bg-red-700 text-white'
                      } text-sm px-4`}
                    >
                      {isSubscribed ? (
                        <>
                          <Bell className="h-4 w-4 ml-1" />
                          دنبال شده
                        </>
                      ) : (
                        <>
                          دنبال کردن
                        </>
                      )}
                    </Button>

                    {/* Tip Button */}
                    {videoData.monetization.enabled && (
                      <Dialog open={showTipModal} onOpenChange={setShowTipModal}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" className="text-sm">
                            <Gift className="h-4 w-4 ml-1" />
                            حمایت
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md" dir="rtl">
                          <DialogHeader>
                            <DialogTitle>حمایت از کریتور</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <label className="text-sm font-medium mb-2 block">مقدار حمایت (سکه)</label>
                              <Input
                                type="number"
                                value={tipAmount}
                                onChange={(e) => setTipAmount(Number(e.target.value))}
                                placeholder="مثال: 100"
                              />
                            </div>
                            <div className="flex gap-2">
                              {[50, 100, 500, 1000].map((amount) => (
                                <Button
                                  key={amount}
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setTipAmount(amount)}
                                  className="flex-1"
                                >
                                  {amount}
                                </Button>
                              ))}
                            </div>
                            <Button onClick={handleTip} className="w-full">
                              <Coins className="h-4 w-4 ml-2" />
                              ارسال حمایت
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}
                  </div>
                </div>

                {/* Monetization Stats */}
                {videoData.monetization.enabled && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-sm font-semibold text-green-600">
                          {formatCurrency(videoData.monetization.tips)}
                        </div>
                        <p className="text-xs text-muted-foreground">حمایت‌ها</p>
                      </div>
                      <div>
                        <div className="text-sm font-semibold">
                          {videoData.monetization.supporters}
                        </div>
                        <p className="text-xs text-muted-foreground">حامیان</p>
                      </div>
                      <div>
                        <div className="text-sm font-semibold">
                          {videoData.stats.engagement}%
                        </div>
                        <p className="text-xs text-muted-foreground">تعامل</p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Comments Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base md:text-lg" dir="rtl">
                  <MessageCircle className="h-5 w-5" />
                  {formatNumber(videoData.comments)} نظر
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4" dir="rtl">
                {/* Add Comment */}
                <div className="flex gap-3">
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarImage src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb3J0cmFpdCUyMG1hbnxlbnwwfHx8fDE2OTgzNzEyMDB8MA&ixlib=rb-4.1.0&q=80&w=1080" />
                    <AvatarFallback>شما</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-2">
                    <Textarea
                      placeholder="نظر خود را بنویسید..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      rows={2}
                      className="resize-none"
                    />
                    <div className="flex justify-between items-center">
                      <div className="flex gap-2">
                        <Button size="sm" variant="ghost">
                          <Smile className="h-4 w-4" />
                        </Button>
                      </div>
                      <Button size="sm" disabled={!newComment.trim()}>
                        <Send className="h-4 w-4 ml-1" />
                        ارسال
                      </Button>
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Comments List */}
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex gap-3">
                      <Avatar className="h-8 w-8 flex-shrink-0">
                        <AvatarImage src={comment.user.avatar} />
                        <AvatarFallback>{comment.user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm">{comment.user.name}</span>
                          {comment.user.verified && (
                            <CheckCircle className="h-3 w-3 text-blue-500" />
                          )}
                          <Badge variant="outline" className="text-xs">
                            <Crown className="h-2 w-2 mr-1" />
                            {comment.user.level}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{comment.timestamp}</span>
                          {comment.isPinned && (
                            <Badge variant="secondary" className="text-xs">
                              <Pin className="h-2 w-2 mr-1" />
                              پین شده
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm">{comment.content}</p>
                        
                        <div className="flex items-center gap-3 text-xs">
                          <Button size="sm" variant="ghost" className="h-auto p-0 text-muted-foreground hover:text-foreground">
                            <ThumbsUp className="h-3 w-3 ml-1" />
                            {comment.likes}
                          </Button>
                          <Button size="sm" variant="ghost" className="h-auto p-0 text-muted-foreground hover:text-foreground">
                            <ThumbsDown className="h-3 w-3" />
                          </Button>
                          <Button size="sm" variant="ghost" className="h-auto p-0 text-muted-foreground hover:text-foreground">
                            <Reply className="h-3 w-3 ml-1" />
                            پاسخ
                          </Button>
                          {comment.replies > 0 && (
                            <Button size="sm" variant="ghost" className="h-auto p-0 text-blue-500 hover:text-blue-600">
                              <ChevronDown className="h-3 w-3 ml-1" />
                              {comment.replies} پاسخ
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Load More Comments */}
                <Button variant="outline" className="w-full">
                  نمایش نظرات بیشتر
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Related Videos */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-base md:text-lg" dir="rtl">ویدیوهای مرتبط</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 p-3 md:p-6">
                {relatedVideos.map((video) => (
                  <div key={video.id} className="flex gap-3 group cursor-pointer" dir="rtl">
                    {/* Thumbnail */}
                    <div className="relative w-32 md:w-40 aspect-video bg-muted rounded-lg overflow-hidden flex-shrink-0">
                      <ImageWithFallback
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      />
                      <div className="absolute bottom-1 left-1 bg-black/80 text-white text-xs px-1 py-0.5 rounded">
                        {video.duration}
                      </div>
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm line-clamp-2 mb-1 group-hover:text-primary">
                        {video.title}
                      </h3>
                      <p className="text-xs text-muted-foreground mb-1">
                        {video.creator}
                      </p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <span>{formatNumber(video.views)} بازدید</span>
                        <span>•</span>
                        <span>{video.uploadDate}</span>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Load More */}
                <Button variant="outline" size="sm" className="w-full">
                  ویدیوهای بیشتر
                </Button>
              </CardContent>
            </Card>

            {/* Creator's Other Videos */}
            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2" dir="rtl">
                  <Video className="h-4 w-4" />
                  سایر ویدیوهای {videoData.creator.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 p-3 md:p-6">
                {relatedVideos.slice(0, 2).map((video) => (
                  <div key={video.id} className="flex gap-3 group cursor-pointer" dir="rtl">
                    <div className="relative w-24 md:w-32 aspect-video bg-muted rounded-lg overflow-hidden flex-shrink-0">
                      <ImageWithFallback
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      />
                      <div className="absolute bottom-1 left-1 bg-black/80 text-white text-xs px-1 py-0.5 rounded">
                        {video.duration}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm line-clamp-2 mb-1 group-hover:text-primary">
                        {video.title}
                      </h3>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <span>{formatNumber(video.views)} بازدید</span>
                        <span>•</span>
                        <span>{video.uploadDate}</span>
                      </div>
                    </div>
                  </div>
                ))}
                
                <Button variant="outline" size="sm" className="w-full">
                  مشاهده کانال
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}