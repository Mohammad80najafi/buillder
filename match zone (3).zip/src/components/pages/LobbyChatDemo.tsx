/**
 * Lobby Chat Demo Page
 * نمایش و تست سیستم چت لابی
 */

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { LobbyChatSystem } from '../gaming/LobbyChatSystem';
import { 
  MessageCircle, 
  Users, 
  Shield, 
  Crown, 
  Lock,
  UserCheck,
  UserX,
  Clock
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

type MembershipStatus = 'none' | 'pending' | 'approved' | 'rejected';

export function LobbyChatDemo() {
  const [membershipStatus, setMembershipStatus] = useState<MembershipStatus>('none');
  const [selectedUser, setSelectedUser] = useState('user1');

  const mockUsers = {
    user1: {
      id: 'user1',
      username: 'گیمر_پرو',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face',
      role: 'member' as const
    },
    user2: {
      id: 'user2',
      username: 'کاپیتان_تیم',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      role: 'owner' as const
    },
    user3: {
      id: 'user3',
      username: 'ادمین_لابی',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      role: 'admin' as const
    }
  };

  const mockMembers = [
    {
      id: '1',
      username: 'کاپیتان_پرو',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      role: 'owner' as const,
      isOnline: true
    },
    {
      id: '2',
      username: 'اسنایپر_پرو',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
      role: 'member' as const,
      isOnline: true
    },
    {
      id: '3',
      username: 'گیمر_فوری',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      role: 'member' as const,
      isOnline: false
    },
    {
      id: '4',
      username: 'تکتیک_استاد',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face',
      role: 'admin' as const,
      isOnline: true
    }
  ];

  const currentUser = mockUsers[selectedUser as keyof typeof mockUsers];

  const getStatusIcon = (status: MembershipStatus) => {
    switch (status) {
      case 'approved':
        return <UserCheck className="w-4 h-4 text-green-400" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'rejected':
        return <UserX className="w-4 h-4 text-red-400" />;
      default:
        return <Lock className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusText = (status: MembershipStatus) => {
    switch (status) {
      case 'approved':
        return 'عضو تایید شده';
      case 'pending':
        return 'در انتظار تایید';
      case 'rejected':
        return 'درخواست رد شده';
      default:
        return 'غیر عضو';
    }
  };

  const getStatusColor = (status: MembershipStatus) => {
    switch (status) {
      case 'approved':
        return 'bg-green-500/10 text-green-400 border-green-500/20';
      case 'pending':
        return 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
      case 'rejected':
        return 'bg-red-500/10 text-red-400 border-red-500/20';
      default:
        return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
    }
  };

  const handleStatusChange = (newStatus: MembershipStatus) => {
    setMembershipStatus(newStatus);
    
    const statusMessages = {
      none: 'وضعیت به غیر عضو تغییر کرد',
      pending: 'درخواست عضویت ارسال شد',
      approved: 'عضویت تایید شد! حالا می‌توانید چت کنید',
      rejected: 'درخواست عضویت رد شد'
    };

    toast.info(statusMessages[newStatus]);
  };

  return (
    <div className="min-h-screen bg-background p-4" dir="rtl">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-3">
            <MessageCircle className="w-8 h-8 text-blue-400" />
            <h1 className="text-3xl font-bold">نمایش سیستم چت لابی</h1>
          </div>
          <p className="text-muted-foreground">
            تست عملکرد چت لابی با سطوح دسترسی مختلف
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Control Panel */}
          <div className="space-y-4">
            {/* User Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  انتخاب کاربر
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(mockUsers).map(([key, user]) => (
                  <button
                    key={key}
                    onClick={() => setSelectedUser(key)}
                    className={`w-full p-3 rounded-lg border-2 text-right transition-all ${
                      selectedUser === key
                        ? 'border-blue-500 bg-blue-500/10'
                        : 'border-border hover:border-border/80'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={user.avatar}
                        alt={user.username}
                        className="w-8 h-8 rounded-full"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{user.username}</span>
                          {user.role === 'owner' && <Crown className="w-3 h-3 text-yellow-400" />}
                          {user.role === 'admin' && <Shield className="w-3 h-3 text-blue-400" />}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {user.role === 'owner' ? 'میزبان' : user.role === 'admin' ? 'ادمین' : 'عضو'}
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* Membership Status Control */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>وضعیت عضویت</span>
                  <Badge className={getStatusColor(membershipStatus)}>
                    {getStatusIcon(membershipStatus)}
                    <span className="mr-1">{getStatusText(membershipStatus)}</span>
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {(['none', 'pending', 'approved', 'rejected'] as MembershipStatus[]).map((status) => (
                  <Button
                    key={status}
                    variant={membershipStatus === status ? "default" : "outline"}
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => handleStatusChange(status)}
                  >
                    {getStatusIcon(status)}
                    <span className="mr-2">{getStatusText(status)}</span>
                  </Button>
                ))}
              </CardContent>
            </Card>

            {/* Info */}
            <Card>
              <CardHeader>
                <CardTitle>راهنما</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="space-y-1">
                  <p className="font-medium">🔒 غیر عضو:</p>
                  <p className="text-muted-foreground">نمی‌تواند چت را ببیند یا پیام ارسال کند</p>
                </div>
                
                <div className="space-y-1">
                  <p className="font-medium">⏳ در انتظار:</p>
                  <p className="text-muted-foreground">نمی‌تواند چت کند تا تایید شود</p>
                </div>
                
                <div className="space-y-1">
                  <p className="font-medium">✅ تایید شده:</p>
                  <p className="text-muted-foreground">دسترسی کامل به چت و ارسال پیام</p>
                </div>
                
                <div className="space-y-1">
                  <p className="font-medium">❌ رد شده:</p>
                  <p className="text-muted-foreground">دسترسی محدود شده</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat System */}
          <div className="xl:col-span-2">
            <div className="h-[600px]">
              <LobbyChatSystem
                lobbyId="demo-lobby-1"
                currentUser={currentUser}
                membershipStatus={membershipStatus}
                members={mockMembers}
                onSendMessage={(message) => {
                  toast.success('پیام ارسال شد!', {
                    description: message.length > 50 ? message.slice(0, 50) + '...' : message
                  });
                }}
              />
            </div>
          </div>
        </div>

        {/* Features Info */}
        <Card>
          <CardHeader>
            <CardTitle>ویژگی‌های سیستم چت</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-green-400 rounded-full mt-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">کنترل دسترسی</p>
                  <p className="text-muted-foreground">فقط اعضای تایید شده می‌توانند چت کنند</p>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">نقش‌های کاربری</p>
                  <p className="text-muted-foreground">نمایش نقش میزبان، ادمین و عضو</p>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-purple-400 rounded-full mt-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">پیام‌های سیستم</p>
                  <p className="text-muted-foreground">اعلان‌های ورود/خروج و سیستمی</p>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">وضعیت آنلاین</p>
                  <p className="text-muted-foreground">نمایش اعضای آنلاین و آفلاین</p>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-red-400 rounded-full mt-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">تایید پیام</p>
                  <p className="text-muted-foreground">نمایش وضعیت تحویل پیام</p>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 bg-teal-400 rounded-full mt-2 flex-shrink-0" />
                <div>
                  <p className="font-medium">UI واکنشگرا</p>
                  <p className="text-muted-foreground">طراحی موبایل و دسکتاپ</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default LobbyChatDemo;