import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { ConnectedSocialFeatures } from '../social/ConnectedSocialFeatures';
import { NotificationSettingsSection } from '../system/NotificationSettingsSection';
import { useNotificationService, useSocialNotifications, useGamingNotifications } from '../system/NotificationService';
import { Bell, Settings, Users, Gamepad2, Activity, Zap } from 'lucide-react';
import { motion } from 'motion/react';

export function ConnectedNotificationDemo() {
  const { notifications, getUnreadCount, clearAllNotifications } = useNotificationService();
  const socialNotifications = useSocialNotifications();
  const gamingNotifications = useGamingNotifications();
  
  const [activeTab, setActiveTab] = useState('demo');
  
  const unreadCount = getUnreadCount();

  const runStressTest = async () => {
    // Test multiple rapid notifications
    const testSequence = [
      () => socialNotifications.notifyNewFollow('گیمر_1'),
      () => socialNotifications.notifyNewMessage('دوست_2', 'سلام! چطوری؟'),
      () => gamingNotifications.notifyMatchFound('CS:GO'),
      () => socialNotifications.notifyLike('کاربر_3'),
      () => gamingNotifications.notifyAchievement('First Blood'),
      () => socialNotifications.notifyNewPost('استریمر_4', 'ویدیو'),
      () => gamingNotifications.notifyInvitation('پرو_پلیر', 'Valorant'),
    ];

    for (let i = 0; i < testSequence.length; i++) {
      setTimeout(() => testSequence[i](), i * 600);
    }
  };

  const quickTests = [
    {
      title: 'دنبال‌کننده جدید',
      action: () => socialNotifications.notifyNewFollow('گیمر_نو'),
      color: 'bg-blue-500/10 border-blue-500/30',
      icon: Users
    },
    {
      title: 'پیام جدید',
      action: () => socialNotifications.notifyNewMessage('دوست_گیمر', 'آماده بازی؟ 🎮'),
      color: 'bg-green-500/10 border-green-500/30', 
      icon: Bell
    },
    {
      title: 'بازی پیدا شد',
      action: () => gamingNotifications.notifyMatchFound('Valorant Competitive'),
      color: 'bg-purple-500/10 border-purple-500/30',
      icon: Gamepad2
    },
    {
      title: 'دستاورد جدید',
      action: () => gamingNotifications.notifyAchievement('Headshot Master 🎯'),
      color: 'bg-yellow-500/10 border-yellow-500/30',
      icon: Activity
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="relative">
              <Bell className="w-12 h-12 text-cyan-500" />
              {unreadCount > 0 && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                  {unreadCount}
                </div>
              )}
            </div>
            <Badge className="bg-gradient-to-r from-purple-600 to-cyan-600 text-white border-none px-4 py-2 text-lg">
              سیستم اعلانات متصل
            </Badge>
          </div>
          
          <h1 className="text-4xl font-bold text-white mb-2">
            Matchzone Notification System
          </h1>
          <p className="text-slate-300 text-lg">
            سیستم اعلانات هوشمند متصل به تمام اجزای اپلیکیشن
          </p>
        </motion.div>

        {/* Status Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-4"
        >
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-cyan-500">{notifications.length}</div>
              <div className="text-sm text-slate-400">کل اعلان‌ها</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-red-500">{unreadCount}</div>
              <div className="text-sm text-slate-400">خوانده نشده</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-500">
                {notifications.filter(n => n.category === 'gaming').length}
              </div>
              <div className="text-sm text-slate-400">گیمینگ</div>
            </CardContent>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-500">
                {notifications.filter(n => n.category === 'social').length}
              </div>
              <div className="text-sm text-slate-400">اجتماعی</div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Test Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500" />
                تست سریع
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                {quickTests.map((test, index) => {
                  const Icon = test.icon;
                  return (
                    <Button
                      key={index}
                      variant="outline"
                      onClick={test.action}
                      className={`${test.color} hover:bg-opacity-30 flex items-center gap-2`}
                    >
                      <Icon className="w-4 h-4" />
                      {test.title}
                    </Button>
                  );
                })}
              </div>
              
              <div className="flex gap-3 flex-wrap">
                <Button
                  onClick={runStressTest}
                  className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
                >
                  تست استرس (7 اعلان)
                </Button>
                
                {notifications.length > 0 && (
                  <Button
                    variant="destructive"
                    onClick={clearAllNotifications}
                  >
                    پاک کردن همه ({notifications.length})
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 bg-slate-800/50">
              <TabsTrigger value="demo" className="data-[state=active]:bg-purple-600">
                دمو تعاملی
              </TabsTrigger>
              <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600">
                تنظیمات
              </TabsTrigger>
            </TabsList>

            <TabsContent value="demo" className="mt-6">
              <ConnectedSocialFeatures />
            </TabsContent>

            <TabsContent value="settings" className="mt-6">
              <NotificationSettingsSection />
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Features List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">ویژگی‌های سیستم اعلانات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-3">🔗 اتصالات</h3>
                  <ul className="space-y-2 text-slate-300 text-sm">
                    <li>✅ دنبال کردن / دنبال‌کنندگان</li>
                    <li>✅ سیستم چت و پیام‌رسانی</li>
                    <li>✅ لابی‌ها و دعوت‌های بازی</li>
                    <li>✅ مسابقات و tournaments</li>
                    <li>✅ دستاوردها و achievements</li>
                    <li>✅ استریم‌ها و محتوای زنده</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-white mb-3">⚙️ قابلیت‌ها</h3>
                  <ul className="space-y-2 text-slate-300 text-sm">
                    <li>✅ شخصی‌سازی کامل تنظیمات</li>
                    <li>✅ دسته‌بندی هوشمند اعلان‌ها</li>
                    <li>✅ صدا و ویبریشن</li>
                    <li>✅ محدودیت تعداد نمایش</li>
                    <li>✅ تنظیم مدت زمان نمایش</li>
                    <li>✅ ذخیره‌سازی تنظیمات محلی</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}