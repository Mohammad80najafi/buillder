import React, { useState, useEffect } from 'react';
import { NotificationBanner } from '../system/NotificationBanner';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Sparkles, CheckCircle, Info, AlertTriangle, Gamepad2, Scroll } from 'lucide-react';
import { motion } from 'motion/react';
import { useMobile } from '../ui/use-mobile';

export function UpdatedFeaturesDemo() {
  const [showNotification, setShowNotification] = useState(false);
  const [notificationType, setNotificationType] = useState<'gaming' | 'success' | 'warning' | 'info'>('gaming');
  const isMobile = useMobile();

  // Auto-show welcome notification
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowNotification(true);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const features = [
    {
      title: 'اسکرولبار بهینه‌شده موبایل',
      description: 'اسکرولبار جدید برای موبایل باریک‌تر (3px) و با رنگ‌های دارک‌تر طراحی شده',
      icon: Scroll,
      improvements: [
        'عرض کاهش یافته از 6px به 3px',
        'رنگ‌های دارک‌تر و حرفه‌ای‌تر',
        'انیمیشن‌های نرم‌تر',
        'بهینه‌سازی برای صفحه‌نمایش‌های کوچک'
      ]
    },
    {
      title: 'سیستم اعلانات بهبود یافته',
      description: 'اعلانات با قابلیت dismiss کردن با swipe در موبایل و دکمه close در دسکتاپ',
      icon: Sparkles,
      improvements: [
        'Swipe gesture برای بستن در موبایل',
        'دکمه ضربدر برای دسکتاپ',
        'انیمیشن‌های ظریف framer motion',
        'پشتیبانی کامل از RTL'
      ]
    }
  ];

  const demoMessages = {
    gaming: '🎮 ویژگی‌های جدید فعال شد! اسکرولبار و اعلانات بهبود یافتند ✨',
    success: '✅ تغییرات با موفقیت اعمال شد! تجربه بهتری خواهید داشت',
    warning: '⚠️ توجه: اسکرولبار جدید فعال است. در صورت مشکل اطلاع دهید',
    info: 'ℹ️ نسخه جدید با اسکرولبار بهینه و سیستم اعلانات پیشرفته در دسترس است'
  };

  const handleShowNotification = (type: typeof notificationType) => {
    setNotificationType(type);
    setShowNotification(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4 gaming-scroll">
      <div className="max-w-4xl mx-auto pt-20">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="w-12 h-12 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-2xl flex items-center justify-center"
            >
              <Sparkles className="w-6 h-6 text-white" />
            </motion.div>
            <Badge className="bg-gradient-to-r from-purple-600 to-cyan-600 text-white border-none px-4 py-1">
              بروزرسانی جدید
            </Badge>
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">
            بهبودهای Matchzone
          </h1>
          <p className="text-slate-300 text-lg">
            اسکرولبار بهینه‌شده و سیستم اعلانات پیشرفته
          </p>
        </motion.div>

        {/* Demo Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Card className="p-6 bg-slate-800/50 backdrop-blur-lg border-slate-700">
            <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <Gamepad2 className="w-5 h-5" />
              آزمایش اعلانات
            </h2>
            <p className="text-slate-300 mb-4">
              {isMobile 
                ? 'برای بستن اعلان، آن را به چپ یا راست بکشید'
                : 'برای بستن اعلان، روی دکمه ضربدر کلیک کنید'
              }
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button
                onClick={() => handleShowNotification('gaming')}
                className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
              >
                Gaming
              </Button>
              <Button
                onClick={() => handleShowNotification('success')}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
              >
                موفق
              </Button>
              <Button
                onClick={() => handleShowNotification('warning')}
                className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700"
              >
                هشدار
              </Button>
              <Button
                onClick={() => handleShowNotification('info')}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              >
                اطلاعات
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* Features List */}
        <div className="grid gap-6 md:grid-cols-2 mb-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                <Card className="p-6 bg-slate-800/50 backdrop-blur-lg border-slate-700 hover:bg-slate-800/70 transition-all">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-white mb-2">
                        {feature.title}
                      </h3>
                      <p className="text-slate-300 mb-4 text-sm">
                        {feature.description}
                      </p>
                      <ul className="space-y-2">
                        {feature.improvements.map((improvement, i) => (
                          <li key={i} className="flex items-center gap-2 text-sm text-slate-400">
                            <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                            {improvement}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Scrollbar Demo Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="p-6 bg-slate-800/50 backdrop-blur-lg border-slate-700">
            <h2 className="text-xl font-semibold text-white mb-4">
              نمایش اسکرولبار جدید
            </h2>
            <div className="max-h-64 overflow-y-auto border border-slate-600 rounded-lg p-4 bg-slate-900/50 space-y-3">
              {Array.from({ length: 25 }, (_, i) => (
                <div key={i} className="p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full" />
                    <span className="text-slate-200">
                      آیتم {i + 1}: تست اسکرولبار جدید با طراحی بهینه‌شده برای موبایل
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-slate-400 text-sm mt-3">
              در این قسمت می‌توانید اسکرولبار جدید را مشاهده کنید. 
              {isMobile ? ' در موبایل باریک‌تر و دارک‌تر است.' : ' در دسکتاپ گرادیانت رنگارنگ دارد.'}
            </p>
          </Card>
        </motion.div>
      </div>

      {/* Notification */}
      {showNotification && (
        <NotificationBanner
          message={demoMessages[notificationType]}
          type={notificationType}
          onDismiss={() => setShowNotification(false)}
        />
      )}
    </div>
  );
}