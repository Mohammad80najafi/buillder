/**
 * Compact Mobile Chat Page - Ultra Mobile-First Design
 * صفحه چت کامپکت کاملاً موبایل محور
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Smile, 
  Plus, 
  Mic, 
  ArrowLeft,
  MoreVertical,
  Crown,
  Shield,
  Star,
  Zap,
  Users,
  Hash,
  Heart,
  ThumbsUp,
  Laugh,
  X
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  isOwn: boolean;
  type: 'text' | 'gift' | 'join';
  role: 'player' | 'admin' | 'vip' | 'moderator';
  avatar?: string;
  reactions?: { emoji: string; count: number }[];
}

interface ChatRoom {
  id: string;
  name: string;
  memberCount: number;
  onlineCount: number;
  type: 'public' | 'lobby' | 'tournament';
}

export function CompactMobileChatPage() {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [showEmojis, setShowEmojis] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickEmojis = ['😀', '😍', '🤔', '😮', '🔥', '💎', '🎯', '👏'];
  const reactionEmojis = ['❤️', '👍', '😂', '🔥'];

  const currentRoom: ChatRoom = {
    id: 'main',
    name: 'لابی اصلی',
    memberCount: 127,
    onlineCount: 89,
    type: 'lobby'
  };

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      username: 'گیمر طلایی',
      message: 'سلام بچه‌ها! 🎮',
      timestamp: new Date(Date.now() - 300000),
      isOwn: false,
      type: 'text',
      role: 'admin',
      avatar: '👑',
      reactions: [{ emoji: '🔥', count: 3 }, { emoji: '👍', count: 5 }]
    },
    {
      id: '2',
      username: 'سارا پرو',
      message: 'کسی برای تیم می‌خواد؟',
      timestamp: new Date(Date.now() - 240000),
      isOwn: false,
      type: 'text',
      role: 'vip',
      avatar: '⭐',
      reactions: [{ emoji: '👍', count: 2 }]
    },
    {
      id: '3',
      username: 'شما',
      message: 'آره! من آماده‌ام 💪',
      timestamp: new Date(Date.now() - 180000),
      isOwn: true,
      type: 'text',
      role: 'player',
      avatar: '🎯'
    },
    {
      id: '4',
      username: 'علی چمپیون',
      message: '',
      timestamp: new Date(Date.now() - 120000),
      isOwn: false,
      type: 'gift',
      role: 'player',
      avatar: '🏆'
    },
    {
      id: '5',
      username: 'مدیر تیم',
      message: 'بیاین VC 🎧',
      timestamp: new Date(Date.now() - 60000),
      isOwn: false,
      type: 'text',
      role: 'moderator',
      avatar: '🛡️'
    },
    {
      id: '6',
      username: 'شما',
      message: 'اومدم!',
      timestamp: new Date(Date.now() - 30000),
      isOwn: true,
      type: 'text',
      role: 'player',
      avatar: '🎯'
    }
  ]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      username: 'شما',
      message: message.trim(),
      timestamp: new Date(),
      isOwn: true,
      type: 'text',
      role: 'player',
      avatar: '🎯'
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const existingReaction = msg.reactions?.find(r => r.emoji === emoji);
        if (existingReaction) {
          return {
            ...msg,
            reactions: msg.reactions?.map(r => 
              r.emoji === emoji ? { ...r, count: r.count + 1 } : r
            )
          };
        } else {
          return {
            ...msg,
            reactions: [...(msg.reactions || []), { emoji, count: 1 }]
          };
        }
      }
      return msg;
    }));
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="w-2.5 h-2.5 text-yellow-400" />;
      case 'moderator': return <Shield className="w-2.5 h-2.5 text-blue-400" />;
      case 'vip': return <Star className="w-2.5 h-2.5 text-purple-400" />;
      default: return null;
    }
  };

  const MessageComponent = ({ message: msg }: { message: ChatMessage }) => (
    <motion.div 
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`mb-2 ${msg.isOwn ? 'text-left' : 'text-right'}`}
      dir={msg.isOwn ? 'ltr' : 'rtl'}
    >
      <div className={`flex items-start gap-2 ${msg.isOwn ? 'flex-row' : 'flex-row-reverse'}`}>
        {!msg.isOwn && (
          <Avatar className="w-6 h-6 flex-shrink-0">
            <AvatarFallback className="text-xs bg-gradient-to-br from-primary/30 to-accent/30">
              {msg.avatar || msg.username[0]}
            </AvatarFallback>
          </Avatar>
        )}
        
        <div className={`flex-1 min-w-0 ${msg.isOwn ? 'text-left' : 'text-right'}`}>
          {!msg.isOwn && (
            <div className="flex items-center gap-1 mb-0.5 px-1">
              {getRoleIcon(msg.role)}
              <span className="text-xs font-medium truncate max-w-20">{msg.username}</span>
              <span className="text-xs text-muted-foreground">
                {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          )}
          
          <div className={`max-w-[75%] ${msg.isOwn ? 'ml-auto' : 'mr-auto'}`}>
            {msg.type === 'gift' ? (
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 p-2 rounded-xl text-xs border border-yellow-500/30">
                <div className="flex items-center gap-1">
                  <Zap className="w-3 h-3 text-yellow-400" />
                  <span>هدیه فرستاد! 🎁</span>
                </div>
              </div>
            ) : msg.type === 'join' ? (
              <div className="bg-muted/50 text-center py-1 px-2 rounded-full text-xs text-muted-foreground">
                {msg.message}
              </div>
            ) : (
              <div className={`py-2 px-3 rounded-xl text-xs ${
                msg.isOwn 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-card border border-border/50'
              }`}>
                {msg.message}
                {msg.isOwn && (
                  <div className="text-xs opacity-70 mt-1">
                    {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                )}
              </div>
            )}
            
            {/* Reactions */}
            {msg.reactions && msg.reactions.length > 0 && (
              <div className="flex gap-1 mt-1">
                {msg.reactions.map((reaction, idx) => (
                  <motion.button
                    key={idx}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleReaction(msg.id, reaction.emoji)}
                    className="flex items-center gap-0.5 bg-muted/50 px-1.5 py-0.5 rounded-full text-xs border border-border/30"
                  >
                    <span>{reaction.emoji}</span>
                    <span className="text-xs">{reaction.count}</span>
                  </motion.button>
                ))}
              </div>
            )}
            
            {/* Quick Reactions */}
            {!msg.isOwn && (
              <div className="flex gap-1 mt-1 opacity-60">
                {reactionEmojis.map((emoji) => (
                  <motion.button
                    key={emoji}
                    whileTap={{ scale: 0.8 }}
                    onClick={() => handleReaction(msg.id, emoji)}
                    className="w-5 h-5 flex items-center justify-center bg-muted/30 rounded-full text-xs"
                  >
                    {emoji}
                  </motion.button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="h-screen w-full max-w-sm mx-auto flex flex-col bg-background overflow-hidden">
      {/* Compact Header */}
      <div className="flex-shrink-0 bg-card/95 backdrop-blur border-b border-border/50">
        <div className="flex items-center justify-between p-3">
          <div className="flex items-center gap-2 flex-1 min-w-0">
            <Button variant="ghost" size="sm" className="p-1 h-8 w-8">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <div className="relative">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-gradient-to-br from-primary/30 to-accent/30">
                    <Hash className="w-4 h-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 rounded-full border border-background" />
              </div>
              
              <div className="flex-1 min-w-0 text-right" dir="rtl">
                <h2 className="text-sm font-medium truncate">{currentRoom.name}</h2>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Users className="w-3 h-3" />
                  <span>{currentRoom.onlineCount}</span>
                </div>
              </div>
            </div>
          </div>
          
          <Button variant="ghost" size="sm" className="p-1 h-8 w-8">
            <MoreVertical className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Messages - Compact */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto px-3 py-2">
          {messages.map((msg) => (
            <MessageComponent key={msg.id} message={msg} />
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Emoji Picker */}
      <AnimatePresence>
        {showEmojis && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="flex-shrink-0 p-3 bg-card/95 border-t border-border/50"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium">Emoji</span>
              <Button 
                variant="ghost" 
                size="sm"
                className="p-1 h-6 w-6"
                onClick={() => setShowEmojis(false)}
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
            <div className="grid grid-cols-8 gap-2">
              {quickEmojis.map((emoji) => (
                <motion.button
                  key={emoji}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    setMessage(prev => prev + emoji);
                    setShowEmojis(false);
                  }}
                  className="w-6 h-6 flex items-center justify-center hover:bg-muted/50 rounded"
                >
                  {emoji}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Compact Input */}
      <div className="flex-shrink-0 p-3 bg-card/95 backdrop-blur border-t border-border/50">
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm"
            className="p-1 h-8 w-8 flex-shrink-0"
            onClick={() => setShowEmojis(!showEmojis)}
          >
            <Smile className="w-4 h-4" />
          </Button>
          
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="پیام..."
            className="flex-1 h-8 text-xs bg-muted/30 border-border/50 rounded-xl"
            dir="rtl"
          />
          
          <Button 
            variant="ghost" 
            size="sm"
            className={`p-1 h-8 w-8 flex-shrink-0 ${isRecording ? 'text-red-500' : ''}`}
            onClick={() => setIsRecording(!isRecording)}
          >
            <Mic className="w-4 h-4" />
          </Button>
          
          <Button 
            onClick={handleSendMessage}
            disabled={!message.trim()}
            size="sm"
            className="p-1 h-8 w-8 flex-shrink-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}