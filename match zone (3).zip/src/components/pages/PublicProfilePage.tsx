import React from 'react';
import { UserProfilePage } from './UserProfilePage';

interface PublicProfilePageProps {
  userId: string;
  onNavigate?: (page: string) => void;
}

export function PublicProfilePage({ userId, onNavigate }: PublicProfilePageProps) {
  return (
    <UserProfilePage 
      userId={userId}
      isOwnProfile={false}
      onNavigate={onNavigate}
    />
  );
}

export default PublicProfilePage;