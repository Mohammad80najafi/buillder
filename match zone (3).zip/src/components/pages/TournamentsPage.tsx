import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Progress } from '../ui/progress';
import { 
  Trophy, Users, Clock, DollarSign, Calendar, Search, Filter, 
  Medal, Crown, Star, Target, Gamepad2, Plus, Eye, Play,
  TrendingUp, Award, Globe, MapPin, AlertCircle, CheckCircle
} from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner@2.0.3';

interface Tournament {
  id: string;
  title: string;
  game: string;
  description: string;
  prize: string;
  prizePool: string;
  entryFee: number;
  participants: { current: number; max: number };
  status: 'registration' | 'started' | 'finished';
  startTime: string;
  startDate: string;
  organizer: { name: string; verified: boolean; avatar?: string };
  format: string;
  requirements: {
    minRank?: string;
    region?: string;
    age?: string;
  };
  teamSize: number;
}

export function TournamentsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [gameFilter, setGameFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedTournament, setSelectedTournament] = useState<string | null>(null);

  // Mock tournament data
  const tournaments: Tournament[] = [
    {
      id: 'tournament-1',
      title: 'کاپ طلایی کالاف دیوتی',
      game: 'کالاف دیوتی',
      description: 'بزرگترین تورنومنت ماه با جوایز نقدی عالی و حضور بهترین تیم‌های کشور',
      prize: '۱۰۰,۰۰۰ تومان',
      prizePool: '۵۰۰,۰۰۰ تومان',
      entryFee: 10000,
      participants: { current: 45, max: 64 },
      status: 'registration',
      startTime: '۲ ساعت دیگر',
      startDate: '۱۴۰۳/۰۸/۱۵',
      organizer: { 
        name: 'گیم‌هاب پرو', 
        verified: true, 
        avatar: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=64'
      },
      format: 'حذفی تک‌مرحله‌ای',
      requirements: {
        minRank: 'الماسی',
        region: 'ایران',
        age: '16+'
      },
      teamSize: 1
    },
    {
      id: 'tournament-2',
      title: 'لیگ فیفا ماهانه',
      game: 'فیفا 24',
      description: 'مسابقات ماهانه فیفا با سیستم لیگی و امکان صعود به لیگ‌های بالاتر',
      prize: '۵۰,۰۰۰ تومان',
      prizePool: '۲۰۰,۰۰۰ تومان',
      entryFee: 5000,
      participants: { current: 28, max: 32 },
      status: 'registration',
      startTime: 'فردا ۲۰:۰۰',
      startDate: '۱۴۰۳/۰۸/۱۶',
      organizer: { 
        name: 'تیم_فیفا_ایران', 
        verified: true,
        avatar: 'https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=64'
      },
      format: 'سیستم لیگی',
      requirements: {
        minRank: 'طلایی',
        region: 'ایران'
      },
      teamSize: 1
    },
    {
      id: 'tournament-3',
      title: 'مسابقات والورانت حرفه‌ای',
      game: 'والورانت',
      description: 'تورنومنت سطح بالا برای تیم‌های حرفه‌ای و بازیکنان با تجربه',
      prize: '۷۵,۰۰۰ تومان',
      prizePool: '۳۰۰,۰۰۰ تومان',
      entryFee: 15000,
      participants: { current: 16, max: 16 },
      status: 'started',
      startTime: 'شروع شده',
      startDate: '۱۴۰۳/۰۸/۱۴',
      organizer: { 
        name: 'والورانت_پرو_لیگ', 
        verified: false,
        avatar: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=64'
      },
      format: 'حذفی تیمی',
      requirements: {
        minRank: 'الماسی',
        region: 'ایران',
        age: '18+'
      },
      teamSize: 5
    }
  ];

  const filteredTournaments = tournaments.filter(tournament => {
    const matchesSearch = tournament.title.includes(searchQuery) || tournament.game.includes(searchQuery);
    const matchesGame = gameFilter === 'all' || tournament.game === gameFilter;
    const matchesStatus = statusFilter === 'all' || tournament.status === statusFilter;
    return matchesSearch && matchesGame && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'registration': return 'default';
      case 'started': return 'secondary';
      case 'finished': return 'destructive';
      default: return 'default';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'registration': return 'ثبت‌نام';
      case 'started': return 'در حال برگزاری';
      case 'finished': return 'تمام شده';
      default: return status;
    }
  };

  const getRegistrationProgress = (current: number, max: number) => {
    return (current / max) * 100;
  };

  const handleRegister = (tournamentId: string) => {
    toast.success('ثبت‌نام موفق!', {
      description: 'شما با موفقیت در تورنومنت ثبت‌نام شدید.'
    });
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div className="flex-1 text-right">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 rounded-xl border border-yellow-500/30">
              <Trophy className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <h1 className="font-bold bg-gradient-to-l from-yellow-400 via-orange-400 to-red-400 bg-clip-text text-transparent">
                تورنومنت‌ها
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <p className="text-muted-foreground">
                  {filteredTournaments.length} تورنومنت فعال • 64 بازیکن
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Plus className="w-4 h-4 ml-2" />
            برگزاری تورنومنت
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="text-center p-4 bg-gradient-to-br from-blue-500/5 to-blue-600/10 border-blue-500/20">
          <div className="text-2xl font-bold text-blue-500">{filteredTournaments.filter(t => t.status === 'registration').length}</div>
          <div className="text-sm text-muted-foreground">باز برای ثبت‌نام</div>
        </Card>
        
        <Card className="text-center p-4 bg-gradient-to-br from-green-500/5 to-green-600/10 border-green-500/20">
          <div className="text-2xl font-bold text-green-500">{filteredTournaments.filter(t => t.status === 'started').length}</div>
          <div className="text-sm text-muted-foreground">در حال برگزاری</div>
        </Card>
        
        <Card className="text-center p-4 bg-gradient-to-br from-yellow-500/5 to-yellow-600/10 border-yellow-500/20">
          <div className="text-2xl font-bold text-yellow-500">1,000,000</div>
          <div className="text-sm text-muted-foreground">تومان جایزه کل</div>
        </Card>
        
        <Card className="text-center p-4 bg-gradient-to-br from-purple-500/5 to-purple-600/10 border-purple-500/20">
          <div className="text-2xl font-bold text-purple-500">64</div>
          <div className="text-sm text-muted-foreground">بازیکن فعال</div>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="جستجوی تورنومنت..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
                dir="rtl"
              />
            </div>

            {/* Filter Controls */}
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="وضعیت" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  <SelectItem value="registration">ثبت‌نام</SelectItem>
                  <SelectItem value="started">در حال برگزاری</SelectItem>
                  <SelectItem value="finished">تمام شده</SelectItem>
                </SelectContent>
              </Select>

              <Select value={gameFilter} onValueChange={setGameFilter}>
                <SelectTrigger className="w-36">
                  <SelectValue placeholder="بازی" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه بازی‌ها</SelectItem>
                  <SelectItem value="کالاف دیوتی">کالاف دیوتی</SelectItem>
                  <SelectItem value="فیفا 24">فیفا 24</SelectItem>
                  <SelectItem value="والورانت">والورانت</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tournament List */}
      <div className="space-y-4">
        {filteredTournaments.map((tournament) => (
          <motion.div
            key={tournament.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="cursor-pointer transition-all duration-200 hover:shadow-lg">
              <CardContent className="p-6">
                <div className="grid md:grid-cols-4 gap-6 items-start">
                  {/* Tournament Info */}
                  <div className="md:col-span-2 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex flex-col items-end space-y-2">
                        <Badge variant={getStatusColor(tournament.status) as any}>
                          {getStatusText(tournament.status)}
                        </Badge>
                        {tournament.organizer.verified && (
                          <Badge variant="secondary" className="text-xs">
                            <Crown className="w-3 h-3 ml-1" />
                            معتبر
                          </Badge>
                        )}
                      </div>
                      <div className="text-right space-y-1 flex-1">
                        <h3 className="font-bold text-xl">{tournament.title}</h3>
                        <div className="flex items-center gap-2 justify-end">
                          <span className="text-primary font-medium">{tournament.game}</span>
                          <Gamepad2 className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <p className="text-sm text-muted-foreground">{tournament.description}</p>
                      </div>
                    </div>

                    {/* Tournament Details */}
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="text-right">
                        <div className="flex justify-between">
                          <span>{tournament.format}</span>
                          <span className="text-muted-foreground">فرمت:</span>
                        </div>
                        <div className="flex justify-between">
                          <span>{tournament.organizer.name}</span>
                          <span className="text-muted-foreground">برگزارکننده:</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex justify-between">
                          <span>{tournament.teamSize === 1 ? 'انفرادی' : `${tournament.teamSize} نفره`}</span>
                          <span className="text-muted-foreground">نوع:</span>
                        </div>
                        <div className="flex justify-between">
                          <span>{tournament.requirements.minRank || 'آزاد'}</span>
                          <span className="text-muted-foreground">حداقل رنک:</span>
                        </div>
                      </div>
                    </div>

                    {/* Registration Progress */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{tournament.participants.current}/{tournament.participants.max}</span>
                        <span>شرکت‌کنندگان</span>
                      </div>
                      <Progress value={getRegistrationProgress(tournament.participants.current, tournament.participants.max)} />
                    </div>
                  </div>

                  {/* Prize & Timing */}
                  <div className="space-y-4 text-right">
                    <div className="space-y-3">
                      <div className="text-center p-4 bg-gradient-to-br from-yellow-500/10 to-orange-500/10 rounded-lg border border-yellow-500/20">
                        <div className="flex items-center justify-center gap-2 mb-2">
                          <Trophy className="w-5 h-5 text-yellow-500" />
                          <span className="text-sm text-muted-foreground">جایزه اول</span>
                        </div>
                        <div className="font-bold text-xl text-yellow-600">{tournament.prize}</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          از کل {tournament.prizePool}
                        </div>
                      </div>

                      <div className="text-center p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center justify-center gap-2 mb-1">
                          <DollarSign className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">هزینه ثبت‌نام</span>
                        </div>
                        <div className="font-bold text-lg">
                          {tournament.entryFee.toLocaleString()} تومان
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-3">
                    <div className="text-center space-y-2">
                      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        <span>{tournament.startTime}</span>
                      </div>
                      <div className="flex items-center justify-center gap-2 text-sm">
                        <Calendar className="w-4 h-4" />
                        <span>{tournament.startDate}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      {tournament.status === 'registration' && (
                        <Button 
                          className="w-full"
                          onClick={() => handleRegister(tournament.id)}
                        >
                          <DollarSign className="w-4 h-4 ml-2" />
                          ثبت‌نام و پرداخت
                        </Button>
                      )}

                      {tournament.status === 'started' && (
                        <div className="space-y-2">
                          <Button variant="default" className="w-full">
                            <Play className="w-4 h-4 ml-2" />
                            مشاهده زنده
                          </Button>
                          <Button variant="outline" className="w-full" size="sm">
                            <Target className="w-4 h-4 ml-2" />
                            جدول مسابقات
                          </Button>
                        </div>
                      )}

                      {tournament.status === 'finished' && (
                        <div className="space-y-2">
                          <Button variant="outline" className="w-full">
                            <Trophy className="w-4 h-4 ml-2" />
                            نتایج نهایی
                          </Button>
                          <Button variant="ghost" className="w-full" size="sm">
                            <Award className="w-4 h-4 ml-2" />
                            برندگان
                          </Button>
                        </div>
                      )}

                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="w-full"
                        onClick={() => setSelectedTournament(selectedTournament === tournament.id ? null : tournament.id)}
                      >
                        <Eye className="w-4 h-4 ml-2" />
                        جزئیات بیشتر
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default TournamentsPage;