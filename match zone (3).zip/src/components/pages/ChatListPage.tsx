/**
 * Chat List Page - صفحه لیست همه چت‌ها
 * نمایش تمام چت‌های کاربر شامل لابی، کلن، خصوصی
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  MessageCircle, 
  Users, 
  Shield, 
  Crown, 
  Plus,
  Hash,
  Lock,
  Volume2,
  VolumeX,
  Pin,
  MoreVertical,
  Archive,
  Star
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { useMobile } from '../ui/use-mobile';

interface ChatItem {
  id: string;
  name: string;
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
  type: 'private' | 'lobby' | 'clan' | 'tournament' | 'public';
  isOnline: boolean;
  isPinned: boolean;
  isMuted: boolean;
  isArchived: boolean;
  avatar?: string;
  members?: number;
  isActive?: boolean; // برای لابی‌های فعال
}

interface ChatListPageProps {
  onChatSelect?: (chatId: string) => void;
  onNewChat?: () => void;
}

export function ChatListPage({ onChatSelect, onNewChat }: ChatListPageProps) {
  const isMobile = useMobile();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'private' | 'lobby' | 'clan'>('all');

  // Mock data - در واقعیت از API یا state management میاد
  const [chats] = useState<ChatItem[]>([
    {
      id: 'lobby_cs2_001',
      name: 'لابی کانتر استرایک 2',
      lastMessage: 'آماده شروع بازی؟',
      lastMessageTime: '2 دقیقه پیش',
      unreadCount: 3,
      type: 'lobby',
      isOnline: true,
      isPinned: true,
      isMuted: false,
      isArchived: false,
      members: 8,
      isActive: true
    },
    {
      id: 'clan_warriors',
      name: 'کلن Warriors',
      lastMessage: 'فردا تورنومنت داریم!',
      lastMessageTime: '5 دقیقه پیش',
      unreadCount: 12,
      type: 'clan',
      isOnline: true,
      isPinned: true,
      isMuted: false,
      isArchived: false,
      members: 45
    },
    {
      id: 'private_user123',
      name: 'امیرحسین گیمر',
      lastMessage: 'سلام! چطوری؟',
      lastMessageTime: '10 دقیقه پیش',
      unreadCount: 1,
      type: 'private',
      isOnline: true,
      isPinned: false,
      isMuted: false,
      isArchived: false
    },
    {
      id: 'tournament_winter',
      name: 'تورنومنت زمستانه',
      lastMessage: 'ثبت‌نام آغاز شد',
      lastMessageTime: '1 ساعت پیش',
      unreadCount: 0,
      type: 'tournament',
      isOnline: false,
      isPinned: false,
      isMuted: false,
      isArchived: false,
      members: 128
    },
    {
      id: 'lobby_valorant_002',
      name: 'لابی ولورانت رنکد',
      lastMessage: 'کی میاد؟',
      lastMessageTime: '2 ساعت پیش',
      unreadCount: 0,
      type: 'lobby',
      isOnline: false,
      isPinned: false,
      isMuted: true,
      isArchived: false,
      members: 5,
      isActive: false
    },
    {
      id: 'public_general',
      name: 'چت عمومی',
      lastMessage: 'کسی برای بازی هست؟',
      lastMessageTime: '3 ساعت پیش',
      unreadCount: 25,
      type: 'public',
      isOnline: true,
      isPinned: false,
      isMuted: true,
      isArchived: false,
      members: 1250
    }
  ]);

  // Filter chats based on search and filter
  const filteredChats = chats.filter(chat => {
    const matchesSearch = chat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         chat.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = selectedFilter === 'all' || chat.type === selectedFilter;
    return matchesSearch && matchesFilter && !chat.isArchived;
  });

  // Sort: pinned first, then by last message time
  const sortedChats = [...filteredChats].sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime();
  });

  const filters = [
    { id: 'all', label: 'همه', icon: MessageCircle },
    { id: 'private', label: 'خصوصی', icon: Users },
    { id: 'lobby', label: 'لابی', icon: Hash },
    { id: 'clan', label: 'کلن', icon: Shield }
  ];

  const getChatIcon = (type: ChatItem['type']) => {
    switch (type) {
      case 'private': return Users;
      case 'lobby': return Hash;
      case 'clan': return Shield;
      case 'tournament': return Crown;
      case 'public': return MessageCircle;
      default: return MessageCircle;
    }
  };

  const getChatColor = (type: ChatItem['type']) => {
    switch (type) {
      case 'private': return 'from-blue-500 to-blue-600';
      case 'lobby': return 'from-green-500 to-green-600';
      case 'clan': return 'from-purple-500 to-purple-600';
      case 'tournament': return 'from-yellow-500 to-yellow-600';
      case 'public': return 'from-gray-500 to-gray-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <div className={`h-screen w-full flex flex-col bg-background ${isMobile ? 'overflow-hidden' : ''}`}>
      {/* Header */}
      <div className="flex-shrink-0 bg-card/95 backdrop-blur border-b border-border/50 p-4 rounded-[10px]">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-lg font-semibold" dir="rtl">چت‌ها</h1>
          <Button
            variant="outline"
            size="sm"
            onClick={onNewChat}
            className="h-8 w-8 p-0"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="جستجو در چت‌ها..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10 text-right"
            dir="rtl"
          />
        </div>

        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide">
          {filters.map((filter) => {
            const Icon = filter.icon;
            const isActive = selectedFilter === filter.id;
            
            return (
              <Button
                key={filter.id}
                variant={isActive ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedFilter(filter.id as any)}
                className={`flex-shrink-0 h-8 ${isActive ? 'bg-primary' : ''}`}
              >
                <Icon className="w-3 h-3 mr-1" />
                {filter.label}
              </Button>
            );
          })}
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        <AnimatePresence>
          {sortedChats.map((chat, index) => {
            const Icon = getChatIcon(chat.type);
            
            return (
              <motion.div
                key={chat.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.05 }}
                className="border-b border-border/30 last:border-b-0"
              >
                <button
                  onClick={() => onChatSelect?.(chat.id)}
                  className="w-full p-4 hover:bg-muted/50 transition-colors text-right"
                  dir="rtl"
                >
                  <div className="flex items-center gap-3">
                    {/* Avatar */}
                    <div className="relative flex-shrink-0">
                      <Avatar className="w-12 h-12">
                        <AvatarFallback className={`bg-gradient-to-br ${getChatColor(chat.type)} text-white`}>
                          <Icon className="w-5 h-5" />
                        </AvatarFallback>
                      </Avatar>
                      
                      {/* Online Status */}
                      {chat.isOnline && (
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-background" />
                      )}
                      
                      {/* Active Lobby Indicator */}
                      {chat.type === 'lobby' && chat.isActive && (
                        <div className="absolute -top-1 -left-1 w-4 h-4 bg-yellow-500 rounded-full border-2 border-background">
                          <div className="w-full h-full bg-yellow-500 rounded-full animate-pulse" />
                        </div>
                      )}
                    </div>

                    {/* Chat Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          {/* Chat Name */}
                          <h3 className="font-medium truncate">{chat.name}</h3>
                          
                          {/* Badges */}
                          <div className="flex items-center gap-1">
                            {chat.isPinned && (
                              <Pin className="w-3 h-3 text-muted-foreground" />
                            )}
                            {chat.isMuted && (
                              <VolumeX className="w-3 h-3 text-muted-foreground" />
                            )}
                            {chat.members && chat.members > 1 && (
                              <Badge variant="secondary" className="text-xs px-1 h-4">
                                {chat.members}
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        <span className="text-xs text-muted-foreground">
                          {chat.lastMessageTime}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-muted-foreground truncate flex-1">
                          {chat.lastMessage}
                        </p>
                        
                        {/* Unread Count */}
                        {chat.unreadCount > 0 && (
                          <Badge className="bg-primary text-primary-foreground mr-2 h-5 min-w-[20px] text-xs">
                            {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {/* Empty State */}
        {sortedChats.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <MessageCircle className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="font-medium mb-2" dir="rtl">
              {searchQuery ? 'چتی پیدا نشد' : 'هنوز چتی نداری'}
            </h3>
            <p className="text-sm text-muted-foreground mb-6" dir="rtl">
              {searchQuery 
                ? 'عبارت دیگری جستجو کن' 
                : 'با دوستانت شروع به چت کن یا به لابی بپیوند'
              }
            </p>
            {!searchQuery && (
              <Button onClick={onNewChat} variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                شروع چت جدید
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default ChatListPage;