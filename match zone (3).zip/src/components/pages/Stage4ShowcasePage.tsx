/**
 * Stage 4 Showcase Page - نمایش مرحله 4 سیستم طراحی
 * صفحه نمایش کامل قابلیت‌های پیشرفته مرحله 4 پلتفرم MatchZone
 */

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { 
  Crown, Trophy, Settings, BarChart3, Bell, Users, 
  Gamepad2, Target, Shield, Star, Award, Zap, Activity,
  TrendingUp, DollarSign, Eye, MessageSquare, Globe,
  Swords, Handshake, GraduationCap, Camera, Play,
  Gift, PieChart, LineChart, Calendar, Clock, Flag,
  CheckCircle, AlertTriangle, RefreshCw, Download,
  Share2, ExternalLink, ArrowRight, Sparkles,
  Rocket, Code, Layers, Database, Cloud, Security
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Import Stage 4 Components
import TournamentAdminPage from './TournamentAdminPage';
import AdvancedNotificationSystem from '../system/AdvancedNotificationSystem';
import PlatformAnalyticsDashboard from '../analytics/PlatformAnalyticsDashboard';

export interface Stage4Feature {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  status: 'completed' | 'in-progress' | 'planned';
  category: 'management' | 'analytics' | 'notifications' | 'clans' | 'tournaments' | 'system';
  component?: React.ComponentType<any>;
  highlights: string[];
  techSpecs: string[];
}

const STAGE_4_FEATURES: Stage4Feature[] = [
  {
    id: 'tournament-admin',
    title: 'پنل مدیریت پیشرفته تورنومنت‌ها',
    description: 'سیستم مدیریت جامع تورنومنت‌ها با قابلیت‌های زنده، تحلیل و کنترل کامل',
    icon: Crown,
    status: 'completed',
    category: 'management',
    component: TournamentAdminPage,
    highlights: [
      'داشبورد زنده با آمار real-time',
      'مدیریت شرکت‌کنندگان و مسابقات',
      'سیستم اعلان‌های هوشمند',
      'تحلیل‌های پیشرفته عملکرد',
      'کنترل استریم و پخش زنده'
    ],
    techSpecs: [
      'Real-time updates با WebSocket',
      'Advanced filtering و search',
      'Bulk operations برای مدیریت',
      'Export به فرمت‌های مختلف',
      'Role-based access control'
    ]
  },
  {
    id: 'advanced-notifications',
    title: 'سیستم اعلان‌های پیشرفته',
    description: 'سیستم notification جامع با قابلیت‌های real-time، دسته‌بندی و تنظیمات پیشرفته',
    icon: Bell,
    status: 'completed',
    category: 'notifications',
    component: AdvancedNotificationSystem,
    highlights: [
      'اعلان‌های Real-time با صدا',
      'دسته‌بندی و فیلترینگ هوشمند',
      'تنظیمات پیشرفته کاربری',
      'گروه‌بندی اعلان‌های مرتبط',
      'چندین کانال ارسال (Push, Email, SMS)'
    ],
    techSpecs: [
      'WebSocket برای real-time',
      'Service Worker برای push notifications',
      'Prioritization و scheduling',
      'Bulk actions و management',
      'Analytics و tracking'
    ]
  },
  {
    id: 'platform-analytics',
    title: 'داشبورد آنالیز پلتفرم',
    description: 'سیستم آنالیز جامع با نمودارهای تعاملی و گزارشات پیشرفته',
    icon: BarChart3,
    status: 'completed',
    category: 'analytics',
    component: PlatformAnalyticsDashboard,
    highlights: [
      'نمودارهای تعاملی پیشرفته',
      'آمار real-time کاربران و درآمد',
      'تحلیل رفتار کاربران',
      'گزارشات قابل صادرات',
      'پیش‌بینی روندها'
    ],
    techSpecs: [
      'Recharts برای visualization',
      'Real-time data updates',
      'Multiple chart types',
      'Export capabilities',
      'Responsive design'
    ]
  },
  {
    id: 'tournament-creation',
    title: 'سیستم ایجاد تورنومنت پیشرفته',
    description: 'فرم جامع ایجاد تورنومنت با تمام امکانات حرفه‌ای',
    icon: Trophy,
    status: 'completed',
    category: 'tournaments',
    highlights: [
      'فرم چند مرحله‌ای با validation',
      'تنظیمات پیشرفته زمان‌بندی',
      'مدیریت جوایز و توزیع',
      'قوانین و الزامات قابل تنظیم',
      'پیش‌نمایش و draft'
    ],
    techSpecs: [
      'Multi-step form با validation',
      'Real-time preview',
      'Auto-save drafts',
      'Advanced scheduling',
      'Prize distribution calculator'
    ]
  },
  {
    id: 'tournament-management',
    title: 'مدیریت زنده تورنومنت‌ها',
    description: 'پنل کنترل زنده برای مدیریت کامل تورنومنت‌ها در حال اجرا',
    icon: Settings,
    status: 'completed',
    category: 'tournaments',
    highlights: [
      'کنترل زنده مسابقات',
      'مدیریت شرکت‌کنندگان real-time',
      'سیستم تعدیل پیشرفته',
      'آمار و عملکرد زنده',
      'کنترل استریم'
    ],
    techSpecs: [
      'Real-time match control',
      'Participant management',
      'Advanced moderation tools',
      'Stream integration',
      'Live statistics'
    ]
  },
  {
    id: 'tournament-analytics',
    title: 'آنالیز تورنومنت‌ها',
    description: 'سیستم آنالیز جامع عملکرد تورنومنت‌ها',
    icon: PieChart,
    status: 'completed',
    category: 'analytics',
    highlights: [
      'آنالیز کامل عملکرد',
      'مقایسه با تورنومنت‌های قبلی',
      'آمار مالی و درآمد',
      'تحلیل تعامل و مشاهده',
      'گزارش کیفیت'
    ],
    techSpecs: [
      'Comprehensive analytics',
      'Performance comparisons',
      'Financial reporting',
      'Engagement metrics',
      'Quality assessment'
    ]
  },
  {
    id: 'tournament-streaming',
    title: 'سیستم پخش زنده تورنومنت‌ها',
    description: 'پلتفرم پخش زنده با قابلیت‌های پیشرفته',
    icon: Camera,
    status: 'completed',
    category: 'tournaments',
    highlights: [
      'پخش زنده با کیفیت بالا',
      'چت زنده با moderation',
      'کنترل کامل استریم',
      'آمار بیننده real-time',
      'ضبط و highlight'
    ],
    techSpecs: [
      'Multi-quality streaming',
      'Real-time chat',
      'Stream controls',
      'Viewer analytics',
      'Recording capabilities'
    ]
  },
  {
    id: 'prize-management',
    title: 'مدیریت جوایز و پرداخت‌ها',
    description: 'سیستم مدیریت جامع جوایز و پرداخت‌ها',
    icon: Gift,
    status: 'completed',
    category: 'management',
    highlights: [
      'محاسبه خودکار جوایز',
      'توزیع عادلانه بین رنک‌ها',
      'پرداخت خودکار',
      'تاریخچه تراکنش‌ها',
      'مالیات و کسورات'
    ],
    techSpecs: [
      'Automated calculations',
      'Fair distribution algorithms',
      'Payment gateway integration',
      'Transaction history',
      'Tax calculations'
    ]
  },
  {
    id: 'clan-wars',
    title: 'سیستم جنگ کلن‌ها',
    description: 'سیستم پیچیده جنگ بین کلن‌ها با امتیازات و رنکینگ',
    icon: Swords,
    status: 'completed',
    category: 'clans',
    highlights: [
      'جنگ‌های منظم بین کلن‌ها',
      'سیستم امتیازدهی پیچیده',
      'تاکتیک و استراتژی',
      'جوایز و تشویق‌ها',
      'تاریخچه و آمار'
    ],
    techSpecs: [
      'Complex war mechanics',
      'Scoring algorithms',
      'Strategy elements',
      'Reward systems',
      'Historical data'
    ]
  },
  {
    id: 'clan-alliances',
    title: 'سیستم اتحاد کلن‌ها',
    description: 'قابلیت تشکیل اتحاد و همکاری بین کلن‌ها',
    icon: Handshake,
    status: 'completed',
    category: 'clans',
    highlights: [
      'تشکیل اتحادهای قدرتمند',
      'همکاری در جنگ‌ها',
      'تبادل منابع',
      'مذاکرات و دیپلماسی',
      'مدیریت روابط'
    ],
    techSpecs: [
      'Alliance management',
      'Cooperation mechanics',
      'Resource sharing',
      'Diplomatic tools',
      'Relationship tracking'
    ]
  },
  {
    id: 'clan-training',
    title: 'سیستم آموزش کلن‌ها',
    description: 'پلتفرم آموزش و توسعه مهارت‌های اعضای کلن',
    icon: GraduationCap,
    status: 'completed',
    category: 'clans',
    highlights: [
      'برنامه‌های آموزشی تخصصی',
      'مربی‌گری و راهنمایی',
      'تمرین‌های گروهی',
      'ارزیابی پیشرفت',
      'مدارک و گواهی‌ها'
    ],
    techSpecs: [
      'Training programs',
      'Mentorship system',
      'Group practices',
      'Progress tracking',
      'Certification system'
    ]
  }
];

const STATUS_COLORS = {
  completed: 'bg-green-500/20 text-green-400 border-green-500/50',
  'in-progress': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
  planned: 'bg-blue-500/20 text-blue-400 border-blue-500/50'
};

const STATUS_LABELS = {
  completed: 'تکمیل شده',
  'in-progress': 'در حال توسعه',
  planned: 'برنامه‌ریزی شده'
};

const CATEGORY_COLORS = {
  management: '#3B82F6',
  analytics: '#22C55E',
  notifications: '#FACC15',
  clans: '#EF4444',
  tournaments: '#8B5CF6',
  system: '#F97316'
};

export function Stage4ShowcasePage() {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedFeature, setSelectedFeature] = useState<Stage4Feature | null>(null);
  const [showDemo, setShowDemo] = useState<string | null>(null);

  const filteredFeatures = activeCategory === 'all' 
    ? STAGE_4_FEATURES 
    : STAGE_4_FEATURES.filter(f => f.category === activeCategory);

  const completedFeatures = STAGE_4_FEATURES.filter(f => f.status === 'completed').length;
  const totalFeatures = STAGE_4_FEATURES.length;
  const completionRate = Math.round((completedFeatures / totalFeatures) * 100);

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500/10 via-blue-500/10 to-green-500/10 border-purple-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-gradient-to-r from-purple-500/20 to-blue-500/20 rounded-xl">
                <Rocket className="w-10 h-10 text-purple-400" />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                    مرحله 4 - پلتفرم پیشرفته
                  </h1>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/50 px-3 py-1">
                    <Sparkles className="w-3 h-3 ml-1" />
                    {completionRate}% تکمیل
                  </Badge>
                </div>
                <p className="text-muted-foreground text-lg">
                  سیستم‌های مدیریت پیشرفته، آنالیز جامع و قابلیت‌های enterprise
                </p>
              </div>
            </div>
            
            <div className="text-left">
              <div className="text-4xl font-bold text-green-500">{completedFeatures}</div>
              <div className="text-sm text-muted-foreground">از {totalFeatures} قابلیت</div>
              <div className="text-xs text-green-500 mt-1">تکمیل شده</div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-500">
              {STAGE_4_FEATURES.filter(f => f.category === 'management').length}
            </div>
            <div className="text-sm text-muted-foreground">سیستم‌های مدیریت</div>
            <div className="w-full bg-blue-500/10 rounded-full h-2 mt-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-1000"
                style={{ width: '100%' }}
              />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-500">
              {STAGE_4_FEATURES.filter(f => f.category === 'analytics').length}
            </div>
            <div className="text-sm text-muted-foreground">سیستم‌های آنالیز</div>
            <div className="w-full bg-green-500/10 rounded-full h-2 mt-2">
              <div 
                className="bg-green-500 h-2 rounded-full transition-all duration-1000"
                style={{ width: '100%' }}
              />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-500">
              {STAGE_4_FEATURES.filter(f => f.category === 'tournaments').length}
            </div>
            <div className="text-sm text-muted-foreground">سیستم‌های تورنومنت</div>
            <div className="w-full bg-purple-500/10 rounded-full h-2 mt-2">
              <div 
                className="bg-purple-500 h-2 rounded-full transition-all duration-1000"
                style={{ width: '100%' }}
              />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-500">
              {STAGE_4_FEATURES.filter(f => f.category === 'clans').length}
            </div>
            <div className="text-sm text-muted-foreground">سیستم‌های کلن</div>
            <div className="w-full bg-red-500/10 rounded-full h-2 mt-2">
              <div 
                className="bg-red-500 h-2 rounded-full transition-all duration-1000"
                style={{ width: '100%' }}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-2">
            <Button
              variant={activeCategory === 'all' ? 'default' : 'outline'}
              onClick={() => setActiveCategory('all')}
              className="flex items-center gap-2"
            >
              <Layers className="w-4 h-4" />
              همه ({STAGE_4_FEATURES.length})
            </Button>
            
            <Button
              variant={activeCategory === 'management' ? 'default' : 'outline'}
              onClick={() => setActiveCategory('management')}
              className="flex items-center gap-2"
            >
              <Settings className="w-4 h-4" />
              مدیریت ({STAGE_4_FEATURES.filter(f => f.category === 'management').length})
            </Button>
            
            <Button
              variant={activeCategory === 'analytics' ? 'default' : 'outline'}
              onClick={() => setActiveCategory('analytics')}
              className="flex items-center gap-2"
            >
              <BarChart3 className="w-4 h-4" />
              آنالیز ({STAGE_4_FEATURES.filter(f => f.category === 'analytics').length})
            </Button>
            
            <Button
              variant={activeCategory === 'tournaments' ? 'default' : 'outline'}
              onClick={() => setActiveCategory('tournaments')}
              className="flex items-center gap-2"
            >
              <Trophy className="w-4 h-4" />
              تورنومنت ({STAGE_4_FEATURES.filter(f => f.category === 'tournaments').length})
            </Button>
            
            <Button
              variant={activeCategory === 'clans' ? 'default' : 'outline'}
              onClick={() => setActiveCategory('clans')}
              className="flex items-center gap-2"
            >
              <Swords className="w-4 h-4" />
              کلن ({STAGE_4_FEATURES.filter(f => f.category === 'clans').length})
            </Button>
            
            <Button
              variant={activeCategory === 'notifications' ? 'default' : 'outline'}
              onClick={() => setActiveCategory('notifications')}
              className="flex items-center gap-2"
            >
              <Bell className="w-4 h-4" />
              اعلان ({STAGE_4_FEATURES.filter(f => f.category === 'notifications').length})
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <AnimatePresence>
          {filteredFeatures.map((feature) => {
            const Icon = feature.icon;
            
            return (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="h-full"
              >
                <Card className="h-full border hover:shadow-lg transition-all duration-300 hover:border-purple-500/50 group">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div 
                          className="p-3 rounded-lg transition-all duration-300 group-hover:scale-110"
                          style={{ 
                            backgroundColor: `${CATEGORY_COLORS[feature.category]}20`,
                            color: CATEGORY_COLORS[feature.category]
                          }}
                        >
                          <Icon className="w-6 h-6" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg leading-tight mb-1">
                            {feature.title}
                          </h3>
                          <Badge className={`${STATUS_COLORS[feature.status]} text-xs mb-2`}>
                            {STATUS_LABELS[feature.status]}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {feature.description}
                    </p>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    {/* Highlights */}
                    <div>
                      <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                        <Star className="w-4 h-4 text-yellow-500" />
                        ویژگی‌های کلیدی
                      </h4>
                      <ul className="space-y-1">
                        {feature.highlights.slice(0, 3).map((highlight, index) => (
                          <li key={index} className="text-xs text-muted-foreground flex items-center gap-2">
                            <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />
                            {highlight}
                          </li>
                        ))}
                        {feature.highlights.length > 3 && (
                          <li className="text-xs text-muted-foreground">
                            و {feature.highlights.length - 3} ویژگی دیگر...
                          </li>
                        )}
                      </ul>
                    </div>

                    {/* Tech Specs Preview */}
                    <div>
                      <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                        <Code className="w-4 h-4 text-blue-500" />
                        مشخصات فنی
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {feature.techSpecs.slice(0, 2).map((spec, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {spec.split(' ')[0]}
                          </Badge>
                        ))}
                        {feature.techSpecs.length > 2 && (
                          <Badge variant="secondary" className="text-xs">
                            +{feature.techSpecs.length - 2}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2 pt-2">
                      <Button
                        size="sm"
                        onClick={() => setSelectedFeature(feature)}
                        className="flex-1"
                      >
                        <Eye className="w-3 h-3 ml-1" />
                        جزئیات
                      </Button>
                      
                      {feature.component && feature.status === 'completed' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setShowDemo(feature.id)}
                          className="flex-1"
                        >
                          <Play className="w-3 h-3 ml-1" />
                          دمو زنده
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Feature Detail Dialog */}
      <Dialog open={!!selectedFeature} onOpenChange={() => setSelectedFeature(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              {selectedFeature && (
                <>
                  <selectedFeature.icon className="w-6 h-6 text-purple-500" />
                  {selectedFeature.title}
                  <Badge className={STATUS_COLORS[selectedFeature.status]}>
                    {STATUS_LABELS[selectedFeature.status]}
                  </Badge>
                </>
              )}
            </DialogTitle>
          </DialogHeader>
          
          {selectedFeature && (
            <div className="space-y-6">
              {/* Description */}
              <div>
                <p className="text-muted-foreground leading-relaxed">
                  {selectedFeature.description}
                </p>
              </div>

              {/* Highlights */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-500" />
                  ویژگی‌های کلیدی
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedFeature.highlights.map((highlight, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                      <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm">{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Technical Specifications */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Code className="w-5 h-5 text-blue-500" />
                  مشخصات فنی
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {selectedFeature.techSpecs.map((spec, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                      <Database className="w-4 h-4 text-blue-500 flex-shrink-0" />
                      <span className="text-sm">{spec}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Demo Button */}
              {selectedFeature.component && selectedFeature.status === 'completed' && (
                <div className="flex justify-end">
                  <Button
                    onClick={() => {
                      setShowDemo(selectedFeature.id);
                      setSelectedFeature(null);
                    }}
                    className="flex items-center gap-2"
                  >
                    <Play className="w-4 h-4" />
                    مشاهده دمو زنده
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Live Demo Dialogs */}
      <Dialog open={showDemo === 'tournament-admin'} onOpenChange={() => setShowDemo(null)}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>دمو زنده: پنل مدیریت پیشرفته تورنومنت‌ها</DialogTitle>
          </DialogHeader>
          <TournamentAdminPage />
        </DialogContent>
      </Dialog>

      <Dialog open={showDemo === 'advanced-notifications'} onOpenChange={() => setShowDemo(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>دمو زنده: سیستم اعلان‌های پیشرفته</DialogTitle>
          </DialogHeader>
          <AdvancedNotificationSystem />
        </DialogContent>
      </Dialog>

      <Dialog open={showDemo === 'platform-analytics'} onOpenChange={() => setShowDemo(null)}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>دمو زنده: داشبورد آنالیز پلتفرم</DialogTitle>
          </DialogHeader>
          <PlatformAnalyticsDashboard />
        </DialogContent>
      </Dialog>

      {/* Stage Summary */}
      <Card className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border-green-500/20">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-500/20 rounded-lg">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-green-500 mb-1">
                  مرحله 4 با موفقیت تکمیل شد!
                </h3>
                <p className="text-muted-foreground">
                  تمام سیستم‌های پیشرفته پلتفرم MatchZone آماده و قابل استفاده هستند
                </p>
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-green-500">{completionRate}%</div>
              <div className="text-sm text-muted-foreground">پیشرفت کل</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default Stage4ShowcasePage;