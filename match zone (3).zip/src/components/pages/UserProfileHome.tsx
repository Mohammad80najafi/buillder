import React, { useState, useCallback } from 'react';
import { 
  Camera, Edit3, Settings, Share2, MoreHorizontal, Grid3X3, 
  Play, Heart, MessageCircle, Bookmark, Users, UserPlus,
  Trophy, Star, Shield, Crown, Award, Zap, Target, 
  Calendar, MapPin, Link2, Instagram, Youtube, Twitch,
  TrendingUp, Eye, Clock, ChevronDown, Filter,
  Image as ImageIcon, Video, Mic, Radio, GamepadIcon,
  Bell, Search, Menu, Plus, Home, BarChart3, User,
  Download, ExternalLink, Copy, Globe, Mail, Phone,
  Lock, Verified, ThumbsUp, MessageSquare, Share,
  UserCheck, UserX, Flag, Volume2, VolumeX, ChevronRight,
  Activity, Flame, Lightning, Headphones, Monitor,
  Wifi, Cpu, HardDrive, MousePointer
} from 'lucide-react';
import { Button } from '../ui/mz-button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '../ui/dropdown-menu';
import { Switch } from '../ui/switch';
import { Slider } from '../ui/slider';
import { Input } from '../ui/mz-input';
import { Textarea } from '../ui/textarea';
import { motion, AnimatePresence } from 'motion/react';
import { useMobile } from '../ui/use-mobile';

interface UserVideo {
  id: string;
  type: 'video' | 'stream' | 'short';
  thumbnail: string;
  title: string;
  description: string;
  duration?: string;
  views: string;
  likes: number;
  comments: number;
  shares: number;
  uploadTime: string;
  game?: string;
  tags: string[];
  isLive?: boolean;
}

interface UserStats {
  followers: number;
  following: number;
  videos: number;
  totalViews: string;
  totalLikes: string;
  totalWatchTime: string;
  monthlyViews: string;
  subscriberGrowth: number;
  avgViewDuration: string;
  topCountries: string[];
  gamerLevel: number;
  gamerRank: string;
  achievementsCount: number;
  tournamentsWon: number;
}

interface UserProfileHomeProps {
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
}

export function UserProfileHome({ onNavigate, onLogout }: UserProfileHomeProps) {
  const [activeTab, setActiveTab] = useState<'videos' | 'analytics' | 'settings'>('videos');
  const [videoFilter, setVideoFilter] = useState<'all' | 'videos' | 'streams' | 'shorts'>('all');
  const [showAnalytics, setShowAnalytics] = useState(true);
  const [profileVisibility, setProfileVisibility] = useState('public');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [autoPlay, setAutoPlay] = useState(true);
  const [qualityPreference, setQualityPreference] = useState([720]);
  
  const isMobile = useMobile();

  // Mock user data - در production از API می‌آید
  const userData = {
    id: 'current_user',
    name: 'محمد رضایی',
    username: 'mohammad_pro_gamer',
    displayId: '@mohammad_pro_gamer',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    coverImage: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    bio: 'گیمر حرفه‌ای 🎮 | استریمر VALORANT 🔥 | مربی بازی‌های FPS 🎯 | قهرمان تورنمنت‌های ملی 🏆\nمحتوای حرفه‌ای گیمینگ، آموزش تکنیک‌های پیشرفته و تحلیل بازی‌ها',
    location: 'تهران، ایران',
    joinDate: 'عضو از بهمن ۱۴۰۱',
    verified: true,
    isLive: false,
    currentGame: 'VALORANT',
    email: 'mohammad@example.com',
    website: 'mohammad-gaming.com',
    socialLinks: {
      instagram: '@mohammad_gaming',
      youtube: 'MohammadProGamer',
      twitch: 'mohammad_stream'
    }
  };

  const userStats: UserStats = {
    followers: 142300,
    following: 312,
    videos: 189,
    totalViews: '15.2M',
    totalLikes: '892K',
    totalWatchTime: '4.2M ساعت',
    monthlyViews: '2.1M',
    subscriberGrowth: 15.8,
    avgViewDuration: '8:32',
    topCountries: ['ایران', 'آلمان', 'کانادا'],
    gamerLevel: 87,
    gamerRank: 'الماسی',
    achievementsCount: 24,
    tournamentsWon: 7
  };

  const userVideos: UserVideo[] = [
    {
      id: '1',
      type: 'video',
      thumbnail: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      title: '🔥 کلچ 1v5 حماسی در VALORANT - فینال تورنمنت',
      description: 'یکی از بهترین کلچ‌های تاریخ VALORANT! این round کل مسابقه رو تغییر داد و ما تونستیم قهرمان شیم. تمام تکنیک‌ها و استراتژی‌هایی که استفاده کردم رو توضیح می‌دم.',
      duration: '12:34',
      views: '289K',
      likes: 18200,
      comments: 1145,
      shares: 892,
      uploadTime: '2 روز پیش',
      game: 'VALORANT',
      tags: ['VALORANT', 'کلچ', 'esports', 'تورنمنت', 'حرفه‌ای']
    },
    {
      id: '2',
      type: 'stream',
      thumbnail: 'https://images.unsplash.com/photo-1617507171089-6cb9aa5add36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHN0cmVhbWluZ3xlbnwxfHx8fDE3NTczMzkxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      title: '🎯 Ranked Push به Radiant - پارت 3',
      description: 'ادامه سری Ranked Push! امروز می‌خوایم از Immortal 3 به Radiant برسیم. همراه ما باشید و تکنیک‌های جدید یاد بگیرید.',
      duration: '4:23:12',
      views: '156K',
      likes: 8900,
      comments: 2567,
      shares: 234,
      uploadTime: '1 هفته پیش',
      game: 'VALORANT',
      tags: ['استریم', 'VALORANT', 'ranked', 'آموزش'],
      isLive: true
    },
    {
      id: '3',
      type: 'video',
      thumbnail: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      title: '📚 آموزش کامل Crosshair Placement',
      description: 'همه چیز درباره Crosshair Placement در VALORANT و CS2. از مبتدی تا حرفه‌ای - تکنیک‌هایی که حتی پروها نمی‌دونن!',
      duration: '18:45',
      views: '567K',
      likes: 21000,
      comments: 1289,
      shares: 445,
      uploadTime: '3 روز پیش',
      game: 'VALORANT',
      tags: ['آموزش', 'crosshair', 'تکنیک', 'FPS']
    },
    {
      id: '4',
      type: 'short',
      thumbnail: 'https://images.unsplash.com/photo-1617507171089-6cb9aa5add36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHN0cmVhbWluZ3xlbnwxfHx8fDE3NTczMzkxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      title: '⚡ نکته مهم Jett Dash',
      description: 'یک تکنیک فوق‌العاده مهم برای Jett که 90% بازیکنا نمی‌دونن!',
      duration: '0:45',
      views: '1.2M',
      likes: 45600,
      comments: 892,
      shares: 1203,
      uploadTime: '1 روز پیش',
      game: 'VALORANT',
      tags: ['نکته', 'Jett', 'تکنیک']
    },
    {
      id: '5',
      type: 'video',
      thumbnail: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      title: '🛠️ بهترین تنظیمات گیمینگ 2024',
      description: 'کامل‌ترین گاید تنظیمات برای بهترین عملکرد در بازی‌های FPS. از تنظیمات در-بازی تا تنظیمات سیستم.',
      duration: '25:23',
      views: '834K',
      likes: 28400,
      comments: 1567,
      shares: 789,
      uploadTime: '5 روز پیش',
      game: 'General',
      tags: ['تنظیمات', 'گیمینگ', 'بهینه‌سازی', 'FPS']
    },
    {
      id: '6',
      type: 'video',
      thumbnail: 'https://images.unsplash.com/photo-1617507171089-6cb9aa5add36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHN0cmVhbWluZ3xlbnwxfHx8fDE3NTczMzkxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      title: '🎯 نکات پیشرفته Aim Training',
      description: 'تکنیک‌های حرفه‌ای برای بهبود aim. روتین تمرینی که من استفاده می‌کنم تا در سطح حرفه‌ای باشم.',
      duration: '21:12',
      views: '476K',
      likes: 16800,
      comments: 956,
      shares: 432,
      uploadTime: '4 روز پیش',
      game: 'Aim Lab',
      tags: ['aim', 'تمرین', 'حرفه‌ای', 'تکنیک']
    }
  ];

  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  const filteredVideos = videoFilter === 'all' 
    ? userVideos 
    : userVideos.filter(video => video.type === videoFilter || (videoFilter === 'videos' && video.type === 'video'));

  const VideoCard = ({ video }: { video: UserVideo }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group cursor-pointer"
    >
      {/* Video Thumbnail */}
      <div className="relative aspect-video bg-black/20 rounded-xl overflow-hidden mb-3">
        <img 
          src={video.thumbnail} 
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Video Type Badge */}
        <div className="absolute top-3 right-3">
          {video.type === 'stream' && (
            <Badge className="bg-red-500 text-white border-0">
              <Radio className="h-3 w-3 mr-1" />
              {video.isLive ? 'زنده' : 'استریم'}
            </Badge>
          )}
          {video.type === 'short' && (
            <Badge className="bg-purple-500 text-white border-0">
              <Lightning className="h-3 w-3 mr-1" />
              شورت
            </Badge>
          )}
          {video.type === 'video' && (
            <Badge className="bg-blue-500 text-white border-0">
              <Play className="h-3 w-3 mr-1" />
              ویدیو
            </Badge>
          )}
        </div>

        {/* Duration */}
        {video.duration && (
          <div className="absolute bottom-3 left-3">
            <Badge className="bg-black/80 text-white border-0 text-xs">
              {video.duration}
            </Badge>
          </div>
        )}

        {/* Play Button Overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 flex items-center justify-center">
          <motion.div
            initial={{ scale: 0 }}
            whileHover={{ scale: 1 }}
            className="bg-white/90 backdrop-blur-sm rounded-full p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          >
            <Play className="h-6 w-6 text-black fill-black" />
          </motion.div>
        </div>
      </div>

      {/* Video Info */}
      <div className="space-y-2">
        <h3 className="font-semibold text-white leading-tight line-clamp-2 group-hover:text-brand-primary transition-colors">
          {video.title}
        </h3>
        
        <div className="flex items-center gap-4 text-sm text-white/60">
          <div className="flex items-center gap-1">
            <Eye className="h-4 w-4" />
            <span>{video.views}</span>
          </div>
          <div className="flex items-center gap-1">
            <Heart className="h-4 w-4" />
            <span>{formatNumber(video.likes)}</span>
          </div>
          <span>{video.uploadTime}</span>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1">
          {video.tags.slice(0, 3).map((tag, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              #{tag}
            </Badge>
          ))}
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-bg-primary via-bg-secondary to-bg-tertiary gaming-scroll">
      {/* Profile Header Section - 30% */}
      <div className="h-[30vh] min-h-[300px] relative">
        {/* Cover Image */}
        <div className="absolute inset-0">
          <img 
            src={userData.coverImage} 
            alt="Cover"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/40 to-black/80" />
        </div>

        {/* Profile Content */}
        <div className="relative h-full flex items-end">
          <div className="w-full max-w-7xl mx-auto p-6 pb-8" dir="rtl">
            <div className="flex items-end gap-6">
              {/* Profile Picture */}
              <div className="relative flex-shrink-0">
                <Avatar className="h-32 w-32 ring-4 ring-white/20 ring-offset-4 ring-offset-black/20">
                  <AvatarImage src={userData.avatar} alt={userData.name} />
                  <AvatarFallback className="bg-gradient-to-br from-brand-primary to-brand-secondary text-white text-4xl">
                    {userData.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                {userData.isLive && (
                  <div className="absolute -bottom-2 -right-2 bg-red-500 rounded-full p-2 border-4 border-white">
                    <Radio className="h-4 w-4 text-white" />
                  </div>
                )}
                {/* Camera Edit Button */}
                <button className="absolute -bottom-2 -left-2 bg-black/70 hover:bg-black/90 rounded-full p-2 transition-colors">
                  <Camera className="h-4 w-4 text-white" />
                </button>
              </div>

              {/* Profile Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4">
                  {/* Name & Info */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h1 className="text-3xl font-bold text-white truncate">{userData.name}</h1>
                      {userData.verified && (
                        <div className="flex-shrink-0">
                          <Crown className="h-6 w-6 text-yellow-400" />
                        </div>
                      )}
                    </div>
                    
                    <p className="text-lg text-white/80 mb-2">{userData.displayId}</p>
                    
                    {/* Gaming Banner */}
                    <div className="flex items-center gap-4 mb-3">
                      <Badge className="bg-gradient-to-r from-brand-primary to-brand-secondary text-white border-0">
                        <GamepadIcon className="h-4 w-4 mr-2" />
                        سطح {userStats.gamerLevel} • رنک {userStats.gamerRank}
                      </Badge>
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                        <Trophy className="h-4 w-4 mr-2" />
                        {userStats.tournamentsWon} قهرمانی
                      </Badge>
                    </div>

                    {/* Bio */}
                    <p className="text-white/90 text-sm leading-relaxed max-w-2xl">
                      {userData.bio}
                    </p>

                    {/* Stats Row */}
                    <div className="flex items-center gap-8 mt-4">
                      <div className="text-center">
                        <div className="text-xl font-bold text-white">{formatNumber(userStats.followers)}</div>
                        <p className="text-sm text-white/60">فالور</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-white">{userStats.videos}</div>
                        <p className="text-sm text-white/60">ویدیو</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-white">{userStats.totalViews}</div>
                        <p className="text-sm text-white/60">بازدید</p>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-white">{userStats.totalLikes}</div>
                        <p className="text-sm text-white/60">لایک</p>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
                      <Share2 className="h-4 w-4 ml-2" />
                      اشتراک‌گذاری
                    </Button>
                    <Button className="bg-gradient-to-r from-brand-primary to-brand-secondary">
                      <Edit3 className="h-4 w-4 ml-2" />
                      ویرایش پروفایل
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="icon" className="border-white/30 text-white hover:bg-white/10">
                          <MoreHorizontal className="h-5 w-5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" dir="rtl">
                        <DropdownMenuItem>
                          <Copy className="ml-2 h-4 w-4" />
                          کپی لینک پروفایل
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="ml-2 h-4 w-4" />
                          دانلود داده‌ها
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => onNavigate?.('settings')}>
                          <Settings className="ml-2 h-4 w-4" />
                          تنظیمات
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={onLogout}>
                          <Home className="ml-2 h-4 w-4" />
                          خروج
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Section - 70% */}
      <div className="min-h-[70vh] bg-bg-primary/95 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto p-6" dir="rtl">
          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)} className="w-full">
            {/* Tab Headers */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-8">
              <TabsList className="bg-black/20 border border-white/10">
                <TabsTrigger value="videos" className="flex items-center gap-2">
                  <Play className="h-4 w-4" />
                  ویدیوها ({userStats.videos})
                </TabsTrigger>
                <TabsTrigger value="analytics" className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  آمار صفحه
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  تنظیمات پروفایل
                </TabsTrigger>
              </TabsList>

              {/* Tab Actions */}
              {activeTab === 'videos' && (
                <div className="flex items-center gap-3">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Filter className="h-4 w-4 ml-2" />
                        {videoFilter === 'all' ? 'همه' : 
                         videoFilter === 'videos' ? 'ویدیوها' :
                         videoFilter === 'streams' ? 'استریم‌ها' : 'شورت‌ها'}
                        <ChevronDown className="h-4 w-4 mr-2" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent dir="rtl">
                      <DropdownMenuItem onClick={() => setVideoFilter('all')}>
                        همه محتوا
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setVideoFilter('videos')}>
                        ویدیوها
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setVideoFilter('streams')}>
                        استریم‌ها
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setVideoFilter('shorts')}>
                        شورت‌ها
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  
                  <Button size="sm" className="bg-gradient-to-r from-brand-primary to-brand-secondary">
                    <Plus className="h-4 w-4 ml-2" />
                    آپلود جدید
                  </Button>
                </div>
              )}
            </div>

            {/* Videos Tab */}
            <TabsContent value="videos" className="space-y-6">
              {/* Videos Grid */}
              <div className={`grid gap-6 ${isMobile ? 'grid-cols-1' : 'grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'}`}>
                <AnimatePresence>
                  {filteredVideos.map((video, index) => (
                    <motion.div
                      key={video.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <VideoCard video={video} />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* Load More */}
              <div className="text-center pt-8">
                <Button variant="outline" size="lg">
                  <ChevronDown className="h-5 w-5 ml-2" />
                  بارگیری بیشتر
                </Button>
              </div>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics" className="space-y-8">
              {/* Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-white/60 mb-1">بازدید ماهانه</p>
                        <p className="text-2xl font-bold text-white">{userStats.monthlyViews}</p>
                        <p className="text-xs text-green-400 flex items-center gap-1 mt-1">
                          <TrendingUp className="h-3 w-3" />
                          +{userStats.subscriberGrowth}%
                        </p>
                      </div>
                      <Eye className="h-8 w-8 text-brand-primary" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-white/60 mb-1">زمان تماشا</p>
                        <p className="text-2xl font-bold text-white">{userStats.totalWatchTime}</p>
                        <p className="text-xs text-white/60 mt-1">میانگین: {userStats.avgViewDuration}</p>
                      </div>
                      <Clock className="h-8 w-8 text-brand-secondary" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-white/60 mb-1">رشد فالور</p>
                        <p className="text-2xl font-bold text-white">+{formatNumber(userStats.subscriberGrowth * 1000)}</p>
                        <p className="text-xs text-green-400 flex items-center gap-1 mt-1">
                          <Users className="h-3 w-3" />
                          این ماه
                        </p>
                      </div>
                      <Users className="h-8 w-8 text-brand-accent" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-white/60 mb-1">دستاوردها</p>
                        <p className="text-2xl font-bold text-white">{userStats.achievementsCount}</p>
                        <p className="text-xs text-yellow-400 flex items-center gap-1 mt-1">
                          <Trophy className="h-3 w-3" />
                          {userStats.tournamentsWon} قهرمانی
                        </p>
                      </div>
                      <Award className="h-8 w-8 text-yellow-400" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Charts and Detailed Analytics */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Performance Chart */}
                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Activity className="h-5 w-5 text-brand-primary" />
                      عملکرد ماهانه
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 flex items-center justify-center text-white/60">
                      <div className="text-center">
                        <BarChart3 className="h-12 w-12 mx-auto mb-4 text-white/30" />
                        <p>نمودار عملکرد اینجا نمایش داده می‌شود</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Top Countries */}
                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Globe className="h-5 w-5 text-brand-secondary" />
                      کشورهای برتر
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {userStats.topCountries.map((country, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <span className="text-white">{country}</span>
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-2 bg-white/10 rounded-full overflow-hidden">
                              <div 
                                className="h-full bg-gradient-to-r from-brand-primary to-brand-secondary rounded-full"
                                style={{ width: `${80 - index * 20}%` }}
                              />
                            </div>
                            <span className="text-sm text-white/60">{80 - index * 20}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="space-y-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Profile Settings */}
                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <User className="h-5 w-5 text-brand-primary" />
                      تنظیمات پروفایل
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-sm text-white/70">نام نمایشی</label>
                      <Input 
                        value={userData.name} 
                        placeholder="نام نمایشی"
                        className="bg-white/5 border-white/20 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-white/70">نام کاربری</label>
                      <Input 
                        value={userData.username} 
                        placeholder="نام کاربری"
                        className="bg-white/5 border-white/20 text-white"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-white/70">بیوگرافی</label>
                      <Textarea 
                        value={userData.bio}
                        placeholder="درباره شما..."
                        className="bg-white/5 border-white/20 text-white min-h-[100px]"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-white/70">وبسایت</label>
                      <Input 
                        value={userData.website} 
                        placeholder="آدرس وبسایت"
                        className="bg-white/5 border-white/20 text-white"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Privacy Settings */}
                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Shield className="h-5 w-5 text-brand-secondary" />
                      حریم خصوصی
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm text-white">پروفایل عمومی</p>
                        <p className="text-xs text-white/60">همه می‌توانند پروفایل شما را ببینند</p>
                      </div>
                      <Switch 
                        checked={profileVisibility === 'public'}
                        onCheckedChange={(checked) => setProfileVisibility(checked ? 'public' : 'private')}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm text-white">نمایش آمار</p>
                        <p className="text-xs text-white/60">نمایش آمار پروفایل برای دیگران</p>
                      </div>
                      <Switch 
                        checked={showAnalytics}
                        onCheckedChange={setShowAnalytics}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm text-white">اعلان‌ها</p>
                        <p className="text-xs text-white/60">دریافت اعلان‌های جدید</p>
                      </div>
                      <Switch 
                        checked={notificationsEnabled}
                        onCheckedChange={setNotificationsEnabled}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <p className="text-sm text-white">پخش خودکار</p>
                        <p className="text-xs text-white/60">پخش خودکار ویدیوها</p>
                      </div>
                      <Switch 
                        checked={autoPlay}
                        onCheckedChange={setAutoPlay}
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="space-y-1">
                        <p className="text-sm text-white">کیفیت پیش‌فرض ویدیو</p>
                        <p className="text-xs text-white/60">کیفیت مورد نظر: {qualityPreference[0]}p</p>
                      </div>
                      <Slider
                        value={qualityPreference}
                        onValueChange={setQualityPreference}
                        max={1080}
                        min={360}
                        step={120}
                        className="w-full"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Social Links */}
                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Link2 className="h-5 w-5 text-brand-accent" />
                      شبکه‌های اجتماعی
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Instagram className="h-5 w-5 text-pink-400" />
                      <Input 
                        value={userData.socialLinks.instagram} 
                        placeholder="@username"
                        className="bg-white/5 border-white/20 text-white flex-1"
                      />
                    </div>

                    <div className="flex items-center gap-3">
                      <Youtube className="h-5 w-5 text-red-400" />
                      <Input 
                        value={userData.socialLinks.youtube} 
                        placeholder="Channel Name"
                        className="bg-white/5 border-white/20 text-white flex-1"
                      />
                    </div>

                    <div className="flex items-center gap-3">
                      <Twitch className="h-5 w-5 text-purple-400" />
                      <Input 
                        value={userData.socialLinks.twitch} 
                        placeholder="username"
                        className="bg-white/5 border-white/20 text-white flex-1"
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Account Actions */}
                <Card className="bg-card/50 backdrop-blur-sm border-white/10">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Settings className="h-5 w-5 text-white" />
                      عملیات حساب
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button variant="outline" className="w-full justify-start">
                      <Download className="h-4 w-4 ml-2" />
                      دانلود داده‌های من
                    </Button>

                    <Button variant="outline" className="w-full justify-start">
                      <Lock className="h-4 w-4 ml-2" />
                      تغییر رمز عبور
                    </Button>

                    <Button variant="outline" className="w-full justify-start">
                      <Mail className="h-4 w-4 ml-2" />
                      تغییر ایمیل
                    </Button>

                    <Button variant="destructive" className="w-full justify-start">
                      <Flag className="h-4 w-4 ml-2" />
                      حذف حساب کاربری
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Save Changes */}
              <div className="flex justify-end gap-4">
                <Button variant="outline">
                  لغو تغییرات
                </Button>
                <Button className="bg-gradient-to-r from-brand-primary to-brand-secondary">
                  ذخیره تغییرات
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

export default UserProfileHome;