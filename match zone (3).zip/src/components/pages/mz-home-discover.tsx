import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, Users, Trophy, Star, Zap, Target, Play, Pause,
  Headphones, Monitor, Wifi, Settings, User, Crown, Shield,
  Flame, Rocket, Activity, BarChart3, Calendar, Clock,
  MessageCircle, Video, Radio, Eye, Heart, Share2, Plus,
  ChevronRight, ArrowUp, TrendingUp, MapPin, Globe, Edit3,
  Cpu, HardDrive, MousePointer, Mic, Volume2, Camera,
  MoreHorizontal, Bell, Search, Home, UserCheck, Award,
  Medal, Gift, Sparkles, Layers, Hexagon, Crosshair,
  GamepadIcon, Twitch, Youtube, Instagram, Discord, Swords,
  Hash, Bookmark, Download, ExternalLink, ArrowRight,
  ThumbsUp, ThumbsDown, Flag, Volume, VolumeX, Maximize,
  Minimize, RotateCcw, RefreshCw, ChevronDown, Filter,
  SortAsc, Grid, List, Sliders, PieChart, LineChart,
  BarChart, Radar, Gauge, Timer, Stopwatch, Calendar as CalendarIcon
} from 'lucide-react';
import { Button } from '../ui/mz-button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { motion, AnimatePresence } from 'motion/react';

interface HomeDiscoverPageProps {
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
  onLobbyClick?: (lobbyId: string) => void;
}

interface GameSession {
  id: string;
  game: string;
  gameImage: string;
  duration: string;
  score: number;
  rank: string;
  timestamp: string;
  highlight: boolean;
  kills?: number;
  deaths?: number;
  assists?: number;
  kdr?: number;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: any;
  progress: number;
  maxProgress: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlocked: boolean;
  category: string;
  reward?: string;
}

interface Friend {
  id: string;
  name: string;
  avatar: string;
  status: 'online' | 'playing' | 'away' | 'offline';
  currentGame?: string;
  lastSeen?: string;
  level?: number;
}

interface GamingSetup {
  id: string;
  component: string;
  model: string;
  icon: any;
  specs: string;
}

export function HomeDiscoverPage({
  onNavigate,
  onLogout,
  onLobbyClick,
}: HomeDiscoverPageProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeView, setActiveView] = useState<'grid' | 'list'>('grid');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Mock Gaming Profile Data
  const userProfile = {
    name: 'KEOXER GAMING',
    title: 'Elite Pro Gamer',
    level: 47,
    xp: 12750,
    xpToNext: 15000,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    coverImage: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    rank: 'Diamond III',
    mainGame: 'VALORANT',
    playTime: '2847h',
    totalGames: 1247,
    winRate: 73,
    currentStreak: 12,
    bestStreak: 28,
    creditsBalance: 24750,
    gemsBalance: 156,
    status: 'در بازی',
    platforms: ['PC', 'PlayStation', 'Xbox'],
    specialties: ['FPS', 'Strategy', 'RPG'],
    joinDate: 'عضو از مرداد ۱۴۰۲',
    location: 'تهران، ایران',
    clan: 'PHOENIX ELITE',
    clanRole: 'Leader'
  };

  const gamingSetup: GamingSetup[] = [
    {
      id: '1',
      component: 'CPU',
      model: 'Intel i9-13900K',
      icon: Cpu,
      specs: '24 Core, 3.0GHz'
    },
    {
      id: '2',
      component: 'GPU',
      model: 'RTX 4090',
      icon: Monitor,
      specs: '24GB VRAM'
    },
    {
      id: '3',
      component: 'Mouse',
      model: 'Logitech G Pro X',
      icon: MousePointer,
      specs: '25600 DPI'
    },
    {
      id: '4',
      component: 'Headset',
      model: 'SteelSeries Pro',
      icon: Headphones,
      specs: 'Wireless, 7.1 Surround'
    }
  ];

  const recentSessions: GameSession[] = [
    {
      id: '1',
      game: 'VALORANT',
      gameImage: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '2h 35m',
      score: 28,
      rank: 'MVP',
      timestamp: '2 دقیقه پیش',
      highlight: true,
      kills: 28,
      deaths: 12,
      assists: 8,
      kdr: 2.33
    },
    {
      id: '2', 
      game: 'CS2',
      gameImage: 'https://images.unsplash.com/photo-1617507171089-6cb9aa5add36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHN0cmVhbWluZ3xlbnwxfHx8fDE3NTczMzkxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '1h 42m',
      score: 31,
      rank: '2nd Place',
      timestamp: '5 ساعت پیش',
      highlight: false,
      kills: 31,
      deaths: 15,
      assists: 6,
      kdr: 2.07
    },
    {
      id: '3',
      game: 'Apex Legends',
      gameImage: 'https://images.unsplash.com/photo-1675310854573-c5c8e4089426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3BvcnRzJTIwdG91cm5hbWVudCUyMGdhbWluZ3xlbnwxfHx8fDE3NTczNTkxODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '45m',
      score: 8,
      rank: 'Champion',
      timestamp: 'دیروز',
      highlight: true,
      kills: 8,
      deaths: 2,
      assists: 4,
      kdr: 4.0
    },
    {
      id: '4',
      game: 'Rocket League',
      gameImage: 'https://images.unsplash.com/photo-1617507171089-6cb9aa5add36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1pbmclMjBzZXR1cCUyMHN0cmVhbWluZ3xlbnwxfHx8fDE3NTczMzkxNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      duration: '1h 20m',
      score: 6,
      rank: 'Winner',
      timestamp: '2 روز پیش',
      highlight: false,
      kills: 0,
      deaths: 0,
      assists: 3,
      kdr: 0
    }
  ];

  const achievements: Achievement[] = [
    {
      id: '1',
      title: 'Headshot King',
      description: '100 headshot در یک بازی',
      icon: Crosshair,
      progress: 87,
      maxProgress: 100,
      rarity: 'epic',
      unlocked: false,
      category: 'Combat',
      reward: '500 XP + Badge'
    },
    {
      id: '2',
      title: 'Win Streak Master',
      description: '15 برد متوالی در Ranked',
      icon: Trophy,
      progress: 15,
      maxProgress: 15,
      rarity: 'legendary',
      unlocked: true,
      category: 'Victory',
      reward: '1000 XP + Title'
    },
    {
      id: '3',
      title: 'Team Player Supreme',
      description: '50 assist در یک ماه',
      icon: Users,
      progress: 34,
      maxProgress: 50,
      rarity: 'rare',
      unlocked: false,
      category: 'Teamwork',
      reward: '300 XP'
    },
    {
      id: '4',
      title: 'Speed Demon',
      description: 'کامل کردن مپ در کمتر از 5 دقیقه',
      icon: Zap,
      progress: 1,
      maxProgress: 1,
      rarity: 'epic',
      unlocked: true,
      category: 'Speed',
      reward: '750 XP + Icon'
    },
    {
      id: '5',
      title: 'Clan Leader',
      description: 'مدیریت کلن با 50+ عضو',
      icon: Crown,
      progress: 1,
      maxProgress: 1,
      rarity: 'legendary',
      unlocked: true,
      category: 'Leadership',
      reward: 'Special Crown Badge'
    },
    {
      id: '6',
      title: 'Tournament Victor',
      description: 'برنده شدن در 5 تورنومنت',
      icon: Award,
      progress: 3,
      maxProgress: 5,
      rarity: 'legendary',
      unlocked: false,
      category: 'Competition',
      reward: '2000 XP + Trophy'
    }
  ];

  const friends: Friend[] = [
    {
      id: '1',
      name: 'Phoenix_Pro',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      status: 'playing',
      currentGame: 'VALORANT - Ranked Match',
      level: 42
    },
    {
      id: '2',
      name: 'ShadowNinja',
      avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      status: 'online',
      level: 39
    },
    {
      id: '3',
      name: 'IronWolf99',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      status: 'away',
      lastSeen: '30 دقیقه پیش',
      level: 51
    },
    {
      id: '4',
      name: 'CyberAce',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lcnxlbnwxfHx8fDE3NTczNTk0Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      status: 'playing',
      currentGame: 'Apex Legends - Squad',
      level: 35
    }
  ];

  const getRarityColor = (rarity: Achievement['rarity']) => {
    switch (rarity) {
      case 'common': return 'text-gray-400 border-gray-400/30 bg-gray-400/10';
      case 'rare': return 'text-blue-400 border-blue-400/30 bg-blue-400/10';
      case 'epic': return 'text-purple-400 border-purple-400/30 bg-purple-400/10';
      case 'legendary': return 'text-yellow-400 border-yellow-400/30 bg-yellow-400/10';
      default: return 'text-gray-400 border-gray-400/30 bg-gray-400/10';
    }
  };

  const getStatusColor = (status: Friend['status']) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'playing': return 'bg-blue-500';
      case 'away': return 'bg-yellow-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const formatTime = (time: Date) => {
    return time.toLocaleTimeString('fa-IR', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-gray-900 to-black text-white overflow-hidden">
      {/* Cyberpunk Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-cyan-500/5" />
        <div className="absolute top-1/4 right-0 w-[600px] h-[600px] bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 left-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-cyan-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Header - Gaming Command Center */}
      <div className="relative z-10 border-b border-cyan-500/20 bg-black/50 backdrop-blur-md">
        <div className="max-w-7xl mx-auto p-6" dir="rtl">
          <div className="flex items-center justify-between mb-6">
            {/* User Profile Section */}
            <div className="flex items-center gap-6">
              <div className="relative">
                <Avatar className="h-24 w-24 ring-4 ring-cyan-400 ring-offset-4 ring-offset-black">
                  <AvatarImage src={userProfile.avatar} alt={userProfile.name} />
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-cyan-500 text-2xl">
                    {userProfile.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-2 -right-2 bg-green-500 rounded-full p-2 border-4 border-black">
                  <Gamepad2 className="h-4 w-4 text-white" />
                </div>
                <div className="absolute -top-2 -left-2 bg-yellow-500 rounded-full p-2 border-4 border-black">
                  <Crown className="h-4 w-4 text-black" />
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                    {userProfile.name}
                  </h1>
                  <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                    {userProfile.title}
                  </Badge>
                </div>
                
                <div className="flex items-center gap-4 text-sm">
                  <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500">
                    LVL {userProfile.level}
                  </Badge>
                  <span className="text-cyan-400">{userProfile.rank}</span>
                  <span className="text-gray-400">•</span>
                  <span className="text-yellow-400">{userProfile.clan}</span>
                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black">
                    {userProfile.clanRole}
                  </Badge>
                </div>
                
                <div className="flex items-center gap-6 text-sm text-gray-400">
                  <span>{userProfile.location}</span>
                  <span>•</span>
                  <span>{userProfile.joinDate}</span>
                  <span>•</span>
                  <span className="text-green-400">{userProfile.status}</span>
                </div>
              </div>
            </div>

            {/* Live Stats */}
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-cyan-400">{formatTime(currentTime)}</div>
                <p className="text-xs text-gray-400">زمان سیستم</p>
              </div>
              
              <div className="flex gap-3">
                <Button variant="outline" className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10">
                  <Settings className="h-4 w-4 ml-2" />
                  تنظیمات
                </Button>
                <Button className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                  <Play className="h-4 w-4 ml-2" />
                  شروع بازی
                </Button>
              </div>
            </div>
          </div>

          {/* XP Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-cyan-400">پیشرفت XP</span>
              <span className="text-gray-400">
                {userProfile.xp.toLocaleString()} / {userProfile.xpToNext.toLocaleString()} XP
              </span>
            </div>
            <Progress 
              value={(userProfile.xp / userProfile.xpToNext) * 100} 
              className="h-3 bg-gray-800"
            />
          </div>
        </div>
      </div>

      {/* Main Dashboard */}
      <div className="relative z-10 max-w-7xl mx-auto p-6">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="bg-black/50 border border-gray-700/50 mb-6" dir="rtl">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              نمای کلی
            </TabsTrigger>
            <TabsTrigger value="achievements" className="flex items-center gap-2">
              <Trophy className="h-4 w-4" />
              دستاوردها
            </TabsTrigger>
            <TabsTrigger value="sessions" className="flex items-center gap-2">
              <Gamepad2 className="h-4 w-4" />
              سشن‌های بازی
            </TabsTrigger>
            <TabsTrigger value="social" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              اجتماعی
            </TabsTrigger>
            <TabsTrigger value="setup" className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              تجهیزات
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6" dir="rtl">
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border-cyan-500/20">
                <CardContent className="p-6 text-center">
                  <Clock className="h-8 w-8 text-cyan-400 mx-auto mb-3" />
                  <div className="text-2xl font-bold text-white">{userProfile.playTime}</div>
                  <p className="text-sm text-gray-400">کل زمان بازی</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
                <CardContent className="p-6 text-center">
                  <TrendingUp className="h-8 w-8 text-green-400 mx-auto mb-3" />
                  <div className="text-2xl font-bold text-white">{userProfile.winRate}%</div>
                  <p className="text-sm text-gray-400">نرخ برد</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
                <CardContent className="p-6 text-center">
                  <Flame className="h-8 w-8 text-yellow-400 mx-auto mb-3" />
                  <div className="text-2xl font-bold text-white">{userProfile.currentStreak}</div>
                  <p className="text-sm text-gray-400">برد متوالی فعلی</p>
                  <p className="text-xs text-yellow-400 mt-1">بهترین: {userProfile.bestStreak}</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
                <CardContent className="p-6 text-center">
                  <Gift className="h-8 w-8 text-purple-400 mx-auto mb-3" />
                  <div className="text-xl font-bold text-white">{userProfile.creditsBalance.toLocaleString()}</div>
                  <p className="text-sm text-gray-400">امتیازات</p>
                  <div className="flex items-center justify-center gap-1 mt-1">
                    <Sparkles className="h-3 w-3 text-cyan-400" />
                    <span className="text-xs text-cyan-400">{userProfile.gemsBalance} جم</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity & Quick Actions */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Recent Highlights */}
              <Card className="lg:col-span-2 bg-black/50 border-gray-700/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Star className="h-5 w-5 text-yellow-400" />
                      هایلایت‌های اخیر
                    </CardTitle>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentSessions.filter(s => s.highlight).map((session) => (
                      <motion.div 
                        key={session.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex items-center justify-between p-4 bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-xl border border-yellow-500/20"
                      >
                        <div className="flex items-center gap-4">
                          <div className="bg-yellow-500/20 rounded-xl p-3">
                            <Trophy className="h-6 w-6 text-yellow-400" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-white">{session.game}</h3>
                            <div className="flex items-center gap-3 text-sm text-gray-400">
                              <span>{session.rank}</span>
                              <span>•</span>
                              <span>K/D: {session.kdr}</span>
                              <span>•</span>
                              <span>{session.timestamp}</span>
                            </div>
                          </div>
                        </div>
                        <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                          <Sparkles className="h-3 w-3 mr-1" />
                          هایلایت
                        </Badge>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-black/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Rocket className="h-5 w-5 text-cyan-400" />
                    اکشن‌های سریع
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
                    onClick={() => onNavigate?.('lobbies')}
                  >
                    <Play className="h-4 w-4 ml-2" />
                    شروع بازی جدید
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full border-purple-500/50 text-purple-400 hover:bg-purple-500/10"
                    onClick={() => onNavigate?.('lobbies')}
                  >
                    <Users className="h-4 w-4 ml-2" />
                    پیوستن به لابی
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full border-green-500/50 text-green-400 hover:bg-green-500/10"
                  >
                    <Video className="h-4 w-4 ml-2" />
                    شروع استریم
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10"
                    onClick={() => onNavigate?.('tournaments')}
                  >
                    <Trophy className="h-4 w-4 ml-2" />
                    تورنومنت‌ها
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6" dir="rtl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">دستاوردهای گیمینگ</h2>
                <p className="text-gray-400">پیشرفت و دستاوردهای شما در بازی‌ها</p>
              </div>
              <Button variant="outline" onClick={() => setActiveView(activeView === 'grid' ? 'list' : 'grid')}>
                {activeView === 'grid' ? <List className="h-4 w-4 ml-2" /> : <Grid className="h-4 w-4 ml-2" />}
                {activeView === 'grid' ? 'نمایش لیستی' : 'نمایش شبکه‌ای'}
              </Button>
            </div>

            <div className={`grid gap-4 ${activeView === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'}`}>
              {achievements.map((achievement) => (
                <Card 
                  key={achievement.id} 
                  className={`bg-black/50 border-gray-700/50 transition-all hover:scale-105 ${
                    achievement.unlocked ? 'ring-2 ring-cyan-500/30 shadow-lg shadow-cyan-500/20' : ''
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`p-4 rounded-xl ${
                        achievement.unlocked 
                          ? 'bg-gradient-to-br from-cyan-500/20 to-blue-500/20' 
                          : 'bg-gray-800/50'
                      }`}>
                        <achievement.icon className={`h-8 w-8 ${
                          achievement.unlocked ? getRarityColor(achievement.rarity).split(' ')[0] : 'text-gray-600'
                        }`} />
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className={`font-semibold ${achievement.unlocked ? 'text-white' : 'text-gray-400'}`}>
                            {achievement.title}
                          </h3>
                          {achievement.unlocked && (
                            <Badge className={getRarityColor(achievement.rarity)}>
                              {achievement.rarity}
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm text-gray-400 mb-3">{achievement.description}</p>
                        
                        {achievement.reward && (
                          <div className="flex items-center gap-1 text-xs text-yellow-400 mb-3">
                            <Gift className="h-3 w-3" />
                            <span>{achievement.reward}</span>
                          </div>
                        )}
                        
                        {!achievement.unlocked && (
                          <div>
                            <div className="flex justify-between text-sm text-gray-400 mb-2">
                              <span>پیشرفت</span>
                              <span>{achievement.progress}/{achievement.maxProgress}</span>
                            </div>
                            <Progress 
                              value={(achievement.progress / achievement.maxProgress) * 100} 
                              className="h-2 bg-gray-800"
                            />
                          </div>
                        )}
                        
                        {achievement.unlocked && (
                          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                            <Trophy className="h-3 w-3 mr-1" />
                            تکمیل شده
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Gaming Sessions Tab */}
          <TabsContent value="sessions" className="space-y-6" dir="rtl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">سشن‌های بازی</h2>
                <p className="text-gray-400">تاریخچه و آمار بازی‌های شما</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 ml-2" />
                  فیلتر
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 ml-2" />
                  دانلود
                </Button>
              </div>
            </div>

            <div className="grid gap-4">
              {recentSessions.map((session) => (
                <Card key={session.id} className="bg-black/50 border-gray-700/50 hover:border-cyan-500/30 transition-all">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <img 
                            src={session.gameImage} 
                            alt={session.game}
                            className="w-16 h-16 rounded-xl object-cover"
                          />
                          <div className="absolute -top-2 -right-2">
                            <Badge className={`${
                              session.rank === 'MVP' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                              session.rank === 'Champion' ? 'bg-purple-500/20 text-purple-400 border-purple-500/30' :
                              session.rank === 'Winner' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                              'bg-blue-500/20 text-blue-400 border-blue-500/30'
                            }`}>
                              {session.rank}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="space-y-1">
                          <h3 className="font-semibold text-white text-lg">{session.game}</h3>
                          <div className="flex items-center gap-4 text-sm text-gray-400">
                            <span>{session.duration}</span>
                            <span>•</span>
                            <span>{session.timestamp}</span>
                            {session.highlight && (
                              <>
                                <span>•</span>
                                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 text-xs">
                                  هایلایت
                                </Badge>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        {session.game !== 'Rocket League' && (
                          <div className="text-center">
                            <div className="text-sm text-gray-400">K/D/A</div>
                            <div className="font-semibold text-white">
                              {session.kills}/{session.deaths}/{session.assists}
                            </div>
                            <div className="text-xs text-cyan-400">KDR: {session.kdr}</div>
                          </div>
                        )}
                        
                        <div className="text-center">
                          <div className="text-sm text-gray-400">امتیاز</div>
                          <div className="text-xl font-bold text-white">{session.score}</div>
                        </div>

                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Social Tab */}
          <TabsContent value="social" className="space-y-6" dir="rtl">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Friends List */}
              <Card className="lg:col-span-2 bg-black/50 border-gray-700/50">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-white">
                      <Users className="h-5 w-5 text-green-400" />
                      دوستان ({friends.length})
                    </CardTitle>
                    <Button variant="ghost" size="sm">
                      <UserCheck className="h-4 w-4 ml-2" />
                      افزودن دوست
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {friends.map((friend) => (
                      <div key={friend.id} className="flex items-center justify-between p-4 bg-gray-800/30 rounded-xl hover:bg-gray-800/50 transition-colors">
                        <div className="flex items-center gap-4">
                          <div className="relative">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={friend.avatar} alt={friend.name} />
                              <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className={`absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-black ${getStatusColor(friend.status)}`} />
                          </div>
                          
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium text-white">{friend.name}</h3>
                              {friend.level && (
                                <Badge className="bg-gray-700 text-gray-300 text-xs">
                                  LVL {friend.level}
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-400">
                              {friend.status === 'playing' ? friend.currentGame :
                               friend.status === 'away' ? friend.lastSeen :
                               friend.status === 'online' ? 'آنلاین' : 'آفلاین'}
                            </p>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" className="p-2">
                            <MessageCircle className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" className="p-2">
                            <Gamepad2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Social Stats */}
              <Card className="bg-black/50 border-gray-700/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <Activity className="h-5 w-5 text-cyan-400" />
                    آمار اجتماعی
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center p-4 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-xl">
                    <div className="text-2xl font-bold text-cyan-400">{friends.length}</div>
                    <p className="text-sm text-gray-400">دوست</p>
                  </div>
                  
                  <div className="text-center p-4 bg-gradient-to-br from-green-500/10 to-emerald-500/10 rounded-xl">
                    <div className="text-2xl font-bold text-green-400">
                      {friends.filter(f => f.status === 'online' || f.status === 'playing').length}
                    </div>
                    <p className="text-sm text-gray-400">آنلاین</p>
                  </div>
                  
                  <div className="text-center p-4 bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-xl">
                    <div className="text-2xl font-bold text-purple-400">
                      {friends.filter(f => f.status === 'playing').length}
                    </div>
                    <p className="text-sm text-gray-400">در بازی</p>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-500">
                    <Users className="h-4 w-4 ml-2" />
                    دعوت دوستان
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Gaming Setup Tab */}
          <TabsContent value="setup" className="space-y-6" dir="rtl">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">تجهیزات گیمینگ</h2>
              <p className="text-gray-400">مشخصات و تجهیزات گیمینگ شما</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {gamingSetup.map((item) => (
                <Card key={item.id} className="bg-black/50 border-gray-700/50 hover:border-cyan-500/30 transition-all">
                  <CardContent className="p-6 text-center">
                    <div className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl p-4 mb-4">
                      <item.icon className="h-8 w-8 text-cyan-400 mx-auto" />
                    </div>
                    <h3 className="font-semibold text-white mb-1">{item.component}</h3>
                    <p className="text-sm text-gray-300 mb-2">{item.model}</p>
                    <p className="text-xs text-gray-400">{item.specs}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Platform Stats */}
            <Card className="bg-black/50 border-gray-700/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Monitor className="h-5 w-5 text-cyan-400" />
                  پلتفرم‌های گیمینگ
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {userProfile.platforms.map((platform, index) => (
                    <div key={index} className="text-center p-4 bg-gray-800/30 rounded-xl">
                      <div className="text-lg font-semibold text-white">{platform}</div>
                      <p className="text-sm text-gray-400">فعال</p>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 pt-6 border-t border-gray-700">
                  <h4 className="font-semibold text-white mb-4">تخصص‌های بازی</h4>
                  <div className="flex flex-wrap gap-2">
                    {userProfile.specialties.map((specialty, index) => (
                      <Badge key={index} className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-purple-400 border-purple-500/30">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default HomeDiscoverPage;