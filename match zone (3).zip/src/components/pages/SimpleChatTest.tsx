/**
 * Simple Chat Test - تست ساده صفحه چت
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  MessageCircle, 
  Search, 
  Filter,
  ArrowLeft,
  Plus,
  Users,
  Pin,
  Hash,
  Volume2,
  ChevronRight,
  User,
  Settings,
  Bell,
  AlertCircle
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { ScrollArea } from '../ui/scroll-area';
import { useMobile } from '../ui/use-mobile';
import { AdvancedChatSystem } from '../chat/AdvancedChatSystem';

interface SimpleChatItem {
  id: string;
  name: string;
  type: 'group' | 'direct' | 'clan' | 'system';
  avatar?: string;
  gradient: string;
  lastMessage: {
    content: string;
    timestamp: string;
    sender: string;
  };
  unreadCount: number;
  isOnline?: boolean;
  members?: number;
  isPinned?: boolean;
  clanTag?: string;
  voiceActive?: boolean;
}

type ChatTab = 'groups' | 'direct' | 'system';

export function SimpleChatTest() {
  const isMobile = useMobile();
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<ChatTab>('groups');

  // Mock data
  const chats: SimpleChatItem[] = [
    // Group Chats
    {
      id: '1',
      name: 'Fire Dragons Elite',
      type: 'clan',
      gradient: 'from-red-500 to-orange-500',
      lastMessage: {
        content: '🏆 آماده برای تورنومنت شب؟',
        timestamp: '2 دقیقه پیش',
        sender: 'Captain Phoenix'
      },
      unreadCount: 7,
      members: 24,
      isPinned: true,
      clanTag: 'FDG',
      voiceActive: true
    },
    {
      id: '3',
      name: 'Night Owls Squad',
      type: 'group',
      gradient: 'from-blue-500 to-cyan-500',
      lastMessage: {
        content: '🌙 شب‌های بازی کی شروع میشه؟',
        timestamp: '15 دقیقه پیش',
        sender: 'NightHunter'
      },
      unreadCount: 4,
      members: 16
    },
    {
      id: '4',
      name: 'Pro Gamers League',
      type: 'group',
      gradient: 'from-green-500 to-emerald-500',
      lastMessage: {
        content: '⚡ مسابقه امشب ساعت 9',
        timestamp: '30 دقیقه پیش',
        sender: 'GameMaster'
      },
      unreadCount: 12,
      members: 45,
      isPinned: false
    },
    
    // Direct Messages
    {
      id: '2',
      name: 'Sarah Pro Gamer',
      type: 'direct',
      gradient: 'from-purple-500 to-pink-500',
      lastMessage: {
        content: '🎮 بازی جدید رو امتحان کردی؟',
        timestamp: '5 دقیقه پیش',
        sender: 'Sarah Pro Gamer'
      },
      unreadCount: 2,
      isOnline: true
    },
    {
      id: '5',
      name: 'Ali Champion',
      type: 'direct',
      gradient: 'from-indigo-500 to-blue-500',
      lastMessage: {
        content: 'سلام! وقت بازی داری؟',
        timestamp: '1 ساعت پیش',
        sender: 'Ali Champion'
      },
      unreadCount: 0,
      isOnline: false
    },
    {
      id: '6',
      name: 'Mina Esports',
      type: 'direct',
      gradient: 'from-rose-500 to-pink-500',
      lastMessage: {
        content: 'استراتژی جدید رو ببین 🔥',
        timestamp: '3 ساعت پیش',
        sender: 'Mina Esports'
      },
      unreadCount: 1,
      isOnline: true
    },
    
    // System Messages
    {
      id: '7',
      name: 'اعلانات سیستم',
      type: 'system',
      gradient: 'from-yellow-500 to-orange-500',
      lastMessage: {
        content: '🔄 بروزرسانی سیستم در ساعت 2 بامداد',
        timestamp: '1 ساعت پیش',
        sender: 'سیستم'
      },
      unreadCount: 3
    },
    {
      id: '8',
      name: 'پشتیبانی فنی',
      type: 'system',
      gradient: 'from-teal-500 to-cyan-500',
      lastMessage: {
        content: '✅ مشکل اتصال برطرف شد',
        timestamp: '2 ساعت پیش',
        sender: 'پشتیبانی'
      },
      unreadCount: 0
    },
    {
      id: '9',
      name: 'گزارش امنیتی',
      type: 'system',
      gradient: 'from-red-500 to-pink-500',
      lastMessage: {
        content: '🔒 ورود جدید از دستگاه ناشناس',
        timestamp: '6 ساعت پیش',
        sender: 'امنیت'
      },
      unreadCount: 1
    }
  ];

  // Filter chats based on active tab and search query
  const filteredChats = chats.filter(chat => {
    // Filter by tab
    let tabMatch = false;
    switch (activeTab) {
      case 'groups':
        tabMatch = chat.type === 'group' || chat.type === 'clan';
        break;
      case 'direct':
        tabMatch = chat.type === 'direct';
        break;
      case 'system':
        tabMatch = chat.type === 'system';
        break;
    }
    
    // Filter by search query
    const searchMatch = !searchQuery || chat.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    return tabMatch && searchMatch;
  });
  
  // Tab counts for badges
  const tabCounts = {
    groups: chats.filter(chat => chat.type === 'group' || chat.type === 'clan').length,
    direct: chats.filter(chat => chat.type === 'direct').length,
    system: chats.filter(chat => chat.type === 'system').length
  };
  
  const unreadCounts = {
    groups: chats.filter(chat => chat.type === 'group' || chat.type === 'clan').reduce((acc, chat) => acc + chat.unreadCount, 0),
    direct: chats.filter(chat => chat.type === 'direct').reduce((acc, chat) => acc + chat.unreadCount, 0),
    system: chats.filter(chat => chat.type === 'system').reduce((acc, chat) => acc + chat.unreadCount, 0)
  };

  // Mobile Chat List Item
  const MobileChatItem = ({ chat }: { chat: SimpleChatItem }) => (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      whileTap={{ scale: 0.98 }}
      className="group"
    >
      <div 
        className={`
          flex items-center p-4 cursor-pointer transition-all duration-200 min-h-[80px]
          ${selectedChat === chat.id 
            ? 'bg-blue-500/10 border-r-4 border-r-blue-500' 
            : 'hover:bg-surface-secondary/30 active:bg-surface-secondary/50'
          }
        `}
        onClick={() => setSelectedChat(chat.id)}
      >
        {/* Avatar */}
        <div className="relative ml-3 flex-shrink-0">
          <div className={`p-0.5 rounded-full bg-gradient-to-br ${chat.gradient}`}>
            <Avatar className="h-12 w-12 bg-background">
              <AvatarImage src={chat.avatar} alt={chat.name} />
              <AvatarFallback className="text-white bg-gradient-to-br from-blue-500 to-purple-500">
                {chat.name[0]}
              </AvatarFallback>
            </Avatar>
          </div>
          
          {chat.isOnline && (
            <div className="absolute -bottom-1 -left-1 h-4 w-4 bg-green-500 rounded-full border-2 border-background animate-pulse" />
          )}
          
          {chat.voiceActive && (
            <div className="absolute -top-1 -right-1 h-5 w-5 bg-blue-500 rounded-full flex items-center justify-center">
              <Volume2 className="h-2.5 w-2.5 text-white" />
            </div>
          )}
        </div>
        
        {/* Chat Info */}
        <div className="flex-1 min-w-0 mr-3">
          <div className="flex items-start justify-between mb-1">
            <div className="flex items-center space-x-1 rtl:space-x-reverse min-w-0 flex-1">
              <h3 className="font-semibold truncate flex items-center space-x-1 rtl:space-x-reverse">
                <span className="truncate">{chat.name}</span>
                {chat.isPinned && <Pin className="h-3 w-3 text-yellow-400 flex-shrink-0" />}
              </h3>
              
              {chat.clanTag && (
                <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400 border-blue-500/30 flex-shrink-0 hidden xs:flex">
                  <Hash className="w-2 h-2 ml-1" />
                  {chat.clanTag}
                </Badge>
              )}
            </div>
            
            <div className="flex flex-col items-end space-y-1 flex-shrink-0">
              <span className="text-xs text-muted-foreground whitespace-nowrap">{chat.lastMessage.timestamp}</span>
              {chat.unreadCount > 0 && (
                <Badge className="h-5 min-w-[20px] px-1 text-xs rounded-full bg-gradient-to-r from-blue-500 to-purple-500">
                  {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                </Badge>
              )}
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground truncate flex items-center space-x-1 rtl:space-x-reverse min-w-0 flex-1">
              {chat.type !== 'direct' && (
                <span className="font-medium flex-shrink-0">{chat.lastMessage.sender}:</span>
              )}
              <span className="truncate">{chat.lastMessage.content}</span>
            </div>
            
            <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0 ml-2" />
          </div>
          
          {chat.members && (
            <div className="flex items-center space-x-1 rtl:space-x-reverse text-xs text-muted-foreground mt-1">
              <Users className="h-3 w-3 flex-shrink-0" />
              <span>{chat.members} عضو</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );

  // Desktop Chat Item
  const DesktopChatItem = ({ chat }: { chat: SimpleChatItem }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="group"
    >
      <Card 
        className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-0 ${
          selectedChat === chat.id 
            ? 'bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-l-4 border-l-blue-500' 
            : 'hover:bg-surface-secondary/50'
        }`}
        onClick={() => setSelectedChat(chat.id)}
      >
        <CardContent className="p-4">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="relative">
              <div className={`p-0.5 rounded-full bg-gradient-to-br ${chat.gradient}`}>
                <Avatar className="h-12 w-12 bg-background">
                  <AvatarImage src={chat.avatar} alt={chat.name} />
                  <AvatarFallback className="text-white bg-gradient-to-br from-blue-500 to-purple-500">
                    {chat.name[0]}
                  </AvatarFallback>
                </Avatar>
              </div>
              
              {chat.isOnline && (
                <div className="absolute -bottom-1 -left-1 h-3 w-3 bg-green-500 rounded-full border-2 border-background animate-pulse" />
              )}
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <h3 className="font-semibold truncate flex items-center space-x-1 rtl:space-x-reverse">
                    <span>{chat.name}</span>
                    {chat.isPinned && <Pin className="h-3 w-3 text-yellow-400" />}
                  </h3>
                  
                  {chat.clanTag && (
                    <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-400 border-blue-500/30">
                      <Hash className="w-2 h-2 ml-1" />
                      {chat.clanTag}
                    </Badge>
                  )}
                </div>
                
                <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs text-muted-foreground">
                  <span>{chat.lastMessage.timestamp}</span>
                  {chat.unreadCount > 0 && (
                    <Badge className="h-5 w-5 p-0 text-xs rounded-full bg-gradient-to-r from-blue-500 to-purple-500">
                      {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="text-sm text-muted-foreground truncate flex items-center space-x-1 rtl:space-x-reverse">
                {chat.type !== 'direct' && (
                  <span className="font-medium">{chat.lastMessage.sender}:</span>
                )}
                <span>{chat.lastMessage.content}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );

  // Chat Interface
  const ChatInterface = () => {
    const selectedChatData = chats.find(chat => chat.id === selectedChat);
    
    return (
      <div className={`flex flex-col bg-background ${isMobile ? 'h-[calc(100vh-76px)]' : 'h-screen'}`}>
        {/* Chat Header */}
        <div className="flex-shrink-0 flex items-center justify-between p-4 border-b border-border/50 bg-background/95 backdrop-blur-sm">
          <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0 flex-1">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setSelectedChat(null)}
              className="flex-shrink-0"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            
            {selectedChatData && (
              <>
                <div className={`p-0.5 rounded-full bg-gradient-to-br ${selectedChatData.gradient} flex-shrink-0`}>
                  <Avatar className="h-8 w-8 bg-background">
                    <AvatarImage src={selectedChatData.avatar} alt={selectedChatData.name} />
                    <AvatarFallback className="text-white bg-gradient-to-br from-blue-500 to-purple-500">
                      {selectedChatData.name[0]}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="min-w-0 flex-1">
                  <h2 className="font-semibold truncate">{selectedChatData.name}</h2>
                  <p className="text-xs text-muted-foreground">
                    {selectedChatData.members ? `${selectedChatData.members} عضو` : 'آنلاین'}
                  </p>
                </div>
              </>
            )}
          </div>
          
          {/* Additional actions for larger screens */}
          {!isMobile && (
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
        
        {/* Chat Content */}
        <div className="flex-1 overflow-hidden">
          <AdvancedChatSystem />
        </div>
      </div>
    );
  };

  // Tab Bar Component
  const TabBar = () => {
    const tabs = [
      { 
        key: 'groups' as ChatTab, 
        label: 'گروه‌ها', 
        icon: Users, 
        count: tabCounts.groups,
        unread: unreadCounts.groups 
      },
      { 
        key: 'direct' as ChatTab, 
        label: 'شخصی‌ها', 
        icon: User, 
        count: tabCounts.direct,
        unread: unreadCounts.direct 
      },
      { 
        key: 'system' as ChatTab, 
        label: 'سیستم', 
        icon: Settings, 
        count: tabCounts.system,
        unread: unreadCounts.system 
      }
    ];

    return (
      <div className="px-4 pb-4">
        <div className="flex bg-surface-secondary/30 rounded-xl p-1 border border-border/30 overflow-hidden">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            
            return (
              <motion.button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`
                  relative flex-1 flex items-center justify-center space-x-1 rtl:space-x-reverse
                  px-2 py-3 rounded-lg font-medium transition-all duration-200
                  ${isMobile ? 'text-xs' : 'text-sm'}
                  ${isActive 
                    ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-surface-secondary/30'
                  }
                `}
                whileTap={{ scale: 0.95 }}
              >
                <Icon className={`${isMobile ? 'h-3.5 w-3.5' : 'h-4 w-4'} flex-shrink-0`} />
                <span className={`${isMobile ? 'hidden xs:inline' : ''} truncate`}>{tab.label}</span>
                
                {/* Count Badge */}
                {tab.count > 0 && (
                  <Badge 
                    variant="secondary" 
                    className={`
                      h-4 min-w-[16px] px-1 text-xs rounded-full flex-shrink-0
                      ${isActive 
                        ? 'bg-white/20 text-white' 
                        : 'bg-surface-secondary text-muted-foreground'
                      }
                    `}
                  >
                    {tab.count > 99 ? '99+' : tab.count}
                  </Badge>
                )}
                
                {/* Unread Badge */}
                {tab.unread > 0 && (
                  <div className={`
                    absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full animate-pulse
                    ${isActive ? 'bg-yellow-400' : 'bg-red-500'}
                  `} />
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    );
  };

  // Main Layout
  if (selectedChat && isMobile) {
    return <ChatInterface />;
  }

  if (selectedChat && !isMobile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900">
        <ChatInterface />
      </div>
    );
  }

  // Chat List View
  if (isMobile) {
    return (
      <div className="flex flex-col h-[calc(100vh-76px)] bg-background"> {/* Adjust height for new bottom navigation */}
        {/* Mobile Header */}
        <div className="flex-shrink-0 bg-background/95 backdrop-blur-sm border-b border-border/50">
          <div className="flex items-center justify-between p-4">
            <div className="flex items-center space-x-3 rtl:space-x-reverse">
              <div className="p-2 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500">
                <MessageCircle className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">چت‌ها</h1>
                <p className="text-sm text-muted-foreground">
                  {filteredChats.length} چت • {filteredChats.reduce((acc, chat) => acc + chat.unreadCount, 0)} پیام جدید
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Button variant="ghost" size="sm">
                <Filter className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Search Bar */}
          <div className="px-4 pb-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجو در چت‌ها..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 bg-surface-secondary/50 border-border/50 focus:border-blue-500/50 text-right"
                dir="rtl"
              />
            </div>
          </div>
          
          {/* Tab Bar */}
          <TabBar />
        </div>
        
        {/* Chat List - Scrollable Area */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full">
            <div className="divide-y divide-border/30 pb-4"> {/* Add bottom padding to content */}
              {filteredChats.map((chat) => (
                <MobileChatItem key={chat.id} chat={chat} />
              ))}
            </div>
            
            {/* Empty State */}
            {filteredChats.length === 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-12 px-4"
              >
                <div className="p-4 rounded-full bg-surface-secondary/50 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  {activeTab === 'groups' && <Users className="h-8 w-8 text-muted-foreground" />}
                  {activeTab === 'direct' && <User className="h-8 w-8 text-muted-foreground" />}
                  {activeTab === 'system' && <Settings className="h-8 w-8 text-muted-foreground" />}
                </div>
                <h3 className="font-semibold mb-2">
                  {activeTab === 'groups' && 'گروهی یافت نشد'}
                  {activeTab === 'direct' && 'چت شخصی یافت نشد'}
                  {activeTab === 'system' && 'پیام سیستمی یافت نشد'}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {searchQuery 
                    ? `${activeTab === 'groups' ? 'گروه' : activeTab === 'direct' ? 'چت شخصی' : 'پیام سیستم'}ی با این جستجو یافت نشد` 
                    : `هنوز ${activeTab === 'groups' ? 'گروه' : activeTab === 'direct' ? 'چت شخصی' : 'پیام سیستم'}ی ندارید`
                  }
                </p>
                {activeTab !== 'system' && (
                  <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
                    <Plus className="h-4 w-4 ml-2" />
                    {activeTab === 'groups' ? 'ساخت گروه جدید' : 'شروع چت جدید'}
                  </Button>
                )}
              </motion.div>
            )}
          </ScrollArea>
        </div>
      </div>
    );
  }

  // Desktop Layout
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Desktop Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500">
              <MessageCircle className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                مرکز ارتباطات
              </h1>
              <p className="text-muted-foreground">
                {filteredChats.length} چت فعال • {filteredChats.reduce((acc, chat) => acc + chat.unreadCount, 0)} پیام جدید
              </p>
            </div>
          </div>
          
          <Button 
            size="sm"
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
          >
            <Plus className="h-4 w-4 ml-2" />
            چت جدید
          </Button>
        </motion.div>

        {/* Search */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="relative max-w-md">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="جستجو در چت‌ها..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10 bg-surface-secondary/50 border-border/50 focus:border-blue-500/50 text-right"
              dir="rtl"
            />
          </div>
        </motion.div>

        {/* Tab Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <TabBar />
        </motion.div>

        {/* Chat Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-2"
        >
          {filteredChats.map((chat) => (
            <DesktopChatItem key={chat.id} chat={chat} />
          ))}
        </motion.div>

        {filteredChats.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12"
          >
            <div className="p-4 rounded-full bg-surface-secondary/50 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              {activeTab === 'groups' && <Users className="h-8 w-8 text-muted-foreground" />}
              {activeTab === 'direct' && <User className="h-8 w-8 text-muted-foreground" />}
              {activeTab === 'system' && <Settings className="h-8 w-8 text-muted-foreground" />}
            </div>
            <h3 className="font-semibold mb-2">
              {activeTab === 'groups' && 'گروهی یافت نشد'}
              {activeTab === 'direct' && 'چت شخصی یافت نشد'}
              {activeTab === 'system' && 'پیام سیستمی یافت نشد'}
            </h3>
            <p className="text-muted-foreground mb-4">
              {searchQuery 
                ? `${activeTab === 'groups' ? 'گروه' : activeTab === 'direct' ? 'چت شخصی' : 'پیام سیستم'}ی با این جستجو یافت نشد` 
                : `هنوز ${activeTab === 'groups' ? 'گروه' : activeTab === 'direct' ? 'چت شخصی' : 'پیام سیستم'}ی ندارید`
              }
            </p>
            {activeTab !== 'system' && (
              <Button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
                <Plus className="h-4 w-4 ml-2" />
                {activeTab === 'groups' ? 'ساخت گروه جدید' : 'شروع چت جدید'}
              </Button>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}

export default SimpleChatTest;