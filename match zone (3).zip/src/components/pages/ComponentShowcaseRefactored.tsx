/**
 * Matchzone Component Showcase - Refactored
 * Interactive showcase of all components with live documentation
 */

import React from 'react';
import { ComponentRegistryDisplay } from '../registry/ComponentRegistry';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { ComponentProps } from '../ui/interfaces';

export interface ComponentShowcaseProps extends ComponentProps {
  /** Show only specific categories */
  categories?: string[];
  /** Interactive mode with editable props */
  interactive?: boolean;
}

/**
 * Component Showcase - Refactored Version
 * 
 * Features:
 * - Live component documentation
 * - Interactive examples
 * - Props editing
 * - Code generation
 * - Responsive design
 * 
 * @param props - ComponentShowcase props
 * @returns {JSX.Element} The rendered showcase
 */
export function ComponentShowcaseRefactored({
  categories,
  interactive = true,
  className,
  ...props
}: ComponentShowcaseProps): JSX.Element {
  return (
    <div className={`min-h-screen bg-background ${className}`} dir="rtl" {...props}>
      <div className="container mx-auto py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">
            🎮 Matchzone Design System
          </h1>
          <p className="text-xl text-text-secondary mb-6">
            سیستم طراحی جامع پلتفرم گیمینگ اجتماعی ایران
          </p>
          
          <div className="flex justify-center gap-2 flex-wrap">
            <Badge className="bg-brand-primary text-white">RTL Support</Badge>
            <Badge className="bg-brand-secondary text-white">Mobile First</Badge>
            <Badge className="bg-brand-accent text-black">WCAG AA</Badge>
            <Badge variant="outline">Component-Oriented</Badge>
            <Badge variant="outline">TypeScript</Badge>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center p-4">
            <CardContent className="pt-2">
              <div className="text-2xl font-bold text-brand-primary">15+</div>
              <p className="text-sm text-text-secondary">کامپوننت پایه</p>
            </CardContent>
          </Card>
          
          <Card className="text-center p-4">
            <CardContent className="pt-2">
              <div className="text-2xl font-bold text-brand-secondary">8+</div>
              <p className="text-sm text-text-secondary">کامپوننت گیمینگ</p>
            </CardContent>
          </Card>
          
          <Card className="text-center p-4">
            <CardContent className="pt-2">
              <div className="text-2xl font-bold text-brand-accent">10+</div>
              <p className="text-sm text-text-secondary">صفحه کامل</p>
            </CardContent>
          </Card>
          
          <Card className="text-center p-4">
            <CardContent className="pt-2">
              <div className="text-2xl font-bold text-purple-500">100%</div>
              <p className="text-sm text-text-secondary">مستندسازی</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="components" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="components">کامپوننت‌ها</TabsTrigger>
            <TabsTrigger value="foundations">Foundations</TabsTrigger>
            <TabsTrigger value="patterns">الگوها</TabsTrigger>
            <TabsTrigger value="guidelines">راهنما</TabsTrigger>
          </TabsList>

          {/* Components Tab */}
          <TabsContent value="components">
            <ComponentRegistryDisplay />
          </TabsContent>

          {/* Foundations Tab */}
          <TabsContent value="foundations">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>🎨 Color System</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Brand Colors */}
                    <div>
                      <h4 className="font-semibold mb-3">رنگ‌های برند</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-brand-primary rounded"></div>
                          <span className="text-sm">Primary - #3B82F6</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-brand-secondary rounded"></div>
                          <span className="text-sm">Secondary - #22C55E</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-brand-accent rounded"></div>
                          <span className="text-sm">Accent - #FACC15</span>
                        </div>
                      </div>
                    </div>

                    {/* State Colors */}
                    <div>
                      <h4 className="font-semibold mb-3">رنگ‌های حالت</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-state-success rounded"></div>
                          <span className="text-sm">Success - #22C55E</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-state-warning rounded"></div>
                          <span className="text-sm">Warning - #FACC15</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-state-danger rounded"></div>
                          <span className="text-sm">Danger - #EF4444</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-state-info rounded"></div>
                          <span className="text-sm">Info - #3B82F6</span>
                        </div>
                      </div>
                    </div>

                    {/* Surface Colors */}
                    <div>
                      <h4 className="font-semibold mb-3">رنگ‌های سطح</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-surface-primary border border-border-primary rounded"></div>
                          <span className="text-sm">Primary Surface</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-surface-secondary border border-border-primary rounded"></div>
                          <span className="text-sm">Secondary Surface</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-6 bg-surface-tertiary border border-border-primary rounded"></div>
                          <span className="text-sm">Tertiary Surface</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>📝 Typography</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h1>Heading 1 - عنوان اصلی</h1>
                      <p className="text-sm text-text-secondary">32px, Semibold, Line-height 1.25</p>
                    </div>
                    <div>
                      <h2>Heading 2 - عنوان فرعی</h2>
                      <p className="text-sm text-text-secondary">24px, Semibold, Line-height 1.25</p>
                    </div>
                    <div>
                      <h3>Heading 3 - عنوان بخش</h3>
                      <p className="text-sm text-text-secondary">18px, Semibold, Line-height 1.5</p>
                    </div>
                    <div>
                      <p>Body Text - متن بدنه اصلی برای خواندن راحت و مناسب</p>
                      <p className="text-sm text-text-secondary">16px, Normal, Line-height 1.5</p>
                    </div>
                    <div>
                      <small>Caption - متن کوچک برای توضیحات اضافی</small>
                      <p className="text-sm text-text-secondary">12px, Normal, Line-height 1.5</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Patterns Tab */}
          <TabsContent value="patterns">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>🏗️ Design Patterns</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-2">Card Pattern</h4>
                      <p className="text-sm text-text-secondary mb-3">
                        استفاده از کارت برای گروه‌بندی محتوا با spacing و elevation مناسب
                      </p>
                      <div className="text-xs font-mono bg-surface-secondary p-2 rounded">
                        <Card><CardHeader>...</CardHeader></Card>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Form Pattern</h4>
                      <p className="text-sm text-text-secondary mb-3">
                        الگوی فرم با validation و state management
                      </p>
                      <div className="text-xs font-mono bg-surface-secondary p-2 rounded">
                        <Input state="error" errorText="..." />
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Gaming Card Pattern</h4>
                      <p className="text-sm text-text-secondary mb-3">
                        کارت‌های اختصاصی گیمینگ با trust levels و status
                      </p>
                      <div className="text-xs font-mono bg-surface-secondary p-2 rounded">
                        <LobbyCard status="open" ownerTrust="high" />
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Navigation Pattern</h4>
                      <p className="text-sm text-text-secondary mb-3">
                        الگوی ناوبری ریسپانسیو با sidebar و bottom navigation
                      </p>
                      <div className="text-xs font-mono bg-surface-secondary p-2 rounded">
                        useNavigation() hook
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Guidelines Tab */}
          <TabsContent value="guidelines">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>📋 Development Guidelines</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">🔧 Component Development</h4>
                      <ul className="list-disc list-inside space-y-1 text-sm text-text-secondary">
                        <li>همیشه از TypeScript interfaces استفاده کنید</li>
                        <li>Props را با createPropDef مستندسازی کنید</li>
                        <li>forwardRef برای تمام کامپوننت‌های base</li>
                        <li>className و ...props را پشتیبانی کنید</li>
                        <li>RTL support با dir="rtl"</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">🎨 Styling Guidelines</h4>
                      <ul className="list-disc list-inside space-y-1 text-sm text-text-secondary">
                        <li>از CSS variables در globals.css استفاده کنید</li>
                        <li>Class Variance Authority برای variants</li>
                        <li>Mobile-first responsive design</li>
                        <li>WCAG AA compliance</li>
                        <li>Gaming-themed animations</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">🚀 Performance</h4>
                      <ul className="list-disc list-inside space-y-1 text-sm text-text-secondary">
                        <li>React.memo برای کامپوننت‌های سنگین</li>
                        <li>useCallback برای event handlers</li>
                        <li>Lazy loading برای images</li>
                        <li>Virtual scrolling برای lists</li>
                        <li>Code splitting برای pages</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">🧪 Testing</h4>
                      <ul className="list-disc list-inside space-y-1 text-text-secondary">
                        <li>data-testid برای همه کامپوننت‌ها</li>
                        <li>Unit tests با Jest</li>
                        <li>Component tests با Testing Library</li>
                        <li>Visual regression tests</li>
                        <li>Accessibility tests</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default ComponentShowcaseRefactored;