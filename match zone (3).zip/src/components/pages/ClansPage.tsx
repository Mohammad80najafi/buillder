import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Shield, Crown, Users, Trophy, Target, Search, Filter, 
  Plus, Star, Globe, MapPin, Calendar, TrendingUp, Award,
  Flame, Zap, Settings, UserPlus, Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import { useResponsive } from '../../hooks/useResponsive';

// Import clan components
import { ClanCard } from '../clans/ClanCard';
import { ClanCreation } from '../clans/ClanCreation';
import { ClanLeaderboard, ClanLeaderboardEntry, ClanLeaderboardStats } from '../clans/ClanLeaderboard';
import { ClanManagement, ClanMember, ClanJoinRequest, ClanSettings } from '../clans/ClanManagement';
import { ClanDetailPage } from '../clans/ClanDetailPage';
import { useClan, Clan } from '../providers/ClanProvider';

export function ClansPage() {
  const { clans, joinClan, leaveClan, getUserClan } = useClan();
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'public' | 'private' | 'invite-only'>('all');
  const [regionFilter, setRegionFilter] = useState('all');
  const [sortBy, setSortBy] = useState<'rank' | 'level' | 'members' | 'trophies'>('rank');
  const [selectedView, setSelectedView] = useState<'discover' | 'leaderboard' | 'manage'>('discover');
  const [selectedClan, setSelectedClan] = useState<Clan | null>(null);
  const { isMobile, isTablet, width } = useResponsive();

  // Mock user data
  const userBalance = 150000;
  const userLevel = 25;
  const userTrophies = 2450;
  const userClanId = 'my-clan-id';
  const userClanRank = 15;

  // Use clans from context (includes user-created clans)

  // Mock leaderboard data
  const mockLeaderboardClans: ClanLeaderboardEntry[] = clans.map((clan, index) => ({
    id: clan.id,
    name: clan.name,
    tag: clan.tag,
    logo: clan.logo,
    rank: clan.stats.rank,
    previousRank: clan.stats.rank + (Math.random() > 0.5 ? 1 : -1),
    level: clan.level,
    totalTrophies: clan.stats.totalTrophies,
    weeklyTrophies: Math.floor(clan.stats.totalTrophies * 0.1),
    members: clan.members,
    winRate: clan.stats.winRate,
    totalWins: clan.stats.wins,
    region: clan.region,
    xp: clan.xp,
    weeklyXp: clan.stats.weeklyXp,
    achievements: clan.achievements,
    isRising: Math.random() > 0.6,
    leader: clan.leader,
    activities: clan.activities
  }));

  const mockLeaderboardStats: ClanLeaderboardStats = {
    totalClans: 1250,
    activeClans: 890,
    totalMembers: 45000,
    averageLevel: 28,
    topRegions: [
      { name: 'ایران', count: 450, percentage: 36 },
      { name: 'آسیای میانه', count: 280, percentage: 22 },
      { name: 'خاورمیانه', count: 180, percentage: 14 },
      { name: 'اروپا', count: 150, percentage: 12 },
      { name: 'آسیا', count: 120, percentage: 10 }
    ],
    weeklyGrowth: 8.5
  };

  // Mock management data (if user is in a clan)
  const mockClanMembers: ClanMember[] = [
    {
      id: 'member-1',
      name: 'شیر_طلایی',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
      level: 67,
      role: 'leader',
      joinDate: '۱۴۰۱/۰۸/۱۵',
      lastActive: 'آنلاین',
      status: 'online',
      stats: {
        trophies: 3200,
        wins: 89,
        losses: 12,
        weeklyActivity: 45,
        donations: 120
      },
      permissions: ['all'],
      isOnline: true
    },
    {
      id: 'member-2',
      name: 'عقاب_سیاه',
      level: 54,
      role: 'officer',
      joinDate: '۱۴۰۱/۱۰/۰۳',
      lastActive: '2 ساعت پیش',
      status: 'away',
      stats: {
        trophies: 2850,
        wins: 76,
        losses: 18,
        weeklyActivity: 32,
        donations: 95
      },
      permissions: ['invite', 'kick'],
      isOnline: false
    },
    {
      id: 'member-3',
      name: 'محمد_پرو',
      level: 41,
      role: 'member',
      joinDate: '۱۴۰۲/۰۲/۲۰',
      lastActive: '1 روز پیش',
      status: 'offline',
      stats: {
        trophies: 2100,
        wins: 54,
        losses: 23,
        weeklyActivity: 18,
        donations: 67
      },
      permissions: [],
      isOnline: false
    }
  ];

  const mockJoinRequests: ClanJoinRequest[] = [
    {
      id: 'req-1',
      player: {
        name: 'نوبیا_گیمر',
        level: 28,
        trophies: 1850,
        winRate: 72
      },
      message: 'سلام! بازیکن فعال و متعهدی هستم و دوست دارم به کلن شما بپیوندم.',
      requestDate: '2 ساعت پیش',
      status: 'pending'
    },
    {
      id: 'req-2',
      player: {
        name: 'استریمر123',
        level: 35,
        trophies: 2200,
        winRate: 68
      },
      message: 'استریمر تویچم و می‌تونم کلن رو تبلیغ کنم. لطفا قبولم کنید.',
      requestDate: '5 ساعت پیش',
      status: 'pending'
    }
  ];

  const mockClanSettings: ClanSettings = {
    name: 'شیرهای طلایی',
    description: 'کلن دوستانه برای بازیکنان حرفه‌ای و نیمه‌حرفه‌ای',
    type: 'public',
    requirements: {
      minLevel: 15,
      minTrophies: 800
    },
    autoAccept: false,
    allowInvites: true,
    maxMembers: 40
  };

  const filteredClans = clans.filter(clan => {
    const matchesSearch = clan.name.includes(searchQuery) || clan.tag.includes(searchQuery);
    const matchesType = typeFilter === 'all' || clan.type === typeFilter;
    const matchesRegion = regionFilter === 'all' || clan.region === regionFilter;
    return matchesSearch && matchesType && matchesRegion;
  }).sort((a, b) => {
    // کلن‌های ایجاد شده توسط کاربر در اول
    if (a.createdByUser && !b.createdByUser) return -1;
    if (!a.createdByUser && b.createdByUser) return 1;
    
    // سپس مرتب‌سازی بر اساس انتخاب کاربر
    switch (sortBy) {
      case 'rank':
        return a.stats.rank - b.stats.rank;
      case 'level':
        return b.level - a.level;
      case 'members':
        return b.members.current - a.members.current;
      case 'trophies':
        return b.stats.totalTrophies - a.stats.totalTrophies;
      default:
        return a.stats.rank - b.stats.rank;
    }
  });

  const featuredClans = clans.filter(clan => clan.stats.rank <= 5);
  const recommendedClans = clans.filter(clan => !clan.isJoined && clan.requirements.minLevel! <= userLevel);
  const userCreatedClans = clans.filter(clan => clan.createdByUser);

  const handleJoinClan = (clanId: string) => {
    joinClan(clanId);
    toast.success('درخواست عضویت ارسال شد', {
      description: 'درخواست شما برای پیوستن به کلن ارسال شد.'
    });
  };

  const handleLeaveClan = (clanId: string) => {
    leaveClan(clanId);
    toast.success('از کلن خارج شدید', {
      description: 'شما با موفقیت از کلن خارج شدید.'
    });
  };

  const handleCreateClan = (data: any) => {
    console.log('Creating clan:', data);
  };

  const handleViewClanDetails = (clanId: string) => {
    const clan = clans.find(c => c.id === clanId);
    if (clan) {
      setSelectedClan(clan);
    }
  };

  const handleBackToList = () => {
    setSelectedClan(null);
  };

  const currentUserClan = getUserClan();

  // Show clan detail page if a clan is selected
  if (selectedClan) {
    return (
      <ClanDetailPage
        clan={selectedClan}
        onJoin={handleJoinClan}
        onLeave={handleLeaveClan}
        onBack={handleBackToList}
      />
    );
  }

  return (
    <div 
      className="min-h-screen bg-background"
      style={{ 
        paddingLeft: isMobile ? 'var(--spacing-sm)' : 'var(--spacing-lg)',
        paddingRight: isMobile ? 'var(--spacing-sm)' : 'var(--spacing-lg)',
        paddingTop: isMobile ? 'var(--spacing-md)' : 'var(--spacing-xl)',
        paddingBottom: isMobile ? 'var(--spacing-xl)' : 'var(--spacing-2xl)'
      }}
      dir="rtl"
    >
      <div 
        className="max-w-7xl mx-auto"
        style={{ 
          gap: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        {/* Responsive Header */}
        <div className={`flex ${isMobile ? 'flex-col gap-4' : 'flex-col lg:flex-row items-start lg:items-center justify-between gap-6'}`}>
          <div className={`flex-1 ${isMobile ? 'text-center' : 'text-right'}`}>
            <div className={`flex items-center ${isMobile ? 'justify-center' : ''} gap-3 mb-2`}>
              <div 
                className="bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30"
                style={{ 
                  padding: isMobile ? 'var(--spacing-sm)' : 'var(--spacing-md)',
                  borderRadius: isMobile ? 'var(--radius-md)' : 'var(--radius-lg)'
                }}
              >
                <Shield className={`${isMobile ? 'w-5 h-5' : 'w-6 h-6'} text-blue-400`} />
              </div>
              <div>
                <h1 
                  className="bg-gradient-to-l from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent"
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-1)',
                    fontWeight: 'var(--font-weight-semibold)',
                    lineHeight: 'var(--line-height-tight)'
                  }}
                >
                  کلن‌ها و تیم‌ها
                </h1>
                <div className="flex items-center gap-2 mt-1">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                  <p 
                    className="text-muted-foreground"
                    style={{ 
                      fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)'
                    }}
                  >
                    {isMobile 
                      ? `${mockLeaderboardStats.totalClans} کلن • ${Math.floor(mockLeaderboardStats.totalMembers/1000)}K عضو`
                      : `${mockLeaderboardStats.totalClans} کلن فعال • ${mockLeaderboardStats.totalMembers.toLocaleString()} عضو`
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* User Clan Info & Create Button */}
          <div className={`flex ${isMobile ? 'flex-col gap-3' : 'items-center gap-3'}`}>
            {currentUserClan && (
              <Card className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border-green-500/20">
                <CardContent style={{ padding: 'var(--spacing-md)' }}>
                  <div className={`flex items-center ${isMobile ? 'justify-between' : 'gap-3'}`}>
                    <div className="text-center">
                      <div 
                        className="text-green-400"
                        style={{ 
                          fontSize: isMobile ? 'var(--font-size-body-2)' : 'var(--font-size-body-1)',
                          fontWeight: 'var(--font-weight-semibold)'
                        }}
                      >
                        [{currentUserClan.tag}]
                      </div>
                      <div 
                        className="text-muted-foreground"
                        style={{ fontSize: 'var(--font-size-caption)' }}
                      >
                        کلن شما
                      </div>
                    </div>
                    <div className="text-center">
                      <div 
                        className="text-blue-400"
                        style={{ 
                          fontSize: isMobile ? 'var(--font-size-body-2)' : 'var(--font-size-body-1)',
                          fontWeight: 'var(--font-weight-semibold)'
                        }}
                      >
                        #{userClanRank}
                      </div>
                      <div 
                        className="text-muted-foreground"
                        style={{ fontSize: 'var(--font-size-caption)' }}
                      >
                        رنک
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            <div className={isMobile ? 'w-full' : ''}>
              <ClanCreation
                onCreateClan={handleCreateClan}
                userBalance={userBalance}
                userLevel={userLevel}
                userTrophies={userTrophies}
              />
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div 
          className={`grid ${isMobile ? 'grid-cols-2' : 'grid-cols-2 md:grid-cols-4'}`}
          style={{ gap: isMobile ? 'var(--spacing-sm)' : 'var(--spacing-lg)' }}
        >
          <Card className="text-center bg-gradient-to-br from-blue-500/5 to-blue-600/10 border-blue-500/20">
            <CardContent style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}>
              <div 
                className="text-blue-500"
                style={{ 
                  fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-1)',
                  fontWeight: 'var(--font-weight-semibold)',
                  lineHeight: 'var(--line-height-tight)'
                }}
              >
                {mockLeaderboardStats.activeClans}
              </div>
              <div 
                className="text-muted-foreground"
                style={{ fontSize: 'var(--font-size-caption)', marginTop: 'var(--spacing-xs)' }}
              >
                کلن فعال
              </div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-green-500/5 to-green-600/10 border-green-500/20">
            <CardContent style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}>
              <div 
                className="text-green-500"
                style={{ 
                  fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-1)',
                  fontWeight: 'var(--font-weight-semibold)',
                  lineHeight: 'var(--line-height-tight)'
                }}
              >
                {isMobile ? `${Math.floor(mockLeaderboardStats.totalMembers/1000)}K` : mockLeaderboardStats.totalMembers.toLocaleString()}
              </div>
              <div 
                className="text-muted-foreground"
                style={{ fontSize: 'var(--font-size-caption)', marginTop: 'var(--spacing-xs)' }}
              >
                عضو فعال
              </div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-yellow-500/5 to-yellow-600/10 border-yellow-500/20">
            <CardContent style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}>
              <div 
                className="text-yellow-500"
                style={{ 
                  fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-1)',
                  fontWeight: 'var(--font-weight-semibold)',
                  lineHeight: 'var(--line-height-tight)'
                }}
              >
                {mockLeaderboardStats.averageLevel}
              </div>
              <div 
                className="text-muted-foreground"
                style={{ fontSize: 'var(--font-size-caption)', marginTop: 'var(--spacing-xs)' }}
              >
                متوسط سطح
              </div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-purple-500/5 to-purple-600/10 border-purple-500/20">
            <CardContent style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}>
              <div 
                className="text-purple-500"
                style={{ 
                  fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-1)',
                  fontWeight: 'var(--font-weight-semibold)',
                  lineHeight: 'var(--line-height-tight)'
                }}
              >
                +{mockLeaderboardStats.weeklyGrowth}%
              </div>
              <div 
                className="text-muted-foreground"
                style={{ fontSize: 'var(--font-size-caption)', marginTop: 'var(--spacing-xs)' }}
              >
                رشد هفتگی
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Navigation */}
        <Tabs value={selectedView} onValueChange={(value: any) => setSelectedView(value)} className="w-full">
          <TabsList 
            className="grid w-full grid-cols-3"
            style={{ 
              height: isMobile ? '40px' : '48px',
              borderRadius: 'var(--radius-md)'
            }}
          >
            <TabsTrigger 
              value="discover" 
              className="flex items-center justify-center"
              style={{ 
                gap: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)',
                fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                padding: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)'
              }}
            >
              <Search className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'}`} />
              {isMobile ? 'کشف' : 'کشف کلن‌ها'}
            </TabsTrigger>
            <TabsTrigger 
              value="leaderboard" 
              className="flex items-center justify-center"
              style={{ 
                gap: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)',
                fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                padding: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)'
              }}
            >
              <Trophy className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'}`} />
              {isMobile ? 'رنکینگ' : 'رنکینگ'}
            </TabsTrigger>
            <TabsTrigger 
              value="manage" 
              className="flex items-center justify-center"
              style={{ 
                gap: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)',
                fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                padding: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)'
              }}
              disabled={!currentUserClan}
            >
              <Settings className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'}`} />
              {isMobile ? 'مدیریت' : 'مدیریت کلن'}
            </TabsTrigger>
          </TabsList>

          <TabsContent 
            value="discover" 
            style={{ 
              marginTop: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)',
              display: 'flex',
              flexDirection: 'column',
              gap: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)'
            }}
          >
          {/* User Created Clans */}
          {userCreatedClans.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 
                  className="flex items-center"
                  style={{ 
                    gap: 'var(--spacing-sm)',
                    fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                    fontWeight: 'var(--font-weight-semibold)'
                  }}
                >
                  <Crown className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} text-green-500`} />
                  کلن‌های ایجاد شده شما
                </h2>
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                  {userCreatedClans.length} کلن
                </Badge>
              </div>
              
              <div 
                className={`grid ${
                  isMobile 
                    ? 'grid-cols-1' 
                    : isTablet 
                      ? 'grid-cols-2' 
                      : 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3'
                }`}
                style={{ gap: isMobile ? 'var(--spacing-md)' : 'var(--spacing-xl)' }}
              >
                {userCreatedClans.map((clan) => (
                  <ClanCard
                    key={clan.id}
                    clan={clan}
                    variant="featured"
                    onJoin={handleJoinClan}
                    onLeave={handleLeaveClan}
                    onViewDetails={handleViewClanDetails}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Featured Clans */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 
                className="flex items-center"
                style={{ 
                  gap: 'var(--spacing-sm)',
                  fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                  fontWeight: 'var(--font-weight-semibold)'
                }}
              >
                <Star className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} text-yellow-500`} />
                کلن‌های ویژه
              </h2>
            </div>
            
            <div 
              className={`grid ${
                isMobile 
                  ? 'grid-cols-1' 
                  : isTablet 
                    ? 'grid-cols-2' 
                    : 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3'
              }`}
              style={{ gap: isMobile ? 'var(--spacing-md)' : 'var(--spacing-xl)' }}
            >
              {featuredClans.map((clan) => (
                <ClanCard
                  key={clan.id}
                  clan={clan}
                  variant="featured"
                  onJoin={handleJoinClan}
                  onLeave={handleLeaveClan}
                  onViewDetails={handleViewClanDetails}
                />
              ))}
            </div>
          </div>

            {/* Search and Filters */}
            <Card>
              <CardContent style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}>
                <div 
                  className={isMobile ? 'space-y-3' : 'flex gap-4'}
                  style={!isMobile ? { alignItems: 'center' } : {}}
                >
                  {/* Search Input */}
                  <div className="relative flex-1">
                    <Search 
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" 
                    />
                    <Input
                      placeholder="جستجوی کلن..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pr-10"
                      style={{ 
                        height: isMobile ? '36px' : '40px',
                        fontSize: 'var(--font-size-body-2)',
                        borderRadius: 'var(--radius-md)'
                      }}
                      dir="rtl"
                    />
                  </div>

                  {/* Filters */}
                  <div 
                    className={`flex ${isMobile ? 'flex-wrap' : ''}`}
                    style={{ gap: 'var(--spacing-sm)' }}
                  >
                    <Select value={typeFilter} onValueChange={(value: any) => setTypeFilter(value)}>
                      <SelectTrigger 
                        className={isMobile ? 'flex-1 min-w-0' : 'w-32'}
                        style={{ 
                          height: isMobile ? '36px' : '40px',
                          fontSize: 'var(--font-size-body-2)'
                        }}
                      >
                        <SelectValue placeholder="نوع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">همه</SelectItem>
                        <SelectItem value="public">عمومی</SelectItem>
                        <SelectItem value="private">خصوصی</SelectItem>
                        <SelectItem value="invite-only">فقط دعوت</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select value={regionFilter} onValueChange={setRegionFilter}>
                      <SelectTrigger 
                        className={isMobile ? 'flex-1 min-w-0' : 'w-32'}
                        style={{ 
                          height: isMobile ? '36px' : '40px',
                          fontSize: 'var(--font-size-body-2)'
                        }}
                      >
                        <SelectValue placeholder="استان" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">همه</SelectItem>
                        <SelectItem value="تهران">تهران</SelectItem>
                        <SelectItem value="اصفهان">اصفهان</SelectItem>
                        <SelectItem value="فارس">فارس</SelectItem>
                        <SelectItem value="خراسان رضوی">خراسان رضوی</SelectItem>
                        <SelectItem value="آذربایجان شرقی">آذربایجان شرقی</SelectItem>
                        <SelectItem value="مازندران">مازندران</SelectItem>
                        <SelectItem value="گیلان">گیلان</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                      <SelectTrigger 
                        className={isMobile ? 'flex-1 min-w-0' : 'w-32'}
                        style={{ 
                          height: isMobile ? '36px' : '40px',
                          fontSize: 'var(--font-size-body-2)'
                        }}
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rank">رنک</SelectItem>
                        <SelectItem value="level">سطح</SelectItem>
                        <SelectItem value="members">اعضا</SelectItem>
                        <SelectItem value="trophies">جام‌ها</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

          {/* Recommended Clans */}
          {recommendedClans.length > 0 && (
            <div className="space-y-4">
              <h2 
                className="flex items-center"
                style={{ 
                  gap: 'var(--spacing-sm)',
                  fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                  fontWeight: 'var(--font-weight-semibold)'
                }}
              >
                <Target className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} text-green-500`} />
                پیشنهاد شده برای شما
              </h2>
              
              <div 
                className={`grid ${
                  isMobile 
                    ? 'grid-cols-1' 
                    : isTablet 
                      ? 'grid-cols-2' 
                      : 'grid-cols-2 lg:grid-cols-3'
                }`}
                style={{ gap: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
              >
                {recommendedClans.slice(0, isMobile ? 4 : 6).map((clan) => (
                  <ClanCard
                    key={clan.id}
                    clan={clan}
                    variant="compact"
                    onJoin={handleJoinClan}
                    onLeave={handleLeaveClan}
                    onViewDetails={handleViewClanDetails}
                  />
                ))}
              </div>
            </div>
          )}

          {/* All Clans */}
          <div className="space-y-4">
            <h2 
              className="flex items-center"
              style={{ 
                gap: 'var(--spacing-sm)',
                fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                fontWeight: 'var(--font-weight-semibold)'
              }}
            >
              <Globe className={`${isMobile ? 'w-4 h-4' : 'w-5 h-5'} text-blue-500`} />
              همه کلن‌ها ({filteredClans.length})
            </h2>
            
            <div 
              className={`grid ${
                isMobile 
                  ? 'grid-cols-1' 
                  : isTablet 
                    ? 'grid-cols-2' 
                    : 'grid-cols-2 lg:grid-cols-3'
              }`}
              style={{ gap: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
            >
              <AnimatePresence>
                {filteredClans.map((clan) => (
                  <ClanCard
                    key={clan.id}
                    clan={clan}
                    onJoin={handleJoinClan}
                    onLeave={handleLeaveClan}
                    onViewDetails={handleViewClanDetails}
                  />
                ))}
              </AnimatePresence>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="leaderboard" className="space-y-4">
          <ClanLeaderboard
            clans={mockLeaderboardClans}
            stats={mockLeaderboardStats}
            userClanRank={userClanRank}
            isGlobal={true}
          />
        </TabsContent>

        <TabsContent value="manage" className="space-y-4">
          {currentUserClan ? (
            <ClanManagement
              members={mockClanMembers}
              joinRequests={mockJoinRequests}
              settings={mockClanSettings}
              userRole="officer" // or based on actual user role
              onUpdateMember={(id, updates) => console.log('Update member:', id, updates)}
              onRemoveMember={(id) => console.log('Remove member:', id)}
              onApproveRequest={(id) => console.log('Approve request:', id)}
              onRejectRequest={(id) => console.log('Reject request:', id)}
              onUpdateSettings={(settings) => console.log('Update settings:', settings)}
              onInvitePlayer={(name) => console.log('Invite player:', name)}
            />
          ) : (
            <Card>
              <CardContent 
                className="text-center"
                style={{ 
                  padding: isMobile ? 'var(--spacing-2xl) var(--spacing-lg)' : 'var(--spacing-3xl) var(--spacing-xl)'
                }}
              >
                <Shield 
                  className={`${isMobile ? 'w-12 h-12' : 'w-16 h-16'} mx-auto text-muted-foreground`}
                  style={{ marginBottom: 'var(--spacing-lg)' }}
                />
                <h3 
                  className="text-center"
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                    fontWeight: 'var(--font-weight-medium)',
                    marginBottom: 'var(--spacing-sm)'
                  }}
                >
                  هنوز عضو کلنی نیستید
                </h3>
                <p 
                  className="text-muted-foreground text-center"
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                    marginBottom: 'var(--spacing-xl)',
                    maxWidth: isMobile ? '280px' : '400px',
                    margin: '0 auto',
                    marginBottom: 'var(--spacing-xl)'
                  }}
                >
                  برای دسترسی به بخش مدیریت، ابتدا باید به کلنی بپیوندید یا کلن جدید ایجاد کنید.
                </p>
                <div 
                  className={`flex justify-center ${isMobile ? 'flex-col items-center' : ''}`}
                  style={{ gap: 'var(--spacing-md)' }}
                >
                  <Button 
                    onClick={() => setSelectedView('discover')}
                    className={isMobile ? 'w-full max-w-xs' : ''}
                    style={{ 
                      height: isMobile ? '36px' : '40px',
                      fontSize: 'var(--font-size-body-2)'
                    }}
                  >
                    <Search className="w-4 h-4 ml-2" />
                    جستجوی کلن
                  </Button>
                  <div className={isMobile ? 'w-full max-w-xs' : ''}>
                    <ClanCreation
                      onCreateClan={handleCreateClan}
                      userBalance={userBalance}
                      userLevel={userLevel}
                      userTrophies={userTrophies}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

          <TabsContent value="leaderboard" style={{ marginTop: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)' }}>
            <ClanLeaderboard
              clans={mockLeaderboardClans}
              stats={mockLeaderboardStats}
              userClanRank={userClanRank}
              isGlobal={true}
            />
          </TabsContent>

          <TabsContent value="manage" style={{ marginTop: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)' }}>
            {currentUserClan ? (
              <ClanManagement
                members={mockClanMembers}
                joinRequests={mockJoinRequests}
                settings={mockClanSettings}
                userRole="officer"
                onUpdateMember={(id, updates) => console.log('Update member:', id, updates)}
                onRemoveMember={(id) => console.log('Remove member:', id)}
                onApproveRequest={(id) => console.log('Approve request:', id)}
                onRejectRequest={(id) => console.log('Reject request:', id)}
                onUpdateSettings={(settings) => console.log('Update settings:', settings)}
                onInvitePlayer={(name) => console.log('Invite player:', name)}
              />
            ) : (
              <Card>
                <CardContent 
                  className="text-center"
                  style={{ 
                    padding: isMobile ? 'var(--spacing-2xl) var(--spacing-lg)' : 'var(--spacing-3xl) var(--spacing-xl)'
                  }}
                >
                  <Shield 
                    className={`${isMobile ? 'w-12 h-12' : 'w-16 h-16'} mx-auto text-muted-foreground`}
                    style={{ marginBottom: 'var(--spacing-lg)' }}
                  />
                  <h3 
                    className="text-center"
                    style={{ 
                      fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                      fontWeight: 'var(--font-weight-medium)',
                      marginBottom: 'var(--spacing-sm)'
                    }}
                  >
                    هنوز عضو کلنی نیستید
                  </h3>
                  <p 
                    className="text-muted-foreground text-center"
                    style={{ 
                      fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                      marginBottom: 'var(--spacing-xl)',
                      maxWidth: isMobile ? '280px' : '400px',
                      margin: '0 auto',
                      marginBottom: 'var(--spacing-xl)'
                    }}
                  >
                    برای دسترسی به بخش مدیریت، ابتدا باید به کلنی بپیوندید یا کلن جدید ایجاد کنید.
                  </p>
                  <div 
                    className={`flex justify-center ${isMobile ? 'flex-col items-center' : ''}`}
                    style={{ gap: 'var(--spacing-md)' }}
                  >
                    <Button 
                      onClick={() => setSelectedView('discover')}
                      className={isMobile ? 'w-full max-w-xs' : ''}
                      style={{ 
                        height: isMobile ? '36px' : '40px',
                        fontSize: 'var(--font-size-body-2)'
                      }}
                    >
                      <Search className="w-4 h-4 ml-2" />
                      جستجوی کلن
                    </Button>
                    <div className={isMobile ? 'w-full max-w-xs' : ''}>
                      <ClanCreation
                        onCreateClan={handleCreateClan}
                        userBalance={userBalance}
                        userLevel={userLevel}
                        userTrophies={userTrophies}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}