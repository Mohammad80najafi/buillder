/**
 * Chat Test Page - برای تست صفحه چت ریسپانسیو
 */

import React from 'react';
import { UltraMobileChatPage } from './UltraMobileChatPage';
import { useMobile } from '../ui/use-mobile';

export function ChatTestPage() {
  const isMobile = useMobile();
  
  return (
    <div className="min-h-screen bg-background dark">
      {isMobile ? (
        <UltraMobileChatPage />
      ) : (
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-muted-foreground">
            <h2>صفحه چت</h2>
            <p className="mt-2">برای تجربه بهتر، از نمای موبایل استفاده کنید</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default ChatTestPage;