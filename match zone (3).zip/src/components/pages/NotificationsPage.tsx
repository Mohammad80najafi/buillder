/**
 * Notifications Page
 * Comprehensive notification management for Matchzone
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  Users, 
  Trophy, 
  MessageCircle, 
  Shield, 
  Settings, 
  Check,
  X,
  Filter,
  Archive,
  Star,
  Clock,
  ChevronRight
} from 'lucide-react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';

interface Notification {
  id: string;
  type: 'lobby' | 'clan' | 'tournament' | 'social' | 'system';
  title: string;
  message: string;
  time: string;
  isRead: boolean;
  isImportant: boolean;
  actionRequired?: boolean;
  data?: any;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'lobby',
    title: 'دعوت به لابی جدید',
    message: 'علی تورو به لابی "مسابقه شب" دعوت کرده',
    time: '2 دقیقه پیش',
    isRead: false,
    isImportant: true,
    actionRequired: true,
    data: { lobbyId: 'lobby_123', inviterName: 'علی' }
  },
  {
    id: '2',
    type: 'tournament',
    title: 'شروع تورنومنت',
    message: 'تورنومنت "جام طلایی" 10 دقیقه دیگه شروع میشه',
    time: '5 دقیقه پیش',
    isRead: false,
    isImportant: true,
    actionRequired: true,
    data: { tournamentId: 'tour_456' }
  },
  {
    id: '3',
    type: 'clan',
    title: 'پیام جدید در کلن',
    message: 'محمد در گروه کلن پیام جدیدی فرستاده',
    time: '15 دقیقه پیش',
    isRead: false,
    isImportant: false,
    data: { clanId: 'clan_789', senderName: 'محمد' }
  },
  {
    id: '4',
    type: 'social',
    title: 'درخواست دوستی',
    message: 'سارا درخواست دوستی براتون فرستاده',
    time: '1 ساعت پیش',
    isRead: true,
    isImportant: false,
    actionRequired: true,
    data: { userId: 'user_321', userName: 'سارا' }
  },
  {
    id: '5',
    type: 'system',
    title: 'به‌روزرسانی سیستم',
    message: 'ویژگی‌های جدید به پلتفرم اضافه شده',
    time: '3 ساعت پیش',
    isRead: true,
    isImportant: false,
    data: { version: '2.1.0' }
  }
];

export function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [activeTab, setActiveTab] = useState('all');
  const [filter, setFilter] = useState<'all' | 'unread' | 'important'>('all');

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'lobby': return Users;
      case 'tournament': return Trophy;
      case 'clan': return Shield;
      case 'social': return MessageCircle;
      case 'system': return Settings;
      default: return Bell;
    }
  };

  const getNotificationColor = (type: Notification['type']) => {
    switch (type) {
      case 'lobby': return 'text-blue-500';
      case 'tournament': return 'text-yellow-500';
      case 'clan': return 'text-purple-500';
      case 'social': return 'text-green-500';
      case 'system': return 'text-gray-500';
      default: return 'text-blue-500';
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, isRead: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, isRead: true }))
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id));
  };

  const filteredNotifications = notifications.filter(notif => {
    if (filter === 'unread') return !notif.isRead;
    if (filter === 'important') return notif.isImportant;
    return true;
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;
  const importantCount = notifications.filter(n => n.isImportant).length;

  return (
    <div className="min-h-screen bg-background p-4">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Bell className="w-6 h-6 text-primary" />
            <h1 className="text-2xl font-bold">اعلان‌ها</h1>
            {unreadCount > 0 && (
              <Badge variant="destructive" className="rounded-full">
                {unreadCount}
              </Badge>
            )}
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={markAllAsRead}
              disabled={unreadCount === 0}
            >
              <Check className="w-4 h-4 ml-2" />
              همه رو خونده علامت بزن
            </Button>
          </div>
        </div>

        {/* Filter Tabs */}
        <Tabs value={filter} onValueChange={(value) => setFilter(value as any)} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all" className="flex items-center gap-2">
              <Bell className="w-4 h-4" />
              همه ({notifications.length})
            </TabsTrigger>
            <TabsTrigger value="unread" className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              خوانده نشده ({unreadCount})
            </TabsTrigger>
            <TabsTrigger value="important" className="flex items-center gap-2">
              <Star className="w-4 h-4" />
              مهم ({importantCount})
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        <AnimatePresence>
          {filteredNotifications.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-12"
            >
              <Bell className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">
                اعلانی وجود ندارد
              </h3>
              <p className="text-sm text-muted-foreground">
                هنوز هیچ اعلانی دریافت نکرده‌اید
              </p>
            </motion.div>
          ) : (
            filteredNotifications.map((notification, index) => {
              const Icon = getNotificationIcon(notification.type);
              const colorClass = getNotificationColor(notification.type);

              return (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -300 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Card 
                    className={`p-4 cursor-pointer transition-all duration-200 ${
                      !notification.isRead 
                        ? 'bg-primary/5 border-primary/20' 
                        : 'hover:bg-muted/50'
                    }`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex items-start gap-3">
                      {/* Icon */}
                      <div className={`p-2 rounded-full bg-surface-secondary ${
                        notification.isImportant ? 'ring-2 ring-primary' : ''
                      }`}>
                        <Icon className={`w-5 h-5 ${colorClass}`} />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-1">
                          <h3 className={`font-medium ${
                            !notification.isRead ? 'text-foreground' : 'text-muted-foreground'
                          }`}>
                            {notification.title}
                            {notification.isImportant && (
                              <Star className="w-4 h-4 text-yellow-500 inline mr-2" />
                            )}
                          </h3>
                          
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground whitespace-nowrap">
                              {notification.time}
                            </span>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-6 h-6 p-0 opacity-0 group-hover:opacity-100"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteNotification(notification.id);
                              }}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>

                        <p className="text-sm text-muted-foreground mb-2">
                          {notification.message}
                        </p>

                        {/* Action Buttons */}
                        {notification.actionRequired && (
                          <div className="flex gap-2">
                            {notification.type === 'lobby' && (
                              <>
                                <Button size="sm" variant="default">
                                  ملحق شدن
                                </Button>
                                <Button size="sm" variant="outline">
                                  رد کردن
                                </Button>
                              </>
                            )}
                            {notification.type === 'social' && (
                              <>
                                <Button size="sm" variant="default">
                                  قبول
                                </Button>
                                <Button size="sm" variant="outline">
                                  رد
                                </Button>
                              </>
                            )}
                            {notification.type === 'tournament' && (
                              <Button size="sm" variant="default">
                                مشاهده تورنومنت
                              </Button>
                            )}
                          </div>
                        )}

                        {/* Read indicator */}
                        {!notification.isRead && (
                          <div className="absolute top-4 left-4 w-2 h-2 bg-primary rounded-full" />
                        )}
                      </div>

                      <ChevronRight className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </Card>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>

      {/* Quick Actions */}
      <div className="fixed bottom-20 left-4 right-4">
        <Card className="p-4 bg-surface-primary/95 backdrop-blur-sm">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">
              {unreadCount} اعلان خوانده نشده
            </span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline">
                <Archive className="w-4 h-4 ml-2" />
                آرشیو
              </Button>
              <Button size="sm" variant="outline">
                <Filter className="w-4 h-4 ml-2" />
                فیلتر
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}