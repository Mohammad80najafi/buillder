/**
 * Modern Chat Detail Page - MatchZone Gaming Platform
 * کاملاً responsive با طراحی مدرن gaming
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Smile, 
  Plus, 
  Mic, 
  MicOff, 
  ArrowLeft,
  MoreVertical,
  Volume2,
  VolumeX,
  Crown,
  Shield,
  Star,
  Zap,
  Info,
  Users,
  Search,
  Hash,
  Lock,
  Globe,
  Trophy,
  Settings,
  X
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  isOwn: boolean;
  type: 'text' | 'gift' | 'system' | 'join' | 'leave';
  role: 'player' | 'admin' | 'vip' | 'moderator';
  avatar?: string;
  reactions?: { emoji: string; count: number; users: string[] }[];
  giftsData?: {
    type: string;
    value: number;
    from: string;
    icon: string;
  };
}

interface ChatRoom {
  id: string;
  name: string;
  description?: string;
  memberCount: number;
  onlineCount: number;
  avatar?: string;
  status: 'online' | 'away' | 'busy' | 'offline';
  type: 'public' | 'private' | 'lobby' | 'tournament';
  game?: string;
  isLive?: boolean;
}

export function ModernChatDetailPage() {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showInfo, setShowInfo] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickReactions = ['❤️', '👍', '😂', '🔥', '⚡', '💎', '🎯', '👏'];
  const quickEmojis = ['😀', '😍', '🤔', '😮', '😢', '😡', '🎮', '🏆', '💪', '🔥', '⚡', '💎'];

  // Mock data
  const currentRoom: ChatRoom = {
    id: 'valorant-pro',
    name: 'لابی Valorant حرفه‌ای',
    description: 'لابی اختصاصی بازیکنان حرفه‌ای Valorant - فقط رنک‌های Immortal+',
    memberCount: 42,
    onlineCount: 28,
    status: 'online',
    type: 'lobby',
    game: 'Valorant',
    isLive: true
  };

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      username: 'Captain Phoenix',
      message: 'سلام تیم! آماده برای مچ امشب؟',
      timestamp: new Date(Date.now() - 600000),
      isOwn: false,
      type: 'text',
      role: 'admin',
      avatar: '🔥',
      reactions: [
        { emoji: '🔥', count: 8, users: ['user1', 'user2'] },
        { emoji: '👍', count: 12, users: ['user3'] }
      ]
    },
    {
      id: '2',
      username: 'Sarah Duelist',
      message: 'حتماً! من Jett main هستم، کسی Sage می‌زنه؟',
      timestamp: new Date(Date.now() - 540000),
      isOwn: false,
      type: 'text',
      role: 'vip',
      avatar: '💫'
    },
    {
      id: '3',
      username: 'شما',
      message: 'من Sage main هستم، بزن بریم 💪',
      timestamp: new Date(Date.now() - 480000),
      isOwn: true,
      type: 'text',
      role: 'player',
      avatar: '🎯'
    },
    {
      id: '4',
      username: 'Pro Player Ali',
      message: '',
      timestamp: new Date(Date.now() - 420000),
      isOwn: false,
      type: 'gift',
      role: 'player',
      avatar: '👑',
      giftsData: {
        type: 'سکه طلایی',
        value: 500,
        from: 'Pro Player Ali',
        icon: '🏆'
      }
    },
    {
      id: '5',
      username: 'سیستم',
      message: 'Team Leader به چت پیوست',
      timestamp: new Date(Date.now() - 360000),
      isOwn: false,
      type: 'join',
      role: 'moderator',
      avatar: '🤖'
    },
    {
      id: '6',
      username: 'Team Leader',
      message: 'بچه‌ها بیاین VC، استراتژی رو توضیح بدم 🎧',
      timestamp: new Date(Date.now() - 300000),
      isOwn: false,
      type: 'text',
      role: 'moderator',
      avatar: '🎯',
      reactions: [
        { emoji: '👍', count: 15, users: ['user1', 'user2'] }
      ]
    },
    {
      id: '7',
      username: 'Valorant Expert',
      message: 'نقشه Haven رو خوب بلدم، split A یا B؟',
      timestamp: new Date(Date.now() - 240000),
      isOwn: false,
      type: 'text',
      role: 'player',
      avatar: '⚡'
    },
    {
      id: '8',
      username: 'شما',
      message: 'B site بهتره، من smoke A رو می‌دم تا شما rush کنین',
      timestamp: new Date(Date.now() - 180000),
      isOwn: true,
      type: 'text',
      role: 'player',
      avatar: '🎯'
    }
  ]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Simulate typing indicator
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsTyping(Math.random() > 0.7);
    }, 3000 + Math.random() * 5000);

    return () => clearTimeout(timer);
  }, [isTyping]);

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      username: 'شما',
      message: message.trim(),
      timestamp: new Date(),
      isOwn: true,
      type: 'text',
      role: 'player',
      avatar: '🎯'
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const existingReaction = msg.reactions?.find(r => r.emoji === emoji);
        if (existingReaction) {
          return {
            ...msg,
            reactions: msg.reactions?.map(r => 
              r.emoji === emoji 
                ? { ...r, count: r.count + 1 }
                : r
            )
          };
        } else {
          return {
            ...msg,
            reactions: [
              ...(msg.reactions || []),
              { emoji, count: 1, users: ['current-user'] }
            ]
          };
        }
      }
      return msg;
    }));
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="w-3 h-3 text-yellow-400" />;
      case 'moderator': return <Shield className="w-3 h-3 text-blue-400" />;
      case 'vip': return <Star className="w-3 h-3 text-purple-400" />;
      default: return null;
    }
  };

  const getRoomTypeIcon = (type: string) => {
    switch (type) {
      case 'public': return <Globe className="w-4 h-4" />;
      case 'private': return <Lock className="w-4 h-4" />;
      case 'lobby': return <Hash className="w-4 h-4" />;
      case 'tournament': return <Trophy className="w-4 h-4" />;
      default: return <Hash className="w-4 h-4" />;
    }
  };

  const MessageComponent = ({ message: msg }: { message: ChatMessage }) => (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`group mb-4 ${msg.isOwn ? 'text-left' : 'text-right'}`} 
      dir={msg.isOwn ? 'ltr' : 'rtl'}
    >
      <div className={`flex items-start gap-3 ${msg.isOwn ? 'flex-row' : 'flex-row-reverse'}`}>
        {!msg.isOwn && (
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="flex-shrink-0"
          >
            <Avatar className="w-8 h-8 md:w-10 md:h-10 ring-2 ring-border">
              <AvatarFallback className="text-sm bg-gradient-to-br from-primary/20 to-accent/20">
                {msg.avatar || msg.username[0]}
              </AvatarFallback>
            </Avatar>
          </motion.div>
        )}
        
        <div className={`flex-1 min-w-0 space-y-1 ${msg.isOwn ? 'text-left' : 'text-right'}`}>
          {!msg.isOwn && (
            <div className="flex items-center gap-2 px-1">
              {getRoleIcon(msg.role)}
              <span className="text-sm font-medium text-foreground/90">{msg.username}</span>
              <span className="text-xs text-muted-foreground">
                {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          )}
          
          <div className={`max-w-[85%] md:max-w-[70%] ${msg.isOwn ? 'ml-auto' : 'mr-auto'}`}>
            {msg.type === 'system' || msg.type === 'join' || msg.type === 'leave' ? (
              <div className="bg-muted/30 text-center py-2 px-4 rounded-full text-xs text-muted-foreground border border-border/50">
                {msg.message}
              </div>
            ) : msg.type === 'gift' ? (
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="bg-gradient-to-r from-yellow-500/10 via-orange-500/10 to-red-500/10 p-4 rounded-2xl border border-yellow-500/20 backdrop-blur-sm"
              >
                <div className="flex items-center gap-3">
                  <div className="text-2xl">{msg.giftsData?.icon}</div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-yellow-400">هدیه ارسال شد!</div>
                    <div className="text-xs text-muted-foreground">
                      {msg.giftsData?.from} یک {msg.giftsData?.type} به ارزش {msg.giftsData?.value} سکه فرستاد
                    </div>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                whileHover={{ scale: 1.01 }}
                className={`py-3 px-4 rounded-2xl relative ${
                  msg.isOwn 
                    ? 'bg-gradient-to-r from-primary to-blue-600 text-primary-foreground shadow-lg shadow-primary/20' 
                    : 'bg-card/80 backdrop-blur-sm border border-border/50 hover:bg-card/90 transition-colors'
                }`}
              >
                <div className="text-sm leading-relaxed">{msg.message}</div>
                {msg.isOwn && (
                  <div className="text-xs opacity-70 mt-2 text-right">
                    {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                )}
              </motion.div>
            )}
            
            {/* Message Reactions */}
            {msg.reactions && msg.reactions.length > 0 && (
              <div className="flex gap-1 mt-2 flex-wrap">
                {msg.reactions.map((reaction, idx) => (
                  <motion.button
                    key={idx}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleReaction(msg.id, reaction.emoji)}
                    className="flex items-center gap-1 bg-muted/50 hover:bg-muted/80 px-2 py-1 rounded-full text-xs border border-border/30 transition-all"
                  >
                    <span className="text-sm">{reaction.emoji}</span>
                    <span className="text-xs font-medium">{reaction.count}</span>
                  </motion.button>
                ))}
              </div>
            )}
            
            {/* Quick Reactions - Show on Hover */}
            <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 mt-2">
              <div className="flex gap-1">
                {quickReactions.slice(0, 4).map((emoji) => (
                  <motion.button
                    key={emoji}
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleReaction(msg.id, emoji)}
                    className="w-6 h-6 flex items-center justify-center bg-muted/30 hover:bg-muted/60 rounded-full text-xs border border-border/20 transition-all"
                  >
                    {emoji}
                  </motion.button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="h-screen flex flex-col bg-gradient-to-b from-background via-background/95 to-background overflow-hidden">
      {/* Header - Ultra Modern & Responsive */}
      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex-shrink-0 bg-card/90 backdrop-blur-xl border-b border-border/50 shadow-lg"
      >
        <div className="px-4 md:px-6 py-3 md:py-4">
          <div className="flex items-center justify-between">
            {/* Left Side */}
            <div className="flex items-center gap-3 md:gap-4 flex-1 min-w-0">
              <Button 
                variant="ghost" 
                size="sm" 
                className="p-2 hover:bg-muted/50 rounded-xl transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              
              <div className="flex items-center gap-3 md:gap-4 flex-1 min-w-0">
                <div className="relative">
                  <Avatar className="w-10 h-10 md:w-12 md:h-12 ring-2 ring-primary/20">
                    <AvatarFallback className="bg-gradient-to-br from-primary/30 to-accent/30 text-lg">
                      {getRoomTypeIcon(currentRoom.type)}
                    </AvatarFallback>
                  </Avatar>
                  {currentRoom.isLive && (
                    <motion.div 
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ repeat: Infinity, duration: 2 }}
                      className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-background flex items-center justify-center"
                    >
                      <div className="w-1.5 h-1.5 bg-white rounded-full" />
                    </motion.div>
                  )}
                </div>
                
                <div className="flex-1 min-w-0 text-right" dir="rtl">
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="font-semibold text-sm md:text-base truncate flex-1">
                      {currentRoom.name}
                    </h2>
                    <Badge 
                      variant="secondary" 
                      className="text-xs px-2 py-0.5 bg-primary/10 text-primary border-primary/20"
                    >
                      {currentRoom.type === 'public' ? 'عمومی' : 
                       currentRoom.type === 'private' ? 'خصوصی' : 
                       currentRoom.type === 'lobby' ? 'لابی' : 'تورنومنت'}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                      {currentRoom.onlineCount} آنلاین
                    </span>
                    <span className="hidden sm:flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {currentRoom.memberCount} عضو
                    </span>
                    {currentRoom.game && (
                      <span className="hidden md:inline text-primary font-medium">
                        {currentRoom.game}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Right Side */}
            <div className="flex items-center gap-1 md:gap-2">
              <Button 
                variant="ghost" 
                size="sm"
                className="p-2 hover:bg-muted/50 rounded-xl transition-colors hidden md:flex"
              >
                <Search className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className={`p-2 hover:bg-muted/50 rounded-xl transition-colors ${isMuted ? 'text-red-500' : ''}`}
                onClick={() => setIsMuted(!isMuted)}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="p-2 hover:bg-muted/50 rounded-xl transition-colors"
                onClick={() => setShowInfo(!showInfo)}
              >
                <Info className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="p-2 hover:bg-muted/50 rounded-xl transition-colors"
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Info Panel */}
        <AnimatePresence>
          {showInfo && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-t border-border/30"
            >
              <div className="px-4 md:px-6 py-3 bg-muted/20">
                <div className="text-sm text-muted-foreground text-center" dir="rtl">
                  {currentRoom.description}
                </div>
                <div className="flex items-center justify-center gap-6 mt-2 text-xs">
                  <span className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    {currentRoom.memberCount} عضو
                  </span>
                  <span className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    {currentRoom.onlineCount} آنلاین
                  </span>
                  {currentRoom.game && (
                    <span className="flex items-center gap-1 text-primary">
                      <Trophy className="w-3 h-3" />
                      {currentRoom.game}
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Messages Area - Smooth Scrolling */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto px-4 md:px-6 py-4 space-y-2">
          <AnimatePresence mode="popLayout">
            {messages.map((msg) => (
              <MessageComponent key={msg.id} message={msg} />
            ))}
          </AnimatePresence>
          
          {/* Typing Indicator */}
          <AnimatePresence>
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center justify-end gap-2 px-4 py-2"
                dir="rtl"
              >
                <span className="text-sm text-muted-foreground">کاربری در حال تایپ</span>
                <div className="flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      animate={{ scale: [1, 1.5, 1] }}
                      transition={{ 
                        repeat: Infinity, 
                        duration: 1.5, 
                        delay: i * 0.2 
                      }}
                      className="w-1.5 h-1.5 bg-primary rounded-full"
                    />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area - Modern & Floating */}
      <motion.div 
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex-shrink-0 p-4 md:p-6 bg-card/90 backdrop-blur-xl border-t border-border/50"
      >
        {/* Emoji Picker */}
        <AnimatePresence>
          {showEmojiPicker && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.9 }}
              className="mb-4 p-4 bg-card/95 backdrop-blur-sm rounded-2xl border border-border/50 shadow-xl"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium">انتخاب emoji</span>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="p-1"
                  onClick={() => setShowEmojiPicker(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <div className="grid grid-cols-6 md:grid-cols-8 gap-2">
                {quickEmojis.map((emoji) => (
                  <motion.button
                    key={emoji}
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => {
                      setMessage(prev => prev + emoji);
                      setShowEmojiPicker(false);
                    }}
                    className="w-8 h-8 flex items-center justify-center hover:bg-muted/50 rounded-lg transition-colors"
                  >
                    {emoji}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex items-center gap-2 md:gap-3">
          <div className="flex-1 relative">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
              placeholder="پیام خود را بنویسید..."
              className="h-12 md:h-14 pr-4 pl-12 bg-muted/30 border-border/50 rounded-2xl text-sm md:text-base focus:bg-muted/50 transition-colors"
              dir="rtl"
            />
            <Button
              variant="ghost"
              size="sm"
              className="absolute left-2 top-1/2 -translate-y-1/2 p-2 hover:bg-muted/50 rounded-xl"
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            >
              <Smile className="w-4 h-4" />
            </Button>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm"
            className="p-3 hover:bg-muted/50 rounded-xl"
          >
            <Plus className="w-5 h-5" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm"
            className={`p-3 hover:bg-muted/50 rounded-xl transition-colors ${isRecording ? 'text-red-500 bg-red-500/10' : ''}`}
            onClick={() => setIsRecording(!isRecording)}
          >
            {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </Button>
          
          <motion.div whileTap={{ scale: 0.95 }}>
            <Button 
              onClick={handleSendMessage}
              disabled={!message.trim()}
              className="p-3 h-12 md:h-14 bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90 rounded-2xl shadow-lg shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </Button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}