/**
 * Matchzone Advanced Lobbies Page
 * Creative lobbies management with game-specific launch mechanisms
 */

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/mz-button';
import { Input } from '../ui/mz-input';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '../ui/sheet';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { Switch } from '../ui/switch';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, Filter, Plus, Users, Clock, MapPin, Gamepad2, Monitor, 
  Smartphone, Globe, Lock, Crown, Shield, Zap, Star, Play, 
  Copy, ExternalLink, Wifi, Signal, Trophy, Target, Flame,
  Steam, Download, Smartphone as Mobile, Settings, RefreshCw,
  CheckCircle, AlertCircle, XCircle, Info
} from 'lucide-react';
import { useMobile } from '../ui/use-mobile';
import { EnhancedLobbyCard } from '../gaming/EnhancedLobbyCard';
import { useGames } from '../providers/GameProvider';
import { useUser } from '../providers/UserProvider';
import { useNavigation } from '../navigation/NavigationProvider';
import { useLobby } from '../gaming/LobbyContext';

// Game definitions with launch mechanisms
interface GameConfig {
  id: string;
  name: string;
  displayName: string;
  icon: string;
  platforms: ('pc' | 'android' | 'ios')[];
  launchMethods: {
    pc?: {
      steam?: string;
      battlenet?: string;
      epic?: string;
      direct?: string;
    };
    android?: {
      intent: string;
      packageName: string;
    };
    ios?: {
      scheme?: string;
      fallback: 'copy' | 'manual';
    };
  };
  serverType: 'dedicated' | 'official' | 'custom';
  joinMethod: 'direct' | 'room_code' | 'invite' | 'lobby_browser';
  popularity: number;
  difficulty: 'easy' | 'medium' | 'hard';
  features: string[];
}

const gameConfigs: GameConfig[] = [
  {
    id: 'cs2',
    name: 'cs2',
    displayName: 'Counter-Strike 2',
    icon: '🔫',
    platforms: ['pc'],
    launchMethods: {
      pc: {
        steam: 'steam://run/730'
      }
    },
    serverType: 'dedicated',
    joinMethod: 'direct',
    popularity: 95,
    difficulty: 'easy',
    features: ['یک‌کلیک واقعی', 'سرور اختصاصی', 'مدیریت کامل', 'پینگ عالی']
  },
  {
    id: 'dota2',
    name: 'dota2',
    displayName: 'Dota 2',
    icon: '⚔️',
    platforms: ['pc'],
    launchMethods: {
      pc: {
        steam: 'steam://run/570'
      }
    },
    serverType: 'official',
    joinMethod: 'lobby_browser',
    popularity: 85,
    difficulty: 'medium',
    features: ['سرور رسمی', 'امنیت بالا', 'لابی خصوصی']
  },
  {
    id: 'warzone',
    name: 'warzone',
    displayName: 'Call of Duty: Warzone',
    icon: '🚁',
    platforms: ['pc'],
    launchMethods: {
      pc: {
        steam: 'steam://run/1962663',
        battlenet: 'battlenet://CODMW'
      }
    },
    serverType: 'official',
    joinMethod: 'invite',
    popularity: 80,
    difficulty: 'medium',
    features: ['چند پلتفرم', 'کراس‌پلی', 'لابی سفارشی']
  },
  {
    id: 'mlbb',
    name: 'mlbb',
    displayName: 'Mobile Legends',
    icon: '🏰',
    platforms: ['android', 'ios'],
    launchMethods: {
      android: {
        intent: 'intent://launch/#Intent;package=com.mobile.legends;end',
        packageName: 'com.mobile.legends'
      },
      ios: {
        fallback: 'copy'
      }
    },
    serverType: 'official',
    joinMethod: 'room_code',
    popularity: 90,
    difficulty: 'medium',
    features: ['محبوب ایران', 'تورنمنت رسمی', 'تیم ۵ نفره']
  },
  {
    id: 'pubgm',
    name: 'pubgm',
    displayName: 'PUBG Mobile',
    icon: '🎯',
    platforms: ['android', 'ios'],
    launchMethods: {
      android: {
        intent: 'intent://launch/#Intent;package=com.tencent.ig;end',
        packageName: 'com.tencent.ig'
      },
      ios: {
        fallback: 'copy'
      }
    },
    serverType: 'official',
    joinMethod: 'room_code',
    popularity: 95,
    difficulty: 'hard',
    features: ['محبوبیت بالا', 'بتل رویال', '۱۰۰ نفره']
  },
  {
    id: 'codm',
    name: 'codm',
    displayName: 'Call of Duty: Mobile',
    icon: '🔥',
    platforms: ['android', 'ios'],
    launchMethods: {
      android: {
        intent: 'intent://launch/#Intent;package=com.activision.callofduty.shooter;end',
        packageName: 'com.activision.callofduty.shooter'
      },
      ios: {
        fallback: 'copy'
      }
    },
    serverType: 'official',
    joinMethod: 'room_code',
    popularity: 88,
    difficulty: 'medium',
    features: ['پرطرفدار', 'چندین حالت', 'شوتر موبایل']
  },
  {
    id: 'amongus',
    name: 'amongus',
    displayName: 'Among Us',
    icon: '🚀',
    platforms: ['pc', 'android', 'ios'],
    launchMethods: {
      pc: {
        steam: 'steam://run/945360'
      },
      android: {
        intent: 'intent://launch/#Intent;package=com.innersloth.spacemafia;end',
        packageName: 'com.innersloth.spacemafia'
      },
      ios: {
        fallback: 'copy'
      }
    },
    serverType: 'official',
    joinMethod: 'room_code',
    popularity: 70,
    difficulty: 'easy',
    features: ['چندپلتفرم', 'ساده', 'کد ساده']
  }
];

// Mock lobby data
interface LobbyData {
  id: string;
  title: string;
  game: GameConfig;
  owner: {
    id: string;
    username: string;
    trustLevel: 'low' | 'mid' | 'high';
    isVerified: boolean;
    avatar?: string;
  };
  currentPlayers: number;
  maxPlayers: number;
  status: 'open' | 'nearfull' | 'full' | 'starting' | 'live';
  createdAt: string;
  server?: {
    ip: string;
    port: number;
    password?: string;
    region: string;
    ping: number;
  };
  room?: {
    id: string;
    password?: string;
  };
  requirements?: {
    minLevel?: number;
    ranked?: boolean;
    verified?: boolean;
  };
  description?: string;
  tags: string[];
  prize?: number;
  isPrivate: boolean;
  joinInfo?: {
    method: 'direct' | 'steam' | 'room_code' | 'invite';
    data: string;
  };
}

// Platform detection
function detectPlatform(): 'pc' | 'android' | 'ios' | 'unknown' {
  const userAgent = navigator.userAgent.toLowerCase();
  if (/android/.test(userAgent)) return 'android';
  if (/iphone|ipad|ipod/.test(userAgent)) return 'ios';
  if (/windows|mac|linux/.test(userAgent)) return 'pc';
  return 'unknown';
}

// Game launcher utility
function launchGame(game: GameConfig, lobby?: LobbyData) {
  const platform = detectPlatform();
  const launchMethod = game.launchMethods[platform];
  
  if (!launchMethod) {
    alert(`این بازی روی ${platform} پشتیبانی نمی‌شود`);
    return;
  }

  switch (platform) {
    case 'pc':
      if (launchMethod.steam) {
        let steamUrl = launchMethod.steam;
        if (lobby?.server && game.joinMethod === 'direct') {
          steamUrl += `// +connect ${lobby.server.ip}:${lobby.server.port}`;
          if (lobby.server.password) {
            steamUrl += ` +password ${lobby.server.password}`;
          }
        }
        window.location.href = steamUrl;
      } else if (launchMethod.battlenet) {
        window.location.href = launchMethod.battlenet;
      }
      break;
      
    case 'android':
      if (launchMethod.intent) {
        window.location.href = launchMethod.intent;
        // Fallback to Play Store
        setTimeout(() => {
          window.open(`https://play.google.com/store/apps/details?id=${launchMethod.packageName}`);
        }, 1500);
      }
      break;
      
    case 'ios':
      if (launchMethod.scheme) {
        window.location.href = launchMethod.scheme;
      } else {
        // Show copy instructions for iOS
        if (lobby?.room?.id) {
          navigator.clipboard.writeText(lobby.room.id);
          alert(`کد روم کپی شد: ${lobby.room.id}\nبازی را دستی باز کرده و کد را وارد کنید`);
        }
      }
      break;
  }
}

export function LobbiesPageAdvanced() {
  const isMobile = useMobile();
  const { navigate } = useNavigation();
  const { setSelectedLobbyId } = useLobby();
  const [selectedGame, setSelectedGame] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [platform] = useState(detectPlatform());
  const [refreshing, setRefreshing] = useState(false);

  // Mock lobbies data
  const [lobbies, setLobbies] = useState<LobbyData[]>([
    {
      id: 'lobby-1',
      title: 'مسابقه تیمی حرفه‌ای CS2',
      game: gameConfigs.find(g => g.id === 'cs2')!,
      owner: {
        id: 'user-1',
        username: 'محمدرضا',
        trustLevel: 'high',
        isVerified: true
      },
      currentPlayers: 8,
      maxPlayers: 10,
      status: 'open',
      createdAt: '۵ دقیقه پیش',
      server: {
        ip: '185.143.232.15',
        port: 27015,
        password: 'mz2024',
        region: 'تهران',
        ping: 25
      },
      joinInfo: {
        method: 'direct',
        data: 'steam://connect/185.143.232.15:27015/mz2024'
      },
      description: 'مسابقه رنک برای بازیکنان حرفه‌ای. حداقل سطح DMG',
      tags: ['رنک', 'تیمی', 'حرفه‌ای'],
      requirements: {
        minLevel: 15,
        ranked: true
      },
      isPrivate: false
    },
    {
      id: 'lobby-2',
      title: 'تورنمنت MLBB جایزه‌دار',
      game: gameConfigs.find(g => g.id === 'mlbb')!,
      owner: {
        id: 'user-2',
        username: 'علی_گیمر',
        trustLevel: 'high',
        isVerified: true
      },
      currentPlayers: 6,
      maxPlayers: 10,
      status: 'open',
      createdAt: '۳ دقیقه پیش',
      room: {
        id: 'ML789456',
        password: '1234'
      },
      joinInfo: {
        method: 'room_code',
        data: 'ML789456'
      },
      description: 'تورنمنت ۵v۵ با جایزه ۱۰۰هزار تومان',
      tags: ['تورنمنت', 'جایزه‌دار', 'رنک'],
      prize: 100000,
      requirements: {
        minLevel: 20,
        ranked: true
      },
      isPrivate: false
    },
    {
      id: 'lobby-3',
      title: 'PUBG Mobile Squad',
      game: gameConfigs.find(g => g.id === 'pubgm')!,
      owner: {
        id: 'user-3',
        username: 'پابجی_کینگ',
        trustLevel: 'mid',
        isVerified: false
      },
      currentPlayers: 3,
      maxPlayers: 4,
      status: 'nearfull',
      createdAt: '۱ دقیقه پیش',
      room: {
        id: '7548963',
        password: undefined
      },
      joinInfo: {
        method: 'room_code',
        data: '7548963'
      },
      description: 'اسکواد ۴ نفره برای رنک پوش',
      tags: ['اسکواد', 'رنک', 'سریع'],
      isPrivate: false
    }
  ]);

  // Filter lobbies
  const filteredLobbies = lobbies.filter(lobby => {
    const matchesGame = selectedGame === 'all' || lobby.game.id === selectedGame;
    const matchesStatus = selectedStatus === 'all' || lobby.status === selectedStatus;
    const matchesSearch = lobby.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         lobby.game.displayName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGame && matchesStatus && matchesSearch;
  });

  // Get available games for current platform
  const availableGames = gameConfigs.filter(game => 
    game.platforms.includes(platform) || platform === 'unknown'
  );

  const refreshLobbies = async () => {
    setRefreshing(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setRefreshing(false);
  };

  return (
    <div className="min-h-screen bg-background gaming-scroll" dir="rtl">
      <div className={`container mx-auto py-6 ${isMobile ? 'px-4' : 'px-6'}`}>
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <Gamepad2 className="h-8 w-8 text-brand-primary" />
                لابی‌های بازی
              </h1>
              <p className="text-text-secondary mt-2">
                به لابی‌های مختلف بپیوندید یا لابی جدید ایجاد کنید
              </p>
            </div>
            
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={refreshLobbies}
                loading={refreshing}
                className="text-text-secondary"
              >
                <RefreshCw className="h-4 w-4" />
                {!isMobile && 'بروزرسانی'}
              </Button>
              
              <Button 
                className="bg-gradient-to-r from-brand-primary to-brand-secondary"
                onClick={() => navigate('create-lobby')}
              >
                <Plus className="h-4 w-4" />
                ایجاد لابی
              </Button>
            </div>
          </div>

          {/* Platform indicator */}
          <div className="flex items-center gap-2 mb-4">
            <Badge variant="outline" className="flex items-center gap-2">
              {platform === 'pc' && <Monitor className="h-3 w-3" />}
              {platform === 'android' && <Smartphone className="h-3 w-3" />}
              {platform === 'ios' && <Mobile className="h-3 w-3" />}
              پلتفرم: {platform === 'pc' ? 'کامپیوتر' : platform === 'android' ? 'اندروید' : 'iOS'}
            </Badge>
            <Badge className="bg-state-success text-white">
              {availableGames.length} بازی پشتیبانی شده
            </Badge>
          </div>
        </motion.div>

        {/* Quick Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6"
        >
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-brand-primary">{lobbies.length}</div>
            <p className="text-sm text-text-secondary">لابی فعال</p>
          </Card>
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-brand-secondary">
              {lobbies.reduce((sum, lobby) => sum + lobby.currentPlayers, 0)}
            </div>
            <p className="text-sm text-text-secondary">بازیکن آنلاین</p>
          </Card>
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-brand-accent">
              {availableGames.length}
            </div>
            <p className="text-sm text-text-secondary">بازی پشتیبانی شده</p>
          </Card>
          <Card className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-500">
              {lobbies.filter(l => l.prize).length}
            </div>
            <p className="text-sm text-text-secondary">مسابقه جایزه‌دار</p>
          </Card>
        </motion.div>

        {/* Search & Filters */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <Card className="p-4">
            <div className="space-y-4">
              {/* Search */}
              <Input
                placeholder="جستجو در لابی‌ها..."
                value={searchQuery}
                onChange={(value) => setSearchQuery(value)}
                leftIcon={<Search className="h-4 w-4" />}
              />
              
              {/* Mobile: Compact filter buttons */}
              {isMobile ? (
                <div className="flex gap-2">
                  <Sheet>
                    <SheetTrigger asChild>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Filter className="h-4 w-4" />
                        {selectedGame !== 'all' ? 
                          availableGames.find(g => g.id === selectedGame)?.displayName.slice(0, 8) + '...' : 
                          'بازی'
                        }
                      </Button>
                    </SheetTrigger>
                    <SheetContent side="bottom" className="max-h-[80vh]">
                      <SheetHeader>
                        <SheetTitle>انتخاب بازی</SheetTitle>
                      </SheetHeader>
                      <div className="grid grid-cols-1 gap-3 mt-4">
                        <Button
                          variant={selectedGame === 'all' ? 'default' : 'outline'}
                          onClick={() => setSelectedGame('all')}
                          className="justify-start h-12"
                        >
                          <Globe className="h-5 w-5 ml-3" />
                          همه بازی‌ها
                        </Button>
                        {availableGames.map(game => (
                          <Button
                            key={game.id}
                            variant={selectedGame === game.id ? 'default' : 'outline'}
                            onClick={() => setSelectedGame(game.id)}
                            className="justify-start h-12"
                          >
                            <span className="text-xl ml-3">{game.icon}</span>
                            {game.displayName}
                          </Button>
                        ))}
                      </div>
                    </SheetContent>
                  </Sheet>

                  <Sheet>
                    <SheetTrigger asChild>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Users className="h-4 w-4" />
                        {selectedStatus !== 'all' ? 
                          selectedStatus === 'open' ? 'باز' :
                          selectedStatus === 'nearfull' ? 'پر' :
                          selectedStatus === 'starting' ? 'شروع' : 'وضعیت'
                          : 'وضعیت'
                        }
                      </Button>
                    </SheetTrigger>
                    <SheetContent side="bottom" className="max-h-[60vh]">
                      <SheetHeader>
                        <SheetTitle>وضعیت لابی</SheetTitle>
                      </SheetHeader>
                      <div className="grid grid-cols-1 gap-3 mt-4">
                        {[
                          { value: 'all', label: 'همه', icon: Globe },
                          { value: 'open', label: 'باز', icon: CheckCircle },
                          { value: 'nearfull', label: 'تقریباً پر', icon: AlertCircle },
                          { value: 'starting', label: 'در حال شروع', icon: Play }
                        ].map(status => (
                          <Button
                            key={status.value}
                            variant={selectedStatus === status.value ? 'default' : 'outline'}
                            onClick={() => setSelectedStatus(status.value)}
                            className="justify-start h-12"
                          >
                            <status.icon className="h-5 w-5 ml-3" />
                            {status.label}
                          </Button>
                        ))}
                      </div>
                    </SheetContent>
                  </Sheet>
                </div>
              ) : (
                /* Desktop: Horizontal filters */
                <div className="flex flex-wrap gap-4">
                  <Select value={selectedGame} onValueChange={setSelectedGame}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="انتخاب بازی" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">همه بازی‌ها</SelectItem>
                      {availableGames.map(game => (
                        <SelectItem key={game.id} value={game.id}>
                          {game.icon} {game.displayName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="وضعیت" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">همه</SelectItem>
                      <SelectItem value="open">باز</SelectItem>
                      <SelectItem value="nearfull">تقریباً پر</SelectItem>
                      <SelectItem value="starting">در حال شروع</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </Card>
        </motion.div>

        {/* Game categories */}
        <Tabs defaultValue="all" className="mb-6">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-6">
            <TabsTrigger value="all">همه</TabsTrigger>
            <TabsTrigger value="pc">PC</TabsTrigger>
            <TabsTrigger value="mobile">موبایل</TabsTrigger>
            <TabsTrigger value="popular">محبوب</TabsTrigger>
            <TabsTrigger value="new">جدید</TabsTrigger>
            <TabsTrigger value="prize">جایزه‌دار</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Lobbies Grid */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="space-y-4"
        >
          <AnimatePresence mode="popLayout">
            {filteredLobbies.map((lobby, index) => (
              <motion.div
                key={lobby.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: index * 0.05 }}
              >
                <AdvancedLobbyCard 
                  lobby={lobby} 
                  platform={platform}
                  onJoin={() => launchGame(lobby.game, lobby)}
                  onViewDetails={() => {
                    setSelectedLobbyId(lobby.id);
                    navigate('lobby-detail');
                  }}
                />
              </motion.div>
            ))}
          </AnimatePresence>

          {filteredLobbies.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <Gamepad2 className="h-16 w-16 text-text-tertiary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-text-secondary mb-2">
                لابی‌ای یافت نشد
              </h3>
              <p className="text-text-tertiary">
                فیلترها را تغییر دهید یا لابی جدید ایجاد کنید
              </p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

// Advanced Lobby Card Component
function AdvancedLobbyCard({ 
  lobby, 
  platform, 
  onJoin,
  onViewDetails
}: { 
  lobby: LobbyData; 
  platform: string;
  onJoin: () => void;
  onViewDetails?: () => void;
}) {
  const isMobile = useMobile();
  const [showJoinDetails, setShowJoinDetails] = useState(false);

  const getStatusBadge = () => {
    switch (lobby.status) {
      case 'open':
        return <Badge className="bg-state-success text-white animate-pulse">باز</Badge>;
      case 'nearfull':
        return <Badge className="bg-state-warning text-black">تقریباً پر</Badge>;
      case 'starting':
        return <Badge className="bg-state-info text-white">در حال شروع</Badge>;
      case 'live':
        return <Badge className="bg-brand-accent text-black">زنده</Badge>;
      default:
        return <Badge variant="outline">نامشخص</Badge>;
    }
  };

  const getJoinButtonText = () => {
    const method = lobby.game.joinMethod;
    switch (method) {
      case 'direct': return 'ورود مستقیم';
      case 'room_code': return 'کپی کد روم';
      case 'invite': return 'درخواست دعوت';
      default: return 'پیوستن';
    }
  };

  const canDirectJoin = lobby.game.platforms.includes(platform as any) && 
                       lobby.game.joinMethod === 'direct';

  const handleCardClick = (e: React.MouseEvent) => {
    // Don't trigger if clicking on buttons or interactive elements
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('[role="button"]')) {
      return;
    }
    
    if (onViewDetails) {
      onViewDetails();
    }
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
      className="group"
    >
      <Card 
        className="overflow-hidden hover:shadow-lg transition-all duration-300 border-border-primary/50 cursor-pointer hover:border-brand-primary/30 hover:bg-surface-secondary/30"
        onClick={handleCardClick}
      >
        <CardContent className="p-0">
          <div className="flex">
          {/* Game Icon & Info */}
          <div className="w-20 h-20 flex items-center justify-center bg-gradient-to-br from-brand-primary/20 to-brand-secondary/20">
            <span className="text-3xl">{lobby.game.icon}</span>
          </div>
          
          {/* Main Content */}
          <div className="flex-1 p-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-semibold text-lg mb-1">{lobby.title}</h3>
                <div className="flex items-center gap-2 text-sm text-text-secondary">
                  <span>{lobby.game.displayName}</span>
                  <span>•</span>
                  <span>میزبان: {lobby.owner.username}</span>
                  {lobby.owner.isVerified && <Crown className="h-3 w-3 text-brand-accent" />}
                </div>
              </div>
              
              <div className="text-left">
                {getStatusBadge()}
                <div className="text-sm text-text-secondary mt-1">
                  {lobby.currentPlayers}/{lobby.maxPlayers} نفر
                </div>
              </div>
            </div>

            {/* Description */}
            {lobby.description && (
              <p className="text-sm text-text-secondary mb-3 line-clamp-2">
                {lobby.description}
              </p>
            )}

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-3">
              {lobby.tags.map((tag, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {tag}
                </Badge>
              ))}
              {lobby.prize && (
                <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs">
                  جایزه: {lobby.prize.toLocaleString()} تومان
                </Badge>
              )}
            </div>

            {/* Server/Room Info */}
            <div className="flex items-center gap-4 text-xs text-text-tertiary mb-3">
              {lobby.server && (
                <>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {lobby.server.region}
                  </div>
                  <div className="flex items-center gap-1">
                    <Wifi className="h-3 w-3" />
                    {lobby.server.ping}ms
                  </div>
                </>
              )}
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {lobby.createdAt}
              </div>
            </div>

            {/* Join Actions */}
            <div className="flex items-center gap-2">
              {/* Click hint */}
              <div className="text-xs text-text-tertiary opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                <ExternalLink className="h-3 w-3" />
                کلیک برای جزئیات
              </div>
              
              {canDirectJoin ? (
                <Button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onJoin();
                  }}
                  className="bg-gradient-to-r from-brand-primary to-brand-secondary text-white"
                  size="sm"
                >
                  <Play className="h-4 w-4" />
                  {getJoinButtonText()}
                </Button>
              ) : (
                <Dialog open={showJoinDetails} onOpenChange={setShowJoinDetails}>
                  <DialogTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Info className="h-4 w-4" />
                      نحوه پیوستن
                    </Button>
                  </DialogTrigger>
                  <JoinInstructionsDialog 
                    lobby={lobby} 
                    platform={platform}
                    onLaunch={onJoin}
                  />
                </Dialog>
              )}

              {onViewDetails && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onViewDetails();
                  }}
                >
                  <ExternalLink className="h-4 w-4" />
                  جزئیات
                </Button>
              )}

              {lobby.server?.password && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigator.clipboard.writeText(lobby.server!.password!);
                    // You would show a toast here
                  }}
                >
                  <Copy className="h-4 w-4" />
                  کپی رمز
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
    </motion.div>
  );
}

// Join Instructions Dialog
function JoinInstructionsDialog({ 
  lobby, 
  platform, 
  onLaunch 
}: { 
  lobby: LobbyData; 
  platform: string;
  onLaunch: () => void;
}) {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Show toast notification
  };

  return (
    <DialogContent className="max-w-md" dir="rtl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <span className="text-2xl">{lobby.game.icon}</span>
          نحوه پیوستن به {lobby.game.displayName}
        </DialogTitle>
      </DialogHeader>

      <div className="space-y-4">
        {/* Platform compatibility */}
        <div className="flex items-center gap-2 p-3 bg-surface-secondary rounded-lg">
          {lobby.game.platforms.includes(platform as any) ? (
            <>
              <CheckCircle className="h-5 w-5 text-state-success" />
              <span className="text-sm">سازگار با {platform}</span>
            </>
          ) : (
            <>
              <XCircle className="h-5 w-5 text-state-danger" />
              <span className="text-sm">ناسازگار با {platform}</span>
            </>
          )}
        </div>

        {/* Join method instructions */}
        {lobby.game.joinMethod === 'room_code' && lobby.room && (
          <div className="space-y-3">
            <h4 className="font-semibold">مراحل پیوستن:</h4>
            <ol className="list-decimal list-inside space-y-2 text-sm">
              <li>بازی را باز کنید</li>
              <li>بخش Custom Room یا Private Match بروید</li>
              <li>کد روم را وارد کنید</li>
              {lobby.room.password && <li>رمز عبور را وارد کنید</li>}
            </ol>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 bg-surface-tertiary rounded-lg">
                <span className="font-mono text-lg">{lobby.room.id}</span>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => copyToClipboard(lobby.room!.id)}
                >
                  <Copy className="h-4 w-4" />
                  کپی کد
                </Button>
              </div>

              {lobby.room.password && (
                <div className="flex items-center justify-between p-3 bg-surface-tertiary rounded-lg">
                  <span className="font-mono">رمز: {lobby.room.password}</span>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => copyToClipboard(lobby.room!.password!)}
                  >
                    <Copy className="h-4 w-4" />
                    کپی رمز
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Launch button */}
        {lobby.game.platforms.includes(platform as any) && (
          <Button 
            onClick={onLaunch}
            className="w-full bg-gradient-to-r from-brand-primary to-brand-secondary"
          >
            <ExternalLink className="h-4 w-4" />
            باز کردن {lobby.game.displayName}
          </Button>
        )}
      </div>
    </DialogContent>
  );
}

// Create Lobby Dialog  
function CreateLobbyDialog({ 
  availableGames, 
  platform, 
  onClose 
}: { 
  availableGames: GameConfig[];
  platform: string;
  onClose: () => void;
}) {
  const [selectedGame, setSelectedGame] = useState<string>('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [maxPlayers, setMaxPlayers] = useState(4);
  const [isPrivate, setIsPrivate] = useState(false);
  const [requiresPassword, setRequiresPassword] = useState(false);
  const [password, setPassword] = useState('');
  const [prizeAmount, setPrizeAmount] = useState(0);
  
  // Age & Gender restrictions
  const [ageRestriction, setAgeRestriction] = useState<string>('none');
  const [genderRestriction, setGenderRestriction] = useState<string>('none');
  const [minLevel, setMinLevel] = useState<number>(1);
  const [requireVerified, setRequireVerified] = useState(false);

  return (
    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Plus className="h-5 w-5" />
          ایجاد لابی جدید
        </DialogTitle>
      </DialogHeader>

      <div className="space-y-6">
        {/* Basic Info */}
        <div className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Info className="h-4 w-4" />
            اطلاعات پایه
          </h3>
          
          <div>
            <label className="block text-sm font-medium mb-2">انتخاب بازی *</label>
            <Select value={selectedGame} onValueChange={setSelectedGame}>
              <SelectTrigger>
                <SelectValue placeholder="یک بازی انتخاب کنید" />
              </SelectTrigger>
              <SelectContent>
                {availableGames.map(game => (
                  <SelectItem key={game.id} value={game.id}>
                    <div className="flex items-center gap-2">
                      <span>{game.icon}</span>
                      <span>{game.displayName}</span>
                      <Badge variant="outline" className="text-xs">
                        {game.difficulty === 'easy' ? 'آسان' : 
                         game.difficulty === 'medium' ? 'متوسط' : 'سخت'}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">عنوان لابی *</label>
            <Input
              placeholder="نام جذابی برای لابی خود انتخاب کنید"
              value={title}
              onChange={setTitle}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">توضیحات</label>
            <textarea
              className="w-full p-3 bg-surface-primary border border-border-primary rounded-lg resize-none"
              placeholder="توضیحی درباره لابی، قوانین، یا نکات مهم..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">حداکثر بازیکنان</label>
              <Select value={maxPlayers.toString()} onValueChange={(value) => setMaxPlayers(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[2, 4, 5, 8, 10, 16, 20, 50, 100].map(num => (
                    <SelectItem key={num} value={num.toString()}>
                      {num} نفر
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">جایزه (تومان)</label>
              <Input
                type="number"
                placeholder="0"
                value={prizeAmount || ''}
                onChange={(value) => setPrizeAmount(parseInt(value) || 0)}
              />
            </div>
          </div>
        </div>

        <Separator />

        {/* Access Control */}
        <div className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Lock className="h-4 w-4" />
            کنترل دسترسی
          </h3>

          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium">لابی خصوصی</label>
              <p className="text-sm text-text-secondary">فقط با دعوت قابل دسترسی</p>
            </div>
            <Switch checked={isPrivate} onCheckedChange={setIsPrivate} />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium">نیاز به رمز عبور</label>
              <p className="text-sm text-text-secondary">رمز برای ورود به لابی</p>
            </div>
            <Switch checked={requiresPassword} onCheckedChange={setRequiresPassword} />
          </div>

          {requiresPassword && (
            <div>
              <label className="block text-sm font-medium mb-2">رمز عبور</label>
              <Input
                type="password"
                placeholder="رمز امن انتخاب کنید"
                value={password}
                onChange={setPassword}
              />
            </div>
          )}
        </div>

        <Separator />

        {/* Demographics & Requirements */}
        <div className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Users className="h-4 w-4" />
            محدودیت‌های دموگرافیک
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">محدودیت سنی</label>
              <Select value={ageRestriction} onValueChange={setAgeRestriction}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون محدودیت</SelectItem>
                  <SelectItem value="13+">۱۳ سال به بالا</SelectItem>
                  <SelectItem value="16+">۱۶ سال به بالا</SelectItem>
                  <SelectItem value="18+">۱۸ سال به بالا (بالغین)</SelectItem>
                  <SelectItem value="21+">۲۱ سال به بالا</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">محدودیت جنسیت</label>
              <Select value={genderRestriction} onValueChange={setGenderRestriction}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">همه جنسیت‌ها</SelectItem>
                  <SelectItem value="male">مخصوص آقایان</SelectItem>
                  <SelectItem value="female">مخصوص خانم‌ها</SelectItem>
                  <SelectItem value="other">سایر هویت‌های جنسی</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">حداقل سطح</label>
              <Select value={minLevel.toString()} onValueChange={(value) => setMinLevel(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[1, 5, 10, 15, 20, 25, 30, 40, 50].map(level => (
                    <SelectItem key={level} value={level.toString()}>
                      سطح {level}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <label className="font-medium">فقط کاربران تأیید شده</label>
                <p className="text-sm text-text-secondary">حساب‌های معتبر</p>
              </div>
              <Switch checked={requireVerified} onCheckedChange={setRequireVerified} />
            </div>
          </div>
        </div>

        {selectedGame && (
          <>
            <Separator />
            <div className="p-4 bg-surface-secondary rounded-lg">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Star className="h-4 w-4" />
                ویژگی‌های این بازی:
              </h4>
              <div className="flex flex-wrap gap-2">
                {availableGames.find(g => g.id === selectedGame)?.features.map((feature, index) => (
                  <Badge key={index} variant="outline" className="text-xs">
                    {feature}
                  </Badge>
                ))}
              </div>
            </div>
          </>
        )}

        <div className="flex gap-3 pt-4">
          <Button onClick={onClose} variant="outline" className="flex-1">
            انصراف
          </Button>
          <Button 
            className="flex-1 bg-gradient-to-r from-brand-primary to-brand-secondary"
            disabled={!selectedGame || !title}
          >
            <Plus className="h-4 w-4" />
            ایجاد لابی
          </Button>
        </div>
      </div>
    </DialogContent>
  );
}

export default LobbiesPageAdvanced;