/**
 * Lobby Invite Chat Notifications
 * اعلان‌های چت برای پذیرش/رد دعوتنامه‌های لابی
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent } from '../ui/card';
import { Avatar } from '../ui/avatar';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { 
  MessageCircle, 
  Check, 
  X, 
  Clock, 
  Users,
  Calendar,
  ThumbsUp,
  ThumbsDown,
  Bell,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { formatPersianDateLong } from '../../utils/persianCalendar';

export interface LobbyInviteChatMessage {
  id: string;
  type: 'invite_sent' | 'invite_accepted' | 'invite_declined' | 'lobby_reminder' | 'lobby_started';
  fromUserId: string;
  fromUsername: string;
  fromAvatar: string;
  toUserId: string;
  lobbyId: string;
  lobbyName: string;
  gameType: string;
  scheduledTime: Date;
  timestamp: Date;
  isRead: boolean;
  metadata?: {
    reason?: string;
    message?: string;
  };
}

// Mock chat messages
const MOCK_CHAT_MESSAGES: LobbyInviteChatMessage[] = [
  {
    id: 'chat_1',
    type: 'invite_accepted',
    fromUserId: 'user_1',
    fromUsername: 'علی حیدری',
    fromAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
    toUserId: 'current_user',
    lobbyId: 'lobby_123',
    lobbyName: 'لابی فیفا شب',
    gameType: 'فیفا موبایل',
    scheduledTime: new Date(Date.now() + 2 * 60 * 60 * 1000),
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    isRead: false
  },
  {
    id: 'chat_2',
    type: 'invite_declined',
    fromUserId: 'user_2',
    fromUsername: 'سارا محمدی',
    fromAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b05b?w=40&h=40&fit=crop&crop=face',
    toUserId: 'current_user',
    lobbyId: 'lobby_456',
    lobbyName: 'تورنومنت پابجی',
    gameType: 'پابجی موبایل',
    scheduledTime: new Date(Date.now() + 4 * 60 * 60 * 1000),
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    isRead: false,
    metadata: {
      reason: 'در آن ساعت مشغولم'
    }
  },
  {
    id: 'chat_3',
    type: 'lobby_reminder',
    fromUserId: 'system',
    fromUsername: 'سیستم',
    fromAvatar: 'https://images.unsplash.com/photo-1516726817505-f5ed825624d8?w=40&h=40&fit=crop&crop=face',
    toUserId: 'current_user',
    lobbyId: 'lobby_789',
    lobbyName: 'لابی کانتر',
    gameType: 'کانتر استرایک 2',
    scheduledTime: new Date(Date.now() + 30 * 60 * 1000),
    timestamp: new Date(Date.now() - 2 * 60 * 1000),
    isRead: false
  }
];

interface ChatMessageCardProps {
  message: LobbyInviteChatMessage;
  onMarkAsRead: (messageId: string) => void;
  onReply?: (messageId: string) => void;
}

const ChatMessageCard: React.FC<ChatMessageCardProps> = ({
  message,
  onMarkAsRead,
  onReply
}) => {
  const getMessageIcon = () => {
    switch (message.type) {
      case 'invite_accepted':
        return <CheckCircle className="w-5 h-5 text-state-success" />;
      case 'invite_declined':
        return <XCircle className="w-5 h-5 text-state-danger" />;
      case 'lobby_reminder':
        return <Clock className="w-5 h-5 text-state-warning" />;
      case 'lobby_started':
        return <Users className="w-5 h-5 text-brand-primary" />;
      default:
        return <MessageCircle className="w-5 h-5 text-text-secondary" />;
    }
  };

  const getMessageText = () => {
    switch (message.type) {
      case 'invite_accepted':
        return `${message.fromUsername} دعوتنامه شما را برای "${message.lobbyName}" پذیرفت`;
      case 'invite_declined':
        return `${message.fromUsername} دعوتنامه شما را برای "${message.lobbyName}" رد کرد`;
      case 'lobby_reminder':
        return `یادآوری: لابی "${message.lobbyName}" در ${getTimeUntilStart()} شروع می‌شود`;
      case 'lobby_started':
        return `لابی "${message.lobbyName}" شروع شده است!`;
      default:
        return 'پیام جدید';
    }
  };

  const getTimeText = () => {
    const diffMs = Date.now() - message.timestamp.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours > 0) return `${diffHours} ساعت پیش`;
    if (diffMinutes > 0) return `${diffMinutes} دقیقه پیش`;
    return 'همین الان';
  };

  const getTimeUntilStart = () => {
    const diffMs = message.scheduledTime.getTime() - Date.now();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours > 0) {
      return `${diffHours} ساعت و ${diffMinutes % 60} دقیقه`;
    } else if (diffMinutes > 0) {
      return `${diffMinutes} دقیقه`;
    } else {
      return 'چند لحظه';
    }
  };

  const getBadgeColor = () => {
    switch (message.type) {
      case 'invite_accepted':
        return 'bg-state-success text-white';
      case 'invite_declined':
        return 'bg-state-danger text-white';
      case 'lobby_reminder':
        return 'bg-state-warning text-black';
      case 'lobby_started':
        return 'bg-brand-primary text-white';
      default:
        return 'bg-text-secondary text-white';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.01 }}
      onClick={() => !message.isRead && onMarkAsRead(message.id)}
      className={cn(
        "p-4 rounded-xl border cursor-pointer transition-all",
        message.isRead 
          ? "bg-surface-secondary border-border opacity-75" 
          : "bg-background border-brand-primary/20 shadow-lg"
      )}
    >
      <div className="space-y-3">
        {/* Header */}
        <div className="flex items-start gap-3">
          <div className="relative">
            <Avatar className="w-10 h-10">
              <ImageWithFallback src={message.fromAvatar} alt={message.fromUsername} />
            </Avatar>
            <div className="absolute -bottom-1 -right-1 p-1 bg-background rounded-full">
              {getMessageIcon()}
            </div>
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-medium text-sm">{message.fromUsername}</h4>
              <Badge className={cn("text-xs", getBadgeColor())}>
                {message.type === 'invite_accepted' && 'پذیرفت'}
                {message.type === 'invite_declined' && 'رد کرد'}
                {message.type === 'lobby_reminder' && 'یادآوری'}
                {message.type === 'lobby_started' && 'شروع شد'}
              </Badge>
              {!message.isRead && (
                <div className="w-2 h-2 bg-brand-primary rounded-full" />
              )}
            </div>
            
            <p className="text-sm text-text-primary mb-2">
              {getMessageText()}
            </p>
            
            {/* Reason/Message */}
            {message.metadata?.reason && (
              <div className="bg-surface-tertiary p-2 rounded-lg mb-2">
                <p className="text-xs text-text-secondary">
                  دلیل: {message.metadata.reason}
                </p>
              </div>
            )}
            
            {/* Lobby Info */}
            <div className="flex items-center gap-4 text-xs text-text-secondary">
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                <span>{formatPersianDateLong(message.scheduledTime)}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>{message.scheduledTime.toLocaleTimeString('fa-IR')}</span>
              </div>
            </div>
            
            <span className="text-xs text-text-tertiary">{getTimeText()}</span>
          </div>
        </div>

        {/* Actions */}
        {(message.type === 'invite_accepted' || message.type === 'lobby_reminder') && (
          <motion.div 
            className="flex gap-2 pt-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {message.type === 'invite_accepted' && (
              <>
                <Button size="sm" variant="outline" className="flex-1 text-xs">
                  <MessageCircle className="w-3 h-3 ml-1" />
                  پیام
                </Button>
                <Button size="sm" className="flex-1 text-xs">
                  <Users className="w-3 h-3 ml-1" />
                  رفتن به لابی
                </Button>
              </>
            )}
            
            {message.type === 'lobby_reminder' && (
              <Button size="sm" className="w-full text-xs">
                <Users className="w-3 h-3 ml-1" />
                پیوستن به لابی
              </Button>
            )}
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};

// Compact notification for top of screen
interface CompactNotificationProps {
  message: LobbyInviteChatMessage;
  onDismiss: (messageId: string) => void;
  onAction?: (messageId: string, action: 'view' | 'join') => void;
}

const CompactNotification: React.FC<CompactNotificationProps> = ({
  message,
  onDismiss,
  onAction
}) => {
  const getIcon = () => {
    switch (message.type) {
      case 'invite_accepted':
        return <ThumbsUp className="w-4 h-4 text-state-success" />;
      case 'invite_declined':
        return <ThumbsDown className="w-4 h-4 text-state-danger" />;
      case 'lobby_reminder':
        return <Bell className="w-4 h-4 text-state-warning" />;
      default:
        return <MessageCircle className="w-4 h-4 text-brand-primary" />;
    }
  };

  const getText = () => {
    switch (message.type) {
      case 'invite_accepted':
        return `${message.fromUsername} دعوتنامه شما را پذیرفت`;
      case 'invite_declined':
        return `${message.fromUsername} دعوتنامه شما را رد کرد`;
      case 'lobby_reminder':
        return `یادآوری: لابی "${message.lobbyName}" نزدیک است`;
      default:
        return 'اعلان جدید';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -50 }}
      className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 max-w-md w-full mx-4"
    >
      <Card className="bg-background/95 backdrop-blur-sm border-brand-primary/20 shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <Avatar className="w-8 h-8">
              <ImageWithFallback src={message.fromAvatar} alt={message.fromUsername} />
            </Avatar>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                {getIcon()}
                <p className="text-sm font-medium truncate">{getText()}</p>
              </div>
              <p className="text-xs text-text-secondary">{message.lobbyName}</p>
            </div>
            
            <div className="flex gap-1">
              <Button 
                size="sm" 
                variant="ghost" 
                className="h-8 w-8 p-0"
                onClick={() => onAction?.(message.id, 'view')}
              >
                <Check className="w-4 h-4" />
              </Button>
              <Button 
                size="sm" 
                variant="ghost" 
                className="h-8 w-8 p-0"
                onClick={() => onDismiss(message.id)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

// Main Component
interface LobbyInviteChatNotificationsProps {
  userId?: string;
  onMessageRead?: (messageId: string) => void;
  onMessageAction?: (messageId: string, action: string) => void;
  showCompactNotifications?: boolean;
}

export const LobbyInviteChatNotifications: React.FC<LobbyInviteChatNotificationsProps> = ({
  userId,
  onMessageRead,
  onMessageAction,
  showCompactNotifications = true
}) => {
  const [messages, setMessages] = useState(MOCK_CHAT_MESSAGES);
  const [compactNotifications, setCompactNotifications] = useState<LobbyInviteChatMessage[]>([]);

  const unreadMessages = messages.filter(msg => !msg.isRead);

  useEffect(() => {
    if (showCompactNotifications) {
      // Show compact notifications for new unread messages
      const newUnread = messages.filter(msg => !msg.isRead && msg.type !== 'lobby_reminder');
      setCompactNotifications(newUnread.slice(0, 1)); // Show only the latest
      
      // Auto-dismiss after 5 seconds
      if (newUnread.length > 0) {
        const timer = setTimeout(() => {
          setCompactNotifications([]);
        }, 5000);
        
        return () => clearTimeout(timer);
      }
    }
  }, [messages, showCompactNotifications]);

  const handleMarkAsRead = (messageId: string) => {
    setMessages(prev =>
      prev.map(msg =>
        msg.id === messageId
          ? { ...msg, isRead: true }
          : msg
      )
    );
    onMessageRead?.(messageId);
  };

  const handleDismissCompact = (messageId: string) => {
    setCompactNotifications(prev => prev.filter(notif => notif.id !== messageId));
    handleMarkAsRead(messageId);
  };

  const handleCompactAction = (messageId: string, action: 'view' | 'join') => {
    setCompactNotifications(prev => prev.filter(notif => notif.id !== messageId));
    onMessageAction?.(messageId, action);
  };

  return (
    <div>
      {/* Compact Notifications */}
      <AnimatePresence>
        {compactNotifications.map(notification => (
          <CompactNotification
            key={notification.id}
            message={notification}
            onDismiss={handleDismissCompact}
            onAction={handleCompactAction}
          />
        ))}
      </AnimatePresence>

      {/* Chat Messages List */}
      <div className="space-y-3">
        {unreadMessages.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <MessageCircle className="w-12 h-12 mx-auto mb-4 text-text-tertiary opacity-50" />
              <h3 className="font-medium mb-2">هیچ اعلان چت جدیدی ندارید</h3>
              <p className="text-sm text-text-secondary">
                اعلان‌های مربوط به دعوتنامه‌ها اینجا نمایش داده می‌شوند
              </p>
            </CardContent>
          </Card>
        ) : (
          <AnimatePresence>
            {unreadMessages
              .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
              .map(message => (
                <ChatMessageCard
                  key={message.id}
                  message={message}
                  onMarkAsRead={handleMarkAsRead}
                  onReply={onMessageAction}
                />
              ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
};