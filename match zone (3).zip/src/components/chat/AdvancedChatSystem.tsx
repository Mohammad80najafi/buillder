/**
 * Advanced Chat System
 * سیستم چت پیشرفته با قابلیت‌های اجتماعی
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, 
  Smile, 
  Paperclip, 
  Mic, 
  MicOff, 
  Heart, 
  ThumbsUp, 
  Laugh,
  MoreVertical,
  Search,
  VideoIcon,
  Phone,
  Volume2,
  VolumeX,
  Crown,
  Shield,
  Star,
  Zap
} from 'lucide-react';

import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { useMobile } from '../ui/use-mobile';

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: Date;
  isOwn: boolean;
  type: 'text' | 'gift' | 'system';
  role: 'player' | 'admin' | 'vip' | 'moderator';
  reactions?: { emoji: string; count: number; users: string[] }[];
  giftsData?: {
    type: string;
    value: number;
    from: string;
  };
}

interface ChatRoom {
  id: string;
  name: string;
  memberCount: number;
  isActive: boolean;
  lastActivity: Date;
}

interface ChatUser {
  id: string;
  username: string;
  level: number;
  role: 'player' | 'admin' | 'vip' | 'moderator';
  status: 'online' | 'away' | 'busy';
  avatar?: string;
}

export function AdvancedChatSystem() {
  const isMobile = useMobile();
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [selectedRoom, setSelectedRoom] = useState('general');
  const [isMuted, setIsMuted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const emojiReactions = ['❤️', '👍', '😂', '😮', '😢', '😡', '🔥', '⚡', '🎯', '💎'];

  // Mock data
  const rooms: ChatRoom[] = [
    {
      id: 'general',
      name: 'چت عمومی',
      memberCount: 156,
      isActive: true,
      lastActivity: new Date()
    },
    {
      id: 'lobby',
      name: 'لابی بازی',
      memberCount: 43,
      isActive: true,
      lastActivity: new Date()
    },
    {
      id: 'tournament',
      name: 'تورنومنت',
      memberCount: 89,
      isActive: false,
      lastActivity: new Date()
    }
  ];

  const users: ChatUser[] = [
    {
      id: '1',
      username: 'Captain Phoenix',
      level: 85,
      role: 'admin',
      status: 'online'
    },
    {
      id: '2',
      username: 'Sarah Pro Gamer',
      level: 72,
      role: 'vip',
      status: 'online'
    },
    {
      id: '3',
      username: 'Ali Champion',
      level: 45,
      role: 'player',
      status: 'away'
    }
  ];

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      username: 'Captain Phoenix',
      message: 'سلام به همه! آماده برای بازی امشب؟ 🎮',
      timestamp: new Date(Date.now() - 300000),
      isOwn: false,
      type: 'text',
      role: 'admin',
      reactions: [
        { emoji: '🔥', count: 5, users: ['user1', 'user2'] },
        { emoji: '👍', count: 3, users: ['user3'] }
      ]
    },
    {
      id: '2',
      username: 'Sarah Pro Gamer',
      message: 'بله! چه بازی‌ای رو پیشنهاد می‌دی؟',
      timestamp: new Date(Date.now() - 240000),
      isOwn: false,
      type: 'text',
      role: 'vip'
    },
    {
      id: '3',
      username: 'شما',
      message: 'من آماده‌ام، بزن بریم! 💪',
      timestamp: new Date(Date.now() - 180000),
      isOwn: true,
      type: 'text',
      role: 'player'
    },
    {
      id: '4',
      username: 'Ali Champion',
      message: '',
      timestamp: new Date(Date.now() - 120000),
      isOwn: false,
      type: 'gift',
      role: 'player',
      giftsData: {
        type: 'جایزه طلایی',
        value: 100,
        from: 'Ali Champion'
      }
    }
  ]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      username: 'شما',
      message: message.trim(),
      timestamp: new Date(),
      isOwn: true,
      type: 'text',
      role: 'player'
    };

    setMessages(prev => [...prev, newMessage]);
    setMessage('');
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const existingReaction = msg.reactions?.find(r => r.emoji === emoji);
        if (existingReaction) {
          return {
            ...msg,
            reactions: msg.reactions?.map(r => 
              r.emoji === emoji 
                ? { ...r, count: r.count + 1 }
                : r
            )
          };
        } else {
          return {
            ...msg,
            reactions: [
              ...(msg.reactions || []),
              { emoji, count: 1, users: ['current-user'] }
            ]
          };
        }
      }
      return msg;
    }));
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Crown className="h-4 w-4 text-yellow-400" />;
      case 'moderator': return <Shield className="h-4 w-4 text-blue-400" />;
      case 'vip': return <Star className="h-4 w-4 text-purple-400" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const MessageComponent = ({ message: msg }: { message: ChatMessage }) => (
    <div className={`group mb-4 ${msg.isOwn ? 'text-left' : 'text-right'}`} dir={msg.isOwn ? 'ltr' : 'rtl'}>
      <div className={`flex items-start space-x-2 ${msg.isOwn ? 'flex-row' : 'flex-row-reverse space-x-reverse'}`}>
        <Avatar className="h-8 w-8">
          <AvatarFallback className="text-xs">{msg.username[0]}</AvatarFallback>
        </Avatar>
        
        <div className={`flex-1 ${msg.isOwn ? 'text-left' : 'text-right'}`}>
          <div className="flex items-center space-x-2 mb-1">
            {!msg.isOwn && getRoleIcon(msg.role)}
            <span className="text-sm font-medium">{msg.username}</span>
            <span className="text-xs text-muted-foreground">
              {msg.timestamp.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
          
          <div className={`max-w-md ${msg.isOwn ? 'mr-auto' : 'ml-auto'}`}>
            {msg.type === 'system' ? (
              <div className="bg-muted/50 text-center p-2 rounded-lg text-sm text-muted-foreground">
                {msg.message}
              </div>
            ) : msg.type === 'gift' ? (
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 p-3 rounded-lg text-sm border border-yellow-500/30">
                <div className="flex items-center space-x-2">
                  <Zap className="h-4 w-4 text-yellow-400" />
                  <span>
                    {msg.giftsData?.from} یک {msg.giftsData?.type} به ارزش {msg.giftsData?.value} سکه فرستاد!
                  </span>
                </div>
              </div>
            ) : (
              <div className={`p-3 rounded-lg ${msg.isOwn ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                {msg.message}
              </div>
            )}
            
            {/* Message Reactions */}
            {msg.reactions && msg.reactions.length > 0 && (
              <div className="flex gap-1 mt-2">
                {msg.reactions.map((reaction, idx) => (
                  <Button
                    key={idx}
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-xs hover:bg-muted"
                    onClick={() => handleReaction(msg.id, reaction.emoji)}
                  >
                    {reaction.emoji} {reaction.count}
                  </Button>
                ))}
              </div>
            )}
            
            {/* Quick Reactions (visible on hover) */}
            <div className="hidden group-hover:flex gap-1 mt-2">
              {emojiReactions.slice(0, 6).map((emoji) => (
                <Button
                  key={emoji}
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 hover:bg-muted"
                  onClick={() => handleReaction(msg.id, emoji)}
                >
                  {emoji}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Desktop Layout
  if (!isMobile) {
    return (
      <div className="h-full flex">
        {/* Sidebar - Chat Rooms & Users */}
        <div className="w-80 border-r bg-card">
          <Tabs defaultValue="rooms" className="h-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="rooms">اتاق‌ها</TabsTrigger>
              <TabsTrigger value="users">کاربران</TabsTrigger>
            </TabsList>
            
            <TabsContent value="rooms" className="h-full">
              <div className="p-3">
                <div className="relative mb-3">
                  <Search className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="جستجو..." className="pr-10" dir="rtl" />
                </div>
                
                <ScrollArea className="h-[calc(100vh-140px)]">
                  <div className="space-y-2">
                    {rooms.map((room) => (
                      <div
                        key={room.id}
                        className={`p-3 rounded-lg cursor-pointer transition-colors ${
                          selectedRoom === room.id ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted/50'
                        }`}
                        onClick={() => setSelectedRoom(room.id)}
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{room.name}</h4>
                          <Badge variant={room.isActive ? 'default' : 'secondary'} className="text-xs">
                            {room.memberCount}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
            
            <TabsContent value="users" className="h-full">
              <div className="p-3">
                <ScrollArea className="h-[calc(100vh-140px)]">
                  <div className="space-y-3">
                    {users.map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs bg-muted px-1.5 py-0.5 rounded">
                            {user.level}
                          </span>
                          {getRoleIcon(user.role)}
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="text-right">
                            <div className="text-sm font-medium">{user.username}</div>
                          </div>
                          <div className="relative">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="text-xs">{user.username[0]}</AvatarFallback>
                            </Avatar>
                            <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-background ${getStatusColor(user.status)}`} />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Chat Header */}
          <div className="border-b p-4 bg-card">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Button variant="ghost" size="sm">
                  <MoreVertical className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <VideoIcon className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Phone className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setIsMuted(!isMuted)}
                >
                  {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </Button>
              </div>
              <div className="text-right" dir="rtl">
                <h2 className="font-semibold">{rooms.find(r => r.id === selectedRoom)?.name}</h2>
                <p className="text-sm text-muted-foreground">
                  {rooms.find(r => r.id === selectedRoom)?.memberCount} عضو آنلاین
                </p>
              </div>
            </div>
          </div>

          {/* Messages Area */}
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((msg) => (
                <MessageComponent key={msg.id} message={msg} />
              ))}
              {isTyping && (
                <div className="text-muted-foreground text-sm text-right" dir="rtl">
                  کاربری در حال تایپ...
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Message Input */}
          <div className="border-t p-4 bg-card/95 backdrop-blur-sm">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleSendMessage}
                disabled={!message.trim()}
                className="flex-shrink-0"
              >
                <Send className="h-4 w-4" />
              </Button>
              
              <Button variant="ghost" size="sm" className="flex-shrink-0">
                <Smile className="h-4 w-4" />
              </Button>
              
              <Button variant="ghost" size="sm" className="flex-shrink-0">
                <Paperclip className="h-4 w-4" />
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm"
                className={`flex-shrink-0 ${isRecording ? 'text-red-500' : ''}`}
                onClick={() => setIsRecording(!isRecording)}
              >
                {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
              
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="پیام خود را بنویسید..."
                className="flex-1 min-w-0"
                dir="rtl"
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Mobile Layout - Fixed Height, No Page Scroll
  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Chat Header - Fixed */}
      <div className="border-b p-4 bg-card flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="sm">
              <MoreVertical className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <VideoIcon className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Phone className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsMuted(!isMuted)}
            >
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
          </div>
          <div className="text-right" dir="rtl">
            <h2 className="font-semibold">{rooms.find(r => r.id === selectedRoom)?.name}</h2>
            <p className="text-sm text-muted-foreground">
              {rooms.find(r => r.id === selectedRoom)?.memberCount} عضو آنلاین
            </p>
          </div>
        </div>
      </div>

      {/* Messages Area - Only This Scrolls */}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full px-4">
          <div className="space-y-4 py-4">
            {messages.map((msg) => (
              <MessageComponent key={msg.id} message={msg} />
            ))}
            {isTyping && (
              <div className="text-muted-foreground text-sm text-right" dir="rtl">
                کاربری در حال تایپ...
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </div>

      {/* Message Input - Fixed to Bottom */}
      <div className="border-t p-4 bg-card flex-shrink-0">
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={handleSendMessage}
            disabled={!message.trim()}
            className="flex-shrink-0"
          >
            <Send className="h-4 w-4" />
          </Button>
          
          <Button variant="ghost" size="sm" className="flex-shrink-0">
            <Smile className="h-4 w-4" />
          </Button>
          
          <Button variant="ghost" size="sm" className="flex-shrink-0">
            <Paperclip className="h-4 w-4" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm"
            className={`flex-shrink-0 ${isRecording ? 'text-red-500' : ''}`}
            onClick={() => setIsRecording(!isRecording)}
          >
            {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
          
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="پیام خود را بنویسید..."
            className="flex-1 min-w-0"
            dir="rtl"
          />
        </div>
      </div>
    </div>
  );
}