/**
 * Mentorship System - Advanced coaching and training platform
 * مرحله 5: سیستم مربیگری و آموزش پیشرفته
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Textarea } from '../ui/textarea';
import { 
  GraduationCap,
  Users,
  Star,
  Clock,
  Target,
  TrendingUp,
  BookOpen,
  Video,
  MessageCircle,
  Calendar,
  Award,
  CheckCircle,
  PlayCircle,
  Zap,
  Shield,
  Trophy,
  Brain,
  Eye,
  Gamepad2,
  BarChart3,
  Timer,
  Heart,
  ThumbsUp
} from 'lucide-react';

interface Mentor {
  id: string;
  name: string;
  title: string;
  avatar: string;
  rating: number;
  totalStudents: number;
  specialties: string[];
  experience: string;
  price: {
    hourly: number;
    package: number;
  };
  availability: string[];
  languages: string[];
  achievements: string[];
  isOnline: boolean;
  responseTime: string;
  successRate: number;
}

interface TrainingSession {
  id: string;
  mentorId: string;
  mentorName: string;
  title: string;
  description: string;
  duration: number;
  scheduledAt: string;
  status: 'upcoming' | 'in-progress' | 'completed' | 'cancelled';
  type: 'individual' | 'group';
  participants: number;
  maxParticipants: number;
  price: number;
  materials: string[];
}

interface LearningPath {
  id: string;
  name: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedHours: number;
  modules: {
    id: string;
    name: string;
    completed: boolean;
    locked: boolean;
  }[];
  progress: number;
  certificate: boolean;
}

interface StudentProgress {
  totalHours: number;
  completedSessions: number;
  currentRank: string;
  improvementScore: number;
  skills: {
    name: string;
    level: number;
    maxLevel: number;
  }[];
}

const mockMentors: Mentor[] = [
  {
    id: '1',
    name: 'استاد حسین رضایی',
    title: 'مربی حرفه‌ای CS:GO',
    avatar: '/mentors/rezaei.jpg',
    rating: 4.9,
    totalStudents: 247,
    specialties: ['استراتژی', 'تیم‌ورک', 'هدف‌گیری'],
    experience: '5+ سال مربیگری، عضو سابق تیم ملی',
    price: { hourly: 50000, package: 400000 },
    availability: ['شنبه', 'یکشنبه', 'دوشنبه'],
    languages: ['فارسی', 'انگلیسی'],
    achievements: ['قهرمان لیگ حرفه‌ای', 'بهترین مربی سال'],
    isOnline: true,
    responseTime: 'کمتر از 2 ساعت',
    successRate: 95
  },
  {
    id: '2',
    name: 'خانم زهرا احمدی',
    title: 'کوچ استراتژی Valorant',
    avatar: '/mentors/ahmadi.jpg',
    rating: 4.8,
    totalStudents: 189,
    specialties: ['استراتژی', 'رهبری', 'انسجام تیمی'],
    experience: '4+ سال تجربه حرفه‌ای',
    price: { hourly: 45000, package: 350000 },
    availability: ['سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه'],
    languages: ['فارسی'],
    achievements: ['رتبه 1 Radiant', 'بهترین استراتژیست'],
    isOnline: false,
    responseTime: 'کمتر از 4 ساعت',
    successRate: 92
  },
  {
    id: '3',
    name: 'آقای علی کریمی',
    title: 'مربی تخصصی League of Legends',
    avatar: '/mentors/karimi.jpg',
    rating: 4.7,
    totalStudents: 156,
    specialties: ['گیم‌پلی', 'آیتم‌بندی', 'مپ کنترل'],
    experience: '3+ سال مربیگری تخصصی',
    price: { hourly: 40000, package: 300000 },
    availability: ['جمعه', 'شنبه'],
    languages: ['فارسی', 'انگلیسی'],
    achievements: ['Challenger Tier', 'مربی برتر کمیونیتی'],
    isOnline: true,
    responseTime: 'کمتر از 1 ساعت',
    successRate: 88
  }
];

const mockSessions: TrainingSession[] = [
  {
    id: '1',
    mentorId: '1',
    mentorName: 'استاد حسین رضایی',
    title: 'تکنیک‌های هدف‌گیری پیشرفته',
    description: 'یادگیری تکنیک‌های حرفه‌ای برای بهبود دقت',
    duration: 90,
    scheduledAt: '1403/06/15 - 18:00',
    status: 'upcoming',
    type: 'individual',
    participants: 1,
    maxParticipants: 1,
    price: 75000,
    materials: ['ویدیو آموزشی', 'تمرین‌های عملی', 'نقشه‌های تمرینی']
  },
  {
    id: '2',
    mentorId: '2',
    mentorName: 'خانم زهرا احمدی',
    title: 'ورکشاپ استراتژی تیمی',
    description: 'آموزش هماهنگی و تاکتیک‌های تیمی',
    duration: 120,
    scheduledAt: '1403/06/17 - 20:00',
    status: 'upcoming',
    type: 'group',
    participants: 4,
    maxParticipants: 6,
    price: 35000,
    materials: ['راهنمای استراتژی', 'نقشه‌های تاکتیکی']
  }
];

const mockLearningPaths: LearningPath[] = [
  {
    id: '1',
    name: 'مسیر مبتدی CS:GO',
    description: 'از صفر تا صد برای تازه‌واردان',
    difficulty: 'beginner',
    estimatedHours: 25,
    modules: [
      { id: '1', name: 'اصول بازی', completed: true, locked: false },
      { id: '2', name: 'حرکات پایه', completed: true, locked: false },
      { id: '3', name: 'اسلحه‌شناسی', completed: false, locked: false },
      { id: '4', name: 'استراتژی پایه', completed: false, locked: true }
    ],
    progress: 40,
    certificate: false
  },
  {
    id: '2',
    name: 'مسیر پیشرفته Valorant',
    description: 'ارتقاء به سطح حرفه‌ای',
    difficulty: 'advanced',
    estimatedHours: 50,
    modules: [
      { id: '1', name: 'تحلیل عمیق نقشه‌ها', completed: false, locked: false },
      { id: '2', name: 'تاکتیک‌های پیچیده', completed: false, locked: true },
      { id: '3', name: 'روانشناسی رقابت', completed: false, locked: true }
    ],
    progress: 0,
    certificate: true
  }
];

const mockProgress: StudentProgress = {
  totalHours: 45,
  completedSessions: 12,
  currentRank: 'طلایی',
  improvementScore: 85,
  skills: [
    { name: 'هدف‌گیری', level: 7, maxLevel: 10 },
    { name: 'استراتژی', level: 6, maxLevel: 10 },
    { name: 'کار تیمی', level: 8, maxLevel: 10 },
    { name: 'تصمیم‌گیری', level: 5, maxLevel: 10 }
  ]
};

const getDifficultyColor = (difficulty: string) => {
  const colors = {
    beginner: 'text-green-600 bg-green-100 dark:bg-green-900',
    intermediate: 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900',
    advanced: 'text-red-600 bg-red-100 dark:bg-red-900'
  };
  return colors[difficulty as keyof typeof colors] || colors.beginner;
};

const getStatusColor = (status: string) => {
  const colors = {
    upcoming: 'text-blue-600 bg-blue-100 dark:bg-blue-900',
    'in-progress': 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900',
    completed: 'text-green-600 bg-green-100 dark:bg-green-900',
    cancelled: 'text-red-600 bg-red-100 dark:bg-red-900'
  };
  return colors[status as keyof typeof colors] || colors.upcoming;
};

export function MentorshipSystem() {
  const [selectedMentor, setSelectedMentor] = useState<Mentor | null>(null);
  const [bookingStep, setBookingStep] = useState<'mentor' | 'session' | 'payment'>('mentor');

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto" dir="rtl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center gap-3">
          <GraduationCap className="w-8 h-8 text-blue-500" />
          <h1 className="text-3xl font-bold">سیستم مربیگری Matchzone</h1>
        </div>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          با بهترین مربیان حرفه‌ای مهارت‌هایتان را ارتقا دهید و به سطح بالاتری از بازی برسید
        </p>
      </motion.div>

      {/* Progress Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-blue-500" />
              پیشرفت شما
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-500">{mockProgress.totalHours}</p>
                <p className="text-sm text-muted-foreground">ساعت آموزش</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-500">{mockProgress.completedSessions}</p>
                <p className="text-sm text-muted-foreground">جلسه تکمیل شده</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-yellow-500">{mockProgress.currentRank}</p>
                <p className="text-sm text-muted-foreground">رتبه فعلی</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-500">{mockProgress.improvementScore}%</p>
                <p className="text-sm text-muted-foreground">میزان بهبود</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mockProgress.skills.map((skill, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{skill.name}</span>
                    <span className="text-sm text-muted-foreground">
                      {skill.level}/{skill.maxLevel}
                    </span>
                  </div>
                  <Progress value={(skill.level / skill.maxLevel) * 100} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Main Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Tabs defaultValue="mentors" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="mentors">مربیان</TabsTrigger>
            <TabsTrigger value="sessions">جلسات</TabsTrigger>
            <TabsTrigger value="paths">مسیرهای یادگیری</TabsTrigger>
            <TabsTrigger value="analytics">تحلیل عملکرد</TabsTrigger>
          </TabsList>

          {/* Mentors */}
          <TabsContent value="mentors" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">مربیان برتر</h2>
              <Button variant="outline" size="sm">
                <Users className="w-4 h-4 ml-2" />
                مشاهده همه
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockMentors.map((mentor, index) => (
                <motion.div
                  key={mentor.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-all">
                    <CardHeader className="pb-3">
                      <div className="flex items-start gap-3">
                        <div className="relative">
                          <Avatar className="w-16 h-16">
                            <AvatarImage src={mentor.avatar} alt={mentor.name} />
                            <AvatarFallback>{mentor.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white ${
                            mentor.isOnline ? 'bg-green-500' : 'bg-gray-400'
                          }`} />
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-semibold">{mentor.name}</h3>
                          <p className="text-sm text-muted-foreground">{mentor.title}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-yellow-500 fill-current" />
                              <span className="text-sm font-medium">{mentor.rating}</span>
                            </div>
                            <Badge variant="secondary" className="text-xs">
                              {mentor.totalStudents} دانشجو
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <div className="flex flex-wrap gap-1">
                        {mentor.specialties.map((specialty, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {specialty}
                          </Badge>
                        ))}
                      </div>

                      <p className="text-sm text-muted-foreground">
                        {mentor.experience}
                      </p>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-sm">
                          <span>درس خصوصی:</span>
                          <span className="font-medium">
                            {mentor.price.hourly.toLocaleString()} تومان/ساعت
                          </span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span>پکیج ماهانه:</span>
                          <span className="font-medium">
                            {mentor.price.package.toLocaleString()} تومان
                          </span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span>زمان پاسخ:</span>
                          <span className="font-medium">{mentor.responseTime}</span>
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <span>نرخ موفقیت:</span>
                          <span className="font-medium text-green-600">
                            {mentor.successRate}%
                          </span>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <Button size="sm" className="flex-1">
                          رزرو جلسه
                        </Button>
                        <Button size="sm" variant="outline">
                          <MessageCircle className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Sessions */}
          <TabsContent value="sessions" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">جلسات آموزشی</h2>
              <Button variant="outline" size="sm">
                <Calendar className="w-4 h-4 ml-2" />
                تقویم
              </Button>
            </div>

            <div className="space-y-4">
              {mockSessions.map((session, index) => (
                <motion.div
                  key={session.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="space-y-3 flex-1">
                          <div className="flex items-start gap-4">
                            <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                              <PlayCircle className="w-5 h-5 text-blue-600" />
                            </div>
                            
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <h3 className="font-semibold">{session.title}</h3>
                                <Badge className={getStatusColor(session.status)}>
                                  {session.status === 'upcoming' ? 'آینده' :
                                   session.status === 'in-progress' ? 'در حال برگزاری' :
                                   session.status === 'completed' ? 'تکمیل شده' : 'لغو شده'}
                                </Badge>
                              </div>
                              
                              <p className="text-sm text-muted-foreground mb-2">
                                {session.description}
                              </p>
                              
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <div className="flex items-center gap-1">
                                  <GraduationCap className="w-4 h-4" />
                                  {session.mentorName}
                                </div>
                                <div className="flex items-center gap-1">
                                  <Timer className="w-4 h-4" />
                                  {session.duration} دقیقه
                                </div>
                                <div className="flex items-center gap-1">
                                  <Clock className="w-4 h-4" />
                                  {session.scheduledAt}
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex flex-wrap gap-2">
                            {session.materials.map((material, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                {material}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div className="text-left space-y-2">
                          <p className="font-semibold text-lg">
                            {session.price.toLocaleString()} تومان
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {session.participants}/{session.maxParticipants} نفر
                          </p>
                          
                          {session.status === 'upcoming' && (
                            <Button size="sm" className="w-full">
                              پیوستن
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Learning Paths */}
          <TabsContent value="paths" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">مسیرهای یادگیری</h2>
              <Button variant="outline" size="sm">
                <BookOpen className="w-4 h-4 ml-2" />
                مسیر جدید
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {mockLearningPaths.map((path, index) => (
                <motion.div
                  key={path.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg mb-1">{path.name}</CardTitle>
                          <p className="text-sm text-muted-foreground mb-2">
                            {path.description}
                          </p>
                          <div className="flex gap-2">
                            <Badge className={getDifficultyColor(path.difficulty)}>
                              {path.difficulty === 'beginner' ? 'مبتدی' :
                               path.difficulty === 'intermediate' ? 'متوسط' : 'پیشرفته'}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {path.estimatedHours} ساعت
                            </Badge>
                          </div>
                        </div>
                        {path.certificate && (
                          <Award className="w-6 h-6 text-yellow-500" />
                        )}
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">پیشرفت کلی:</span>
                          <span className="text-sm font-medium">{path.progress}%</span>
                        </div>
                        <Progress value={path.progress} className="h-2" />
                      </div>

                      <div className="space-y-2">
                        <p className="text-sm font-medium">ماژول‌ها:</p>
                        {path.modules.map((module, idx) => (
                          <div key={module.id} className="flex items-center gap-2">
                            {module.completed ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : module.locked ? (
                              <Shield className="w-4 h-4 text-gray-400" />
                            ) : (
                              <PlayCircle className="w-4 h-4 text-blue-500" />
                            )}
                            <span className={`text-sm ${
                              module.completed ? 'line-through text-muted-foreground' :
                              module.locked ? 'text-muted-foreground' : ''
                            }`}>
                              {module.name}
                            </span>
                          </div>
                        ))}
                      </div>

                      <Button size="sm" className="w-full" disabled={path.progress === 100}>
                        {path.progress === 100 ? 'تکمیل شده' : 'ادامه یادگیری'}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-4">
            <h2 className="text-xl font-semibold">تحلیل عملکرد</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <Brain className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold">+32%</p>
                  <p className="text-sm text-muted-foreground">بهبود مهارت</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <Target className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold">87%</p>
                  <p className="text-sm text-muted-foreground">دقت هدف‌گیری</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold">15</p>
                  <p className="text-sm text-muted-foreground">پیروزی متوالی</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <Heart className="w-8 h-8 text-red-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold">4.8</p>
                  <p className="text-sm text-muted-foreground">رضایت از آموزش</p>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Charts would go here */}
            <Card>
              <CardHeader>
                <CardTitle>نمودار پیشرفت ماهانه</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  نمودار پیشرفت اینجا نمایش داده خواهد شد
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}