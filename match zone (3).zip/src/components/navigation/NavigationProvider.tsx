/**
 * Matchzone Navigation Provider
 * Centralized navigation state management - FAB only navigation
 */

import React, { createContext, useContext, useState, useCallback } from 'react';
import { NavigationPage, NavigationState, NavigationActions } from '../../types/navigation';

interface NavigationContextType extends NavigationState, NavigationActions {}

const NavigationContext = createContext<NavigationContextType | null>(null);

interface NavigationProviderProps {
  children: React.ReactNode;
  initialPage?: NavigationPage;
  initialAuth?: boolean;
}

export function NavigationProvider({ 
  children, 
  initialPage = 'home',
  initialAuth = true 
}: NavigationProviderProps) {
  const [currentPage, setCurrentPage] = useState<NavigationPage>(initialPage);
  const [isAuthenticated, setIsAuthenticated] = useState(initialAuth);
  const [currentLobbyId, setCurrentLobbyId] = useState<string>();

  const navigate = useCallback((page: NavigationPage) => {
    setCurrentPage(page);
    // Clear lobby ID when navigating to non-lobby pages
    if (page !== 'lobby-detail') {
      setCurrentLobbyId(undefined);
    }
  }, []);

  const navigateToLobby = useCallback((lobbyId: string) => {
    setCurrentLobbyId(lobbyId);
    setCurrentPage('lobby-detail');
  }, []);

  const authenticate = useCallback((success: boolean) => {
    setIsAuthenticated(success);
    if (success) {
      setCurrentPage('home');
    }
  }, []);

  const logout = useCallback(() => {
    setIsAuthenticated(false);
    setCurrentPage('home');
    setCurrentLobbyId(undefined);
  }, []);

  const value: NavigationContextType = {
    // State
    currentPage,
    isAuthenticated,
    currentLobbyId,
    
    // Actions
    navigate,
    navigateToLobby,
    authenticate,
    logout
  };

  return (
    <NavigationContext.Provider value={value}>
      {children}
    </NavigationContext.Provider>
  );
}

export function useNavigation() {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error('useNavigation must be used within NavigationProvider');
  }
  return context;
}

// Navigation utilities
export const navigationConfig = {
  requiresAuth: [
    'lobbies', 'tournaments', 'social', 'profile', 'store', 'settings'
  ] as NavigationPage[],
  
  showcasePages: [
    'showcase', 'scrollbar', 'docs'
  ] as NavigationPage[],
  
  mobileOptimized: [
    'home', 'social', 'media'
  ] as NavigationPage[]
};

export function shouldShowSidebar(page: NavigationPage, isMobile: boolean): boolean {
  return !isMobile && !navigationConfig.showcasePages.includes(page);
}