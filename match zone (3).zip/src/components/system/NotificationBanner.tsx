import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, PanInfo } from 'motion/react';
import { X, Sparkles } from 'lucide-react';
import { useMobile } from '../ui/use-mobile';

interface NotificationBannerProps {
  message: string;
  type?: 'info' | 'success' | 'warning' | 'gaming';
  autoHide?: boolean;
  duration?: number;
  onDismiss?: () => void;
}

interface NotificationBannerExtendedProps extends NotificationBannerProps {
  index?: number;
}

export function NotificationBanner({
  message,
  type = 'gaming',
  autoHide = false,
  duration = 5000,
  onDismiss,
  index = 0
}: NotificationBannerExtendedProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [dragX, setDragX] = useState(0);
  const isMobile = useMobile();

  const typeStyles = {
    info: {
      bg: 'from-blue-500/20 to-blue-600/20',
      border: 'border-blue-500/30',
      text: 'text-blue-200',
      icon: 'text-blue-400'
    },
    success: {
      bg: 'from-green-500/20 to-green-600/20',
      border: 'border-green-500/30',
      text: 'text-green-200',
      icon: 'text-green-400'
    },
    warning: {
      bg: 'from-yellow-500/20 to-yellow-600/20',
      border: 'border-yellow-500/30',
      text: 'text-yellow-200',
      icon: 'text-yellow-400'
    },
    gaming: {
      bg: 'from-purple-500/20 via-blue-500/20 to-cyan-500/20',
      border: 'border-cyan-500/30',
      text: 'text-cyan-200',
      icon: 'text-cyan-400'
    }
  };

  const currentStyle = typeStyles[type];

  useEffect(() => {
    if (autoHide && duration > 0) {
      const timer = setTimeout(() => {
        handleDismiss();
      }, duration);
      return () => clearTimeout(timer);
    }
  }, [autoHide, duration]);

  const handleDismiss = () => {
    setIsVisible(false);
    onDismiss?.();
  };

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (isMobile) {
      const threshold = 100;
      if (Math.abs(info.offset.x) > threshold) {
        handleDismiss();
      } else {
        setDragX(0);
      }
    }
  };

  const handleDrag = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (isMobile) {
      setDragX(info.offset.x);
    }
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ 
            y: 0, 
            opacity: 1,
            x: dragX
          }}
          exit={{ 
            y: -100, 
            opacity: 0,
            transition: { duration: 0.3 }
          }}
          drag={isMobile ? "x" : false}
          dragConstraints={{ left: -200, right: 200 }}
          dragElastic={0.2}
          onDrag={handleDrag}
          onDragEnd={handleDragEnd}
          className={`
            w-full
            bg-gradient-to-r ${currentStyle.bg}
            backdrop-blur-lg border ${currentStyle.border}
            rounded-xl shadow-2xl
            overflow-hidden
          `}
          style={{
            boxShadow: `
              0 10px 25px -5px rgba(0, 0, 0, 0.4),
              0 0 0 1px rgba(255, 255, 255, 0.05),
              inset 0 1px 0 rgba(255, 255, 255, 0.1)
            `
          }}

        >
          {/* Gaming Glow Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-pulse" />
          
          <div className="relative flex items-center gap-3 p-4">
            {/* Icon */}
            <div className={`flex-shrink-0 ${currentStyle.icon}`}>
              <Sparkles className="w-5 h-5" />
            </div>
            
            {/* Message */}
            <div className={`flex-1 font-medium ${currentStyle.text} text-sm`}>
              {message}
            </div>

            {/* Close Button - Desktop Only */}
            {!isMobile && (
              <button
                onClick={handleDismiss}
                className={`
                  flex-shrink-0 p-1 rounded-lg 
                  ${currentStyle.text} hover:bg-white/10 
                  transition-colors duration-200
                `}
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Mobile Swipe Indicator */}
          {isMobile && (
            <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-12 h-1 bg-white/20 rounded-full mb-1" />
          )}

          {/* Progress Bar for Auto-hide */}
          {autoHide && (
            <motion.div
              initial={{ width: "100%" }}
              animate={{ width: "0%" }}
              transition={{ duration: duration / 1000, ease: "linear" }}
              className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r ${currentStyle.bg.replace('/20', '/60')}`}
            />
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Hook for managing multiple notifications
export function useNotifications() {
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    message: string;
    type: 'info' | 'success' | 'warning' | 'gaming';
    autoHide?: boolean;
    duration?: number;
  }>>([]);

  const addNotification = (notification: Omit<typeof notifications[0], 'id'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    setNotifications(prev => [...prev, { ...notification, id }]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  return {
    notifications,
    addNotification,
    removeNotification,
    clearAll
  };
}

// Container component for managing multiple notifications
export function NotificationContainer({ 
  notifications, 
  onRemove 
}: { 
  notifications: Array<{
    id: string;
    message: string;
    type: 'info' | 'success' | 'warning' | 'gaming';
    autoHide?: boolean;
    duration?: number;
  }>;
  onRemove: (id: string) => void;
}) {
  const isMobile = useMobile();
  const maxVisible = isMobile ? 3 : 4; // Limit visible notifications to prevent overflow
  const maxHeight = isMobile ? 'max-h-[60vh]' : 'max-h-[50vh]'; // Prevent overflow

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      <div className={`absolute top-4 left-4 right-4 ${isMobile ? 'mx-2' : 'max-w-md mx-auto left-1/2 -translate-x-1/2'}`}>
        <div className={`${maxHeight} overflow-hidden space-y-3`}>
          {notifications.slice(0, maxVisible).map((notification, index) => (
            <motion.div 
              key={notification.id} 
              className="pointer-events-auto"
              initial={{ y: -50, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: -50, opacity: 0, scale: 0.95 }}
              transition={{ 
                type: "spring",
                stiffness: 300,
                damping: 25,
                delay: index * 0.1
              }}
            >
              <NotificationBanner
                message={notification.message}
                type={notification.type}
                autoHide={notification.autoHide}
                duration={notification.duration}
                index={0} // Reset index since container handles positioning
                onDismiss={() => onRemove(notification.id)}
              />
            </motion.div>
          ))}
        </div>
        
        {/* Show overflow indicator if there are more notifications */}
        {notifications.length > maxVisible && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="pointer-events-none mt-3 text-center"
          >
            <div className="inline-block px-4 py-2 bg-slate-800/95 backdrop-blur-lg rounded-full border border-slate-600/50 text-slate-300 text-sm font-medium shadow-lg">
              <span className="inline-block w-2 h-2 bg-yellow-500 rounded-full mr-2 animate-pulse"></span>
              و {notifications.length - maxVisible} اعلان دیگر در صف...
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}