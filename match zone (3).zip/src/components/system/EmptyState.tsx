import React from 'react';
import { cn } from '../ui/utils';
import { GameButton } from '../ui/game-button';
import { 
  SearchX, 
  GamepadIcon, 
  Users, 
  Trophy, 
  MessageCircle,
  Heart,
  Store,
  PlayCircle,
  Inbox
} from 'lucide-react';

interface EmptyStateProps {
  type: 'search' | 'lobbies' | 'tournaments' | 'friends' | 'messages' | 'favorites' | 'store' | 'videos' | 'notifications';
  title?: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

const emptyStateConfig = {
  search: {
    icon: SearchX,
    title: 'نتیجه‌ای یافت نشد',
    description: 'متأسفانه چیزی با این جستجو پیدا نکردیم. کلمات کلیدی دیگری امتحان کنید.',
    actionLabel: 'جستجوی جدید',
  },
  lobbies: {
    icon: GamepadIcon,
    title: 'هیچ لابی‌ای یافت نشد',
    description: 'در حال حاضر لابی فعالی وجود ندارد. اولین نفری باشید که لابی می‌سازد!',
    actionLabel: 'ساخت لابی',
  },
  tournaments: {
    icon: Trophy,
    title: 'تورنومنتی در حال برگزاری نیست',
    description: 'فعلاً مسابقه‌ای برگزار نمی‌شود. برای اطلاع از مسابقات آینده منتظر بمانید.',
  },
  friends: {
    icon: Users,
    title: 'هنوز دوستی ندارید',
    description: 'با بازیکنان دیگر آشنا شوید و دوستان جدید پیدا کنید!',
    actionLabel: 'جستجوی بازیکنان',
  },
  messages: {
    icon: MessageCircle,
    title: 'پیامی ندارید',
    description: 'صندوق پیام شما خالی است. با دوستانتان چت کنید!',
  },
  favorites: {
    icon: Heart,
    title: 'هیچ موردی علاقه‌مند نکرده‌اید',
    description: 'محتواهای مورد علاقه‌تان را اینجا مشاهده کنید.',
  },
  store: {
    icon: Store,
    title: 'فروشگاه خالی است',
    description: 'در حال حاضر محصولی برای فروش موجود نیست.',
  },
  videos: {
    icon: PlayCircle,
    title: 'ویدیویی یافت نشد',
    description: 'محتوای ویدیویی جدیدی در این بخش موجود نیست.',
  },
  notifications: {
    icon: Inbox,
    title: 'اعلانی ندارید',
    description: 'همه اعلان‌های شما را خوانده‌اید. عالی!',
  },
};

export const EmptyState: React.FC<EmptyStateProps> = ({
  type,
  title,
  description,
  actionLabel,
  onAction,
  className,
}) => {
  const config = emptyStateConfig[type];
  const Icon = config.icon;

  return (
    <div className={cn('flex flex-col items-center justify-center py-12 px-4 text-center', className)}>
      <Icon className="w-16 h-16 text-muted-foreground/50 mb-4" />
      
      <h3 className="text-lg font-medium text-foreground mb-2">
        {title || config.title}
      </h3>
      
      <p className="text-muted-foreground mb-6 max-w-md">
        {description || config.description}
      </p>
      
      {(onAction && (actionLabel || config.actionLabel)) && (
        <GameButton onClick={onAction} variant="primary">
          {actionLabel || config.actionLabel}
        </GameButton>
      )}
    </div>
  );
};