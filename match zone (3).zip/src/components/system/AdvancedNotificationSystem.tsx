/**
 * Advanced Notification System - مرحله 4 سیستم طراحی
 * سیستم اعلان‌های پیشرفته با قابلیت‌های زنده، دسته‌بندی و مدیریت هوشمند
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { 
  Bell, BellOff, Settings, Filter, Search, Trash2, Archive,
  Check, Eye, EyeOff, Volume2, VolumeX, Smartphone,
  Mail, MessageSquare, Trophy, Users, DollarSign, AlertTriangle,
  CheckCircle, XCircle, Info, Star, Crown, Target, Zap,
  Calendar, Clock, Globe, Shield, Activity, TrendingUp,
  Gift, Award, Flag, Heart, Share2, ExternalLink, Copy,
  Download, Upload, RefreshCw, Pause, Play, MoreHorizontal
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion, AnimatePresence } from 'motion/react';

export type NotificationType = 
  | 'tournament_invite' | 'tournament_start' | 'tournament_end' | 'tournament_cancel'
  | 'lobby_invite' | 'lobby_start' | 'lobby_full' | 'lobby_cancel'
  | 'clan_invite' | 'clan_war' | 'clan_promotion' | 'clan_event'
  | 'friend_request' | 'friend_online' | 'friend_achievement'
  | 'payment_success' | 'payment_failed' | 'prize_won' | 'refund'
  | 'system_maintenance' | 'system_update' | 'security_alert'
  | 'achievement_unlocked' | 'level_up' | 'streak' | 'milestone'
  | 'message' | 'mention' | 'comment' | 'reaction'
  | 'stream_live' | 'event_reminder' | 'match_result';

export type NotificationPriority = 'low' | 'medium' | 'high' | 'urgent';

export type NotificationChannel = 'in_app' | 'push' | 'email' | 'sms';

export interface NotificationAction {
  id: string;
  label: string;
  action: 'view' | 'join' | 'accept' | 'decline' | 'dismiss' | 'link';
  url?: string;
  primary?: boolean;
}

export interface AdvancedNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  priority: NotificationPriority;
  category: 'tournament' | 'lobby' | 'clan' | 'social' | 'system' | 'achievement' | 'financial';
  channels: NotificationChannel[];
  
  // Metadata
  timestamp: string;
  expiresAt?: string;
  read: boolean;
  archived: boolean;
  starred: boolean;
  dismissed: boolean;
  
  // Rich content
  avatar?: string;
  image?: string;
  icon?: string;
  color?: string;
  
  // Interactive
  actions?: NotificationAction[];
  
  // Context
  userId?: string;
  tournamentId?: string;
  lobbyId?: string;
  clanId?: string;
  senderId?: string;
  
  // Delivery tracking
  delivered: boolean;
  deliveredAt?: string;
  clicked: boolean;
  clickedAt?: string;
  
  // Grouping
  groupId?: string;
  grouped?: boolean;
  groupCount?: number;
}

export interface NotificationSettings {
  globalEnabled: boolean;
  channels: {
    in_app: boolean;
    push: boolean;
    email: boolean;
    sms: boolean;
  };
  categories: {
    tournament: { enabled: boolean; priority: NotificationPriority; channels: NotificationChannel[] };
    lobby: { enabled: boolean; priority: NotificationPriority; channels: NotificationChannel[] };
    clan: { enabled: boolean; priority: NotificationPriority; channels: NotificationChannel[] };
    social: { enabled: boolean; priority: NotificationPriority; channels: NotificationChannel[] };
    system: { enabled: boolean; priority: NotificationPriority; channels: NotificationChannel[] };
    achievement: { enabled: boolean; priority: NotificationPriority; channels: NotificationChannel[] };
    financial: { enabled: boolean; priority: NotificationPriority; channels: NotificationChannel[] };
  };
  schedule: {
    quietHours: { enabled: boolean; start: string; end: string };
    weekends: boolean;
    timezone: string;
  };
  sounds: {
    enabled: boolean;
    volume: number;
    customSounds: Record<NotificationType, string>;
  };
  grouping: {
    enabled: boolean;
    maxGroupSize: number;
    groupTimeout: number; // minutes
  };
}

// Mock data
const MOCK_NOTIFICATIONS: AdvancedNotification[] = [
  {
    id: '1',
    type: 'tournament_invite',
    title: 'دعوت به تورنومنت',
    message: 'شما به تورنومنت "کاپ طلایی کالاف دیوتی" دعوت شدید',
    priority: 'high',
    category: 'tournament',
    channels: ['in_app', 'push'],
    timestamp: '2 دقیقه پیش',
    expiresAt: '2 ساعت دیگر',
    read: false,
    archived: false,
    starred: false,
    dismissed: false,
    avatar: '/avatars/tournament-host.jpg',
    icon: 'trophy',
    color: '#FFD700',
    actions: [
      { id: '1', label: 'پیوستن', action: 'accept', primary: true },
      { id: '2', label: 'رد کردن', action: 'decline' },
      { id: '3', label: 'مشاهده جزئیات', action: 'view' }
    ],
    tournamentId: 'tour_123',
    senderId: 'user_456',
    delivered: true,
    deliveredAt: '2 دقیقه پیش',
    clicked: false
  },
  {
    id: '2',
    type: 'friend_online',
    title: 'دوست آنلاین شد',
    message: 'امیررضا الان آنلاین شده و آماده بازی است',
    priority: 'medium',
    category: 'social',
    channels: ['in_app'],
    timestamp: '5 دقیقه پیش',
    read: false,
    archived: false,
    starred: false,
    dismissed: false,
    avatar: '/avatars/friend-1.jpg',
    icon: 'users',
    color: '#22C55E',
    actions: [
      { id: '1', label: 'دعوت به بازی', action: 'view', primary: true },
      { id: '2', label: 'ارسال پیام', action: 'view' }
    ],
    senderId: 'friend_789',
    delivered: true,
    deliveredAt: '5 دقیقه پیش',
    clicked: false
  },
  {
    id: '3',
    type: 'achievement_unlocked',
    title: 'دستاورد جدید!',
    message: 'شما دستاورد "قهرمان ۱۰ مسابقه" را کسب کردید',
    priority: 'medium',
    category: 'achievement',
    channels: ['in_app', 'push'],
    timestamp: '10 دقیقه پیش',
    read: true,
    archived: false,
    starred: true,
    dismissed: false,
    image: '/achievements/champion-10.jpg',
    icon: 'award',
    color: '#8B5CF6',
    actions: [
      { id: '1', label: 'مشاهده دستاوردها', action: 'view', primary: true },
      { id: '2', label: 'اشتراک‌گذاری', action: 'view' }
    ],
    delivered: true,
    deliveredAt: '10 دقیقه پیش',
    clicked: true,
    clickedAt: '8 دقیقه پیش'
  }
];

const MOCK_SETTINGS: NotificationSettings = {
  globalEnabled: true,
  channels: {
    in_app: true,
    push: true,
    email: true,
    sms: false
  },
  categories: {
    tournament: { enabled: true, priority: 'high', channels: ['in_app', 'push', 'email'] },
    lobby: { enabled: true, priority: 'medium', channels: ['in_app', 'push'] },
    clan: { enabled: true, priority: 'medium', channels: ['in_app', 'push'] },
    social: { enabled: true, priority: 'low', channels: ['in_app'] },
    system: { enabled: true, priority: 'high', channels: ['in_app', 'email'] },
    achievement: { enabled: true, priority: 'low', channels: ['in_app'] },
    financial: { enabled: true, priority: 'high', channels: ['in_app', 'push', 'email', 'sms'] }
  },
  schedule: {
    quietHours: { enabled: true, start: '22:00', end: '08:00' },
    weekends: true,
    timezone: 'Asia/Tehran'
  },
  sounds: {
    enabled: true,
    volume: 75,
    customSounds: {}
  },
  grouping: {
    enabled: true,
    maxGroupSize: 5,
    groupTimeout: 30
  }
};

export interface AdvancedNotificationSystemProps {
  notifications?: AdvancedNotification[];
  settings?: NotificationSettings;
  onNotificationClick?: (notification: AdvancedNotification) => void;
  onNotificationAction?: (notificationId: string, actionId: string) => void;
  onSettingsChange?: (settings: NotificationSettings) => void;
  maxVisible?: number;
  showSettings?: boolean;
}

export function AdvancedNotificationSystem({
  notifications: propNotifications = MOCK_NOTIFICATIONS,
  settings: propSettings = MOCK_SETTINGS,
  onNotificationClick,
  onNotificationAction,
  onSettingsChange,
  maxVisible = 5,
  showSettings = true
}: AdvancedNotificationSystemProps) {
  const [notifications, setNotifications] = useState<AdvancedNotification[]>(propNotifications);
  const [settings, setSettings] = useState<NotificationSettings>(propSettings);
  const [activeTab, setActiveTab] = useState<'all' | 'unread' | 'starred' | 'archived'>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  const [selectedNotifications, setSelectedNotifications] = useState<string[]>([]);
  const [isOnline, setIsOnline] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(settings.sounds.enabled);
  
  const audioRef = useRef<HTMLAudioElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Real-time updates simulation
  useEffect(() => {
    if (!isOnline) return;

    const interval = setInterval(() => {
      // Simulate receiving new notifications
      if (Math.random() < 0.1) { // 10% chance every 5 seconds
        const newNotification: AdvancedNotification = {
          id: `new_${Date.now()}`,
          type: 'friend_online',
          title: 'اعلان جدید',
          message: 'این یک اعلان تست است',
          priority: 'medium',
          category: 'social',
          channels: ['in_app'],
          timestamp: 'همین الان',
          read: false,
          archived: false,
          starred: false,
          dismissed: false,
          delivered: true,
          deliveredAt: 'همین الان',
          clicked: false
        };

        setNotifications(prev => [newNotification, ...prev]);
        
        // Play notification sound
        if (soundEnabled && audioRef.current) {
          audioRef.current.play().catch(() => {});
        }
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [isOnline, soundEnabled]);

  const filteredNotifications = notifications.filter(notification => {
    if (activeTab === 'unread' && notification.read) return false;
    if (activeTab === 'starred' && !notification.starred) return false;
    if (activeTab === 'archived' && !notification.archived) return false;
    if (activeTab === 'all' && notification.archived) return false;

    if (filterCategory !== 'all' && notification.category !== filterCategory) return false;

    if (searchQuery && !notification.title.toLowerCase().includes(searchQuery.toLowerCase()) && 
        !notification.message.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }

    return true;
  });

  const unreadCount = notifications.filter(n => !n.read && !n.archived).length;

  const handleNotificationClick = (notification: AdvancedNotification) => {
    // Mark as read
    setNotifications(prev => 
      prev.map(n => 
        n.id === notification.id 
          ? { ...n, read: true, clicked: true, clickedAt: 'همین الان' }
          : n
      )
    );

    onNotificationClick?.(notification);
  };

  const handleNotificationAction = (notificationId: string, actionId: string) => {
    const notification = notifications.find(n => n.id === notificationId);
    const action = notification?.actions?.find(a => a.id === actionId);

    if (action?.action === 'dismiss') {
      setNotifications(prev => 
        prev.map(n => 
          n.id === notificationId 
            ? { ...n, dismissed: true }
            : n
        )
      );
    }

    onNotificationAction?.(notificationId, actionId);
    toast.success('عملیات انجام شد');
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, read: true }))
    );
    toast.success('همه اعلان‌ها خوانده شد');
  };

  const clearAll = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, dismissed: true }))
    );
    toast.success('همه اعلان‌ها حذف شد');
  };

  const toggleStar = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(n => 
        n.id === notificationId 
          ? { ...n, starred: !n.starred }
          : n
      )
    );
  };

  const archiveNotification = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(n => 
        n.id === notificationId 
          ? { ...n, archived: true }
          : n
      )
    );
    toast.success('اعلان بایگانی شد');
  };

  const bulkAction = (action: 'read' | 'archive' | 'delete') => {
    setNotifications(prev => 
      prev.map(n => {
        if (selectedNotifications.includes(n.id)) {
          switch (action) {
            case 'read':
              return { ...n, read: true };
            case 'archive':
              return { ...n, archived: true };
            case 'delete':
              return { ...n, dismissed: true };
            default:
              return n;
          }
        }
        return n;
      })
    );
    setSelectedNotifications([]);
    toast.success(`${selectedNotifications.length} اعلان ${action === 'read' ? 'خوانده' : action === 'archive' ? 'بایگانی' : 'حذف'} شد`);
  };

  const getPriorityColor = (priority: NotificationPriority) => {
    switch (priority) {
      case 'urgent': return 'border-red-500 bg-red-500/10';
      case 'high': return 'border-orange-500 bg-orange-500/10';
      case 'medium': return 'border-yellow-500 bg-yellow-500/10';
      case 'low': return 'border-blue-500 bg-blue-500/10';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'tournament': return Trophy;
      case 'lobby': return Target;
      case 'clan': return Crown;
      case 'social': return Users;
      case 'system': return Settings;
      case 'achievement': return Award;
      case 'financial': return DollarSign;
      default: return Bell;
    }
  };

  return (
    <div className="space-y-4" dir="rtl" ref={containerRef}>
      {/* Notification Sound */}
      <audio ref={audioRef} preload="auto">
        <source src="/sounds/notification.mp3" type="audio/mpeg" />
      </audio>

      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Bell className="w-6 h-6" />
                {unreadCount > 0 && (
                  <span className="absolute -top-2 -left-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </div>
              <div>
                <h2 className="text-xl font-bold">اعلان‌ها</h2>
                <p className="text-sm text-muted-foreground">
                  {unreadCount} اعلان خوانده نشده از {notifications.length} اعلان
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <Switch
                  checked={soundEnabled}
                  onCheckedChange={setSoundEnabled}
                  size="sm"
                />
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </div>

              <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>

              {showSettings && (
                <Button variant="outline" size="sm" onClick={() => setShowSettingsDialog(true)}>
                  <Settings className="w-4 h-4" />
                </Button>
              )}

              <Button variant="outline" size="sm" onClick={markAllAsRead}>
                <Check className="w-4 h-4 ml-2" />
                خواندن همه
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Filters and Search */}
      <Card>
        <CardContent className="p-4">
          <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)}>
            <div className="flex items-center justify-between mb-4">
              <TabsList className="grid w-80 grid-cols-4">
                <TabsTrigger value="all">همه</TabsTrigger>
                <TabsTrigger value="unread">
                  خوانده نشده {unreadCount > 0 && `(${unreadCount})`}
                </TabsTrigger>
                <TabsTrigger value="starred">ستاره‌دار</TabsTrigger>
                <TabsTrigger value="archived">بایگانی</TabsTrigger>
              </TabsList>

              <div className="flex items-center gap-2">
                <Input
                  placeholder="جستجو در اعلان‌ها..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-60"
                />
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">همه دسته‌ها</SelectItem>
                    <SelectItem value="tournament">تورنومنت</SelectItem>
                    <SelectItem value="lobby">لابی</SelectItem>
                    <SelectItem value="clan">کلن</SelectItem>
                    <SelectItem value="social">اجتماعی</SelectItem>
                    <SelectItem value="system">سیستم</SelectItem>
                    <SelectItem value="achievement">دستاورد</SelectItem>
                    <SelectItem value="financial">مالی</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Bulk Actions */}
            {selectedNotifications.length > 0 && (
              <div className="flex items-center gap-2 p-2 bg-blue-500/10 rounded-lg mb-4">
                <span className="text-sm">{selectedNotifications.length} اعلان انتخاب شده</span>
                <Button size="sm" variant="outline" onClick={() => bulkAction('read')}>
                  <Check className="w-3 h-3 ml-1" />
                  خواندن
                </Button>
                <Button size="sm" variant="outline" onClick={() => bulkAction('archive')}>
                  <Archive className="w-3 h-3 ml-1" />
                  بایگانی
                </Button>
                <Button size="sm" variant="outline" onClick={() => bulkAction('delete')}>
                  <Trash2 className="w-3 h-3 ml-1" />
                  حذف
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setSelectedNotifications([])}>
                  لغو
                </Button>
              </div>
            )}

            {/* Notifications List */}
            <TabsContent value={activeTab} className="mt-0">
              <AnimatePresence>
                {filteredNotifications.length === 0 ? (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-12"
                  >
                    <Bell className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      {activeTab === 'unread' ? 'هیچ اعلان خوانده نشده‌ای وجود ندارد' :
                       activeTab === 'starred' ? 'هیچ اعلان ستاره‌داری وجود ندارد' :
                       activeTab === 'archived' ? 'هیچ اعلان بایگانی‌شده‌ای وجود ندارد' :
                       'هیچ اعلانی وجود ندارد'}
                    </p>
                  </motion.div>
                ) : (
                  <div className="space-y-2">
                    {filteredNotifications.slice(0, isExpanded ? undefined : maxVisible).map((notification) => {
                      const Icon = getCategoryIcon(notification.category);
                      
                      return (
                        <motion.div
                          key={notification.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, x: -100 }}
                          className={`p-4 rounded-lg border transition-all duration-200 hover:shadow-md cursor-pointer ${
                            getPriorityColor(notification.priority)
                          } ${notification.read ? 'opacity-70' : ''} ${
                            selectedNotifications.includes(notification.id) ? 'ring-2 ring-blue-500' : ''
                          }`}
                          onClick={() => handleNotificationClick(notification)}
                        >
                          <div className="flex items-start gap-3">
                            {/* Selection Checkbox */}
                            <input
                              type="checkbox"
                              checked={selectedNotifications.includes(notification.id)}
                              onChange={(e) => {
                                e.stopPropagation();
                                if (e.target.checked) {
                                  setSelectedNotifications(prev => [...prev, notification.id]);
                                } else {
                                  setSelectedNotifications(prev => prev.filter(id => id !== notification.id));
                                }
                              }}
                              className="mt-1"
                            />

                            {/* Avatar/Icon */}
                            <div className="flex-shrink-0">
                              {notification.avatar ? (
                                <Avatar className="w-10 h-10">
                                  <AvatarImage src={notification.avatar} />
                                  <AvatarFallback>
                                    <Icon className="w-5 h-5" />
                                  </AvatarFallback>
                                </Avatar>
                              ) : (
                                <div className={`p-2 rounded-lg ${
                                  notification.priority === 'urgent' ? 'bg-red-500/20' :
                                  notification.priority === 'high' ? 'bg-orange-500/20' :
                                  notification.priority === 'medium' ? 'bg-yellow-500/20' :
                                  'bg-blue-500/20'
                                }`}>
                                  <Icon className="w-5 h-5" />
                                </div>
                              )}
                            </div>

                            {/* Content */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <h4 className={`font-medium text-sm ${!notification.read ? 'font-semibold' : ''}`}>
                                      {notification.title}
                                    </h4>
                                    {!notification.read && (
                                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                    )}
                                    <Badge variant="secondary" className="text-xs">
                                      {notification.category === 'tournament' ? 'تورنومنت' :
                                       notification.category === 'lobby' ? 'لابی' :
                                       notification.category === 'clan' ? 'کلن' :
                                       notification.category === 'social' ? 'اجتماعی' :
                                       notification.category === 'system' ? 'سیستم' :
                                       notification.category === 'achievement' ? 'دستاورد' :
                                       'مالی'}
                                    </Badge>
                                  </div>
                                  <p className="text-sm text-muted-foreground mb-2">
                                    {notification.message}
                                  </p>
                                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                                    <span className="flex items-center gap-1">
                                      <Clock className="w-3 h-3" />
                                      {notification.timestamp}
                                    </span>
                                    {notification.expiresAt && (
                                      <span className="text-orange-500">
                                        انقضا: {notification.expiresAt}
                                      </span>
                                    )}
                                    {notification.clicked && (
                                      <span className="text-green-500">
                                        کلیک شده
                                      </span>
                                    )}
                                  </div>
                                </div>

                                {/* Action Buttons */}
                                <div className="flex items-center gap-1">
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      toggleStar(notification.id);
                                    }}
                                    className={notification.starred ? 'text-yellow-500' : ''}
                                  >
                                    <Star className="w-3 h-3" />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      archiveNotification(notification.id);
                                    }}
                                  >
                                    <Archive className="w-3 h-3" />
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleNotificationAction(notification.id, 'dismiss');
                                    }}
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </Button>
                                </div>
                              </div>

                              {/* Actions */}
                              {notification.actions && notification.actions.length > 0 && (
                                <div className="flex items-center gap-2 mt-3">
                                  {notification.actions.map((action) => (
                                    <Button
                                      key={action.id}
                                      size="sm"
                                      variant={action.primary ? "default" : "outline"}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleNotificationAction(notification.id, action.id);
                                      }}
                                    >
                                      {action.label}
                                    </Button>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}

                    {/* Show More Button */}
                    {!isExpanded && filteredNotifications.length > maxVisible && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-center pt-4"
                      >
                        <Button variant="outline" onClick={() => setIsExpanded(true)}>
                          مشاهده {filteredNotifications.length - maxVisible} اعلان دیگر
                        </Button>
                      </motion.div>
                    )}

                    {/* Show Less Button */}
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-center pt-4"
                      >
                        <Button variant="outline" onClick={() => setIsExpanded(false)}>
                          نمایش کمتر
                        </Button>
                      </motion.div>
                    )}
                  </div>
                )}
              </AnimatePresence>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Settings Dialog */}
      <Dialog open={showSettingsDialog} onOpenChange={setShowSettingsDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>تنظیمات اعلان‌ها</DialogTitle>
            <DialogDescription>
              تنظیمات اعلان‌های پلتفرم Matchzone را مدیریت کنید و نحوه دریافت اعلان‌ها را شخصی‌سازی کنید.
            </DialogDescription>
          </DialogHeader>
          
          <Tabs defaultValue="general" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="general">عمومی</TabsTrigger>
              <TabsTrigger value="categories">دسته‌بندی</TabsTrigger>
              <TabsTrigger value="schedule">زمان‌بندی</TabsTrigger>
              <TabsTrigger value="channels">کانال‌ها</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general" className="space-y-4">
              <Card>
                <CardContent className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">فعال‌سازی اعلان‌ها</h4>
                      <p className="text-sm text-muted-foreground">دریافت همه اعلان‌ها</p>
                    </div>
                    <Switch
                      checked={settings.globalEnabled}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({ ...prev, globalEnabled: checked }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">صدای اعلان</h4>
                      <p className="text-sm text-muted-foreground">پخش صدا هنگام دریافت اعلان</p>
                    </div>
                    <Switch
                      checked={settings.sounds.enabled}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({ ...prev, sounds: { ...prev.sounds, enabled: checked } }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">گروه‌بندی اعلان‌ها</h4>
                      <p className="text-sm text-muted-foreground">ترکیب اعلان‌های مشابه</p>
                    </div>
                    <Switch
                      checked={settings.grouping.enabled}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({ ...prev, grouping: { ...prev.grouping, enabled: checked } }))
                      }
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="categories">
              <div className="space-y-4">
                {Object.entries(settings.categories).map(([category, categorySettings]) => (
                  <Card key={category}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">
                          {category === 'tournament' ? 'تورنومنت' :
                           category === 'lobby' ? 'لابی' :
                           category === 'clan' ? 'کلن' :
                           category === 'social' ? 'اجتماعی' :
                           category === 'system' ? 'سیستم' :
                           category === 'achievement' ? 'دستاورد' :
                           'مالی'}
                        </h4>
                        <Switch
                          checked={categorySettings.enabled}
                          onCheckedChange={(checked) => 
                            setSettings(prev => ({
                              ...prev,
                              categories: {
                                ...prev.categories,
                                [category]: { ...categorySettings, enabled: checked }
                              }
                            }))
                          }
                        />
                      </div>
                      
                      {categorySettings.enabled && (
                        <div className="space-y-3">
                          <div>
                            <label className="text-sm font-medium">اولویت</label>
                            <Select
                              value={categorySettings.priority}
                              onValueChange={(value: NotificationPriority) =>
                                setSettings(prev => ({
                                  ...prev,
                                  categories: {
                                    ...prev.categories,
                                    [category]: { ...categorySettings, priority: value }
                                  }
                                }))
                              }
                            >
                              <SelectTrigger className="w-full mt-1">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">کم</SelectItem>
                                <SelectItem value="medium">متوسط</SelectItem>
                                <SelectItem value="high">بالا</SelectItem>
                                <SelectItem value="urgent">فوری</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div>
                            <label className="text-sm font-medium">کانال‌های ارسال</label>
                            <div className="flex gap-2 mt-2">
                              {(['in_app', 'push', 'email', 'sms'] as NotificationChannel[]).map((channel) => (
                                <label key={channel} className="flex items-center gap-2 text-sm">
                                  <input
                                    type="checkbox"
                                    checked={categorySettings.channels.includes(channel)}
                                    onChange={(e) => {
                                      const newChannels = e.target.checked
                                        ? [...categorySettings.channels, channel]
                                        : categorySettings.channels.filter(c => c !== channel);
                                      
                                      setSettings(prev => ({
                                        ...prev,
                                        categories: {
                                          ...prev.categories,
                                          [category]: { ...categorySettings, channels: newChannels }
                                        }
                                      }));
                                    }}
                                  />
                                  {channel === 'in_app' ? 'درون برنامه' :
                                   channel === 'push' ? 'پوش' :
                                   channel === 'email' ? 'ایمیل' : 'پیامک'}
                                </label>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={() => setShowSettingsDialog(false)}>
              انصراف
            </Button>
            <Button onClick={() => {
              onSettingsChange?.(settings);
              setShowSettingsDialog(false);
              toast.success('تنظیمات ذخیره شد');
            }}>
              ذخیره تنظیمات
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default AdvancedNotificationSystem;