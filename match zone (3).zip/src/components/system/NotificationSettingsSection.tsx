import React, { useState } from 'react';
import { Bell, BellOff, Volume2, VolumeX, Smartphone, Users, Gamepad2, Settings as SettingsIcon, TestTube, Clock } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Switch } from '../ui/switch';
import { Slider } from '../ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Label } from '../ui/label';
import { Separator } from '../ui/separator';
import { Progress } from '../ui/progress';
import { useNotificationService, useSocialNotifications, useGamingNotifications, useSystemNotifications } from './NotificationService';
import { motion } from 'motion/react';

export function NotificationSettingsSection() {
  const { config, updateConfig, notifications, clearAllNotifications, getUnreadCount } = useNotificationService();
  const socialNotifications = useSocialNotifications();
  const gamingNotifications = useGamingNotifications();
  const systemNotifications = useSystemNotifications();

  const [testingCategory, setTestingCategory] = useState<string | null>(null);

  const handleConfigChange = <K extends keyof typeof config>(key: K, value: typeof config[K]) => {
    updateConfig({ [key]: value });
  };

  const handleCategoryChange = <K extends keyof typeof config.categories>(category: K, enabled: boolean) => {
    updateConfig({
      categories: {
        ...config.categories,
        [category]: enabled
      }
    });
  };

  const testNotification = async (category: 'social' | 'gaming' | 'system') => {
    setTestingCategory(category);
    
    setTimeout(() => {
      switch (category) {
        case 'social':
          socialNotifications.notifyNewFollow('کاربر_تست');
          setTimeout(() => {
            socialNotifications.notifyNewMessage('دوست_گیمر', 'سلام! آماده بازی هستی؟');
          }, 800);
          break;
        case 'gaming':
          gamingNotifications.notifyMatchFound('CS:GO Competitive');
          setTimeout(() => {
            gamingNotifications.notifyAchievement('First Blood Master');
          }, 1000);
          break;
        case 'system':
          systemNotifications.notifyUpdate('2.1.0');
          break;
      }
      
      setTimeout(() => setTestingCategory(null), 2000);
    }, 500);
  };

  const formatDuration = (ms: number) => {
    return `${ms / 1000} ثانیه`;
  };

  const unreadCount = getUnreadCount();

  const categoryInfo = {
    social: {
      title: 'اجتماعی',
      description: 'دنبال‌کنندگان، پیام‌ها و فعالیت‌های دوستان',
      icon: Users,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10'
    },
    gaming: {
      title: 'گیمینگ',
      description: 'مسابقات، دعوت‌ها و دستاوردها',
      icon: Gamepad2,
      color: 'text-purple-500',
      bgColor: 'bg-purple-500/10'
    },
    system: {
      title: 'سیستم',
      description: 'بروزرسانی‌ها و اطلاعات مهم',
      icon: SettingsIcon,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10'
    },
    marketing: {
      title: 'تبلیغات',
      description: 'پیشنهادات و محتوای تجاری',
      icon: Bell,
      color: 'text-orange-500',
      bgColor: 'bg-orange-500/10'
    }
  };

  return (
    <div className="space-y-6">
      {/* Master Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              {config.enabled ? (
                <Bell className="h-5 w-5 text-green-500" />
              ) : (
                <BellOff className="h-5 w-5 text-red-500" />
              )}
              تنظیمات کلی اعلان‌ها
            </CardTitle>
            
            {unreadCount > 0 && (
              <Badge variant="secondary" className="bg-red-500/20 text-red-400">
                {unreadCount} خوانده نشده
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Main Enable/Disable */}
          <div className="flex items-center justify-between p-4 bg-card rounded-lg border">
            <div>
              <Label className="text-base">فعال‌سازی اعلان‌ها</Label>
              <p className="text-sm text-muted-foreground">
                {config.enabled ? 'اعلان‌ها فعال هستند' : 'تمام اعلان‌ها غیرفعال شده‌اند'}
              </p>
            </div>
            <Switch 
              checked={config.enabled}
              onCheckedChange={(enabled) => handleConfigChange('enabled', enabled)}
              className="data-[state=checked]:bg-green-600"
            />
          </div>

          {config.enabled && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-6"
            >
              {/* Quick Actions */}
              <div className="flex flex-wrap gap-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => clearAllNotifications()}
                  disabled={notifications.length === 0}
                >
                  پاک کردن همه ({notifications.length})
                </Button>
                
                <Button
                  variant="outline" 
                  size="sm"
                  onClick={() => testNotification('gaming')}
                  disabled={testingCategory !== null}
                >
                  {testingCategory === 'gaming' ? 'در حال تست...' : 'تست اعلان'}
                </Button>
              </div>

              <Separator />

              {/* Display Settings */}
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Smartphone className="h-4 w-4" />
                  تنظیمات نمایش
                </h4>
                
                {/* Max Visible */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>حداکثر اعلان همزمان: {config.maxVisible}</Label>
                    <Badge variant="outline">{config.maxVisible} اعلان</Badge>
                  </div>
                  <Slider
                    value={[config.maxVisible]}
                    onValueChange={([value]) => handleConfigChange('maxVisible', value)}
                    min={1}
                    max={6}
                    step={1}
                    className="w-full"
                  />
                  <p className="text-xs text-muted-foreground">
                    در موبایل حداکثر 3 اعلان نمایش داده می‌شود
                  </p>
                </div>

                {/* Default Duration */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label>مدت نمایش پیش‌فرض</Label>
                    <Badge variant="outline">{formatDuration(config.defaultDuration)}</Badge>
                  </div>
                  <Slider
                    value={[config.defaultDuration]}
                    onValueChange={([value]) => handleConfigChange('defaultDuration', value)}
                    min={2000}
                    max={15000}
                    step={1000}
                    className="w-full"
                  />
                </div>

                {/* Auto Hide */}
                <div className="flex items-center justify-between">
                  <div>
                    <Label>مخفی شدن خودکار</Label>
                    <p className="text-sm text-muted-foreground">بستن خودکار اعلان‌ها بعد از مدت زمان مشخص</p>
                  </div>
                  <Switch 
                    checked={config.autoHideEnabled}
                    onCheckedChange={(enabled) => handleConfigChange('autoHideEnabled', enabled)}
                  />
                </div>
              </div>

              <Separator />

              {/* Sound & Vibration */}
              <div className="space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Volume2 className="h-4 w-4" />
                  صدا و ویبریشن
                </h4>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>صدای اعلان</Label>
                    <p className="text-sm text-muted-foreground">پخش صدا برای انواع مختلف اعلان</p>
                  </div>
                  <Switch 
                    checked={config.soundEnabled}
                    onCheckedChange={(enabled) => handleConfigChange('soundEnabled', enabled)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>ویبریشن (موبایل)</Label>
                    <p className="text-sm text-muted-foreground">ویبریشن در دستگاه‌های موبایل</p>
                  </div>
                  <Switch 
                    checked={config.vibrationEnabled}
                    onCheckedChange={(enabled) => handleConfigChange('vibrationEnabled', enabled)}
                  />
                </div>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Category Settings */}
      {config.enabled && (
        <Card>
          <CardHeader>
            <CardTitle>دسته‌بندی اعلان‌ها</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(config.categories).map(([category, enabled]) => {
              const info = categoryInfo[category as keyof typeof categoryInfo];
              const Icon = info.icon;
              
              return (
                <motion.div
                  key={category}
                  layout
                  className={`flex items-center justify-between p-4 rounded-lg border transition-colors ${
                    enabled ? info.bgColor + ' border-current/20' : 'bg-muted/30 border-muted'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${enabled ? info.bgColor : 'bg-muted/50'}`}>
                      <Icon className={`h-5 w-5 ${enabled ? info.color : 'text-muted-foreground'}`} />
                    </div>
                    <div>
                      <Label className={enabled ? '' : 'text-muted-foreground'}>{info.title}</Label>
                      <p className="text-sm text-muted-foreground">{info.description}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {enabled && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => testNotification(category as any)}
                        disabled={testingCategory !== null}
                        className="text-xs"
                      >
                        {testingCategory === category ? (
                          <div className="flex items-center gap-1">
                            <div className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />
                            تست
                          </div>
                        ) : (
                          <>
                            <TestTube className="h-3 w-3 ml-1" />
                            تست
                          </>
                        )}
                      </Button>
                    )}
                    
                    <Switch 
                      checked={enabled}
                      onCheckedChange={(checked) => handleCategoryChange(category as keyof typeof config.categories, checked)}
                    />
                  </div>
                </motion.div>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Statistics */}
      {notifications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>آمار اعلان‌ها</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-card rounded-lg border">
                <div className="text-2xl font-bold text-primary">{notifications.length}</div>
                <div className="text-sm text-muted-foreground">کل اعلان‌ها</div>
              </div>
              <div className="text-center p-4 bg-card rounded-lg border">
                <div className="text-2xl font-bold text-green-500">{unreadCount}</div>
                <div className="text-sm text-muted-foreground">خوانده نشده</div>
              </div>
              <div className="text-center p-4 bg-card rounded-lg border">
                <div className="text-2xl font-bold text-purple-500">
                  {notifications.filter(n => n.category === 'gaming').length}
                </div>
                <div className="text-sm text-muted-foreground">گیمینگ</div>
              </div>
              <div className="text-center p-4 bg-card rounded-lg border">
                <div className="text-2xl font-bold text-blue-500">
                  {notifications.filter(n => n.category === 'social').length}
                </div>
                <div className="text-sm text-muted-foreground">اجتماعی</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}