import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { NotificationContainer } from './NotificationBanner';

export interface NotificationConfig {
  enabled: boolean;
  maxVisible: number;
  defaultDuration: number;
  autoHideEnabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  categories: {
    social: boolean;
    gaming: boolean;
    system: boolean;
    marketing: boolean;
  };
}

export interface Notification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'gaming';
  category: 'social' | 'gaming' | 'system' | 'marketing';
  autoHide?: boolean;
  duration?: number;
  userId?: string;
  actionUrl?: string;
  imageUrl?: string;
  timestamp: Date;
}

interface NotificationContextType {
  notifications: Notification[];
  config: NotificationConfig;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp'>) => void;
  removeNotification: (id: string) => void;
  clearAllNotifications: () => void;
  updateConfig: (newConfig: Partial<NotificationConfig>) => void;
  markAsRead: (id: string) => void;
  getUnreadCount: () => number;
}

const defaultConfig: NotificationConfig = {
  enabled: true,
  maxVisible: 3,
  defaultDuration: 5000,
  autoHideEnabled: true,
  soundEnabled: true,
  vibrationEnabled: true,
  categories: {
    social: true,
    gaming: true,
    system: true,
    marketing: false
  }
};

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [config, setConfig] = useState<NotificationConfig>(() => {
    // Load config from localStorage
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('matchzone-notification-config');
      return saved ? { ...defaultConfig, ...JSON.parse(saved) } : defaultConfig;
    }
    return defaultConfig;
  });
  const [readNotifications, setReadNotifications] = useState<Set<string>>(new Set());

  // Save config to localStorage when it changes
  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('matchzone-notification-config', JSON.stringify(config));
    }
  }, [config]);

  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp'>) => {
    // Check if notifications are enabled
    if (!config.enabled) return;
    
    // Check if category is enabled
    if (!config.categories[notification.category]) return;

    const id = Math.random().toString(36).substr(2, 9);
    const newNotification: Notification = {
      ...notification,
      id,
      timestamp: new Date(),
      autoHide: notification.autoHide ?? config.autoHideEnabled,
      duration: notification.duration ?? config.defaultDuration
    };

    setNotifications(prev => {
      // Keep only the most recent notifications based on maxVisible setting
      const updated = [newNotification, ...prev];
      return updated.slice(0, Math.max(config.maxVisible, 10)); // Keep max 10 in history
    });

    // Play sound if enabled
    if (config.soundEnabled) {
      playNotificationSound(notification.type);
    }

    // Vibrate if enabled and supported
    if (config.vibrationEnabled && 'vibrate' in navigator) {
      navigator.vibrate(getVibrationPattern(notification.type));
    }
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  const updateConfig = (newConfig: Partial<NotificationConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  };

  const markAsRead = (id: string) => {
    setReadNotifications(prev => new Set([...prev, id]));
  };

  const getUnreadCount = () => {
    return notifications.filter(n => !readNotifications.has(n.id)).length;
  };

  // Helper functions
  const playNotificationSound = (type: Notification['type']) => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      // Different frequencies for different notification types
      const frequencies = {
        gaming: [440, 554, 659], // Gaming chord
        success: [523, 659, 784], // Success chord  
        warning: [349, 440], // Warning tone
        info: [523, 659] // Info tone
      };

      const freq = frequencies[type];
      oscillator.frequency.setValueAtTime(freq[0], audioContext.currentTime);
      
      if (freq.length > 1) {
        oscillator.frequency.linearRampToValueAtTime(freq[1], audioContext.currentTime + 0.1);
      }

      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);

      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.3);
    } catch (error) {
      console.log('Sound not available:', error);
    }
  };

  const getVibrationPattern = (type: Notification['type']): number[] => {
    const patterns = {
      gaming: [100, 50, 100, 50, 200],
      success: [200, 100, 200],
      warning: [300, 100, 300, 100, 300],
      info: [100, 50, 100]
    };
    return patterns[type];
  };

  return (
    <NotificationContext.Provider value={{
      notifications,
      config,
      addNotification,
      removeNotification,
      clearAllNotifications,
      updateConfig,
      markAsRead,
      getUnreadCount
    }}>
      {children}
      
      {/* Render notification container */}
      {config.enabled && notifications.length > 0 && (
        <NotificationContainer
          notifications={notifications.slice(0, config.maxVisible)}
          onRemove={removeNotification}
        />
      )}
    </NotificationContext.Provider>
  );
}

export const useNotificationService = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotificationService must be used within a NotificationProvider');
  }
  return context;
};

// Helper hooks for specific notification types
export const useSocialNotifications = () => {
  const { addNotification } = useNotificationService();
  
  return {
    notifyNewFollow: (username: string) => {
      addNotification({
        message: `${username} شما را دنبال کرد`,
        type: 'success',
        category: 'social',
        autoHide: true,
        duration: 4000
      });
    },
    
    notifyNewPost: (username: string, postType: string = 'پست') => {
      addNotification({
        message: `${username} ${postType} جدیدی منتشر کرد`,
        type: 'info',
        category: 'social',
        autoHide: true,
        duration: 5000
      });
    },
    
    notifyNewMessage: (username: string, messagePreview?: string) => {
      addNotification({
        message: `پیام جدید از ${username}${messagePreview ? ': ' + messagePreview.substring(0, 30) + '...' : ''}`,
        type: 'gaming',
        category: 'social',
        autoHide: true,
        duration: 6000
      });
    },
    
    notifyLike: (username: string) => {
      addNotification({
        message: `${username} پست شما را پسندید`,
        type: 'success',
        category: 'social',
        autoHide: true,
        duration: 3000
      });
    }
  };
};

export const useGamingNotifications = () => {
  const { addNotification } = useNotificationService();
  
  return {
    notifyMatchFound: (gameMode: string) => {
      addNotification({
        message: `بازی ${gameMode} پیدا شد! آماده باشید 🎮`,
        type: 'gaming',
        category: 'gaming',
        autoHide: false, // Important gaming notifications shouldn't auto-hide
        duration: 10000
      });
    },
    
    notifyTournamentStart: (tournamentName: string) => {
      addNotification({
        message: `مسابقه ${tournamentName} شروع شد!`,
        type: 'gaming',
        category: 'gaming',
        autoHide: false,
        duration: 15000
      });
    },
    
    notifyInvitation: (username: string, gameType: string) => {
      addNotification({
        message: `${username} شما را به بازی ${gameType} دعوت کرد`,
        type: 'gaming',
        category: 'gaming',
        autoHide: false,
        duration: 10000
      });
    },
    
    notifyAchievement: (achievement: string) => {
      addNotification({
        message: `دستاورد جدید: ${achievement} 🏆`,
        type: 'success',
        category: 'gaming',
        autoHide: true,
        duration: 7000
      });
    }
  };
};

export const useSystemNotifications = () => {
  const { addNotification } = useNotificationService();
  
  return {
    notifyUpdate: (version: string) => {
      addNotification({
        message: `نسخه ${version} منتشر شد! ویژگی‌های جدید در دسترس است`,
        type: 'info',
        category: 'system',
        autoHide: true,
        duration: 8000
      });
    },
    
    notifyMaintenance: (startTime: string) => {
      addNotification({
        message: `تعمیرات برنامه‌ریزی شده از ساعت ${startTime}`,
        type: 'warning',
        category: 'system',
        autoHide: false,
        duration: 12000
      });
    },
    
    notifyError: (error: string) => {
      addNotification({
        message: `خطا: ${error}`,
        type: 'warning',
        category: 'system',
        autoHide: true,
        duration: 6000
      });
    }
  };
};