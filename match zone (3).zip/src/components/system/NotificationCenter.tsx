import React, { useState } from 'react';
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { ScrollArea } from '../ui/scroll-area';
import { Separator } from '../ui/separator';
import { Bell, Check, CheckCheck, X, Trophy, Users, MessageCircle, Gift, Star, Trash2 } from 'lucide-react';
import { useMobile } from '../ui/use-mobile';

export function NotificationCenter() {
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'tournament',
      title: 'تورنومنت شروع شد',
      message: 'کاپ طلایی کالاف دیوتی اکنون شروع شده است',
      time: '۵ دقیقه پیش',
      read: false,
      icon: Trophy,
      iconColor: 'text-yellow-500',
      avatar: null,
      action: 'مشاهده تورنومنت'
    },
    {
      id: 2,
      type: 'friend',
      title: 'دوست جدید',
      message: 'علی_گیمر درخواست دوستی شما را پذیرفت',
      time: '۱۰ دقیقه پیش',
      read: false,
      icon: Users,
      iconColor: 'text-blue-500',
      avatar: '/avatars/ali.jpg',
      action: 'مشاهده پروفایل'
    },
    {
      id: 3,
      type: 'message',
      title: 'پیام جدید',
      message: 'سارا_پرو: سلام! آماده‌ای برای بازی؟',
      time: '۱۵ دقیقه پیش',
      read: true,
      icon: MessageCircle,
      iconColor: 'text-green-500',
      avatar: '/avatars/sara.jpg',
      action: 'پاسخ'
    },
    {
      id: 4,
      type: 'gift',
      title: 'انعام دریافتی',
      message: 'محمد_استریمر ۱۰,۰۰۰ تومان انعام برای شما ارسال کرد',
      time: '۳۰ دقیقه پیش',
      read: true,
      icon: Gift,
      iconColor: 'text-pink-500',
      avatar: '/avatars/mohammad.jpg',
      action: 'تشکر'
    },
    {
      id: 5,
      type: 'achievement',
      title: 'دستاورد جدید',
      message: 'شما دستاورد "قهرمان ماه" را کسب کردید!',
      time: '۱ ساعت پیش',
      read: true,
      icon: Star,
      iconColor: 'text-purple-500',
      avatar: null,
      action: 'مشاهده دستاوردها'
    },
    {
      id: 6,
      type: 'lobby',
      title: 'لابی پر شد',
      message: 'لابی "مسابقه تیمی 5v5" پر شد و آماده شروع است',
      time: '۲ ساعت پیش',
      read: true,
      icon: Users,
      iconColor: 'text-orange-500',
      avatar: null,
      action: 'پیوستن'
    }
  ]);

  const isMobile = useMobile();

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (id: number) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  const deleteNotification = (id: number) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const getNotificationBg = (type: string, read: boolean) => {
    if (!read) {
      switch (type) {
        case 'tournament': return 'bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800';
        case 'friend': return 'bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800';
        case 'message': return 'bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800';
        case 'gift': return 'bg-pink-50 dark:bg-pink-950 border-pink-200 dark:border-pink-800';
        case 'achievement': return 'bg-purple-50 dark:bg-purple-950 border-purple-200 dark:border-purple-800';
        default: return 'bg-muted border-muted';
      }
    }
    return 'bg-background border-border';
  };

  return (
    <div className="w-full">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {unreadCount > 0 && (
              <>
                <Button variant="ghost" size="sm" onClick={clearAll}>
                  <Trash2 className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                  <CheckCheck className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>
          <div className="flex items-center space-x-2" dir="rtl">
            {unreadCount > 0 && (
              <Badge variant="destructive" className="h-5 w-5 p-0 text-xs rounded-full">
                {unreadCount}
              </Badge>
            )}
            <h3 className="flex items-center font-medium">
              <Bell className="h-5 w-5 ml-2" />
              اعلان‌ها
            </h3>
          </div>
        </div>
        <p className="text-sm text-muted-foreground text-right" dir="rtl">
          {unreadCount > 0 ? `${unreadCount} اعلان خوانده نشده` : 'همه اعلان‌ها خوانده شده'}
        </p>
      </div>

      <div className="">
        <ScrollArea className="h-96">
          {notifications.length === 0 ? (
            <div className="p-8 text-center space-y-4">
              <Bell className="h-12 w-12 text-muted-foreground mx-auto" />
              <div>
                <h3 className="text-lg font-medium">اعلانی وجود ندارد</h3>
                <p className="text-muted-foreground">شما هیچ اعلان جدیدی ندارید</p>
              </div>
            </div>
          ) : (
            <div className="space-y-1">
              {notifications.map((notification, index) => {
                const Icon = notification.icon;
                return (
                  <div key={notification.id}>
                    <div 
                      className={`p-4 transition-colors hover:bg-muted/50 cursor-pointer ${
                        getNotificationBg(notification.type, notification.read)
                      }`}
                      onClick={() => !notification.read && markAsRead(notification.id)}
                    >
                      <div className="flex items-start space-x-3">
                        {/* Actions */}
                        <div className="flex flex-col space-y-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteNotification(notification.id);
                            }}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                          {!notification.read && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={(e) => {
                                e.stopPropagation();
                                markAsRead(notification.id);
                              }}
                            >
                              <Check className="h-3 w-3" />
                            </Button>
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 space-y-2" dir="rtl">
                          <div className="flex items-start justify-end space-x-3">
                            <div className="text-right space-y-1">
                              <div className="flex items-center justify-end space-x-2">
                                {!notification.read && (
                                  <div className="h-2 w-2 bg-primary rounded-full"></div>
                                )}
                                <h4 className="font-medium text-sm">{notification.title}</h4>
                              </div>
                              <p className="text-sm text-muted-foreground">
                                {notification.message}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {notification.time}
                              </p>
                            </div>

                            {/* Icon/Avatar */}
                            <div className="relative flex-shrink-0">
                              {notification.avatar ? (
                                <Avatar className="h-10 w-10">
                                  <AvatarFallback>{notification.title[0]}</AvatarFallback>
                                </Avatar>
                              ) : (
                                <div className={`h-10 w-10 rounded-full bg-muted flex items-center justify-center`}>
                                  <Icon className={`h-5 w-5 ${notification.iconColor}`} />
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Action Button */}
                          {notification.action && (
                            <div className="flex justify-end">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  console.log('Action:', notification.action);
                                }}
                              >
                                {notification.action}
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    {index < notifications.length - 1 && <Separator />}
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </div>
    </div>
  );
}