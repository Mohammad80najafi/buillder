import React from 'react';
import { cn } from '../ui/utils';
import { Skeleton } from '../ui/skeleton';
import { Card, CardContent, CardHeader } from '../ui/card';

interface LoadingSkeletonProps {
  type: 'card' | 'list' | 'profile' | 'chat' | 'video' | 'lobby' | 'tournament';
  count?: number;
  className?: string;
}

const CardSkeleton = ({ className }: { className?: string }) => (
  <Card className={className}>
    <CardHeader>
      <div className="flex items-center space-x-4">
        <Skeleton className="h-12 w-12 rounded-full" />
        <div className="space-y-2">
          <Skeleton className="h-4 w-[250px]" />
          <Skeleton className="h-4 w-[200px]" />
        </div>
      </div>
    </CardHeader>
    <CardContent>
      <div className="space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-8 w-24 mt-4" />
      </div>
    </CardContent>
  </Card>
);

const ListSkeleton = ({ className }: { className?: string }) => (
  <div className={cn('space-y-3', className)}>
    {Array.from({ length: 5 }, (_, i) => (
      <div key={i} className="flex items-center space-x-4 p-3 border rounded-lg">
        <Skeleton className="h-8 w-8 rounded-full" />
        <div className="space-y-2">
          <Skeleton className="h-4 w-[200px]" />
          <Skeleton className="h-3 w-[150px]" />
        </div>
      </div>
    ))}
  </div>
);

const ProfileSkeleton = ({ className }: { className?: string }) => (
  <Card className={className}>
    <CardContent className="p-6">
      <div className="flex flex-col items-center text-center space-y-4">
        <Skeleton className="h-24 w-24 rounded-full" />
        <div className="space-y-2">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-4 w-24" />
        </div>
        <div className="flex space-x-2">
          <Skeleton className="h-6 w-16" />
          <Skeleton className="h-6 w-16" />
        </div>
        <div className="w-full space-y-2">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      </div>
    </CardContent>
  </Card>
);

const ChatSkeleton = ({ className }: { className?: string }) => (
  <div className={cn('space-y-4 p-4', className)}>
    {Array.from({ length: 6 }, (_, i) => (
      <div key={i} className={cn('flex gap-3', i % 2 === 0 ? 'justify-start' : 'justify-end')}>
        {i % 2 === 0 && <Skeleton className="h-8 w-8 rounded-full" />}
        <div className={cn('space-y-1', i % 2 === 0 ? 'items-start' : 'items-end')}>
          <Skeleton className={cn('h-8', i % 3 === 0 ? 'w-32' : i % 3 === 1 ? 'w-48' : 'w-24')} />
          <Skeleton className="h-3 w-16" />
        </div>
        {i % 2 === 1 && <Skeleton className="h-8 w-8 rounded-full" />}
      </div>
    ))}
  </div>
);

const VideoSkeleton = ({ className }: { className?: string }) => (
  <Card className={className}>
    <CardContent className="p-0">
      <Skeleton className="aspect-video w-full rounded-t-lg" />
      <div className="p-3">
        <div className="flex gap-3">
          <Skeleton className="h-10 w-10 rounded-full flex-shrink-0" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-3 w-2/3" />
            <div className="flex gap-4">
              <Skeleton className="h-3 w-16" />
              <Skeleton className="h-3 w-12" />
            </div>
          </div>
        </div>
      </div>
    </CardContent>
  </Card>
);

const LobbySkeleton = ({ className }: { className?: string }) => (
  <Card className={className}>
    <CardHeader>
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <Skeleton className="h-5 w-48" />
          <Skeleton className="h-4 w-32" />
        </div>
        <Skeleton className="h-6 w-16" />
      </div>
    </CardHeader>
    <CardContent className="space-y-4">
      <div className="flex items-center gap-2">
        <Skeleton className="h-6 w-6 rounded-full" />
        <Skeleton className="h-4 w-32" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Skeleton className="h-4 w-20" />
        <Skeleton className="h-4 w-16" />
        <Skeleton className="h-4 w-24" />
        <Skeleton className="h-4 w-18" />
      </div>
      <Skeleton className="h-10 w-full" />
    </CardContent>
  </Card>
);

const TournamentSkeleton = ({ className }: { className?: string }) => (
  <Card className={className}>
    <CardHeader>
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <Skeleton className="h-5 w-56" />
          <Skeleton className="h-4 w-40" />
        </div>
        <Skeleton className="h-6 w-20" />
      </div>
    </CardHeader>
    <CardContent className="space-y-4">
      <div className="flex items-center gap-2">
        <Skeleton className="h-6 w-6 rounded-full" />
        <Skeleton className="h-4 w-36" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-4 w-32" />
        </div>
        <div className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-4 w-20" />
        </div>
      </div>
      <div className="p-3 bg-muted/50 rounded-lg">
        <Skeleton className="h-4 w-40 mb-1" />
        <div className="flex gap-4">
          <Skeleton className="h-6 w-12" />
          <Skeleton className="h-6 w-12" />
          <Skeleton className="h-6 w-12" />
          <Skeleton className="h-6 w-12" />
        </div>
      </div>
      <Skeleton className="h-10 w-full" />
    </CardContent>
  </Card>
);

const skeletonComponents = {
  card: CardSkeleton,
  list: ListSkeleton,
  profile: ProfileSkeleton,
  chat: ChatSkeleton,
  video: VideoSkeleton,
  lobby: LobbySkeleton,
  tournament: TournamentSkeleton,
};

export const LoadingSkeleton: React.FC<LoadingSkeletonProps> = ({
  type,
  count = 1,
  className,
}) => {
  const SkeletonComponent = skeletonComponents[type];

  if (count === 1) {
    return <SkeletonComponent className={className} />;
  }

  return (
    <div className={cn('space-y-4', className)}>
      {Array.from({ length: count }, (_, i) => (
        <SkeletonComponent key={i} />
      ))}
    </div>
  );
};