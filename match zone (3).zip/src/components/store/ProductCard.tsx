import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardFooter } from '../ui/card';
import { GameButton } from '../ui/game-button';
import { Badge } from '../ui/badge';
import { Coins, Star, Gift } from 'lucide-react';

export interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  type: 'coin-pack' | 'skin' | 'emote-pack' | 'avatar' | 'badge' | 'premium';
  price: {
    coins?: number;
    irr?: number;
  };
  originalPrice?: {
    coins?: number;
    irr?: number;
  };
  discount?: number;
  rarity?: 'common' | 'rare' | 'epic' | 'legendary';
  isPopular?: boolean;
  isLimited?: boolean;
  stock?: number;
  game?: string;
}

interface ProductCardProps {
  product: Product;
  onPurchase?: () => void;
  isPurchasing?: boolean;
  className?: string;
}

const typeLabels = {
  'coin-pack': 'بسته سکه',
  'skin': 'اسکین',
  'emote-pack': 'بسته ایموت',
  'avatar': 'آواتار',
  'badge': 'نشان',
  'premium': 'پریمیوم',
};

const rarityColors = {
  common: 'bg-gray-100 text-gray-800 dark:bg-gray-900/20',
  rare: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20',
  epic: 'bg-purple-100 text-purple-800 dark:bg-purple-900/20',
  legendary: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20',
};

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onPurchase,
  isPurchasing = false,
  className,
}) => {
  const hasDiscount = product.discount && product.discount > 0;
  const isOutOfStock = product.stock !== undefined && product.stock <= 0;

  return (
    <Card className={cn('relative group transition-all duration-200 hover:shadow-lg', className)}>
      {product.isPopular && (
        <div className="absolute -top-2 -right-2 z-10">
          <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
            <Star className="w-3 h-3 mr-1" />
            محبوب
          </Badge>
        </div>
      )}

      {hasDiscount && (
        <div className="absolute -top-2 -left-2 z-10">
          <Badge className="bg-red-500 text-white">
            {product.discount}% تخفیف
          </Badge>
        </div>
      )}

      <CardContent className="p-0">
        <div className="relative aspect-square overflow-hidden rounded-t-lg">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
          />
          
          {product.isLimited && (
            <div className="absolute top-2 left-2">
              <Badge variant="destructive" className="text-xs">
                محدود
              </Badge>
            </div>
          )}

          {product.rarity && (
            <div className="absolute bottom-2 right-2">
              <Badge className={cn('text-xs', rarityColors[product.rarity])}>
                {product.rarity === 'common' && 'عادی'}
                {product.rarity === 'rare' && 'نادر'}
                {product.rarity === 'epic' && 'حماسی'}
                {product.rarity === 'legendary' && 'افسانه‌ای'}
              </Badge>
            </div>
          )}
        </div>

        <div className="p-4">
          <div className="flex items-center justify-between mb-2">
            <Badge variant="secondary" className="text-xs">
              {typeLabels[product.type]}
            </Badge>
            {product.game && (
              <Badge variant="outline" className="text-xs">
                {product.game}
              </Badge>
            )}
          </div>

          <h3 className="font-medium text-foreground mb-2 line-clamp-2">
            {product.name}
          </h3>
          
          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
            {product.description}
          </p>

          <div className="space-y-2">
            {product.price.coins && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Coins className="w-4 h-4 text-yellow-600" />
                  <span className="font-medium">
                    {product.price.coins.toLocaleString('fa-IR')}
                  </span>
                  {hasDiscount && product.originalPrice?.coins && (
                    <span className="text-sm text-muted-foreground line-through">
                      {product.originalPrice.coins.toLocaleString('fa-IR')}
                    </span>
                  )}
                </div>
              </div>
            )}

            {product.price.irr && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <span className="text-sm">تومان</span>
                  <span className="font-medium">
                    {product.price.irr.toLocaleString('fa-IR')}
                  </span>
                  {hasDiscount && product.originalPrice?.irr && (
                    <span className="text-sm text-muted-foreground line-through">
                      {product.originalPrice.irr.toLocaleString('fa-IR')}
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {product.stock !== undefined && product.stock <= 10 && product.stock > 0 && (
            <div className="mt-2 text-xs text-orange-600">
              تنها {product.stock} عدد باقی مانده
            </div>
          )}
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <GameButton
          onClick={onPurchase}
          disabled={isOutOfStock || isPurchasing}
          isLoading={isPurchasing}
          className="w-full"
          variant={isOutOfStock ? 'secondary' : 'primary'}
        >
          {isOutOfStock ? 'ناموجود' : 'خرید'}
        </GameButton>
      </CardFooter>
    </Card>
  );
};