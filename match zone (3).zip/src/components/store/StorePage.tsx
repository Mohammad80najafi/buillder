import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Coins, Package, Zap, Crown, Gift, Star, ShoppingCart, Check } from 'lucide-react';
import { WalletWidget } from './WalletWidget';
import { useMobile } from '../ui/use-mobile';

export function StorePage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [isPurchasing, setPurchasing] = useState(false);
  const isMobile = useMobile();

  const products = [
    {
      id: 1,
      name: 'پک کوین ۱۰۰',
      description: 'پک ۱۰۰ کوین برای خریدهای درون‌برنامه‌ای',
      price: { irr: 50000, coins: null },
      category: 'coins',
      image: '/store/coin-pack-100.jpg',
      bonus: '۱۰ کوین اضافی',
      popular: false,
      badge: null
    },
    {
      id: 2,
      name: 'پک کوین ۵۰۰',
      description: 'پک ۵۰۰ کوین با ۱۰% تخفیف',
      price: { irr: 225000, coins: null },
      category: 'coins',
      image: '/store/coin-pack-500.jpg',
      bonus: '۷۵ کوین اضافی',
      popular: true,
      badge: 'محبوب'
    },
    {
      id: 3,
      name: 'پک کوین ۱۰۰۰',
      description: 'پک ۱۰۰۰ کوین با ۲۰% تخفیف',
      price: { irr: 400000, coins: null },
      category: 'coins',
      image: '/store/coin-pack-1000.jpg',
      bonus: '۳۰۰ کوین اضافی',
      popular: false,
      badge: 'بهترین ارزش'
    },
    {
      id: 4,
      name: 'پاس گیمر ماهانه',
      description: 'دسترسی به امکانات ویژه و جوایز اضافی',
      price: { irr: 150000, coins: null },
      category: 'passes',
      image: '/store/gamer-pass.jpg',
      bonus: 'تخفیف ۲۰% در فروشگاه',
      popular: false,
      badge: 'جدید'
    },
    {
      id: 5,
      name: 'پاس VIP',
      description: 'دسترسی به تورنومنت‌های VIP و چت اولویت‌دار',
      price: { irr: 300000, coins: null },
      category: 'passes',
      image: '/store/vip-pass.jpg',
      bonus: 'نشان ویژه پروفایل',
      popular: false,
      badge: 'VIP'
    },
    {
      id: 6,
      name: 'پک ایموجی کلاسیک',
      description: '۲۰ ایموجی خاص برای چت و کامنت',
      price: { irr: null, coins: 150 },
      category: 'emotes',
      image: '/store/emote-classic.jpg',
      bonus: null,
      popular: false,
      badge: null
    },
    {
      id: 7,
      name: 'پک ایموجی گیمینگ',
      description: '۳۰ ایموجی تخصصی بازی‌های ویدئویی',
      price: { irr: null, coins: 250 },
      category: 'emotes',
      image: '/store/emote-gaming.jpg',
      bonus: '۵ ایموجی متحرک',
      popular: true,
      badge: null
    },
    {
      id: 8,
      name: 'آواتار فریم طلایی',
      description: 'قاب طلایی برای آواتار پروفایل',
      price: { irr: null, coins: 300 },
      category: 'cosmetics',
      image: '/store/golden-frame.jpg',
      bonus: null,
      popular: false,
      badge: 'محدود'
    }
  ];

  const categories = [
    { id: 'all', name: 'همه', icon: Package },
    { id: 'coins', name: 'کوین‌ها', icon: Coins },
    { id: 'passes', name: 'پاس‌ها', icon: Crown },
    { id: 'emotes', name: 'ایموجی', icon: Gift },
    { id: 'cosmetics', name: 'آیتم‌ها', icon: Star }
  ];

  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const formatPrice = (price: { irr: number | null, coins: number | null }) => {
    if (price.irr) {
      return new Intl.NumberFormat('fa-IR').format(price.irr) + ' تومان';
    }
    if (price.coins) {
      return new Intl.NumberFormat('fa-IR').format(price.coins) + ' کوین';
    }
    return '';
  };

  const getBadgeVariant = (badge: string | null) => {
    switch (badge) {
      case 'محبوب': return 'default';
      case 'جدید': return 'secondary';
      case 'بهترین ارزش': return 'destructive';
      case 'VIP': return 'destructive';
      case 'محدود': return 'secondary';
      default: return 'default';
    }
  };

  const handlePurchase = (product: any) => {
    setPurchasing(true);
    console.log('Purchasing:', product);
    
    // Simulate purchase process
    setTimeout(() => {
      setPurchasing(false);
      setSelectedProduct(null);
      // Show success message
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="text-right" dir="rtl">
          <h1 className="text-2xl font-bold">فروشگاه</h1>
          <p className="text-muted-foreground">خرید کوین، پاس و آیتم‌های ویژه</p>
        </div>
      </div>

      <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-4'} gap-6`}>
        {/* Sidebar */}
        <div className={`${isMobile ? 'col-span-1' : 'col-span-1'} space-y-6`}>
          {/* Wallet Widget */}
          <WalletWidget />

          {/* Categories */}
          <Card>
            <CardHeader>
              <CardTitle className="text-right" dir="rtl">دسته‌بندی‌ها</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {categories.map((category) => {
                const Icon = category.icon;
                return (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? 'default' : 'ghost'}
                    className="w-full justify-start text-right"
                    onClick={() => setSelectedCategory(category.id)}
                    dir="rtl"
                  >
                    <Icon className="h-4 w-4 ml-2" />
                    {category.name}
                  </Button>
                );
              })}
            </CardContent>
          </Card>
        </div>

        {/* Products Grid */}
        <div className={`${isMobile ? 'col-span-1' : 'col-span-3'}`}>
          <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-2 xl:grid-cols-3'} gap-4`}>
            {filteredProducts.map((product) => (
              <Card key={product.id} className="relative overflow-hidden group hover:shadow-lg transition-shadow">
                {/* Product Badges */}
                <div className="absolute top-2 right-2 z-10 space-y-1">
                  {product.popular && (
                    <Badge className="bg-orange-500 text-white">
                      <Star className="h-3 w-3 ml-1" />
                      محبوب
                    </Badge>
                  )}
                  {product.badge && (
                    <Badge variant={getBadgeVariant(product.badge) as any}>
                      {product.badge}
                    </Badge>
                  )}
                </div>

                {/* Product Image */}
                <div className="aspect-square bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                  {product.category === 'coins' && <Coins className="h-12 w-12 text-yellow-500" />}
                  {product.category === 'passes' && <Crown className="h-12 w-12 text-purple-500" />}
                  {product.category === 'emotes' && <Gift className="h-12 w-12 text-pink-500" />}
                  {product.category === 'cosmetics' && <Star className="h-12 w-12 text-blue-500" />}
                </div>

                <CardContent className="p-4">
                  <div className="space-y-3">
                    {/* Product Info */}
                    <div className="text-right space-y-1" dir="rtl">
                      <h3 className="font-semibold">{product.name}</h3>
                      <p className="text-sm text-muted-foreground">{product.description}</p>
                      {product.bonus && (
                        <p className="text-xs text-green-600">🎁 {product.bonus}</p>
                      )}
                    </div>

                    {/* Price & Purchase */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              size="sm" 
                              className="flex-1"
                              onClick={() => setSelectedProduct(product)}
                            >
                              <ShoppingCart className="h-3 w-3 ml-1" />
                              خرید
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle className="text-right" dir="rtl">تایید خرید</DialogTitle>
                              <DialogDescription className="text-right" dir="rtl">
                                آیا از خرید این محصول اطمینان دارید؟
                              </DialogDescription>
                            </DialogHeader>
                            
                            {selectedProduct && (
                              <div className="space-y-4">
                                <div className="p-4 bg-muted rounded-lg space-y-2">
                                  <h4 className="font-medium text-right" dir="rtl">{selectedProduct.name}</h4>
                                  <p className="text-sm text-muted-foreground text-right" dir="rtl">
                                    {selectedProduct.description}
                                  </p>
                                  <div className="flex justify-between items-center">
                                    <span className="font-bold text-lg">{formatPrice(selectedProduct.price)}</span>
                                    <span className="text-right text-sm" dir="rtl">قیمت:</span>
                                  </div>
                                </div>

                                <div className="flex space-x-2">
                                  <Button 
                                    variant="outline" 
                                    className="flex-1"
                                    onClick={() => setSelectedProduct(null)}
                                  >
                                    لغو
                                  </Button>
                                  <Button 
                                    className="flex-1"
                                    onClick={() => handlePurchase(selectedProduct)}
                                    disabled={isPurchasing}
                                  >
                                    {isPurchasing ? (
                                      <>
                                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                        در حال پردازش...
                                      </>
                                    ) : (
                                      <>
                                        <Check className="h-4 w-4 ml-2" />
                                        تایید خرید
                                      </>
                                    )}
                                  </Button>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                        <div className="text-right font-bold text-lg">
                          {formatPrice(product.price)}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <Card className="p-12 text-center">
              <div className="space-y-4">
                <Package className="h-12 w-12 text-muted-foreground mx-auto" />
                <div>
                  <h3 className="text-lg font-medium">محصولی یافت نشد</h3>
                  <p className="text-muted-foreground">در این دسته‌بندی محصولی موجود نیست</p>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}