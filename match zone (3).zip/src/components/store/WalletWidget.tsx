import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { GameButton } from '../ui/game-button';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Wallet, Plus, Minus, CreditCard, Banknote, ArrowUpRight, ArrowDownLeft, History } from 'lucide-react';

export function WalletWidget() {
  const [balance, setBalance] = useState(125000);
  const [coinBalance, setCoinBalance] = useState(1250);
  const [isDepositOpen, setIsDepositOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');

  const transactions = [
    { id: 1, type: 'deposit', amount: 50000, description: 'شارژ کیف پول', date: '۱۴۰۳/۰۸/۱۵' },
    { id: 2, type: 'purchase', amount: -15000, description: 'خرید کوین پک', date: '۱۴۰۳/۰۸/۱۴' },
    { id: 3, type: 'tournament', amount: 25000, description: 'جایزه تورنومنت', date: '۱۴۰۳/۰۸/۱۲' },
    { id: 4, type: 'tip', amount: -5000, description: 'انعام به استریمر', date: '۱۴۰۳/۰۸/۱۰' }
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fa-IR').format(amount) + ' تومان';
  };

  const formatCoins = (amount: number) => {
    return new Intl.NumberFormat('fa-IR').format(amount) + ' کوین';
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit': return <ArrowDownLeft className="h-4 w-4 text-green-600" />;
      case 'purchase': return <ArrowUpRight className="h-4 w-4 text-red-600" />;
      case 'tournament': return <ArrowDownLeft className="h-4 w-4 text-green-600" />;
      case 'tip': return <ArrowUpRight className="h-4 w-4 text-blue-600" />;
      default: return <History className="h-4 w-4" />;
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'deposit':
      case 'tournament': return 'text-green-600';
      case 'purchase':
      case 'tip': return 'text-red-600';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-right flex items-center" dir="rtl">
          <Wallet className="h-5 w-5 ml-2" />
          کیف پول
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Balance Display */}
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-950 rounded-lg">
            <div className="flex items-center space-x-2">
              <Banknote className="h-4 w-4 text-green-600" />
              <span className="text-sm text-green-600">IRR</span>
            </div>
            <div className="text-right" dir="rtl">
              <p className="text-lg font-bold text-green-600">{formatCurrency(balance)}</p>
              <p className="text-xs text-muted-foreground">موجودی ریالی</p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <div className="flex items-center space-x-2">
              <div className="h-4 w-4 bg-blue-600 rounded-full"></div>
              <span className="text-sm text-blue-600">COIN</span>
            </div>
            <div className="text-right" dir="rtl">
              <p className="text-lg font-bold text-blue-600">{formatCoins(coinBalance)}</p>
              <p className="text-xs text-muted-foreground">موجودی کوین</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <Dialog open={isDepositOpen} onOpenChange={setIsDepositOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Plus className="h-4 w-4 ml-2" />
                شارژ
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="text-right" dir="rtl">شارژ کیف پول</DialogTitle>
                <DialogDescription className="text-right" dir="rtl">
                  مبلغ مورد نظر خود را وارد کنید
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="amount" className="text-right" dir="rtl">مبلغ (تومان)</Label>
                  <Input
                    id="amount"
                    placeholder="مثال: ۵۰۰۰۰"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    className="text-right"
                    dir="rtl"
                  />
                </div>

                {/* Quick amounts */}
                <div className="grid grid-cols-3 gap-2">
                  {[50000, 100000, 200000].map((amount) => (
                    <Button
                      key={amount}
                      variant="outline"
                      size="sm"
                      onClick={() => setDepositAmount(amount.toString())}
                    >
                      {formatCurrency(amount)}
                    </Button>
                  ))}
                </div>

                <div className="space-y-2">
                  <Label className="text-right" dir="rtl">روش پرداخت</Label>
                  <Select defaultValue="card">
                    <SelectTrigger className="text-right" dir="rtl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="card">کارت بانکی</SelectItem>
                      <SelectItem value="internet">اینترنت بانک</SelectItem>
                      <SelectItem value="wallet">کیف پول دیجیتال</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  className="w-full" 
                  onClick={() => {
                    console.log('Deposit:', depositAmount);
                    setIsDepositOpen(false);
                    setDepositAmount('');
                  }}
                  disabled={!depositAmount}
                >
                  <CreditCard className="h-4 w-4 ml-2" />
                  پرداخت و شارژ
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isWithdrawOpen} onOpenChange={setIsWithdrawOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Minus className="h-4 w-4 ml-2" />
                برداشت
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="text-right" dir="rtl">برداشت از کیف پول</DialogTitle>
                <DialogDescription className="text-right" dir="rtl">
                  مبلغ قابل برداشت: {formatCurrency(balance)}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="withdraw-amount" className="text-right" dir="rtl">مبلغ برداشت (تومان)</Label>
                  <Input
                    id="withdraw-amount"
                    placeholder="مثال: ۲۵۰۰۰"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="text-right"
                    dir="rtl"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-right" dir="rtl">شماره کارت مقصد</Label>
                  <Input
                    placeholder="۱۲۳۴-۵۶۷۸-۹۰۱۲-۳۴۵۶"
                    className="text-center"
                    dir="ltr"
                  />
                </div>

                <div className="p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                  <p className="text-xs text-yellow-700 dark:text-yellow-300 text-right" dir="rtl">
                    توجه: برداشت تا ۲۴ ساعت کاری طول می‌کشد
                  </p>
                </div>

                <Button 
                  className="w-full" 
                  onClick={() => {
                    console.log('Withdraw:', withdrawAmount);
                    setIsWithdrawOpen(false);
                    setWithdrawAmount('');
                  }}
                  disabled={!withdrawAmount}
                >
                  درخواست برداشت
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Recent Transactions */}
        <div className="space-y-3">
          <h4 className="font-medium text-right" dir="rtl">تراکنش‌های اخیر</h4>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {transactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-2 bg-muted rounded text-sm">
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-muted-foreground">{transaction.date}</span>
                  {getTransactionIcon(transaction.type)}
                </div>
                <div className="flex-1 text-right" dir="rtl">
                  <p className="font-medium">{transaction.description}</p>
                  <p className={`text-xs ${getTransactionColor(transaction.type)}`}>
                    {transaction.amount > 0 ? '+' : ''}{formatCurrency(Math.abs(transaction.amount))}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}