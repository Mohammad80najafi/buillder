import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  ArrowRight, Users, Trophy, Target, Crown, Shield, Sword, 
  MapPin, Calendar, ChevronRight, Lock, Unlock, TrendingUp, 
  Award, Flag, Zap, Star, Activity, MessageCircle, Settings,
  UserPlus, UserMinus, Share2, Copy, ExternalLink, Bell,
  History, BarChart3, Medal, Gift, Flame, Globe, Clock,
  ChevronDown, ChevronUp, Eye, Heart, ThumbsUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import { useResponsive } from '../../hooks/useResponsive';
import { Clan } from '../providers/ClanProvider';

interface ClanMember {
  id: string;
  name: string;
  avatar: string;
  level: number;
  role: 'leader' | 'co-leader' | 'officer' | 'member';
  joinDate: string;
  lastActive: string;
  status: 'online' | 'away' | 'offline';
  stats: {
    trophies: number;
    wins: number;
    losses: number;
    weeklyActivity: number;
    donations: number;
  };
  achievements: string[];
  isOnline: boolean;
}

interface ClanActivity {
  id: string;
  type: 'member_joined' | 'member_promoted' | 'trophy_gained' | 'war_won' | 'level_up' | 'achievement';
  member: {
    name: string;
    avatar: string;
  };
  description: string;
  timestamp: string;
  icon: string;
  color: string;
}

interface ClanDetailPageProps {
  clan?: Clan;
  onJoin?: (clanId: string) => void;
  onLeave?: (clanId: string) => void;
  onRequestJoin?: (clanId: string) => void;
  onBack?: () => void;
}

export function ClanDetailPage({ clan, onJoin, onLeave, onRequestJoin, onBack }: ClanDetailPageProps) {
  const { isMobile, isTablet } = useResponsive();
  const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'activity' | 'wars'>('overview');
  const [showAllMembers, setShowAllMembers] = useState(false);
  const [memberFilter, setMemberFilter] = useState<'all' | 'online' | 'officers'>('all');

  // Mock data - در حالت واقعی از props یا API می‌آید
  const mockClan: Clan = clan || {
    id: 'clan-1',
    name: 'شیران طلایی',
    tag: 'GOLD',
    description: 'کلن حرفه‌ای بازیکنان ایرانی با تمرکز بر رشد مهارت‌ها و کار تیمی. ما در تمام بازی‌های محبوب فعال هستیم.',
    logo: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=100',
    banner: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800',
    level: 15,
    xp: 45000,
    maxXp: 50000,
    type: 'public',
    region: 'تهران',
    language: 'فارسی',
    founded: '۱۴۰۲/۰۵/۱۲',
    members: {
      current: 28,
      max: 30
    },
    requirements: {
      minLevel: 10,
      minTrophies: 1000,
      requiresApproval: false
    },
    stats: {
      rank: 15,
      totalTrophies: 125000,
      weeklyTrophies: 8500,
      wins: 342,
      losses: 89,
      winRate: 79,
      weeklyXp: 12500
    },
    leader: {
      id: 'leader-1',
      name: 'شیر_طلایی',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
      level: 67
    },
    activities: {
      activeMembers: 22,
      lastActive: '۲ ساعت پیش',
      weeklyMatches: 156,
      weeklyDonations: 890
    },
    achievements: [
      { id: 'ace', name: 'قهرمان کلن', icon: '🏆' },
      { id: 'streak', name: 'برد متوالی', icon: '🔥' },
      { id: 'social', name: 'کلن اجتماعی', icon: '👥' }
    ],
    isJoined: false,
    createdByUser: false
  };

  const mockMembers: ClanMember[] = [
    {
      id: 'member-1',
      name: 'شیر_طلایی',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
      level: 67,
      role: 'leader',
      joinDate: '۱۴۰۲/۰۵/۱۲',
      lastActive: 'آنلاین',
      status: 'online',
      stats: {
        trophies: 3200,
        wins: 89,
        losses: 12,
        weeklyActivity: 45,
        donations: 120
      },
      achievements: ['ace', 'streak', 'master'],
      isOnline: true
    },
    {
      id: 'member-2',
      name: 'عقاب_سریع',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64',
      level: 54,
      role: 'co-leader',
      joinDate: '۱۴۰۲/۰۶/۰۸',
      lastActive: '۱۰ دقیقه پیش',
      status: 'away',
      stats: {
        trophies: 2800,
        wins: 76,
        losses: 18,
        weeklyActivity: 38,
        donations: 95
      },
      achievements: ['streak', 'social'],
      isOnline: false
    },
    {
      id: 'member-3',
      name: 'پلنگ_آبی',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64',
      level: 48,
      role: 'officer',
      joinDate: '۱۴۰۲/۰۷/۲۳',
      lastActive: 'آنلاین',
      status: 'online',
      stats: {
        trophies: 2400,
        wins: 65,
        losses: 22,
        weeklyActivity: 42,
        donations: 110
      },
      achievements: ['social', 'veteran'],
      isOnline: true
    }
  ];

  const mockActivities: ClanActivity[] = [
    {
      id: 'activity-1',
      type: 'member_joined',
      member: {
        name: 'باز_جدید',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64'
      },
      description: 'به کلن پیوست',
      timestamp: '۱ ساعت پیش',
      icon: '👋',
      color: 'text-green-400'
    },
    {
      id: 'activity-2',
      type: 'trophy_gained',
      member: {
        name: 'شیر_طلایی',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64'
      },
      description: '۲۵۰ جام کسب کرد',
      timestamp: '۳ ساعت پیش',
      icon: '🏆',
      color: 'text-yellow-400'
    },
    {
      id: 'activity-3',
      type: 'level_up',
      member: {
        name: 'عقاب_سریع',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64'
      },
      description: 'به سطح ۵۴ رسید',
      timestamp: '۵ ساعت پیش',
      icon: '⬆️',
      color: 'text-blue-400'
    }
  ];

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'leader': return <Crown className="w-4 h-4 text-yellow-500" />;
      case 'co-leader': return <Shield className="w-4 h-4 text-orange-500" />;
      case 'officer': return <Sword className="w-4 h-4 text-blue-500" />;
      default: return <Users className="w-4 h-4 text-gray-500" />;
    }
  };

  const getRoleText = (role: string) => {
    switch (role) {
      case 'leader': return 'رهبر';
      case 'co-leader': return 'معاون';
      case 'officer': return 'افسر';
      default: return 'عضو';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const filteredMembers = mockMembers.filter(member => {
    if (memberFilter === 'online') return member.isOnline;
    if (memberFilter === 'officers') return ['leader', 'co-leader', 'officer'].includes(member.role);
    return true;
  });

  const displayedMembers = showAllMembers ? filteredMembers : filteredMembers.slice(0, isMobile ? 5 : 8);

  const handleCopyInviteCode = () => {
    navigator.clipboard.writeText(`کد دعوت: ${mockClan.tag}-${mockClan.id}`);
    toast.success('کد دعوت کپی شد!');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `کلن ${mockClan.name}`,
        text: `به کلن ${mockClan.name} بپیوندید!`,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('لینک کپی شد!');
    }
  };

  return (
    <div 
      className="min-h-screen bg-background"
      style={{ 
        paddingLeft: isMobile ? 'var(--spacing-sm)' : 'var(--spacing-lg)',
        paddingRight: isMobile ? 'var(--spacing-sm)' : 'var(--spacing-lg)',
        paddingTop: isMobile ? 'var(--spacing-md)' : 'var(--spacing-xl)',
        paddingBottom: isMobile ? 'var(--spacing-xl)' : 'var(--spacing-2xl)'
      }}
      dir="rtl"
    >
      <div className="max-w-6xl mx-auto">
        {/* Header با Background Banner */}
        <div className="relative">
          {/* Banner Background */}
          {mockClan.banner && (
            <div 
              className="absolute inset-0 bg-cover bg-center rounded-lg opacity-20"
              style={{ 
                backgroundImage: `url(${mockClan.banner})`,
                height: isMobile ? '200px' : '250px'
              }}
            />
          )}
          
          <Card className="relative overflow-hidden">
            <div 
              className="absolute inset-0 bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10"
            />
            
            <CardContent 
              style={{ 
                padding: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-2xl)'
              }}
            >
              {/* Back Button */}
              {onBack && (
                <Button 
                  variant="outline" 
                  onClick={onBack}
                  className="mb-4"
                  style={{ height: isMobile ? '32px' : '36px' }}
                >
                  <ArrowRight className="w-4 h-4 ml-2" />
                  بازگشت
                </Button>
              )}

              <div 
                className={`flex ${isMobile ? 'flex-col' : 'items-start'}`}
                style={{ gap: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)' }}
              >
                {/* Clan Logo & Basic Info */}
                <div className={`flex ${isMobile ? 'flex-col items-center text-center' : 'items-start'}`}>
                  <div className="relative">
                    <Avatar 
                      className="ring-4 ring-primary/30"
                      style={{ 
                        width: isMobile ? '80px' : '100px',
                        height: isMobile ? '80px' : '100px'
                      }}
                    >
                      <AvatarImage src={mockClan.logo} />
                      <AvatarFallback 
                        className="bg-gradient-to-br from-blue-500 to-purple-500 text-white"
                        style={{ 
                          fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-2)',
                          fontWeight: 'var(--font-weight-semibold)'
                        }}
                      >
                        {mockClan.tag}
                      </AvatarFallback>
                    </Avatar>
                    
                    {/* Clan Level Badge */}
                    <div 
                      className="absolute -bottom-2 -right-2 bg-gradient-to-r from-yellow-500 to-orange-500 text-white rounded-full flex items-center justify-center"
                      style={{ 
                        width: isMobile ? '24px' : '32px',
                        height: isMobile ? '24px' : '32px',
                        fontSize: 'var(--font-size-caption)',
                        fontWeight: 'var(--font-weight-semibold)'
                      }}
                    >
                      {mockClan.level}
                    </div>
                  </div>

                  <div 
                    className={isMobile ? 'mt-4' : 'mr-6 flex-1'}
                    style={!isMobile ? { minWidth: '0' } : {}}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <h1 
                        style={{ 
                          fontSize: isMobile ? 'var(--font-size-heading-2)' : 'var(--font-size-heading-1)',
                          fontWeight: 'var(--font-weight-semibold)',
                          lineHeight: 'var(--line-height-tight)'
                        }}
                      >
                        [{mockClan.tag}] {mockClan.name}
                      </h1>
                      <Badge 
                        variant="outline" 
                        className="bg-green-500/20 text-green-400 border-green-500/30"
                      >
                        رنک #{mockClan.stats.rank}
                      </Badge>
                    </div>

                    <p 
                      className="text-muted-foreground mb-4"
                      style={{ 
                        fontSize: isMobile ? 'var(--font-size-body-2)' : 'var(--font-size-body-1)',
                        lineHeight: 'var(--line-height-base)'
                      }}
                    >
                      {mockClan.description}
                    </p>

                    {/* Quick Stats */}
                    <div 
                      className={`flex ${isMobile ? 'justify-center flex-wrap' : 'items-center'}`}
                      style={{ gap: isMobile ? 'var(--spacing-sm)' : 'var(--spacing-lg)' }}
                    >
                      <div key="members-stat" className="flex items-center gap-1">
                        <Users className="w-4 h-4 text-blue-400" />
                        <span 
                          style={{ 
                            fontSize: 'var(--font-size-body-2)',
                            fontWeight: 'var(--font-weight-medium)'
                          }}
                        >
                          {mockClan.members.current}/{mockClan.members.max}
                        </span>
                      </div>
                      
                      <div key="trophies-stat" className="flex items-center gap-1">
                        <Trophy className="w-4 h-4 text-yellow-400" />
                        <span 
                          style={{ 
                            fontSize: 'var(--font-size-body-2)',
                            fontWeight: 'var(--font-weight-medium)'
                          }}
                        >
                          {isMobile ? `${Math.floor(mockClan.stats.totalTrophies/1000)}K` : mockClan.stats.totalTrophies.toLocaleString()}
                        </span>
                      </div>
                      
                      <div key="winrate-stat" className="flex items-center gap-1">
                        <Target className="w-4 h-4 text-green-400" />
                        <span 
                          style={{ 
                            fontSize: 'var(--font-size-body-2)',
                            fontWeight: 'var(--font-weight-medium)'
                          }}
                        >
                          {mockClan.stats.winRate}%
                        </span>
                      </div>

                      <div key="region-stat" className="flex items-center gap-1">
                        <MapPin className="w-4 h-4 text-purple-400" />
                        <span 
                          style={{ 
                            fontSize: 'var(--font-size-body-2)',
                            fontWeight: 'var(--font-weight-medium)'
                          }}
                        >
                          {mockClan.region}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div 
                  className={`flex ${isMobile ? 'w-full justify-center' : 'flex-col'}`}
                  style={{ gap: 'var(--spacing-sm)' }}
                >
                  {!mockClan.isJoined ? (
                    <Button 
                      onClick={() => onJoin?.(mockClan.id)}
                      className={`bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 ${isMobile ? 'flex-1' : ''}`}
                      style={{ height: isMobile ? '36px' : '40px' }}
                    >
                      <UserPlus className="w-4 h-4 ml-2" />
                      {mockClan.type === 'private' ? 'درخواست عضویت' : 'پیوستن'}
                    </Button>
                  ) : (
                    <Button 
                      onClick={() => onLeave?.(mockClan.id)}
                      variant="destructive"
                      className={isMobile ? 'flex-1' : ''}
                      style={{ height: isMobile ? '36px' : '40px' }}
                    >
                      <UserMinus className="w-4 h-4 ml-2" />
                      ترک کلن
                    </Button>
                  )}

                  <div className={`flex ${isMobile ? '' : 'flex-col'}`} style={{ gap: 'var(--spacing-xs)' }}>
                    <Button 
                      key="share-button"
                      variant="outline" 
                      onClick={handleShare}
                      style={{ height: isMobile ? '36px' : '40px' }}
                    >
                      <Share2 className="w-4 h-4" />
                    </Button>
                    
                    <Button 
                      key="copy-button"
                      variant="outline" 
                      onClick={handleCopyInviteCode}
                      style={{ height: isMobile ? '36px' : '40px' }}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Clan Progress */}
              <div className="mt-6">
                <div 
                  className="flex justify-between mb-2"
                  style={{ fontSize: 'var(--font-size-body-2)' }}
                >
                  <span>پیشرفت تا سطح بعد</span>
                  <span>
                    {isMobile 
                      ? `${Math.floor(mockClan.xp/1000)}K/${Math.floor(mockClan.maxXp/1000)}K`
                      : `${mockClan.xp.toLocaleString()}/${mockClan.maxXp.toLocaleString()}`
                    }
                  </span>
                </div>
                <Progress 
                  value={(mockClan.xp / mockClan.maxXp) * 100} 
                  className="h-3 bg-muted" 
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs Navigation */}
        <Tabs 
          value={activeTab} 
          onValueChange={(value: any) => setActiveTab(value)} 
          className="mt-6"
        >
          <TabsList 
            className="grid w-full grid-cols-4"
            style={{ height: isMobile ? '40px' : '48px' }}
          >
            <TabsTrigger 
              value="overview"
              style={{ 
                fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                padding: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)'
              }}
            >
              <BarChart3 className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} ml-1`} />
              {isMobile ? 'آمار' : 'نمای کلی'}
            </TabsTrigger>
            <TabsTrigger 
              value="members"
              style={{ 
                fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                padding: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)'
              }}
            >
              <Users className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} ml-1`} />
              اعضا
            </TabsTrigger>
            <TabsTrigger 
              value="activity"
              style={{ 
                fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                padding: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)'
              }}
            >
              <Activity className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} ml-1`} />
              فعالیت
            </TabsTrigger>
            <TabsTrigger 
              value="wars"
              style={{ 
                fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                padding: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)'
              }}
            >
              <Sword className={`${isMobile ? 'w-3 h-3' : 'w-4 h-4'} ml-1`} />
              {isMobile ? 'جنگ' : 'جنگ کلن'}
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent 
            value="overview" 
            style={{ 
              marginTop: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)',
              display: 'flex',
              flexDirection: 'column',
              gap: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)'
            }}
          >
            {/* Stats Grid */}
            <div 
              className={`grid ${isMobile ? 'grid-cols-2' : 'grid-cols-2 md:grid-cols-4'}`}
              style={{ gap: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
            >
              <Card key="trophies-card">
                <CardContent 
                  className="text-center"
                  style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
                >
                  <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                  <div 
                    className="text-yellow-500"
                    style={{ 
                      fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-2)',
                      fontWeight: 'var(--font-weight-semibold)'
                    }}
                  >
                    {isMobile ? `${Math.floor(mockClan.stats.totalTrophies/1000)}K` : mockClan.stats.totalTrophies.toLocaleString()}
                  </div>
                  <div 
                    className="text-muted-foreground"
                    style={{ fontSize: 'var(--font-size-caption)' }}
                  >
                    کل جام‌ها
                  </div>
                </CardContent>
              </Card>

              <Card key="winrate-card">
                <CardContent 
                  className="text-center"
                  style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
                >
                  <Target className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <div 
                    className="text-green-500"
                    style={{ 
                      fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-2)',
                      fontWeight: 'var(--font-weight-semibold)'
                    }}
                  >
                    {mockClan.stats.winRate}%
                  </div>
                  <div 
                    className="text-muted-foreground"
                    style={{ fontSize: 'var(--font-size-caption)' }}
                  >
                    درصد برد
                  </div>
                </CardContent>
              </Card>

              <Card key="members-card">
                <CardContent 
                  className="text-center"
                  style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
                >
                  <Users className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                  <div 
                    className="text-blue-500"
                    style={{ 
                      fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-2)',
                      fontWeight: 'var(--font-weight-semibold)'
                    }}
                  >
                    {mockClan.activities.activeMembers}
                  </div>
                  <div 
                    className="text-muted-foreground"
                    style={{ fontSize: 'var(--font-size-caption)' }}
                  >
                    اعضای فعال
                  </div>
                </CardContent>
              </Card>

              <Card key="matches-card">
                <CardContent 
                  className="text-center"
                  style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
                >
                  <Flame className="w-8 h-8 text-orange-500 mx-auto mb-2" />
                  <div 
                    className="text-orange-500"
                    style={{ 
                      fontSize: isMobile ? 'var(--font-size-heading-3)' : 'var(--font-size-heading-2)',
                      fontWeight: 'var(--font-weight-semibold)'
                    }}
                  >
                    {mockClan.activities.weeklyMatches}
                  </div>
                  <div 
                    className="text-muted-foreground"
                    style={{ fontSize: 'var(--font-size-caption)' }}
                  >
                    مسابقات هفتگی
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Achievements */}
            <Card>
              <CardHeader>
                <CardTitle 
                  className="flex items-center"
                  style={{ 
                    gap: 'var(--spacing-sm)',
                    fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)'
                  }}
                >
                  <Award className="w-5 h-5 text-yellow-500" />
                  دستاورد‌ها
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div 
                  className={`grid ${isMobile ? 'grid-cols-2' : 'grid-cols-3'}`}
                  style={{ gap: 'var(--spacing-md)' }}
                >
                  {mockClan.achievements.map((achievement) => (
                    <div 
                      key={achievement.id}
                      className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg"
                    >
                      <div className="text-2xl">{achievement.icon}</div>
                      <div>
                        <div 
                          style={{ 
                            fontSize: 'var(--font-size-body-2)',
                            fontWeight: 'var(--font-weight-medium)'
                          }}
                        >
                          {achievement.name}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Leader Info */}
            <Card>
              <CardHeader>
                <CardTitle 
                  className="flex items-center"
                  style={{ 
                    gap: 'var(--spacing-sm)',
                    fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)'
                  }}
                >
                  <Crown className="w-5 h-5 text-yellow-500" />
                  رهبری کلن
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={mockClan.leader.avatar} />
                    <AvatarFallback>{mockClan.leader.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div 
                      className="flex items-center gap-2 mb-1"
                    >
                      <span 
                        style={{ 
                          fontSize: 'var(--font-size-body-1)',
                          fontWeight: 'var(--font-weight-medium)'
                        }}
                      >
                        {mockClan.leader.name}
                      </span>
                      <Crown className="w-4 h-4 text-yellow-500" />
                    </div>
                    <div 
                      className="text-muted-foreground"
                      style={{ fontSize: 'var(--font-size-body-2)' }}
                    >
                      سطح {mockClan.leader.level} • رهبر کلن
                    </div>
                  </div>
                  <div 
                    className="text-center"
                  >
                    <div 
                      className="text-muted-foreground"
                      style={{ fontSize: 'var(--font-size-caption)' }}
                    >
                      تأسیس
                    </div>
                    <div 
                      style={{ 
                        fontSize: 'var(--font-size-body-2)',
                        fontWeight: 'var(--font-weight-medium)'
                      }}
                    >
                      {mockClan.founded}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Members Tab */}
          <TabsContent 
            value="members"
            style={{ 
              marginTop: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)'
            }}
          >
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle 
                    style={{ 
                      fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)'
                    }}
                  >
                    اعضای کلن ({mockClan.members.current}/{mockClan.members.max})
                  </CardTitle>
                  
                  {!isMobile && (
                    <div className="flex gap-2">
                      <Button
                        key="filter-all"
                        variant={memberFilter === 'all' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setMemberFilter('all')}
                      >
                        همه
                      </Button>
                      <Button
                        key="filter-online"
                        variant={memberFilter === 'online' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setMemberFilter('online')}
                      >
                        آنلاین
                      </Button>
                      <Button
                        key="filter-officers"
                        variant={memberFilter === 'officers' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setMemberFilter('officers')}
                      >
                        مقامات
                      </Button>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div 
                  style={{ 
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'var(--spacing-md)'
                  }}
                >
                  {displayedMembers.map((member) => (
                    <div 
                      key={member.id}
                      className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="relative">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={member.avatar} />
                            <AvatarFallback>{member.name[0]}</AvatarFallback>
                          </Avatar>
                          <div 
                            className={`absolute -bottom-1 -right-1 w-3 h-3 border-2 border-background rounded-full ${getStatusColor(member.status)}`}
                          />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span 
                              className="truncate"
                              style={{ 
                                fontSize: 'var(--font-size-body-2)',
                                fontWeight: 'var(--font-weight-medium)'
                              }}
                            >
                              {member.name}
                            </span>
                            {getRoleIcon(member.role)}
                          </div>
                          <div 
                            className="text-muted-foreground"
                            style={{ fontSize: 'var(--font-size-caption)' }}
                          >
                            {getRoleText(member.role)} • سطح {member.level}
                          </div>
                        </div>
                      </div>

                      <div className="text-center">
                        <div 
                          className="text-yellow-400"
                          style={{ 
                            fontSize: 'var(--font-size-body-2)',
                            fontWeight: 'var(--font-weight-medium)'
                          }}
                        >
                          {isMobile ? `${Math.floor(member.stats.trophies/1000)}K` : member.stats.trophies.toLocaleString()}
                        </div>
                        <div 
                          className="text-muted-foreground"
                          style={{ fontSize: 'var(--font-size-caption)' }}
                        >
                          {member.lastActive}
                        </div>
                      </div>
                    </div>
                  ))}

                  {filteredMembers.length > displayedMembers.length && (
                    <Button 
                      variant="outline" 
                      onClick={() => setShowAllMembers(!showAllMembers)}
                      className="w-full"
                    >
                      {showAllMembers ? (
                        <>
                          <ChevronUp className="w-4 h-4 ml-2" />
                          نمایش کمتر
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-4 h-4 ml-2" />
                          نمایش همه ({filteredMembers.length - displayedMembers.length} عضو دیگر)
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent 
            value="activity"
            style={{ 
              marginTop: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)'
            }}
          >
            <Card>
              <CardHeader>
                <CardTitle 
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)'
                  }}
                >
                  آخرین فعالیت‌ها
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div 
                  style={{ 
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'var(--spacing-md)'
                  }}
                >
                  {mockActivities.map((activity, index) => (
                    <div key={activity.id}>
                      <div className="flex items-center gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={activity.member.avatar} />
                          <AvatarFallback>{activity.member.name[0]}</AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1">
                          <div 
                            style={{ 
                              fontSize: 'var(--font-size-body-2)',
                              fontWeight: 'var(--font-weight-medium)'
                            }}
                          >
                            <span className={activity.color}>{activity.member.name}</span>
                            {' '}{activity.description}
                            <span className="ml-2">{activity.icon}</span>
                          </div>
                          <div 
                            className="text-muted-foreground"
                            style={{ fontSize: 'var(--font-size-caption)' }}
                          >
                            {activity.timestamp}
                          </div>
                        </div>
                      </div>
                      
                      {index < mockActivities.length - 1 && (
                        <Separator className="mt-4" />
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Wars Tab */}
          <TabsContent 
            value="wars"
            style={{ 
              marginTop: isMobile ? 'var(--spacing-lg)' : 'var(--spacing-xl)'
            }}
          >
            <Card>
              <CardContent 
                className="text-center"
                style={{ 
                  padding: isMobile ? 'var(--spacing-xl)' : 'var(--spacing-3xl)'
                }}
              >
                <Sword className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                    fontWeight: 'var(--font-weight-medium)',
                    marginBottom: 'var(--spacing-sm)'
                  }}
                >
                  جنگ کلن‌ها
                </h3>
                <p 
                  className="text-muted-foreground"
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)'
                  }}
                >
                  این ویژگی به زودی اضافه خواهد شد
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}