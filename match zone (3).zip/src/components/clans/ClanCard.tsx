import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { 
  Users, Trophy, Target, Crown, Shield, Sword, Star, 
  MapPin, Calendar, ChevronRight, Lock, Unlock, 
  TrendingUp, Award, Flag, Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Clan } from '../providers/ClanProvider';
import { useResponsive } from '../../hooks/useResponsive';



export interface ClanCardProps {
  clan: Clan;
  onJoin?: (clanId: string) => void;
  onLeave?: (clanId: string) => void;
  onViewDetails?: (clanId: string) => void;
  variant?: 'default' | 'compact' | 'featured';
  showActions?: boolean;
}

export function ClanCard({ 
  clan, 
  onJoin, 
  onLeave, 
  onViewDetails,
  variant = 'default',
  showActions = true 
}: ClanCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const { isMobile, isTablet } = useResponsive();

  const getLevelColor = (level: number) => {
    if (level >= 50) return 'text-purple-400 bg-purple-500/20';
    if (level >= 30) return 'text-yellow-400 bg-yellow-500/20';
    if (level >= 15) return 'text-blue-400 bg-blue-500/20';
    return 'text-green-400 bg-green-500/20';
  };

  const getTypeIcon = (type: Clan['type']) => {
    switch (type) {
      case 'public':
        return <Unlock className="w-4 h-4 text-green-500" />;
      case 'private':
        return <Lock className="w-4 h-4 text-red-500" />;
      case 'invite-only':
        return <Crown className="w-4 h-4 text-yellow-500" />;
    }
  };

  const getTypeText = (type: Clan['type']) => {
    switch (type) {
      case 'public':
        return 'عمومی';
      case 'private':
        return 'خصوصی';
      case 'invite-only':
        return 'فقط دعوت';
    }
  };

  const getJoinButtonText = () => {
    if (clan.isJoined) return 'عضو هستید';
    if (clan.joinRequestPending) return 'درخواست ارسال شده';
    if (clan.type === 'public') return 'پیوستن';
    if (clan.type === 'invite-only') return 'درخواست عضویت';
    return 'درخواست عضویت';
  };

  const getJoinButtonVariant = () => {
    if (clan.isJoined) return 'secondary';
    if (clan.joinRequestPending) return 'outline';
    return 'default';
  };

  const canJoin = () => {
    if (clan.isJoined || clan.joinRequestPending) return false;
    if (clan.members.current >= clan.members.max) return false;
    // Check requirements
    if (clan.requirements.minLevel && clan.requirements.minLevel > 25) return false; //假设用户等级为25
    if (clan.requirements.minTrophies && clan.requirements.minTrophies > 1500) return false; // 假设用户奖杯为1500
    return true;
  };

  if (variant === 'compact') {
    return (
      <motion.div
        whileHover={{ y: -2 }}
        className={`bg-card border rounded-lg p-4 cursor-pointer relative ${clan.createdByUser ? 'ring-2 ring-green-500/50' : ''}`}
        onClick={() => onViewDetails?.(clan.id)}
      >
        {clan.createdByUser && (
          <div className="absolute -top-2 -right-2 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
            جدید! ✨
          </div>
        )}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Avatar className="w-12 h-12 ring-2 ring-primary/20">
              <AvatarImage src={clan.logo} />
              <AvatarFallback className="font-bold text-lg">{clan.tag}</AvatarFallback>
            </Avatar>
            <div className={`absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full text-xs font-bold ${getLevelColor(clan.level)}`}>
              {clan.level}
            </div>
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-bold truncate">[{clan.tag}] {clan.name}</h3>
              {clan.achievements.length > 0 && <Award className="w-4 h-4 text-yellow-500" />}
              {clan.createdByUser && <span className="text-green-500 text-xs">🎉</span>}
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="w-3 h-3" />
              <span>{clan.members.current}/{clan.members.max}</span>
              <Trophy className="w-3 h-3" />
              <span>{clan.stats.totalTrophies.toLocaleString()}</span>
            </div>
          </div>
          
          <ChevronRight className="w-5 h-5 text-muted-foreground" />
        </div>
      </motion.div>
    );
  }

  if (variant === 'featured') {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        whileHover={{ scale: 1.02 }}
        className="relative overflow-hidden"
      >
        <Card className="relative overflow-hidden bg-gradient-to-br from-yellow-500/10 via-orange-500/10 to-red-500/10 border-yellow-500/30">
          {/* Featured Banner */}
          <div className="absolute top-0 right-0 bg-gradient-to-l from-yellow-500 to-orange-500 text-white px-3 py-1 text-xs font-bold rounded-bl-lg">
            <Star className="w-3 h-3 inline ml-1" />
            ویژه
          </div>

          {/* Clan Banner Background */}
          {clan.banner && (
            <div 
              className="absolute inset-0 opacity-20 bg-cover bg-center"
              style={{ backgroundImage: `url(${clan.banner})` }}
            />
          )}

          <CardContent className="relative p-4 md:p-6 space-y-3 md:space-y-4">
            {/* Clan Header */}
            <div className="flex items-start gap-3 md:gap-4">
              <div className="relative">
                <Avatar className="w-12 h-12 md:w-16 md:h-16 ring-2 md:ring-4 ring-yellow-500/50">
                  <AvatarImage src={clan.logo} />
                  <AvatarFallback className="font-bold text-sm md:text-xl bg-gradient-to-br from-yellow-500 to-orange-500 text-white">
                    {clan.tag}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-1 -right-1 md:-bottom-2 md:-right-2 bg-yellow-500 text-white px-1 py-0.5 md:px-2 md:py-1 rounded-full text-xs font-bold">
                  #{clan.stats.rank}
                </div>
              </div>

              <div className="flex-1 space-y-1 md:space-y-2 min-w-0">
                <div>
                  <h3 className="font-bold text-sm md:text-xl text-yellow-400 truncate">[{clan.tag}] {clan.name}</h3>
                  <p className="text-xs md:text-sm text-muted-foreground line-clamp-2">{clan.description}</p>
                </div>

                <div className="flex items-center gap-2 md:gap-4 flex-wrap">
                  <div key="featured-trophies" className="flex items-center gap-1">
                    <Trophy className="w-3 h-3 md:w-4 md:h-4 text-yellow-500" />
                    <span className="font-semibold text-yellow-400 text-xs md:text-sm">
                      {window.innerWidth < 768 ? `${Math.floor(clan.stats.totalTrophies/1000)}K` : clan.stats.totalTrophies.toLocaleString()}
                    </span>
                  </div>
                  <div key="featured-members" className="flex items-center gap-1">
                    <Users className="w-3 h-3 md:w-4 md:h-4 text-blue-400" />
                    <span className="text-xs md:text-sm">{clan.members.current}/{clan.members.max}</span>
                  </div>
                  <div key="featured-winrate" className="flex items-center gap-1">
                    <Target className="w-3 h-3 md:w-4 md:h-4 text-green-400" />
                    <span className="text-xs md:text-sm">{clan.stats.winRate}%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Featured Stats */}
            <div className="grid grid-cols-3 gap-3">
              <div key="level-stat" className="text-center p-3 bg-black/20 rounded-lg border border-yellow-500/30">
                <div className="font-bold text-lg text-yellow-400">{clan.level}</div>
                <div className="text-xs text-muted-foreground">سطح کلن</div>
              </div>
              <div key="wins-stat" className="text-center p-3 bg-black/20 rounded-lg border border-green-500/30">
                <div className="font-bold text-lg text-green-400">{clan.stats.wins}W</div>
                <div className="text-xs text-muted-foreground">پیروزی</div>
              </div>
              <div key="active-stat" className="text-center p-3 bg-black/20 rounded-lg border border-blue-500/30">
                <div className="font-bold text-lg text-blue-400">{clan.activities.activeMembers}</div>
                <div className="text-xs text-muted-foreground">فع��ل</div>
              </div>
            </div>

            {showActions && (
              <div className="flex gap-2">
                <Button 
                  key="featured-details-btn"
                  onClick={() => onViewDetails?.(clan.id)}
                  variant="outline"
                  className="flex-1 border-yellow-500/50 hover:bg-yellow-500/10"
                >
                  مشاهده جزئیات
                </Button>
                <Button 
                  key="featured-join-btn"
                  onClick={() => clan.isJoined ? onLeave?.(clan.id) : onJoin?.(clan.id)}
                  disabled={!canJoin() && !clan.isJoined}
                  variant={getJoinButtonVariant() as any}
                  className="flex-1"
                >
                  {getJoinButtonText()}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  // Default variant
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card className={`relative overflow-hidden transition-all duration-300 hover:shadow-xl ${clan.createdByUser ? 'ring-2 ring-green-500/50 shadow-green-500/20' : ''}`}>
        {/* New Clan Badge */}
        {clan.createdByUser && (
          <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 p-1">
            <div className="bg-card rounded p-1 text-center">
              <span className="text-xs font-bold text-green-400 animate-pulse">🎉 کلن جدید شما</span>
            </div>
          </div>
        )}
        
        {/* Clan Level Banner */}
        <div className={`absolute ${clan.createdByUser ? 'top-8' : 'top-0'} left-0 px-3 py-1 text-xs font-bold rounded-br-lg ${getLevelColor(clan.level)}`}>
          سطح {clan.level}
        </div>

        {/* Clan Type Icon */}
        <div className={`absolute ${clan.createdByUser ? 'top-10' : 'top-2'} right-2`}>
          {getTypeIcon(clan.type)}
        </div>

        <CardContent 
          style={{ 
            padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-xl)',
            display: 'flex',
            flexDirection: 'column',
            gap: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)'
          }} 
          dir="rtl"
        >
          {/* Clan Header */}
          <div 
            className="flex items-start"
            style={{ gap: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
          >
            <div className="relative">
              <Avatar 
                className="ring-2 ring-primary/20"
                style={{ 
                  width: isMobile ? '48px' : '56px',
                  height: isMobile ? '48px' : '56px'
                }}
              >
                <AvatarImage src={clan.logo} />
                <AvatarFallback 
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-body-2)' : 'var(--font-size-heading-3)',
                    fontWeight: 'var(--font-weight-semibold)'
                  }}
                >
                  {clan.tag}
                </AvatarFallback>
              </Avatar>
              
              {clan.achievements.length > 0 && (
                <div 
                  className="absolute -top-1 -left-1 bg-yellow-500 rounded-full"
                  style={{ padding: 'var(--spacing-xs)' }}
                >
                  <Award className={`${isMobile ? 'w-2 h-2' : 'w-3 h-3'} text-white`} />
                </div>
              )}
            </div>

            <div 
              className="flex-1 min-w-0"
              style={{ 
                display: 'flex',
                flexDirection: 'column',
                gap: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)'
              }}
            >
              <div>
                <h3 
                  className="truncate"
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                    fontWeight: 'var(--font-weight-semibold)',
                    lineHeight: 'var(--line-height-tight)'
                  }}
                >
                  [{clan.tag}] {clan.name}
                </h3>
                <p 
                  className="text-muted-foreground line-clamp-2"
                  style={{ 
                    fontSize: isMobile ? 'var(--font-size-caption)' : 'var(--font-size-body-2)',
                    lineHeight: 'var(--line-height-base)'
                  }}
                >
                  {clan.description}
                </p>
              </div>

              <div 
                className="flex items-center flex-wrap"
                style={{ gap: isMobile ? 'var(--spacing-xs)' : 'var(--spacing-sm)' }}
              >
                <Badge 
                  variant="outline" 
                  className="gap-1"
                  style={{ fontSize: 'var(--font-size-caption)' }}
                >
                  {getTypeIcon(clan.type)}
                  {getTypeText(clan.type)}
                </Badge>
                <Badge 
                  variant="outline" 
                  className="gap-1"
                  style={{ fontSize: 'var(--font-size-caption)' }}
                >
                  <MapPin className={`${isMobile ? 'w-2 h-2' : 'w-3 h-3'}`} />
                  {clan.region}
                </Badge>
                <Badge 
                  variant="outline"
                  style={{ fontSize: 'var(--font-size-caption)' }}
                >
                  #{clan.stats.rank}
                </Badge>
              </div>
            </div>
          </div>

          {/* Clan Stats */}
          <div className="grid grid-cols-2 gap-2 md:gap-4">
            <div className="space-y-2 md:space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 md:gap-2">
                  <Users className="w-3 h-3 md:w-4 md:h-4 text-blue-400" />
                  <span className="text-xs md:text-sm">اعضا</span>
                </div>
                <span className="font-semibold text-xs md:text-sm">{clan.members.current}/{clan.members.max}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 md:gap-2">
                  <Trophy className="w-3 h-3 md:w-4 md:h-4 text-yellow-400" />
                  <span className="text-xs md:text-sm">جام‌ها</span>
                </div>
                <span className="font-semibold text-xs md:text-sm">
                  {isMobile ? `${Math.floor(clan.stats.totalTrophies/1000)}K` : clan.stats.totalTrophies.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="space-y-2 md:space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 md:gap-2">
                  <Target className="w-3 h-3 md:w-4 md:h-4 text-green-400" />
                  <span className="text-xs md:text-sm">درصد برد</span>
                </div>
                <span className="font-semibold text-green-400 text-xs md:text-sm">{clan.stats.winRate}%</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 md:gap-2">
                  <Zap className="w-3 h-3 md:w-4 md:h-4 text-purple-400" />
                  <span className="text-xs md:text-sm">فعال</span>
                </div>
                <span className="font-semibold text-xs md:text-sm">{clan.activities.activeMembers}</span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Clan Progress */}
          <div className="space-y-1 md:space-y-2">
            <div className="flex justify-between text-xs md:text-sm">
              <span>پیشرفت تا سطح بعد</span>
              <span>
                {isMobile 
                  ? `${Math.floor(clan.xp/1000)}K/${Math.floor(clan.maxXp/1000)}K XP`
                  : `${clan.xp.toLocaleString()}/${clan.maxXp.toLocaleString()} XP`
                }
              </span>
            </div>
            <Progress value={(clan.xp / clan.maxXp) * 100} className="h-1.5 md:h-2" />
          </div>

          {/* Leader Info */}
          <div className="flex items-center gap-2 md:gap-3 p-2 md:p-3 bg-muted/50 rounded-lg">
            <Crown className="w-3 h-3 md:w-4 md:h-4 text-yellow-500" />
            <Avatar className="w-6 h-6 md:w-8 md:h-8">
              <AvatarImage src={clan.leader.avatar} />
              <AvatarFallback className="text-xs">{clan.leader.name[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-xs md:text-sm truncate">{clan.leader.name}</div>
              <div className="text-xs md:text-xs text-muted-foreground">رهبر کلن • سطح {clan.leader.level}</div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="text-center text-xs text-muted-foreground leading-relaxed">
            آخرین فعالیت: {clan.activities.lastActive}
            {!isMobile && (
              <> • {clan.activities.weeklyMatches} مسابقه این هفته</>
            )}
          </div>

          {/* Action Buttons */}
          {showActions && (
            <div className="flex gap-2">
              <Button 
                key="default-details-btn"
                onClick={() => onViewDetails?.(clan.id)}
                variant="outline"
                className="flex-1"
                size={window.innerWidth < 768 ? "sm" : "sm"}
              >
                <span className="text-xs md:text-sm">جزئیات</span>
              </Button>
              
              {clan.isJoined ? (
                <Button 
                  key="default-leave-btn"
                  onClick={() => onLeave?.(clan.id)}
                  variant="destructive"
                  className="flex-1"
                  size={window.innerWidth < 768 ? "sm" : "sm"}
                >
                  <span className="text-xs md:text-sm">ترک کلن</span>
                </Button>
              ) : (
                <Button 
                  key="default-join-btn"
                  onClick={() => onJoin?.(clan.id)}
                  disabled={!canJoin()}
                  variant={getJoinButtonVariant() as any}
                  className="flex-1"
                  size={window.innerWidth < 768 ? "sm" : "sm"}
                >
                  <span className="text-xs md:text-sm">{getJoinButtonText()}</span>
                </Button>
              )}
            </div>
          )}

          {/* Hover Animation Effect */}
          <AnimatePresence>
            {isHovered && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 pointer-events-none"
              />
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
}