import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { 
  GraduationCap, Target, Users, Clock, Trophy, Star, Zap,
  PlayCircle, PauseCircle, RotateCcw, CheckCircle, XCircle,
  TrendingUp, BarChart3, Award, Medal, BookOpen, Brain,
  Sword, Shield, Heart, Plus, Eye, Calendar, Timer,
  Flame, Crown, ArrowUp, ArrowRight, MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';

export interface TrainingProgram {
  id: string;
  name: string;
  description: string;
  category: 'strategy' | 'combat' | 'teamwork' | 'leadership';
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  duration: number; // minutes
  requiredLevel: number;
  maxParticipants: number;
  currentParticipants: number;
  instructor: {
    id: string;
    name: string;
    avatar: string;
    level: number;
    speciality: string;
    rating: number;
    completedSessions: number;
  };
  schedule: {
    startTime: string;
    endTime: string;
    frequency: 'daily' | 'weekly' | 'monthly';
  };
  rewards: {
    experience: number;
    coins: number;
    badges: string[];
    skills: string[];
  };
  requirements: string[];
  status: 'upcoming' | 'active' | 'completed' | 'canceled';
  completionRate: number;
  averageRating: number;
}

export interface TrainingSession {
  id: string;
  programId: string;
  name: string;
  startTime: string;
  duration: number;
  participants: Array<{
    id: string;
    name: string;
    avatar: string;
    level: number;
    performance: number;
    attendance: boolean;
  }>;
  objectives: string[];
  progress: {
    completed: number;
    total: number;
  };
  status: 'waiting' | 'active' | 'break' | 'completed';
  currentObjective: string;
  notes: string;
}

export interface ClanTrainingSystemProps {
  clanId: string;
  onTrainingAction?: (action: string, data: any) => void;
  className?: string;
}

const MOCK_PROGRAMS: TrainingProgram[] = [
  {
    id: 'program-1',
    name: 'استراتژی‌های حمله پیشرفته',
    description: 'آموزش تاکتیک‌های حرفه‌ای برای حمله‌های مؤثر و هماهنگ تیمی',
    category: 'strategy',
    difficulty: 'advanced',
    duration: 90,
    requiredLevel: 10,
    maxParticipants: 15,
    currentParticipants: 12,
    instructor: {
      id: 'instructor-1',
      name: 'مربی علی‌رضا',
      avatar: '/avatars/instructor-1.png',
      level: 25,
      speciality: 'استراتژیست ارشد',
      rating: 4.8,
      completedSessions: 156
    },
    schedule: {
      startTime: '2024-12-25T19:00:00Z',
      endTime: '2024-12-25T20:30:00Z',
      frequency: 'weekly'
    },
    rewards: {
      experience: 500,
      coins: 1000,
      badges: ['استراتژیست', 'رهبر تیم'],
      skills: ['تاکتیک حمله', 'رهبری']
    },
    requirements: ['حداقل ۵ جنگ کلن', 'دانش پایه‌ای استراتژی'],
    status: 'upcoming',
    completionRate: 85,
    averageRating: 4.7
  },
  {
    id: 'program-2',
    name: 'تکنیک‌های دفاعی',
    description: 'یادگیری روش‌های مؤثر دفاع و حفاظت از پایگاه کلن',
    category: 'combat',
    difficulty: 'intermediate',
    duration: 60,
    requiredLevel: 7,
    maxParticipants: 20,
    currentParticipants: 18,
    instructor: {
      id: 'instructor-2',
      name: 'مربی مریم',
      avatar: '/avatars/instructor-2.png',
      level: 22,
      speciality: 'متخصص دفاع',
      rating: 4.9,
      completedSessions: 203
    },
    schedule: {
      startTime: '2024-12-26T20:00:00Z',
      endTime: '2024-12-26T21:00:00Z',
      frequency: 'weekly'
    },
    rewards: {
      experience: 300,
      coins: 600,
      badges: ['محافظ', 'دیوار آهنین'],
      skills: ['دفاع پیشرفته', 'مقاومت']
    },
    requirements: ['تجربه ۳ ماهه بازی', 'شرکت در جنگ کلن'],
    status: 'active',
    completionRate: 92,
    averageRating: 4.8
  },
  {
    id: 'program-3',
    name: 'همکاری تیمی حرفه‌ای',
    description: 'تقویت روحیه تیمی و هماهنگی بین اعضای کلن',
    category: 'teamwork',
    difficulty: 'beginner',
    duration: 45,
    requiredLevel: 5,
    maxParticipants: 25,
    currentParticipants: 8,
    instructor: {
      id: 'instructor-3',
      name: 'مربی حسن',
      avatar: '/avatars/instructor-3.png',
      level: 20,
      speciality: 'روانشناس تیمی',
      rating: 4.6,
      completedSessions: 98
    },
    schedule: {
      startTime: '2024-12-27T18:30:00Z',
      endTime: '2024-12-27T19:15:00Z',
      frequency: 'weekly'
    },
    rewards: {
      experience: 200,
      coins: 400,
      badges: ['همتیمی', 'روح تیم'],
      skills: ['همکاری', 'ارتباطات']
    },
    requirements: ['عضویت در کلن', 'حداقل ۱ ماه فعالیت'],
    status: 'upcoming',
    completionRate: 78,
    averageRating: 4.5
  }
];

const MOCK_ACTIVE_SESSION: TrainingSession = {
  id: 'session-1',
  programId: 'program-2',
  name: 'جلسه ۳: تقویت دفاع‌های داخلی',
  startTime: '2024-12-26T20:00:00Z',
  duration: 60,
  participants: [
    {
      id: 'user-1',
      name: 'احمد',
      avatar: '/avatars/user-1.png',
      level: 12,
      performance: 85,
      attendance: true
    },
    {
      id: 'user-2',
      name: 'فاطمه',
      avatar: '/avatars/user-2.png',
      level: 14,
      performance: 92,
      attendance: true
    },
    {
      id: 'user-3',
      name: 'علی',
      avatar: '/avatars/user-3.png',
      level: 11,
      performance: 78,
      attendance: false
    },
    {
      id: 'user-4',
      name: 'زهرا',
      avatar: '/avatars/user-4.png',
      level: 13,
      performance: 89,
      attendance: true
    }
  ],
  objectives: [
    'بررسی انواع دفاع‌های پایگاه',
    'تمرین عملی طراحی دفاع',
    'شناسایی نقاط ضعف',
    'ارائه بازخورد و بهبود'
  ],
  progress: {
    completed: 2,
    total: 4
  },
  status: 'active',
  currentObjective: 'تمرین عملی طراحی دفاع',
  notes: 'شرکت‌کنندگان عملکرد فوق‌العاده‌ای دارند. نیاز به تمرین بیشتر روی هماهنگی تیمی.'
};

export function ClanTrainingSystem({ clanId, onTrainingAction, className }: ClanTrainingSystemProps) {
  const [activeTab, setActiveTab] = useState('programs');
  const [programs] = useState<TrainingProgram[]>(MOCK_PROGRAMS);
  const [activeSession, setActiveSession] = useState<TrainingSession | null>(MOCK_ACTIVE_SESSION);
  const [selectedProgram, setSelectedProgram] = useState<TrainingProgram | null>(null);
  const [isCreateProgramOpen, setIsCreateProgramOpen] = useState(false);

  const getCategoryInfo = (category: TrainingProgram['category']) => {
    switch (category) {
      case 'strategy':
        return {
          name: 'استراتژی',
          icon: Brain,
          color: 'text-purple-500',
          bg: 'bg-purple-500/10'
        };
      case 'combat':
        return {
          name: 'نبرد',
          icon: Sword,
          color: 'text-red-500',
          bg: 'bg-red-500/10'
        };
      case 'teamwork':
        return {
          name: 'تیم‌ورک',
          icon: Users,
          color: 'text-blue-500',
          bg: 'bg-blue-500/10'
        };
      case 'leadership':
        return {
          name: 'رهبری',
          icon: Crown,
          color: 'text-yellow-500',
          bg: 'bg-yellow-500/10'
        };
    }
  };

  const getDifficultyColor = (difficulty: TrainingProgram['difficulty']) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-500';
      case 'intermediate': return 'text-yellow-500';
      case 'advanced': return 'text-orange-500';
      case 'expert': return 'text-red-500';
      default: return 'text-muted-foreground';
    }
  };

  const getDifficultyText = (difficulty: TrainingProgram['difficulty']) => {
    switch (difficulty) {
      case 'beginner': return 'مبتدی';
      case 'intermediate': return 'متوسط';
      case 'advanced': return 'پیشرفته';
      case 'expert': return 'حرفه‌ای';
      default: return 'نامشخص';
    }
  };

  const getStatusColor = (status: TrainingProgram['status']) => {
    switch (status) {
      case 'upcoming': return 'text-blue-500';
      case 'active': return 'text-green-500';
      case 'completed': return 'text-gray-500';
      case 'canceled': return 'text-red-500';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusText = (status: TrainingProgram['status']) => {
    switch (status) {
      case 'upcoming': return 'آینده';
      case 'active': return 'فعال';
      case 'completed': return 'تکمیل شده';
      case 'canceled': return 'لغو شده';
      default: return 'نامشخص';
    }
  };

  const handleTrainingAction = (action: string, data: any) => {
    onTrainingAction?.(action, data);
    toast.success(`عملیات "${action}" انجام شد`);
  };

  const joinProgram = (programId: string) => {
    handleTrainingAction('join-program', { programId, clanId });
  };

  const leaveProgram = (programId: string) => {
    handleTrainingAction('leave-program', { programId, clanId });
  };

  const formatTimeRemaining = (startTime: string) => {
    const now = new Date().getTime();
    const start = new Date(startTime).getTime();
    const remaining = start - now;
    
    if (remaining <= 0) return 'در حال برگزاری';
    
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours} ساعت و ${minutes} دقیقه`;
    }
    return `${minutes} دقیقه`;
  };

  const ProgramCard = ({ program }: { program: TrainingProgram }) => {
    const categoryInfo = getCategoryInfo(program.category);
    const CategoryIcon = categoryInfo.icon;

    return (
      <Card className="border-2 hover:border-blue-500/50 transition-all duration-200">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 ${categoryInfo.bg} rounded-lg`}>
                <CategoryIcon className={`w-5 h-5 ${categoryInfo.color}`} />
              </div>
              <div>
                <CardTitle className="text-base">{program.name}</CardTitle>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Badge variant="outline" className={categoryInfo.color}>
                    {categoryInfo.name}
                  </Badge>
                  <Badge variant="outline" className={getDifficultyColor(program.difficulty)}>
                    {getDifficultyText(program.difficulty)}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="text-right text-sm">
              <div className={`font-medium ${getStatusColor(program.status)}`}>
                {getStatusText(program.status)}
              </div>
              <div className="text-muted-foreground">
                {program.currentParticipants}/{program.maxParticipants} نفر
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">{program.description}</p>

          {/* Instructor */}
          <div className="flex items-center gap-2">
            <Avatar className="w-8 h-8">
              <AvatarImage src={program.instructor.avatar} />
              <AvatarFallback>{program.instructor.name.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium">{program.instructor.name}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>{program.instructor.speciality}</span>
                <span>•</span>
                <div className="flex items-center gap-1">
                  <Star className="w-3 h-3 text-yellow-500 fill-current" />
                  {program.instructor.rating}
                </div>
              </div>
            </div>
          </div>

          {/* Schedule & Duration */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span>{program.duration} دقیقه</span>
            </div>
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <span>{formatTimeRemaining(program.schedule.startTime)}</span>
            </div>
          </div>

          {/* Progress & Rating */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>نرخ تکمیل</span>
              <span>{program.completionRate}%</span>
            </div>
            <Progress value={program.completionRate} className="h-2" />
            
            <div className="flex justify-between text-sm">
              <span>امتیاز متوسط</span>
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 text-yellow-500 fill-current" />
                {program.averageRating}
              </div>
            </div>
          </div>

          {/* Rewards Preview */}
          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1">
              <Zap className="w-3 h-3 text-blue-500" />
              <span>{program.rewards.experience} XP</span>
            </div>
            <div className="flex items-center gap-1">
              <Trophy className="w-3 h-3 text-yellow-500" />
              <span>{program.rewards.coins.toLocaleString()} سکه</span>
            </div>
            <div className="flex items-center gap-1">
              <Medal className="w-3 h-3 text-purple-500" />
              <span>{program.rewards.badges.length} مدال</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => setSelectedProgram(program)}
            >
              <Eye className="w-4 h-4 ml-2" />
              جزئیات
            </Button>
            
            {program.status === 'upcoming' && (
              <Button 
                size="sm" 
                className="flex-1 bg-green-600 hover:bg-green-700"
                onClick={() => joinProgram(program.id)}
                disabled={program.currentParticipants >= program.maxParticipants}
              >
                <Plus className="w-4 h-4 ml-2" />
                ثبت‌نام
              </Button>
            )}

            {program.status === 'active' && (
              <Button 
                size="sm" 
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                <PlayCircle className="w-4 h-4 ml-2" />
                پیوستن
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const ActiveSessionCard = () => {
    if (!activeSession) return null;

    const progressPercent = (activeSession.progress.completed / activeSession.progress.total) * 100;
    const attendeeCount = activeSession.participants.filter(p => p.attendance).length;

    return (
      <Card className="border-2 border-green-500/50 bg-green-500/5">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
              جلسه فعال
            </CardTitle>
            <Badge className="bg-green-500 text-white">
              زنده
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">{activeSession.name}</p>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Current Objective */}
          <div className="p-3 bg-muted rounded-lg">
            <h4 className="font-medium mb-1">هدف فعلی:</h4>
            <p className="text-sm">{activeSession.currentObjective}</p>
          </div>

          {/* Progress */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>پیشرفت جلسه</span>
              <span>{activeSession.progress.completed}/{activeSession.progress.total}</span>
            </div>
            <Progress value={progressPercent} className="h-3" />
          </div>

          {/* Participants */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-medium text-sm">شرکت‌کنندگان</h4>
              <span className="text-sm text-muted-foreground">
                {attendeeCount}/{activeSession.participants.length} نفر حاضر
              </span>
            </div>
            
            <div className="space-y-2">
              {activeSession.participants.map((participant) => (
                <div key={participant.id} className="flex items-center justify-between p-2 rounded bg-muted/30">
                  <div className="flex items-center gap-2">
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={participant.avatar} />
                      <AvatarFallback className="text-xs">{participant.name.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">{participant.name}</p>
                      <p className="text-xs text-muted-foreground">سطح {participant.level}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <div className="text-sm font-medium">{participant.performance}%</div>
                      <div className="text-xs text-muted-foreground">عملکرد</div>
                    </div>
                    <div className={`w-2 h-2 rounded-full ${
                      participant.attendance ? 'bg-green-500' : 'bg-red-500'
                    }`} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Objectives List */}
          <div>
            <h4 className="font-medium text-sm mb-2">اهداف جلسه</h4>
            <div className="space-y-1">
              {activeSession.objectives.map((objective, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  {index < activeSession.progress.completed ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : index === activeSession.progress.completed ? (
                    <PlayCircle className="w-4 h-4 text-blue-500" />
                  ) : (
                    <div className="w-4 h-4 border-2 border-muted-foreground rounded-full" />
                  )}
                  <span className={
                    index < activeSession.progress.completed 
                      ? 'text-green-500' 
                      : index === activeSession.progress.completed 
                        ? 'text-blue-500'
                        : 'text-muted-foreground'
                  }>
                    {objective}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button className="flex-1 bg-green-600 hover:bg-green-700">
              <PlayCircle className="w-4 h-4 ml-2" />
              پیوستن به جلسه
            </Button>
            <Button variant="outline">
              <MessageSquare className="w-4 h-4 ml-2" />
              چت
            </Button>
          </div>

          {/* Notes */}
          {activeSession.notes && (
            <div className="p-3 bg-blue-500/10 rounded-lg border-r-4 border-blue-500">
              <h4 className="font-medium text-sm mb-1">یادداشت‌های مربی:</h4>
              <p className="text-sm text-muted-foreground">{activeSession.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className={`space-y-6 ${className || ''}`} dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border-green-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <GraduationCap className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <CardTitle className="text-xl">سیستم آموزش کلن</CardTitle>
                <p className="text-muted-foreground text-sm">
                  پیشرفت مهارت‌های اعضای کلن با برنامه‌های آموزشی حرفه‌ای
                </p>
              </div>
            </div>
            <Button onClick={() => setIsCreateProgramOpen(true)}>
              <Plus className="w-4 h-4 ml-2" />
              ایجاد برنامه
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Active Session */}
      {activeSession && <ActiveSessionCard />}

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="programs" className="flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            برنامه‌های آموزشی
          </TabsTrigger>
          <TabsTrigger value="my-programs" className="flex items-center gap-2">
            <Star className="w-4 h-4" />
            برنامه‌های من
          </TabsTrigger>
          <TabsTrigger value="instructors" className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4" />
            مربیان
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            آمار و گزارش
          </TabsTrigger>
        </TabsList>

        {/* All Programs Tab */}
        <TabsContent value="programs" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {programs.map((program) => (
              <ProgramCard key={program.id} program={program} />
            ))}
          </div>

          {programs.length === 0 && (
            <Card className="p-8 text-center">
              <div className="space-y-4">
                <GraduationCap className="w-16 h-16 text-muted-foreground/50 mx-auto" />
                <div>
                  <h3 className="text-lg font-semibold">هیچ برنامه آموزشی موجود نیست</h3>
                  <p className="text-muted-foreground">
                    اولین برنامه آموزشی کلن خود را ایجاد کنید
                  </p>
                </div>
                <Button onClick={() => setIsCreateProgramOpen(true)}>
                  <Plus className="w-4 h-4 ml-2" />
                  ایجاد برنامه جدید
                </Button>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* My Programs Tab */}
        <TabsContent value="my-programs" className="space-y-4">
          <Card className="p-8 text-center">
            <div className="space-y-4">
              <Star className="w-16 h-16 text-muted-foreground/50 mx-auto" />
              <div>
                <h3 className="text-lg font-semibold">برنامه‌های شخصی شما</h3>
                <p className="text-muted-foreground">
                  برنامه‌هایی که در آن‌ها ثبت‌نام کرده‌اید در اینجا نمایش داده می‌شود
                </p>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Instructors Tab */}
        <TabsContent value="instructors" className="space-y-4">
          <Card className="p-8 text-center">
            <div className="space-y-4">
              <GraduationCap className="w-16 h-16 text-muted-foreground/50 mx-auto" />
              <div>
                <h3 className="text-lg font-semibold">مربیان کلن</h3>
                <p className="text-muted-foreground">
                  لیست مربیان و متخصصین آموزشی کلن در اینجا نمایش داده می‌شود
                </p>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-green-500">24</div>
                <p className="text-sm text-muted-foreground">جلسه تکمیل شده</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-blue-500">89%</div>
                <p className="text-sm text-muted-foreground">نرخ حضور</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-purple-500">4.7</div>
                <p className="text-sm text-muted-foreground">امتیاز متوسط</p>
              </CardContent>
            </Card>
          </div>

          <Card className="p-8 text-center">
            <div className="space-y-4">
              <BarChart3 className="w-16 h-16 text-muted-foreground/50 mx-auto" />
              <div>
                <h3 className="text-lg font-semibold">آمار تفصیلی</h3>
                <p className="text-muted-foreground">
                  نمودارها و گزارش‌های تفصیلی از عملکرد آموزشی کلن
                </p>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Program Details Dialog */}
      <Dialog open={!!selectedProgram} onOpenChange={() => setSelectedProgram(null)}>
        <DialogContent className="max-w-4xl" dir="rtl">
          {selectedProgram && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <GraduationCap className="w-5 h-5" />
                  {selectedProgram.name}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Program Overview */}
                <Card>
                  <CardContent className="p-4">
                    <p className="mb-4">{selectedProgram.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <h4 className="font-medium mb-2">اطلاعات کلی</h4>
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span>دسته‌بندی:</span>
                            <Badge>{getCategoryInfo(selectedProgram.category).name}</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span>سطح:</span>
                            <span className={getDifficultyColor(selectedProgram.difficulty)}>
                              {getDifficultyText(selectedProgram.difficulty)}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>مدت:</span>
                            <span>{selectedProgram.duration} دقیقه</span>
                          </div>
                          <div className="flex justify-between">
                            <span>حداقل سطح:</span>
                            <span>{selectedProgram.requiredLevel}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-medium mb-2">جوایز</h4>
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span>تجربه:</span>
                            <span className="text-blue-500">{selectedProgram.rewards.experience} XP</span>
                          </div>
                          <div className="flex justify-between">
                            <span>سکه:</span>
                            <span className="text-yellow-500">{selectedProgram.rewards.coins.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>مدال‌ها:</span>
                            <span>{selectedProgram.rewards.badges.join(', ')}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Requirements */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-2">پیش‌نیازها</h4>
                    <ul className="space-y-1 text-sm">
                      {selectedProgram.requirements.map((req, index) => (
                        <li key={index} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-500" />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Instructor */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-3">مربی دوره</h4>
                    <div className="flex items-center gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={selectedProgram.instructor.avatar} />
                        <AvatarFallback>{selectedProgram.instructor.name.slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{selectedProgram.instructor.name}</p>
                        <p className="text-sm text-muted-foreground">{selectedProgram.instructor.speciality}</p>
                        <div className="flex items-center gap-3 text-sm">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-500 fill-current" />
                            {selectedProgram.instructor.rating}
                          </div>
                          <span>•</span>
                          <span>{selectedProgram.instructor.completedSessions} جلسه تکمیل شده</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button 
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={() => {
                      joinProgram(selectedProgram.id);
                      setSelectedProgram(null);
                    }}
                    disabled={selectedProgram.currentParticipants >= selectedProgram.maxParticipants}
                  >
                    <Plus className="w-4 h-4 ml-2" />
                    ثبت‌نام در دوره
                  </Button>
                  <Button variant="outline" onClick={() => setSelectedProgram(null)}>
                    بستن
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Program Dialog */}
      <Dialog open={isCreateProgramOpen} onOpenChange={setIsCreateProgramOpen}>
        <DialogContent className="max-w-2xl" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              ایجاد برنامه آموزشی جدید
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="program-name">نام برنامه</Label>
                <Input 
                  id="program-name"
                  placeholder="مثلاً: استراتژی‌های پیشرفته"
                />
              </div>
              <div>
                <Label htmlFor="program-category">دسته‌بندی</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="انتخاب دسته‌بندی" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="strategy">استراتژی</SelectItem>
                    <SelectItem value="combat">نبرد</SelectItem>
                    <SelectItem value="teamwork">تیم‌ورک</SelectItem>
                    <SelectItem value="leadership">رهبری</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="program-description">توضیحات</Label>
              <Textarea
                id="program-description"
                placeholder="توضیح کاملی از اهداف و محتوای برنامه آموزشی..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="program-duration">مدت (دقیقه)</Label>
                <Input 
                  id="program-duration"
                  type="number"
                  placeholder="60"
                />
              </div>
              <div>
                <Label htmlFor="program-level">حداقل سطح</Label>
                <Input 
                  id="program-level"
                  type="number"
                  placeholder="5"
                />
              </div>
              <div>
                <Label htmlFor="program-participants">حداکثر شرکت‌کننده</Label>
                <Input 
                  id="program-participants"
                  type="number"
                  placeholder="20"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button 
                className="flex-1"
                onClick={() => {
                  handleTrainingAction('create-program', { clanId });
                  setIsCreateProgramOpen(false);
                }}
              >
                <Plus className="w-4 h-4 ml-2" />
                ایجاد برنامه
              </Button>
              <Button variant="outline" onClick={() => setIsCreateProgramOpen(false)}>
                انصراف
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default ClanTrainingSystem;