import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Send, Crown, Shield, Sword, Users, Settings, 
  Volume2, VolumeX, Pin, MoreVertical, Hash,
  Smile, Image, Paperclip, Reply, Heart, ThumbsUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import { useResponsive } from '../../hooks/useResponsive';
import { Clan } from '../providers/ClanProvider';

interface ClanMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderRole: 'leader' | 'co-leader' | 'officer' | 'member';
  content: string;
  timestamp: string;
  type: 'text' | 'image' | 'system' | 'announcement';
  reactions?: {
    [emoji: string]: {
      count: number;
      users: string[];
    };
  };
  replyTo?: {
    id: string;
    senderName: string;
    content: string;
  };
  isPinned?: boolean;
}

interface ClanChatSystemProps {
  clan: Clan;
  currentUserId: string;
  currentUserRole: 'leader' | 'co-leader' | 'officer' | 'member';
  onClose?: () => void;
  isMinimized?: boolean;
  onToggleMinimize?: () => void;
  className?: string;
}

export function ClanChatSystem({ 
  clan, 
  currentUserId, 
  currentUserRole,
  onClose, 
  isMinimized = false,
  onToggleMinimize,
  className = ""
}: ClanChatSystemProps) {
  const { isMobile, isTablet } = useResponsive();
  const [messages, setMessages] = useState<ClanMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [replyTo, setReplyTo] = useState<ClanMessage | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isTyping, setIsTyping] = useState<string[]>([]);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Mock initial messages
  useEffect(() => {
    const mockMessages: ClanMessage[] = [
      {
        id: 'msg-1',
        senderId: 'leader-1',
        senderName: 'شیر_طلایی',
        senderAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=64',
        senderRole: 'leader',
        content: 'سلام به همه! امروز مسابقه مهمی داریم. همه آماده باشید 🏆',
        timestamp: '2 ساعت پیش',
        type: 'text',
        reactions: {
          '🔥': { count: 5, users: ['user1', 'user2', 'user3', 'user4', 'user5'] },
          '👍': { count: 3, users: ['user6', 'user7', 'user8'] }
        },
        isPinned: true
      },
      {
        id: 'msg-2',
        senderId: 'member-2',
        senderName: 'عقاب_سریع',
        senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64',
        senderRole: 'co-leader',
        content: 'بچه‌ها کی می‌تونه امشب تمرین بیاد؟',
        timestamp: '1 ساعت پیش',
        type: 'text',
        reactions: {
          '✋': { count: 4, users: ['user1', 'user3', 'user5', 'user9'] }
        }
      },
      {
        id: 'msg-3',
        senderId: 'system',
        senderName: 'سیستم',
        senderAvatar: '',
        senderRole: 'member',
        content: 'باز_جدید به کلن پیوست!',
        timestamp: '30 دقیقه پیش',
        type: 'system'
      },
      {
        id: 'msg-4',
        senderId: 'member-3',
        senderName: 'پلنگ_آبی',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64',
        senderRole: 'officer',
        content: 'من حاضرم! بیایید این مسابقه رو ببریم 💪',
        timestamp: '15 دقیقه پیش',
        type: 'text',
        replyTo: {
          id: 'msg-1',
          senderName: 'شیر_طلایی',
          content: 'سلام به همه! امروز مسابقه مهمی داریم...'
        }
      }
    ];
    setMessages(mockMessages);
  }, []);

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'leader': return <Crown className="w-3 h-3 text-yellow-500" />;
      case 'co-leader': return <Shield className="w-3 h-3 text-orange-500" />;
      case 'officer': return <Sword className="w-3 h-3 text-blue-500" />;
      default: return null;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'leader': return 'text-yellow-500';
      case 'co-leader': return 'text-orange-500';
      case 'officer': return 'text-blue-500';
      default: return 'text-gray-400';
    }
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const message: ClanMessage = {
      id: `msg-${Date.now()}`,
      senderId: currentUserId,
      senderName: 'شما', // در حالت واقعی از user state می‌آید
      senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=64',
      senderRole: currentUserRole,
      content: newMessage.trim(),
      timestamp: 'الان',
      type: 'text',
      replyTo: replyTo ? {
        id: replyTo.id,
        senderName: replyTo.senderName,
        content: replyTo.content.length > 50 ? replyTo.content.substring(0, 50) + '...' : replyTo.content
      } : undefined
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');
    setReplyTo(null);
    
    // Auto scroll to bottom
    setTimeout(() => {
      if (scrollAreaRef.current) {
        scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
      }
    }, 100);

    toast.success('پیام ارسال شد');
  };

  const handleReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const reactions = { ...msg.reactions };
        if (reactions[emoji]) {
          if (reactions[emoji].users.includes(currentUserId)) {
            reactions[emoji].count--;
            reactions[emoji].users = reactions[emoji].users.filter(u => u !== currentUserId);
            if (reactions[emoji].count === 0) {
              delete reactions[emoji];
            }
          } else {
            reactions[emoji].count++;
            reactions[emoji].users.push(currentUserId);
          }
        } else {
          reactions[emoji] = { count: 1, users: [currentUserId] };
        }
        return { ...msg, reactions };
      }
      return msg;
    }));
  };

  const handleReply = (message: ClanMessage) => {
    setReplyTo(message);
    inputRef.current?.focus();
  };

  const canManageMessages = currentUserRole === 'leader' || currentUserRole === 'co-leader';

  if (isMinimized) {
    return (
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className={`fixed bottom-4 right-4 z-50 ${className}`}
      >
        <Button
          onClick={onToggleMinimize}
          className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 shadow-lg"
          style={{ 
            padding: isMobile ? 'var(--spacing-sm)' : 'var(--spacing-md)',
            borderRadius: 'var(--radius-lg)'
          }}
        >
          <Hash className="w-4 h-4 ml-2" />
          چت {clan.name}
          {messages.length > 0 && (
            <Badge variant="destructive" className="mr-2 px-1 min-w-[20px] h-5">
              {messages.length}
            </Badge>
          )}
        </Button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={`bg-card border rounded-lg shadow-xl ${className}`}
      style={{
        width: isMobile ? '100%' : '400px',
        height: isMobile ? '100vh' : '600px',
        maxHeight: isMobile ? '100vh' : '600px'
      }}
      dir="rtl"
    >
      {/* Chat Header */}
      <CardHeader 
        className="border-b bg-gradient-to-r from-blue-500/10 to-purple-500/10"
        style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="w-8 h-8">
              <AvatarImage src={clan.logo} />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                {clan.tag}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle 
                className="flex items-center gap-2"
                style={{ 
                  fontSize: isMobile ? 'var(--font-size-body-1)' : 'var(--font-size-heading-3)',
                  fontWeight: 'var(--font-weight-semibold)'
                }}
              >
                <Hash className="w-4 h-4 text-blue-400" />
                {clan.name}
              </CardTitle>
              <div 
                className="flex items-center gap-2 text-muted-foreground"
                style={{ fontSize: 'var(--font-size-caption)' }}
              >
                <Users className="w-3 h-3" />
                {clan.members.current} عضو آنلاین
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMuted(!isMuted)}
              className="p-1"
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 text-muted-foreground" />
              ) : (
                <Volume2 className="w-4 h-4 text-green-400" />
              )}
            </Button>
            
            {onToggleMinimize && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleMinimize}
                className="p-1"
              >
                <MoreVertical className="w-4 h-4" />
              </Button>
            )}
            
            {onClose && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="p-1"
              >
                ✕
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      {/* Messages Area */}
      <CardContent 
        className="flex-1 p-0 overflow-hidden"
        style={{ height: 'calc(100% - 140px)' }}
      >
        <ScrollArea 
          ref={scrollAreaRef}
          className="h-full"
          style={{ padding: isMobile ? 'var(--spacing-md)' : 'var(--spacing-lg)' }}
        >
          <div 
            style={{ 
              display: 'flex',
              flexDirection: 'column',
              gap: 'var(--spacing-md)'
            }}
          >
            <AnimatePresence>
              {messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {message.type === 'system' ? (
                    <div className="text-center py-2">
                      <Badge variant="outline" className="bg-blue-500/10 text-blue-400">
                        {message.content}
                      </Badge>
                    </div>
                  ) : (
                    <div className={`flex gap-3 ${message.senderId === currentUserId ? 'flex-row-reverse' : ''}`}>
                      <Avatar className="w-8 h-8 flex-shrink-0">
                        <AvatarImage src={message.senderAvatar} />
                        <AvatarFallback>{message.senderName[0]}</AvatarFallback>
                      </Avatar>
                      
                      <div className={`flex-1 ${message.senderId === currentUserId ? 'text-left' : ''}`}>
                        {/* Sender Info */}
                        <div className="flex items-center gap-2 mb-1">
                          <span 
                            className={`${getRoleColor(message.senderRole)}`}
                            style={{ 
                              fontSize: 'var(--font-size-caption)',
                              fontWeight: 'var(--font-weight-medium)'
                            }}
                          >
                            {message.senderName}
                          </span>
                          {getRoleIcon(message.senderRole)}
                          {message.isPinned && <Pin className="w-3 h-3 text-yellow-500" />}
                          <span 
                            className="text-muted-foreground"
                            style={{ fontSize: 'var(--font-size-caption)' }}
                          >
                            {message.timestamp}
                          </span>
                        </div>

                        {/* Reply Context */}
                        {message.replyTo && (
                          <div className="bg-muted/30 border-r-2 border-blue-500 pr-3 py-1 mb-2 rounded">
                            <div 
                              className="text-blue-400"
                              style={{ fontSize: 'var(--font-size-caption)' }}
                            >
                              پاسخ به {message.replyTo.senderName}
                            </div>
                            <div 
                              className="text-muted-foreground truncate"
                              style={{ fontSize: 'var(--font-size-caption)' }}
                            >
                              {message.replyTo.content}
                            </div>
                          </div>
                        )}

                        {/* Message Content */}
                        <div 
                          className={`p-3 rounded-lg ${
                            message.senderId === currentUserId 
                              ? 'bg-blue-500 text-white ml-8' 
                              : 'bg-muted/50'
                          }`}
                        >
                          <p 
                            style={{ 
                              fontSize: 'var(--font-size-body-2)',
                              lineHeight: 'var(--line-height-base)'
                            }}
                          >
                            {message.content}
                          </p>
                        </div>

                        {/* Reactions */}
                        {message.reactions && Object.keys(message.reactions).length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {Object.entries(message.reactions).map(([emoji, data]) => (
                              <Button
                                key={emoji}
                                variant="outline"
                                size="sm"
                                onClick={() => handleReaction(message.id, emoji)}
                                className={`h-6 px-2 ${
                                  data.users.includes(currentUserId) 
                                    ? 'bg-blue-500/20 border-blue-500/50' 
                                    : ''
                                }`}
                              >
                                <span className="text-sm">{emoji}</span>
                                <span 
                                  className="mr-1"
                                  style={{ fontSize: 'var(--font-size-caption)' }}
                                >
                                  {data.count}
                                </span>
                              </Button>
                            ))}
                          </div>
                        )}

                        {/* Message Actions */}
                        {message.senderId !== currentUserId && (
                          <div className="flex gap-1 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleReaction(message.id, '👍')}
                              className="h-6 px-2"
                            >
                              <ThumbsUp className="w-3 h-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleReaction(message.id, '❤️')}
                              className="h-6 px-2"
                            >
                              <Heart className="w-3 h-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleReply(message)}
                              className="h-6 px-2"
                            >
                              <Reply className="w-3 h-3" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Typing Indicator */}
            {isTyping.length > 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 text-muted-foreground"
              >
                <div className="flex gap-1">
                  <div className="w-1 h-1 bg-blue-400 rounded-full animate-bounce" />
                  <div className="w-1 h-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                  <div className="w-1 h-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                </div>
                <span style={{ fontSize: 'var(--font-size-caption)' }}>
                  {isTyping.join(', ')} در حال تایپ...
                </span>
              </motion.div>
            )}
          </div>
        </ScrollArea>
      </CardContent>

      <Separator />

      {/* Reply Preview */}
      {replyTo && (
        <div 
          className="bg-muted/30 border-t px-4 py-2 flex items-center justify-between"
        >
          <div className="flex-1 min-w-0">
            <div 
              className="text-blue-400"
              style={{ fontSize: 'var(--font-size-caption)' }}
            >
              پاسخ به {replyTo.senderName}
            </div>
            <div 
              className="text-muted-foreground truncate"
              style={{ fontSize: 'var(--font-size-caption)' }}
            >
              {replyTo.content}
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setReplyTo(null)}
            className="p-1"
          >
            ✕
          </Button>
        </div>
      )}

      {/* Message Input */}
      <div 
        className="border-t p-4"
        style={{ padding: 'var(--spacing-md)' }}
      >
        <div className="flex gap-2">
          <Input
            ref={inputRef}
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="پیام خود را بنویسید..."
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            className="flex-1"
            style={{ fontSize: 'var(--font-size-body-2)' }}
          />
          
          <Button
            variant="ghost"
            size="sm"
            className="p-2"
          >
            <Smile className="w-4 h-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="p-2"
          >
            <Paperclip className="w-4 h-4" />
          </Button>
          
          <Button
            onClick={handleSendMessage}
            disabled={!newMessage.trim()}
            className="bg-blue-500 hover:bg-blue-600"
            size="sm"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}