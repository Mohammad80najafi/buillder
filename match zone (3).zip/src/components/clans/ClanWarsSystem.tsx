import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { 
  Swords, Shield, Crown, Trophy, Target, Clock, Users, Zap,
  Star, Flame, AlertTriangle, CheckCircle, XCircle, Eye,
  Play, Pause, BarChart3, TrendingUp, Award, Medal,
  Sword, ArrowUp, ArrowDown, Calendar, MapPin, Flag
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';

export interface ClanWarMatch {
  id: string;
  attackerClan: {
    id: string;
    name: string;
    logo: string;
    level: number;
    members: number;
  };
  defenderClan: {
    id: string;
    name: string;
    logo: string;
    level: number;
    members: number;
  };
  startTime: string;
  endTime: string;
  status: 'upcoming' | 'preparation' | 'battle' | 'finished';
  preparationHours: number;
  battleHours: number;
  winCondition: 'destruction' | 'stars' | 'time';
  prizes: {
    winner: { gold: number; experience: number; trophies: number };
    loser: { gold: number; experience: number; trophies: number };
  };
  currentScore: {
    attacker: { stars: number; destruction: number; attacks: number };
    defender: { stars: number; destruction: number; attacks: number };
  };
  maxAttacksPerMember: number;
  allowedStrategies: string[];
}

export interface ClanWarSeason {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  status: 'active' | 'ended' | 'upcoming';
  participants: number;
  prizePool: {
    first: { gold: number; gems: number; title: string };
    second: { gold: number; gems: number; title: string };
    third: { gold: number; gems: number; title: string };
  };
  leaderboard: Array<{
    rank: number;
    clan: {
      id: string;
      name: string;
      logo: string;
    };
    wins: number;
    losses: number;
    winRate: number;
    totalStars: number;
    trophies: number;
  }>;
}

export interface ClanWarSystemProps {
  clanId: string;
  onWarAction?: (action: string, data: any) => void;
  className?: string;
}

const MOCK_WARS: ClanWarMatch[] = [
  {
    id: '1',
    attackerClan: {
      id: 'clan1',
      name: 'شیران پارس',
      logo: '/clan-logos/shirane-pars.png',
      level: 15,
      members: 48
    },
    defenderClan: {
      id: 'clan2',
      name: 'عقاب‌های طلایی',
      logo: '/clan-logos/golden-eagles.png',
      level: 13,
      members: 42
    },
    startTime: '2024-12-25T20:00:00Z',
    endTime: '2024-12-27T20:00:00Z',
    status: 'battle',
    preparationHours: 24,
    battleHours: 24,
    winCondition: 'stars',
    prizes: {
      winner: { gold: 50000, experience: 2500, trophies: 100 },
      loser: { gold: 20000, experience: 1000, trophies: -50 }
    },
    currentScore: {
      attacker: { stars: 127, destruction: 89.5, attacks: 35 },
      defender: { stars: 134, destruction: 91.2, attacks: 38 }
    },
    maxAttacksPerMember: 2,
    allowedStrategies: ['سنتی', 'سریع', 'دفاعی']
  },
  {
    id: '2',
    attackerClan: {
      id: 'clan3',
      name: 'نینجاهای سایه',
      logo: '/clan-logos/shadow-ninjas.png',
      level: 12,
      members: 35
    },
    defenderClan: {
      id: 'clan1',
      name: 'شیران پارس',
      logo: '/clan-logos/shirane-pars.png',
      level: 15,
      members: 48
    },
    startTime: '2024-12-28T18:00:00Z',
    endTime: '2024-12-30T18:00:00Z',
    status: 'upcoming',
    preparationHours: 24,
    battleHours: 24,
    winCondition: 'destruction',
    prizes: {
      winner: { gold: 45000, experience: 2200, trophies: 80 },
      loser: { gold: 18000, experience: 900, trophies: -40 }
    },
    currentScore: {
      attacker: { stars: 0, destruction: 0, attacks: 0 },
      defender: { stars: 0, destruction: 0, attacks: 0 }
    },
    maxAttacksPerMember: 2,
    allowedStrategies: ['تمام استراتژی‌ها']
  }
];

const MOCK_SEASON: ClanWarSeason = {
  id: 'season-winter-2024',
  name: 'فصل زمستان ۱۴۰۳',
  startDate: '2024-12-01T00:00:00Z',
  endDate: '2025-03-01T00:00:00Z',
  status: 'active',
  participants: 156,
  prizePool: {
    first: { gold: 1000000, gems: 5000, title: 'شاهان زمستان' },
    second: { gold: 600000, gems: 3000, title: 'شاهزادگان یخی' },
    third: { gold: 300000, gems: 1500, title: 'جنگجویان سرما' }
  },
  leaderboard: [
    {
      rank: 1,
      clan: { id: '1', name: 'شیران پارس', logo: '/clan-logos/shirane-pars.png' },
      wins: 24,
      losses: 3,
      winRate: 88.9,
      totalStars: 2456,
      trophies: 3890
    },
    {
      rank: 2,
      clan: { id: '2', name: 'عقاب‌های طلایی', logo: '/clan-logos/golden-eagles.png' },
      wins: 22,
      losses: 5,
      winRate: 81.5,
      totalStars: 2298,
      trophies: 3654
    },
    {
      rank: 3,
      clan: { id: '3', name: 'نینجاهای سایه', logo: '/clan-logos/shadow-ninjas.png' },
      wins: 20,
      losses: 7,
      winRate: 74.1,
      totalStars: 2156,
      trophies: 3421
    }
  ]
};

export function ClanWarsSystem({ clanId, onWarAction, className }: ClanWarSystemProps) {
  const [activeTab, setActiveTab] = useState('active-wars');
  const [wars] = useState<ClanWarMatch[]>(MOCK_WARS);
  const [season] = useState<ClanWarSeason>(MOCK_SEASON);
  const [selectedWar, setSelectedWar] = useState<ClanWarMatch | null>(null);
  const [isAttackDialogOpen, setIsAttackDialogOpen] = useState(false);

  const getWarStatusColor = (status: ClanWarMatch['status']) => {
    switch (status) {
      case 'upcoming': return 'bg-blue-500';
      case 'preparation': return 'bg-yellow-500';
      case 'battle': return 'bg-red-500';
      case 'finished': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getWarStatusText = (status: ClanWarMatch['status']) => {
    switch (status) {
      case 'upcoming': return 'در انتظار';
      case 'preparation': return 'آماده‌سازی';
      case 'battle': return 'نبرد';
      case 'finished': return 'پایان یافته';
      default: return 'نامشخص';
    }
  };

  const formatTimeRemaining = (endTime: string) => {
    const now = new Date().getTime();
    const end = new Date(endTime).getTime();
    const remaining = end - now;
    
    if (remaining <= 0) return 'پایان یافته';
    
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}:${minutes.toString().padStart(2, '0')}`;
  };

  const handleWarAction = (action: string, data: any) => {
    onWarAction?.(action, data);
    toast.success(`عملیات "${action}" انجام شد`);
  };

  const WarCard = ({ war }: { war: ClanWarMatch }) => (
    <Card className="border-2 hover:border-blue-500/50 transition-all duration-200">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${getWarStatusColor(war.status)} animate-pulse`} />
            <Badge variant="outline" className="text-xs">
              {getWarStatusText(war.status)}
            </Badge>
          </div>
          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" />
            {formatTimeRemaining(war.endTime)}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Clans */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="w-12 h-12">
              <AvatarImage src={war.attackerClan.logo} />
              <AvatarFallback>{war.attackerClan.name.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{war.attackerClan.name}</p>
              <p className="text-xs text-muted-foreground">
                سطح {war.attackerClan.level} • {war.attackerClan.members} عضو
              </p>
            </div>
          </div>

          <div className="text-center">
            <Swords className="w-6 h-6 text-orange-500 mx-auto" />
            <p className="text-xs text-muted-foreground mt-1">VS</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="font-medium">{war.defenderClan.name}</p>
              <p className="text-xs text-muted-foreground">
                سطح {war.defenderClan.level} • {war.defenderClan.members} عضو
              </p>
            </div>
            <Avatar className="w-12 h-12">
              <AvatarImage src={war.defenderClan.logo} />
              <AvatarFallback>{war.defenderClan.name.slice(0, 2)}</AvatarFallback>
            </Avatar>
          </div>
        </div>

        {/* Score */}
        {war.status !== 'upcoming' && (
          <div className="space-y-2">
            <div className="flex justify-between items-center text-sm">
              <span>ستاره‌ها</span>
              <span className="font-mono">
                {war.currentScore.attacker.stars} - {war.currentScore.defender.stars}
              </span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span>تخریب</span>
              <span className="font-mono">
                {war.currentScore.attacker.destruction}% - {war.currentScore.defender.destruction}%
              </span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span>حمله‌ها</span>
              <span className="font-mono">
                {war.currentScore.attacker.attacks} - {war.currentScore.defender.attacks}
              </span>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="flex-1"
            onClick={() => setSelectedWar(war)}
          >
            <Eye className="w-4 h-4 ml-2" />
            مشاهده
          </Button>
          
          {war.status === 'battle' && (
            <Button 
              size="sm" 
              className="flex-1 bg-red-600 hover:bg-red-700"
              onClick={() => setIsAttackDialogOpen(true)}
            >
              <Sword className="w-4 h-4 ml-2" />
              حمله
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );

  const LeaderboardRow = ({ entry }: { entry: ClanWarSeason['leaderboard'][0] }) => (
    <div className="flex items-center gap-4 p-4 rounded-lg bg-card border hover:bg-accent/5 transition-colors">
      <div className="flex items-center gap-3">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
          entry.rank === 1 ? 'bg-yellow-500 text-black' :
          entry.rank === 2 ? 'bg-gray-300 text-black' :
          entry.rank === 3 ? 'bg-orange-600 text-white' :
          'bg-muted text-muted-foreground'
        }`}>
          {entry.rank}
        </div>
        <Avatar className="w-10 h-10">
          <AvatarImage src={entry.clan.logo} />
          <AvatarFallback>{entry.clan.name.slice(0, 2)}</AvatarFallback>
        </Avatar>
        <div>
          <p className="font-medium">{entry.clan.name}</p>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Trophy className="w-3 h-3" />
            {entry.trophies.toLocaleString()}
          </div>
        </div>
      </div>

      <div className="mr-auto grid grid-cols-3 gap-6 text-sm">
        <div className="text-center">
          <p className="font-medium text-green-500">{entry.wins}</p>
          <p className="text-muted-foreground">برد</p>
        </div>
        <div className="text-center">
          <p className="font-medium text-red-500">{entry.losses}</p>
          <p className="text-muted-foreground">باخت</p>
        </div>
        <div className="text-center">
          <p className="font-medium">{entry.winRate.toFixed(1)}%</p>
          <p className="text-muted-foreground">نرخ برد</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className={`space-y-6 ${className || ''}`} dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-red-500/10 to-orange-500/10 border-red-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-500/20 rounded-lg">
                <Swords className="w-6 h-6 text-red-400" />
              </div>
              <div>
                <CardTitle className="text-xl">جنگ کلن‌ها</CardTitle>
                <p className="text-muted-foreground text-sm">
                  مبارزات حماسی بین کلن‌ها و کسب جوایز ارزشمند
                </p>
              </div>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-500">{season.name}</p>
              <p className="text-sm text-muted-foreground">{season.participants} کلن شرکت‌کننده</p>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="active-wars" className="flex items-center gap-2">
            <Flame className="w-4 h-4" />
            جنگ‌های فعال
          </TabsTrigger>
          <TabsTrigger value="leaderboard" className="flex items-center gap-2">
            <Trophy className="w-4 h-4" />
            رتبه‌بندی
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            تاریخچه
          </TabsTrigger>
        </TabsList>

        {/* Active Wars Tab */}
        <TabsContent value="active-wars" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {wars.map((war) => (
              <WarCard key={war.id} war={war} />
            ))}
          </div>

          {wars.length === 0 && (
            <Card className="p-8 text-center">
              <div className="space-y-4">
                <Swords className="w-16 h-16 text-muted-foreground/50 mx-auto" />
                <div>
                  <h3 className="text-lg font-semibold">هیچ جنگی در حال انجام نیست</h3>
                  <p className="text-muted-foreground">
                    منتظر جنگ‌های جدید باشید یا از طریق کلن خود درخواست جنگ دهید
                  </p>
                </div>
                <Button onClick={() => handleWarAction('request-war', { clanId })}>
                  درخواست جنگ جدید
                </Button>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* Leaderboard Tab */}
        <TabsContent value="leaderboard" className="space-y-4">
          {/* Season Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-yellow-500" />
                {season.name}
              </CardTitle>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">جایزه اول</p>
                  <div className="flex items-center gap-1 font-medium">
                    <Medal className="w-4 h-4 text-yellow-500" />
                    {season.prizePool.first.gold.toLocaleString()} طلا
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground">جایزه دوم</p>
                  <div className="flex items-center gap-1 font-medium">
                    <Medal className="w-4 h-4 text-gray-400" />
                    {season.prizePool.second.gold.toLocaleString()} طلا
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground">جایزه سوم</p>
                  <div className="flex items-center gap-1 font-medium">
                    <Medal className="w-4 h-4 text-orange-600" />
                    {season.prizePool.third.gold.toLocaleString()} طلا
                  </div>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                رتبه‌بندی کلن‌ها
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {season.leaderboard.map((entry) => (
                <LeaderboardRow key={entry.clan.id} entry={entry} />
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-4">
          <Card className="p-8 text-center">
            <div className="space-y-4">
              <Calendar className="w-16 h-16 text-muted-foreground/50 mx-auto" />
              <div>
                <h3 className="text-lg font-semibold">تاریخچه جنگ‌ها</h3>
                <p className="text-muted-foreground">
                  تاریخچه کامل جنگ‌های کلن شما در این بخش نمایش داده خواهد شد
                </p>
              </div>
              <Button variant="outline">
                مشاهده تاریخچه کامل
              </Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* War Details Modal */}
      <Dialog open={!!selectedWar} onOpenChange={() => setSelectedWar(null)}>
        <DialogContent className="max-w-4xl" dir="rtl">
          {selectedWar && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Swords className="w-5 h-5" />
                  جزئیات جنگ
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                {/* War Overview */}
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={selectedWar.attackerClan.logo} />
                          <AvatarFallback>{selectedWar.attackerClan.name.slice(0, 2)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{selectedWar.attackerClan.name}</p>
                          <p className="text-sm text-muted-foreground">مهاجم</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={selectedWar.defenderClan.logo} />
                          <AvatarFallback>{selectedWar.defenderClan.name.slice(0, 2)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{selectedWar.defenderClan.name}</p>
                          <p className="text-sm text-muted-foreground">مدافع</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Live Score */}
                {selectedWar.status !== 'upcoming' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-center">امتیاز زنده</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="text-center text-4xl font-bold">
                          {selectedWar.currentScore.attacker.stars} - {selectedWar.currentScore.defender.stars}
                        </div>
                        <Progress 
                          value={selectedWar.currentScore.attacker.destruction} 
                          className="h-3" 
                        />
                        <div className="grid grid-cols-3 gap-4 text-sm text-center">
                          <div>
                            <p className="font-medium">{selectedWar.currentScore.attacker.attacks}</p>
                            <p className="text-muted-foreground">حمله‌های مهاجم</p>
                          </div>
                          <div>
                            <p className="font-medium">{selectedWar.currentScore.attacker.destruction}%</p>
                            <p className="text-muted-foreground">تخریب</p>
                          </div>
                          <div>
                            <p className="font-medium">{selectedWar.currentScore.defender.attacks}</p>
                            <p className="text-muted-foreground">حمله‌های مدافع</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* War Info */}
                <div className="grid grid-cols-2 gap-4">
                  <Card>
                    <CardContent className="p-4 space-y-2">
                      <h4 className="font-medium">اطلاعات جنگ</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>وضعیت:</span>
                          <Badge>{getWarStatusText(selectedWar.status)}</Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>شرط برد:</span>
                          <span>{selectedWar.winCondition === 'stars' ? 'ستاره‌ها' : 'تخریب'}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>حمله در نفر:</span>
                          <span>{selectedWar.maxAttacksPerMember}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4 space-y-2">
                      <h4 className="font-medium">جوایز</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span>برنده:</span>
                          <span>{selectedWar.prizes.winner.gold.toLocaleString()} طلا</span>
                        </div>
                        <div className="flex justify-between">
                          <span>بازنده:</span>
                          <span>{selectedWar.prizes.loser.gold.toLocaleString()} طلا</span>
                        </div>
                        <div className="flex justify-between">
                          <span>تجربه:</span>
                          <span>{selectedWar.prizes.winner.experience.toLocaleString()}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Attack Dialog */}
      <Dialog open={isAttackDialogOpen} onOpenChange={setIsAttackDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sword className="w-5 h-5 text-red-500" />
              تدوین استراتژی حمله
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>نوع استراتژی</Label>
              <p className="text-sm text-muted-foreground mb-2">
                استراتژی حمله خود را انتخاب کنید
              </p>
              <div className="grid grid-cols-3 gap-2">
                <Button variant="outline" size="sm">سنتی</Button>
                <Button variant="outline" size="sm">سریع</Button>
                <Button variant="outline" size="sm">دفاعی</Button>
              </div>
            </div>
            
            <div>
              <Label htmlFor="target">هدف حمله</Label>
              <Input 
                id="target"
                placeholder="شماره پایگاه مورد نظر (1-50)"
                type="number"
                min="1"
                max="50"
              />
            </div>

            <div>
              <Label htmlFor="strategy-notes">یادداشت‌های استراتژی</Label>
              <Textarea 
                id="strategy-notes"
                placeholder="توضیحات اضافی برای تیم..."
                rows={3}
              />
            </div>

            <div className="flex gap-2">
              <Button className="flex-1 bg-red-600 hover:bg-red-700">
                <Flame className="w-4 h-4 ml-2" />
                شروع حمله
              </Button>
              <Button variant="outline" onClick={() => setIsAttackDialogOpen(false)}>
                انصراف
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default ClanWarsSystem;