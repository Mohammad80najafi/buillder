import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Separator } from '../ui/separator';
import { Checkbox } from '../ui/checkbox';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { 
  Shield, Crown, Upload, Eye, EyeOff, Lock, Unlock, 
  Users, DollarSign, Star, Flag, Palette, Image,
  CheckCircle, AlertCircle, Info, Zap, Trophy, Target, UserPlus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';
import { ClanMemberInvite } from './ClanMemberInvite';
import { useNavigation } from '../navigation/NavigationProvider';
import { useClan } from '../providers/ClanProvider';

export interface ClanCreationData {
  name: string;
  tag: string;
  description: string;
  logo?: File;
  banner?: File;
  type: 'public' | 'private' | 'invite-only';
  region: string;
  gameTypes: string[];
  requirements: {
    minLevel: number;
    minAge: number;
    gender: 'male' | 'female' | 'all';
  };
  settings: {
    autoAccept: boolean;
    allowInvites: boolean;
    showStats: boolean;
  };
  cost: number;
}

export interface ClanCreationProps {
  onCreateClan: (data: ClanCreationData) => void;
  userBalance: number;
  userLevel: number;
  userTrophies: number;
}

const CLAN_CREATION_COST = 50000; // تومان
const AVAILABLE_REGIONS = [
  'سراسر ایران',
  'آذربایجان شرقی',
  'آذربایجان غربی', 
  'اردبیل',
  'اصفهان',
  'البرز',
  'ایلام',
  'بوشهر',
  'تهران',
  'چهارمحال و بختیاری',
  'خراسان جنوبی',
  'خراسان رضوی',
  'خراسان شمالی',
  'خوزستان',
  'زنجان',
  'سمنان',
  'سیستان و بلوچستان',
  'فارس',
  'قزوین',
  'قم',
  'کردستان',
  'کرمان',
  'کرمانشاه',
  'کهگیلویه و بویراحمد',
  'گلستان',
  'گیلان',
  'لرستان',
  'مازندران',
  'مرکزی',
  'هرمزگان',
  'همدان',
  'یزد'
];
const AVAILABLE_GAME_TYPES = [
  'کالاف دیوتی', 'فیفا', 'والورانت', 'لیگ آف لجندز', 'Counter-Strike', 'Fortnite', 
  'PUBG', 'Apex Legends', 'Rocket League', 'Overwatch'
];

export function ClanCreation({ onCreateClan, userBalance, userLevel, userTrophies }: ClanCreationProps) {
  const { navigate } = useNavigation();
  const { addClan } = useClan();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<ClanCreationData>({
    name: '',
    tag: '',
    description: '',
    type: 'public',
    region: 'تهران',
    gameTypes: [],
    requirements: {
      minLevel: 1,
      minAge: 16,
      gender: 'all'
    },
    settings: {
      autoAccept: true,
      allowInvites: true,
      showStats: true
    },
    cost: CLAN_CREATION_COST
  });
  
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [bannerPreview, setBannerPreview] = useState<string>('');
  const [tagAvailable, setTagAvailable] = useState<boolean | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [open, setOpen] = useState(false);

  const canAfford = userBalance >= CLAN_CREATION_COST;
  const meetsRequirements = userLevel >= 10; // حداقل سطح برای ایجاد کلن

  const validateStep = (stepNumber: number) => {
    const newErrors: Record<string, string> = {};
    
    if (stepNumber === 1) {
      if (!formData.name.trim()) newErrors.name = 'نام کلن الزامی است';
      if (formData.name.length < 3) newErrors.name = 'نام کلن باید حداقل 3 حرف باشد';
      if (formData.name.length > 30) newErrors.name = 'نام کلن نباید بیش از 30 حرف باشد';
      
      if (!formData.tag.trim()) newErrors.tag = 'تگ کلن الزامی است';
      if (formData.tag.length < 2) newErrors.tag = 'تگ باید حداقل 2 حرف باشد';
      if (formData.tag.length > 6) newErrors.tag = 'تگ نباید بیش از 6 حرف باشد';
      if (!/^[A-Za-z0-9]+$/.test(formData.tag)) newErrors.tag = 'تگ فقط حروف انگلیسی و اعداد';
      
      if (!formData.description.trim()) newErrors.description = 'توضیحات الزامی است';
      if (formData.description.length < 10) newErrors.description = 'توضیحات باید حداقل 10 حرف باشد';
    }
    
    if (stepNumber === 2) {
      if (formData.gameTypes.length === 0) newErrors.gameTypes = 'حداقل یک نوع بازی انتخاب کنید';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    }
  };

  const handlePrevStep = () => {
    setStep(step - 1);
  };

  const handleTagChange = async (value: string) => {
    const upperTag = value.toUpperCase();
    setFormData({ ...formData, tag: upperTag });
    
    if (upperTag.length >= 2) {
      // Simulate tag availability check
      setTagAvailable(null);
      setTimeout(() => {
        // Mock API call - in real app, check with server
        const unavailableTags = ['IRAN', 'GAME', 'CLAN', 'TEAM', 'PRO'];
        setTagAvailable(!unavailableTags.includes(upperTag));
      }, 500);
    } else {
      setTagAvailable(null);
    }
  };

  const handleImageUpload = (file: File, type: 'logo' | 'banner') => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (type === 'logo') {
        setLogoPreview(reader.result as string);
        setFormData({ ...formData, logo: file });
      } else {
        setBannerPreview(reader.result as string);
        setFormData({ ...formData, banner: file });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    if (!validateStep(step)) return;
    if (!canAfford) {
      toast.error('موجودی کافی ندارید', {
        description: `برای ایجاد کلن ${CLAN_CREATION_COST.toLocaleString()} تومان نیاز دارید.`
      });
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Add clan to global state
      const newClan = addClan(formData, 'current-user-id');
      
      // Call parent callback if provided
      onCreateClan(formData);
      
      toast.success('کلن با موفقیت ایجاد شد! 🏰', {
        description: `کلن [${formData.tag}] ${formData.name} آماده است.`
      });
      
      setStep(5); // Success step
    } catch (error) {
      toast.error('خطا در ایجاد کلن', {
        description: 'لطفا دوباره تلاش کنید.'
      });
    }
    
    setIsProcessing(false);
  };

  const getStepIcon = (stepNumber: number) => {
    if (step > stepNumber) return <CheckCircle className="w-5 h-5 text-green-500" />;
    if (step === stepNumber) return <div className="w-5 h-5 rounded-full bg-primary" />;
    return <div className="w-5 h-5 rounded-full bg-muted border-2" />;
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'public': return <Unlock className="w-4 h-4" />;
      case 'private': return <Lock className="w-4 h-4" />;
      case 'invite-only': return <Crown className="w-4 h-4" />;
    }
  };

  const getTypeDescription = (type: string) => {
    switch (type) {
      case 'public': return 'همه می‌توانند درخواست عضویت دهند';
      case 'private': return 'فقط از طریق دعوت قابل پیوستن';
      case 'invite-only': return 'فقط افراد خاص می‌توانند بپیوندند';
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          disabled={!meetsRequirements || !canAfford}
          className="gap-2"
        >
          <Shield className="w-4 h-4" />
          ایجاد کلن
        </Button>
      </DialogTrigger>

      <DialogContent className="w-[95vw] max-w-4xl max-h-[90vh] overflow-y-auto p-3 sm:p-6" dir="rtl">
        <DialogHeader className="pb-2">
          <DialogTitle className="text-right flex items-center gap-2 text-base sm:text-lg">
            <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
            ایجاد کلن جدید
          </DialogTitle>
          <DialogDescription className="text-right text-sm">
            فرایند ایجاد کلن جدید در پلتفرم Matchzone
          </DialogDescription>
        </DialogHeader>

        {/* Requirements Check */}
        {(!meetsRequirements || !canAfford) && (
          <Card className="bg-destructive/5 border-destructive/20 mb-4">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-destructive mt-0.5" />
                <div className="space-y-2">
                  <h4 className="font-medium text-destructive">شرایط ایجاد کلن:</h4>
                  <ul className="space-y-1 text-sm">
                    {!meetsRequirements && (
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-3 h-3 text-red-500" />
                        حداقل سطح 10 (سطح فعلی: {userLevel})
                      </li>
                    )}
                    {!canAfford && (
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-3 h-3 text-red-500" />
                        موجودی {CLAN_CREATION_COST.toLocaleString()} تومان (موجودی فعلی: {userBalance.toLocaleString()})
                      </li>
                    )}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-1 sm:gap-3 py-3 sm:py-4 overflow-x-auto px-1 scrollbar-hide">
          {[1, 2, 3, 4, 5].map((stepNum) => (
            <div key={stepNum} className="flex items-center">
              <div className="flex flex-col items-center min-w-0">
                <div className="flex-shrink-0 mb-1">
                  {getStepIcon(stepNum)}
                </div>
                <span className={`text-[10px] sm:text-xs text-center whitespace-nowrap leading-tight px-1 ${step === stepNum ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                  {stepNum === 1 && 'اطلاعات'}
                  {stepNum === 2 && 'تنظیمات'}
                  {stepNum === 3 && 'تصاویر'}
                  {stepNum === 4 && 'تایید'}
                  {stepNum === 5 && 'تکمیل'}
                </span>
              </div>
              {stepNum < 5 && (
                <div className={`w-3 sm:w-6 h-0.5 mx-1 sm:mx-2 flex-shrink-0 ${step > stepNum ? 'bg-green-500' : 'bg-muted'}`} />
              )}
            </div>
          ))}
        </div>

        <Separator />

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm sm:text-base">اطلاعات اصلی کلن</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 sm:space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="clanName" className="text-sm">نام کلن *</Label>
                      <Input
                        id="clanName"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="نام کلن شما"
                        dir="rtl"
                        className={`h-10 sm:h-11 ${errors.name ? 'border-destructive' : ''}`}
                      />
                      {errors.name && (
                        <p className="text-xs text-destructive">{errors.name}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="clanTag" className="text-sm">تگ کلن *</Label>
                      <div className="relative">
                        <Input
                          id="clanTag"
                          value={formData.tag}
                          onChange={(e) => handleTagChange(e.target.value)}
                          placeholder="TAG"
                          className={`h-10 sm:h-11 ${errors.tag ? 'border-destructive' : ''} uppercase font-bold`}
                          maxLength={6}
                        />
                        <div className="absolute left-2 top-1/2 transform -translate-y-1/2">
                          {tagAvailable === true && <CheckCircle className="w-4 h-4 text-green-500" />}
                          {tagAvailable === false && <AlertCircle className="w-4 h-4 text-destructive" />}
                        </div>
                      </div>
                      {errors.tag && (
                        <p className="text-xs text-destructive">{errors.tag}</p>
                      )}
                      {tagAvailable === false && (
                        <p className="text-xs text-destructive">این تگ قبلاً استفاده شده</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description" className="text-sm">توضیحات کلن *</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({...formData, description: e.target.value})}
                      placeholder="درباره کلن، اهداف و قوانین..."
                      dir="rtl"
                      rows={3}
                      className={`min-h-[80px] ${errors.description ? 'border-destructive' : ''}`}
                    />
                    {errors.description && (
                      <p className="text-xs text-destructive">{errors.description}</p>
                    )}
                    <p className="text-xs text-muted-foreground">
                      {formData.description.length}/500 حرف
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm">استان</Label>
                    <Select value={formData.region} onValueChange={(value) => setFormData({...formData, region: value})}>
                      <SelectTrigger className="h-10 sm:h-11">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {AVAILABLE_REGIONS.map(region => (
                          <SelectItem key={region} value={region}>{region}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              <Button onClick={handleNextStep} className="w-full h-10 sm:h-11" disabled={!formData.name || !formData.tag || !formData.description}>
                مرحله بعد
              </Button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Clan Type */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm sm:text-base">نوع کلن</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 sm:space-y-4">
                  <div className="grid gap-3">
                    {(['public', 'private', 'invite-only'] as const).map((type) => (
                      <div 
                        key={type}
                        className={`
                          p-3 sm:p-4 border rounded-lg cursor-pointer transition-all touch-manipulation
                          ${formData.type === type ? 'border-primary bg-primary/5' : 'border-muted hover:border-primary/50'}
                        `}
                        onClick={() => setFormData({...formData, type})}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-full flex-shrink-0 ${formData.type === type ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                            {getTypeIcon(type)}
                          </div>
                          <div className="min-w-0">
                            <div className="font-medium text-sm sm:text-base">
                              {type === 'public' && 'عمومی'}
                              {type === 'private' && 'خصوصی'}
                              {type === 'invite-only' && 'فقط دعوت'}
                            </div>
                            <div className="text-xs sm:text-sm text-muted-foreground">
                              {getTypeDescription(type)}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Game Types */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm sm:text-base">انواع بازی *</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {AVAILABLE_GAME_TYPES.map((game) => (
                      <div key={game} className="flex items-center space-x-2 p-2 hover:bg-muted/30 rounded-md touch-manipulation">
                        <Checkbox
                          id={game}
                          checked={formData.gameTypes.includes(game)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData({...formData, gameTypes: [...formData.gameTypes, game]});
                            } else {
                              setFormData({...formData, gameTypes: formData.gameTypes.filter(g => g !== game)});
                            }
                          }}
                        />
                        <Label htmlFor={game} className="text-sm cursor-pointer flex-1">{game}</Label>
                      </div>
                    ))}
                  </div>
                  {errors.gameTypes && (
                    <p className="text-xs text-destructive mt-3">{errors.gameTypes}</p>
                  )}
                </CardContent>
              </Card>

              {/* Requirements */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm sm:text-base">شرایط عضویت</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-sm">حداقل سطح</Label>
                      <Input
                        type="number"
                        min="1"
                        max="100"
                        value={formData.requirements.minLevel}
                        onChange={(e) => setFormData({
                          ...formData, 
                          requirements: { 
                            ...formData.requirements,
                            minLevel: parseInt(e.target.value) || 1 
                          }
                        })}
                        placeholder="حداقل سطح برای عضویت"
                        className="h-10 sm:h-11"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm">حداقل سن</Label>
                      <Input
                        type="number"
                        min="13"
                        max="99"
                        value={formData.requirements.minAge}
                        onChange={(e) => setFormData({
                          ...formData, 
                          requirements: { 
                            ...formData.requirements,
                            minAge: parseInt(e.target.value) || 16 
                          }
                        })}
                        placeholder="حداقل سن برای عضویت"
                        className="h-10 sm:h-11"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-sm">جنسیت</Label>
                    <Select 
                      value={formData.requirements.gender} 
                      onValueChange={(value: 'male' | 'female' | 'all') => 
                        setFormData({
                          ...formData, 
                          requirements: { 
                            ...formData.requirements,
                            gender: value 
                          }
                        })
                      }
                    >
                      <SelectTrigger className="h-10 sm:h-11">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">همه</SelectItem>
                        <SelectItem value="male">آقا</SelectItem>
                        <SelectItem value="female">خانم</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="text-xs text-muted-foreground space-y-1">
                    <p>• کاربران با سطح کمتر از حداقل مجاز نمی‌توانند درخواست عضویت دهند</p>
                    <p>• حداقل سن برای همه کاربران پلتفرم 13 سال است</p>
                  </div>
                </CardContent>
              </Card>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <Button variant="outline" onClick={handlePrevStep} className="flex-1 h-10 sm:h-11">
                  مرحله قبل
                </Button>
                <Button onClick={handleNextStep} className="flex-1 h-10 sm:h-11">
                  مرحله بعد
                </Button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm sm:text-base">تصاویر کلن</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Logo Upload */}
                  <div className="space-y-3">
                    <Label>لوگو کلن (اختیاری)</Label>
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <Avatar className="w-16 h-16">
                          {logoPreview ? (
                            <AvatarImage src={logoPreview} />
                          ) : (
                            <AvatarFallback className="font-bold text-lg">{formData.tag}</AvatarFallback>
                          )}
                        </Avatar>
                        {logoPreview && (
                          <Button
                            size="sm"
                            variant="destructive"
                            className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0"
                            onClick={() => {
                              setLogoPreview('');
                              setFormData({...formData, logo: undefined});
                            }}
                          >
                            ×
                          </Button>
                        )}
                      </div>
                      <div>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleImageUpload(file, 'logo');
                          }}
                          className="hidden"
                          id="logo-upload"
                        />
                        <Label htmlFor="logo-upload" className="cursor-pointer">
                          <div className="flex items-center gap-2 p-2 border rounded-lg hover:bg-muted/50">
                            <Upload className="w-4 h-4" />
                            <span className="text-sm">انتخاب لوگو</span>
                          </div>
                        </Label>
                        <p className="text-xs text-muted-foreground mt-1">PNG, JPG حداکثر 2MB</p>
                      </div>
                    </div>
                  </div>

                  {/* Banner Upload */}
                  <div className="space-y-3">
                    <Label>بنر کلن (اختیاری)</Label>
                    <div className="space-y-3">
                      {bannerPreview ? (
                        <div className="relative">
                          <img src={bannerPreview} alt="Banner" className="w-full h-32 object-cover rounded-lg" />
                          <Button
                            size="sm"
                            variant="destructive"
                            className="absolute top-2 right-2"
                            onClick={() => {
                              setBannerPreview('');
                              setFormData({...formData, banner: undefined});
                            }}
                          >
                            حذف
                          </Button>
                        </div>
                      ) : (
                        <div className="border-2 border-dashed border-muted rounded-lg h-32 flex items-center justify-center">
                          <div className="text-center">
                            <Image className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                            <p className="text-sm text-muted-foreground">بنر کلن</p>
                          </div>
                        </div>
                      )}
                      
                      <div>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleImageUpload(file, 'banner');
                          }}
                          className="hidden"
                          id="banner-upload"
                        />
                        <Label htmlFor="banner-upload" className="cursor-pointer">
                          <div className="flex items-center gap-2 p-2 border rounded-lg hover:bg-muted/50 w-fit">
                            <Upload className="w-4 h-4" />
                            <span className="text-sm">انتخاب بنر</span>
                          </div>
                        </Label>
                        <p className="text-xs text-muted-foreground">PNG, JPG حداکثر 5MB • اندازه پیشنهادی: 800x200</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <Button variant="outline" onClick={handlePrevStep} className="flex-1 h-10 sm:h-11">
                  مرحله قبل
                </Button>
                <Button onClick={handleNextStep} className="flex-1 h-10 sm:h-11">
                  مرحله بعد
                </Button>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Preview */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm sm:text-base">پیش‌نمای کلن</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 p-3 sm:p-4 border rounded-lg bg-muted/20">
                    <div className="flex items-center gap-3 sm:gap-4">
                      <Avatar className="w-12 h-12 sm:w-16 sm:h-16">
                        {logoPreview ? (
                          <AvatarImage src={logoPreview} />
                        ) : (
                          <AvatarFallback className="font-bold text-lg">{formData.tag}</AvatarFallback>
                        )}
                      </Avatar>
                      <div>
                        <h3 className="font-bold text-lg">[{formData.tag}] {formData.name}</h3>
                        <p className="text-sm text-muted-foreground">{formData.description}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="flex justify-between">
                          <span>{formData.type === 'public' ? 'عمومی' : formData.type === 'private' ? 'خصوصی' : 'فقط دعوت'}</span>
                          <span>نوع:</span>
                        </div>
                        <div className="flex justify-between">
                          <span>{formData.region}</span>
                          <span>استان:</span>
                        </div>
                        <div className="flex justify-between">
                          <span>سطح {formData.requirements.minLevel}+</span>
                          <span>حداقل سطح:</span>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between">
                          <span>{formData.requirements.minAge}+ سال</span>
                          <span>حداقل سن:</span>
                        </div>
                        <div className="flex justify-between">
                          <span>
                            {formData.requirements.gender === 'all' ? 'همه' : 
                             formData.requirements.gender === 'male' ? 'آقا' : 'خانم'}
                          </span>
                          <span>جنسیت:</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {formData.gameTypes.map(game => (
                        <Badge key={game} variant="outline">{game}</Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cost */}
              <Card className="bg-green-500/5 border-green-500/20">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-green-500" />
                      <span>هزینه ایجاد کلن:</span>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-xl text-green-600">
                        {CLAN_CREATION_COST.toLocaleString()} تومان
                      </div>
                      <div className="text-xs text-muted-foreground">
                        موجودی فعلی: {userBalance.toLocaleString()} تومان
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-2">
                <Button variant="outline" onClick={handlePrevStep} className="flex-1">
                  مرحله قبل
                </Button>
                <Button 
                  onClick={handleSubmit}
                  disabled={!canAfford || isProcessing}
                  className="flex-1"
                >
                  {isProcessing ? 'در حال ایجاد...' : 'ایجاد کلن'}
                </Button>
              </div>
            </motion.div>
          )}

          {step === 5 && (
            <motion.div
              key="step5"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-6 py-8"
            >
              <div className="w-20 h-20 bg-[var(--color-state-success-bg)] border-2 border-[var(--color-state-success)]/30 rounded-full flex items-center justify-center mx-auto">
                <Shield className="w-10 h-10 text-[var(--color-state-success)]" />
              </div>
              
              <div>
                <h3 className="font-bold text-2xl mb-2 text-[var(--color-text-primary)]">کلن شما ایجاد شد! 🏰</h3>
                <p className="text-[var(--color-text-secondary)]">
                  کلن [{formData.tag}] {formData.name} با موفقیت ایجاد شد و آماده پذیرش اعضا است.
                </p>
              </div>

              <Card className="bg-[var(--color-state-info-bg)] border-[var(--color-state-info)]/20 text-right" dir="rtl">
                <CardContent className="p-4 space-y-2 text-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-[var(--color-text-primary)] font-medium">شما</span>
                    <span className="text-[var(--color-text-secondary)]">رهبر کلن:</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[var(--color-text-primary)] font-medium">0/50 نفر</span>
                    <span className="text-[var(--color-text-secondary)]">اعضا:</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[var(--color-text-primary)] font-medium">1</span>
                    <span className="text-[var(--color-text-secondary)]">سطح کلن:</span>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-2">
                <ClanMemberInvite 
                  clanData={formData}
                  trigger={
                    <Button variant="outline" className="flex-1 gap-2">
                      <UserPlus className="w-4 h-4" />
                      دعوت اعضا
                    </Button>
                  }
                  onInviteSent={(friendIds) => {
                    toast.success(`${friendIds.length} نفر دعوت شدند! 🎉`, {
                      description: 'دعوت‌نامه‌ها ارسال شد و اعضا اطلاع‌رسانی خواهند شد.'
                    });
                  }}
                />
                <Button 
                  className="flex-1"
                  onClick={() => {
                    setOpen(false);
                    navigate('clans');
                    // Reset form after navigation
                    setTimeout(() => {
                      setStep(1);
                      setFormData({
                        name: '',
                        tag: '',
                        description: '',
                        type: 'public',
                        region: 'تهران',
                        gameTypes: [],
                        requirements: {
                          minLevel: 1,
                          minAge: 16,
                          gender: 'all'
                        },
                        settings: {
                          autoAccept: true,
                          allowInvites: true,
                          showStats: true
                        },
                        cost: CLAN_CREATION_COST
                      });
                    }, 500);
                  }}
                >
                  مشاهده کلن
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}