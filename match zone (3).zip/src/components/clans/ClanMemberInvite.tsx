import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Card, CardContent } from '../ui/card';
import { 
  Users, Search, Send, UserPlus, Check, X, 
  Shield, Star, Trophy, Zap, Heart
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';

interface Friend {
  id: string;
  username: string;
  avatar?: string;
  level: number;
  trophies: number;
  status: 'online' | 'offline' | 'in-game';
  isEligible: boolean;
  favoriteGames: string[];
  isClose?: boolean; // دوست نزدیک
}

interface ClanData {
  name: string;
  tag: string;
  requirements: {
    minLevel: number;
    minAge: number;
    gender: 'male' | 'female' | 'all';
  };
  gameTypes: string[];
}

interface ClanMemberInviteProps {
  clanData: ClanData;
  trigger?: React.ReactNode;
  onInviteSent?: (friendIds: string[]) => void;
}

// Mock friends data با دوستان نزدیک
const MOCK_FRIENDS: Friend[] = [
  {
    id: '1',
    username: 'علی_گیمر',
    avatar: '',
    level: 15,
    trophies: 1250,
    status: 'online',
    isEligible: true,
    favoriteGames: ['کالاف دیوتی', 'فیفا'],
    isClose: true
  },
  {
    id: '2',
    username: 'سارا_پرو',
    avatar: '',
    level: 22,
    trophies: 1800,
    status: 'in-game',
    isEligible: true,
    favoriteGames: ['والورانت', 'Counter-Strike'],
    isClose: true
  },
  {
    id: '3',
    username: 'محمد_کینگ',
    avatar: '',
    level: 8,
    trophies: 650,
    status: 'offline',
    isEligible: false,
    favoriteGames: ['PUBG', 'Fortnite']
  },
  {
    id: '4',
    username: 'مینا_چمپ',
    avatar: '',
    level: 18,
    trophies: 1400,
    status: 'online',
    isEligible: true,
    favoriteGames: ['لیگ آف لجندز', 'والورانت']
  },
  {
    id: '5',
    username: 'رضا_ماستر',
    avatar: '',
    level: 25,
    trophies: 2100,
    status: 'offline',
    isEligible: true,
    favoriteGames: ['کالاف دیوتی', 'Apex Legends'],
    isClose: true
  },
  {
    id: '6',
    username: 'نیلوفر_نینجا',
    avatar: '',
    level: 20,
    trophies: 1650,
    status: 'online',
    isEligible: true,
    favoriteGames: ['والورانت', 'Counter-Strike']
  }
];

export function ClanMemberInvite({ clanData, trigger, onInviteSent }: ClanMemberInviteProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFriends, setSelectedFriends] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [open, setOpen] = useState(false);

  // Filter friends
  const filteredFriends = MOCK_FRIENDS.filter(friend => 
    friend.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const closeFriends = filteredFriends.filter(f => f.isClose && f.isEligible);
  const otherEligible = filteredFriends.filter(f => !f.isClose && f.isEligible);
  const ineligible = filteredFriends.filter(f => !f.isEligible);

  const handleFriendToggle = (friendId: string) => {
    setSelectedFriends(prev => 
      prev.includes(friendId) 
        ? prev.filter(id => id !== friendId)
        : [...prev, friendId]
    );
  };

  const handleQuickSelect = () => {
    const quickSelect = closeFriends.slice(0, 3).map(f => f.id);
    setSelectedFriends(quickSelect);
  };

  const handleSendInvites = async () => {
    if (selectedFriends.length === 0) {
      toast.error('هیچ دوستی انتخاب نشده');
      return;
    }

    setIsLoading(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast.success(`🎉 ${selectedFriends.length} نفر دعوت شدند!`, {
        description: `دعوت‌نامه‌ها به کلن [${clanData.tag}] ${clanData.name} ارسال شد`
      });

      onInviteSent?.(selectedFriends);
      setSelectedFriends([]);
      setOpen(false);
    } catch (error) {
      toast.error('خطا در ارسال دعوت‌نامه');
    }

    setIsLoading(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online':
        return <div className="w-3 h-3 bg-green-500 rounded-full border-2 border-white" />;
      case 'in-game':
        return <div className="w-3 h-3 bg-blue-500 rounded-full border-2 border-white" />;
      case 'offline':
        return <div className="w-3 h-3 bg-gray-400 rounded-full border-2 border-white" />;
    }
  };

  const FriendItem = ({ friend, showHeart = false }: { friend: Friend; showHeart?: boolean }) => {
    const isSelected = selectedFriends.includes(friend.id);
    
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`
          relative p-3 rounded-xl border-2 transition-all cursor-pointer group
          ${friend.isEligible 
            ? (isSelected 
              ? 'border-primary bg-primary/10' 
              : 'border-transparent bg-card hover:border-primary/30') 
            : 'border-transparent bg-destructive/5 cursor-not-allowed opacity-60'
          }
        `}
        onClick={() => friend.isEligible && handleFriendToggle(friend.id)}
      >
        {/* Close Friend Heart */}
        {showHeart && (
          <div className="absolute -top-2 -right-2">
            <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
              <Heart className="w-3 h-3 text-white fill-white" />
            </div>
          </div>
        )}

        <div className="flex items-center gap-3">
          {/* Avatar with Status */}
          <div className="relative flex-shrink-0">
            <Avatar className="w-12 h-12">
              <AvatarImage src={friend.avatar} />
              <AvatarFallback className="text-sm font-bold">
                {friend.username.slice(0, 2)}
              </AvatarFallback>
            </Avatar>
            <div className="absolute -bottom-1 -right-1">
              {getStatusIcon(friend.status)}
            </div>
          </div>

          {/* Friend Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-semibold truncate">{friend.username}</h4>
              {isSelected && <Check className="w-4 h-4 text-primary" />}
            </div>
            
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3" />
                <span>{friend.level}</span>
              </div>
              <div className="flex items-center gap-1">
                <Trophy className="w-3 h-3" />
                <span>{friend.trophies.toLocaleString()}</span>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-xs ${
                friend.status === 'online' ? 'bg-green-500/20 text-green-400' :
                friend.status === 'in-game' ? 'bg-blue-500/20 text-blue-400' :
                'bg-gray-500/20 text-gray-400'
              }`}>
                {friend.status === 'online' ? 'آنلاین' : 
                 friend.status === 'in-game' ? 'در بازی' : 'آفلاین'}
              </span>
            </div>
          </div>

          {/* Selection Indicator */}
          {friend.isEligible && (
            <div className={`
              w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all
              ${isSelected ? 'bg-primary border-primary' : 'border-muted-foreground/30'}
            `}>
              {isSelected && <Check className="w-3 h-3 text-white" />}
            </div>
          )}
        </div>

        {/* Ineligible Reason */}
        {!friend.isEligible && (
          <div className="mt-2 text-xs text-destructive">
            سطح کمتر از حداقل مجاز ({clanData.requirements.minLevel})
          </div>
        )}
      </motion.div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className="gap-2">
            <UserPlus className="w-4 h-4" />
            دعوت اعضا
          </Button>
        )}
      </DialogTrigger>

      <DialogContent className="w-[95vw] max-w-md max-h-[85vh] p-0" dir="rtl">
        {/* Header */}
        <div className="p-6 pb-0">
          <DialogHeader>
            <DialogTitle className="text-right flex items-center gap-2 mb-2">
              <Shield className="w-5 h-5 text-primary" />
              دعوت به کلن {clanData.name}
            </DialogTitle>
            <DialogDescription className="text-right text-sm">
              دوستان خود را به کلن [{clanData.tag}] دعوت کنید
            </DialogDescription>
          </DialogHeader>

          {/* Search */}
          <div className="relative mt-4">
            <Search className="absolute right-3 top-3 w-4 h-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجو در دوستان..."
              className="pl-4 pr-10"
            />
          </div>

          {/* Quick Actions */}
          <div className="flex items-center justify-between mt-4">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleQuickSelect}
              className="gap-1 text-xs"
            >
              <Zap className="w-3 h-3" />
              انتخاب سریع
            </Button>
            <Badge variant="secondary" className="text-xs">
              {selectedFriends.length} انتخاب شده
            </Badge>
          </div>
        </div>

        {/* Friends List */}
        <div className="flex-1 px-6 overflow-y-auto max-h-[400px]">
          <div className="space-y-4 pb-4">
            {/* Close Friends */}
            {closeFriends.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-primary mb-3 flex items-center gap-2">
                  <Heart className="w-4 h-4" />
                  دوستان نزدیک ({closeFriends.length})
                </h4>
                <div className="space-y-2">
                  <AnimatePresence>
                    {closeFriends.map(friend => (
                      <FriendItem key={friend.id} friend={friend} showHeart />
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}

            {/* Other Eligible Friends */}
            {otherEligible.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-green-600 mb-3 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  سایر دوستان ({otherEligible.length})
                </h4>
                <div className="space-y-2">
                  <AnimatePresence>
                    {otherEligible.map(friend => (
                      <FriendItem key={friend.id} friend={friend} />
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}

            {/* Ineligible Friends */}
            {ineligible.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-destructive mb-3 flex items-center gap-2">
                  <X className="w-4 h-4" />
                  فاقد شرایط ({ineligible.length})
                </h4>
                <div className="space-y-2">
                  <AnimatePresence>
                    {ineligible.map(friend => (
                      <FriendItem key={friend.id} friend={friend} />
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            )}

            {/* Empty State */}
            {filteredFriends.length === 0 && (
              <div className="text-center py-8">
                <Users className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">
                  {searchQuery ? 'دوستی با این نام یافت نشد' : 'شما هنوز دوستی ندارید'}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-6 pt-4 border-t bg-card/50">
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={() => setOpen(false)}
              className="flex-1"
              disabled={isLoading}
            >
              انصراف
            </Button>
            <Button 
              onClick={handleSendInvites}
              disabled={selectedFriends.length === 0 || isLoading}
              className="flex-1 gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ارسال...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  ارسال ({selectedFriends.length})
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}