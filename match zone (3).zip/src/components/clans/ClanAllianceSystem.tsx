import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../ui/alert-dialog';
import { 
  Handshake, Shield, Users, Crown, Star, Sword, Heart,
  CheckCircle, XCircle, Clock, Send, UserPlus, MessageCircle,
  Gift, Trophy, Target, AlertTriangle, Flag, Eye, Plus,
  ArrowRight, ArrowLeft, Zap, Globe, Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';

export interface Alliance {
  id: string;
  name: string;
  type: 'offensive' | 'defensive' | 'trade' | 'friendship';
  status: 'active' | 'pending' | 'expired' | 'canceled';
  members: Array<{
    id: string;
    name: string;
    logo: string;
    level: number;
    members: number;
    power: number;
    contribution: number;
  }>;
  leader: {
    id: string;
    name: string;
  };
  createdAt: string;
  expiresAt: string;
  description: string;
  benefits: {
    tradeBonus: number;
    warSupport: number;
    resourceSharing: boolean;
    jointEvents: boolean;
  };
  requirements: {
    minLevel: number;
    minMembers: number;
    minPower: number;
  };
  maxMembers: number;
  currentMembers: number;
}

export interface AllianceInvitation {
  id: string;
  from: {
    id: string;
    name: string;
    logo: string;
    level: number;
  };
  to: {
    id: string;
    name: string;
    logo: string;
    level: number;
  };
  allianceType: Alliance['type'];
  message: string;
  sentAt: string;
  expiresAt: string;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
}

export interface ClanAllianceSystemProps {
  clanId: string;
  onAllianceAction?: (action: string, data: any) => void;
  className?: string;
}

const MOCK_ALLIANCES: Alliance[] = [
  {
    id: 'alliance-1',
    name: 'اتحاد شرق آسیا',
    type: 'offensive',
    status: 'active',
    members: [
      {
        id: 'clan-1',
        name: 'شیران پارس',
        logo: '/clan-logos/shirane-pars.png',
        level: 15,
        members: 48,
        power: 89500,
        contribution: 85
      },
      {
        id: 'clan-2',
        name: 'عقاب‌های طلایی',
        logo: '/clan-logos/golden-eagles.png',
        level: 13,
        members: 42,
        power: 78900,
        contribution: 78
      },
      {
        id: 'clan-3',
        name: 'نینجاهای سایه',
        logo: '/clan-logos/shadow-ninjas.png',
        level: 12,
        members: 35,
        power: 67800,
        contribution: 92
      }
    ],
    leader: {
      id: 'clan-1',
      name: 'شیران پارس'
    },
    createdAt: '2024-11-15T10:00:00Z',
    expiresAt: '2025-02-15T10:00:00Z',
    description: 'اتحادی قدرتمند برای حمله‌های هماهنگ و تسلط بر میدان نبرد',
    benefits: {
      tradeBonus: 15,
      warSupport: 25,
      resourceSharing: true,
      jointEvents: true
    },
    requirements: {
      minLevel: 10,
      minMembers: 30,
      minPower: 60000
    },
    maxMembers: 5,
    currentMembers: 3
  },
  {
    id: 'alliance-2',
    name: 'پیمان دفاعی شمال',
    type: 'defensive',
    status: 'active',
    members: [
      {
        id: 'clan-4',
        name: 'محافظان کوهستان',
        logo: '/clan-logos/mountain-guardians.png',
        level: 14,
        members: 45,
        power: 82300,
        contribution: 88
      },
      {
        id: 'clan-1',
        name: 'شیران پارس',
        logo: '/clan-logos/shirane-pars.png',
        level: 15,
        members: 48,
        power: 89500,
        contribution: 91
      }
    ],
    leader: {
      id: 'clan-4',
      name: 'محافظان کوهستان'
    },
    createdAt: '2024-12-01T14:30:00Z',
    expiresAt: '2025-03-01T14:30:00Z',
    description: 'پیمان دفاعی برای حمایت متقابل در برابر تهدیدات خارجی',
    benefits: {
      tradeBonus: 10,
      warSupport: 40,
      resourceSharing: true,
      jointEvents: false
    },
    requirements: {
      minLevel: 12,
      minMembers: 35,
      minPower: 70000
    },
    maxMembers: 4,
    currentMembers: 2
  }
];

const MOCK_INVITATIONS: AllianceInvitation[] = [
  {
    id: 'inv-1',
    from: {
      id: 'clan-5',
      name: 'اژدهایان آتش',
      logo: '/clan-logos/fire-dragons.png',
      level: 16
    },
    to: {
      id: 'clan-1',
      name: 'شیران پارس',
      logo: '/clan-logos/shirane-pars.png',
      level: 15
    },
    allianceType: 'trade',
    message: 'سلام! علاقه‌مندیم با کلن قدرتمند شما اتحاد تجاری تشکیل دهیم. منابع ما کامل یکدیگر را تکمیل می‌کند.',
    sentAt: '2024-12-20T09:15:00Z',
    expiresAt: '2024-12-27T09:15:00Z',
    status: 'pending'
  },
  {
    id: 'inv-2',
    from: {
      id: 'clan-6',
      name: 'شبح‌های شب',
      logo: '/clan-logos/night-ghosts.png',
      level: 11
    },
    to: {
      id: 'clan-1',
      name: 'شیران پارس',
      logo: '/clan-logos/shirane-pars.png',
      level: 15
    },
    allianceType: 'friendship',
    message: 'کلن شما واقعاً الهام‌بخش است! آیا می‌توانیم پیمان دوستی ببندیم؟',
    sentAt: '2024-12-22T16:45:00Z',
    expiresAt: '2024-12-29T16:45:00Z',
    status: 'pending'
  }
];

export function ClanAllianceSystem({ clanId, onAllianceAction, className }: ClanAllianceSystemProps) {
  const [activeTab, setActiveTab] = useState('alliances');
  const [alliances] = useState<Alliance[]>(MOCK_ALLIANCES);
  const [invitations] = useState<AllianceInvitation[]>(MOCK_INVITATIONS);
  const [selectedAlliance, setSelectedAlliance] = useState<Alliance | null>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  
  const [newAllianceName, setNewAllianceName] = useState('');
  const [newAllianceType, setNewAllianceType] = useState<Alliance['type']>('friendship');
  const [newAllianceDescription, setNewAllianceDescription] = useState('');
  const [inviteClanName, setInviteClanName] = useState('');
  const [inviteMessage, setInviteMessage] = useState('');

  const getAllianceTypeInfo = (type: Alliance['type']) => {
    switch (type) {
      case 'offensive':
        return {
          name: 'تهاجمی',
          icon: Sword,
          color: 'text-red-500',
          bg: 'bg-red-500/10',
          description: 'برای حمله‌های هماهنگ و تسلط نظامی'
        };
      case 'defensive':
        return {
          name: 'دفاعی',
          icon: Shield,
          color: 'text-blue-500',
          bg: 'bg-blue-500/10',
          description: 'برای حمایت متقابل و دفاع مشترک'
        };
      case 'trade':
        return {
          name: 'تجاری',
          icon: Gift,
          color: 'text-green-500',
          bg: 'bg-green-500/10',
          description: 'برای تبادل منابع و همکاری اقتصا��ی'
        };
      case 'friendship':
        return {
          name: 'دوستی',
          icon: Heart,
          color: 'text-pink-500',
          bg: 'bg-pink-500/10',
          description: 'برای روابط دوستانه و فعالیت‌های مشترک'
        };
    }
  };

  const getStatusColor = (status: Alliance['status']) => {
    switch (status) {
      case 'active': return 'text-green-500';
      case 'pending': return 'text-yellow-500';
      case 'expired': return 'text-gray-500';
      case 'canceled': return 'text-red-500';
      default: return 'text-muted-foreground';
    }
  };

  const getStatusText = (status: Alliance['status']) => {
    switch (status) {
      case 'active': return 'فعال';
      case 'pending': return 'در انتظار';
      case 'expired': return 'منقضی شده';
      case 'canceled': return 'لغو شده';
      default: return 'نامشخص';
    }
  };

  const handleAllianceAction = (action: string, data: any) => {
    onAllianceAction?.(action, data);
    toast.success(`عملیات "${action}" انجام شد`);
  };

  const handleInvitationResponse = (invitationId: string, response: 'accept' | 'decline') => {
    handleAllianceAction('invitation-response', { invitationId, response });
  };

  const handleCreateAlliance = () => {
    if (!newAllianceName.trim()) {
      toast.error('نام اتحاد الزامی است');
      return;
    }

    const allianceData = {
      name: newAllianceName,
      type: newAllianceType,
      description: newAllianceDescription,
      clanId
    };

    handleAllianceAction('create-alliance', allianceData);
    setIsCreateDialogOpen(false);
    setNewAllianceName('');
    setNewAllianceDescription('');
  };

  const handleSendInvite = () => {
    if (!inviteClanName.trim()) {
      toast.error('نام کلن الزامی است');
      return;
    }

    const inviteData = {
      toClan: inviteClanName,
      message: inviteMessage,
      fromClanId: clanId
    };

    handleAllianceAction('send-invite', inviteData);
    setIsInviteDialogOpen(false);
    setInviteClanName('');
    setInviteMessage('');
  };

  const AllianceCard = ({ alliance }: { alliance: Alliance }) => {
    const typeInfo = getAllianceTypeInfo(alliance.type);
    const TypeIcon = typeInfo.icon;

    return (
      <Card className="border-2 hover:border-blue-500/50 transition-all duration-200">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 ${typeInfo.bg} rounded-lg`}>
                <TypeIcon className={`w-5 h-5 ${typeInfo.color}`} />
              </div>
              <div>
                <CardTitle className="text-base">{alliance.name}</CardTitle>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Badge variant="outline" className={typeInfo.color}>
                    {typeInfo.name}
                  </Badge>
                  <span className={getStatusColor(alliance.status)}>
                    {getStatusText(alliance.status)}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right text-sm text-muted-foreground">
              <p>{alliance.currentMembers}/{alliance.maxMembers} عضو</p>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">{alliance.description}</p>

          {/* Members Preview */}
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2">
              {alliance.members.slice(0, 4).map((member) => (
                <Avatar key={member.id} className="w-8 h-8 border-2 border-background">
                  <AvatarImage src={member.logo} />
                  <AvatarFallback className="text-xs">{member.name.slice(0, 2)}</AvatarFallback>
                </Avatar>
              ))}
            </div>
            {alliance.members.length > 4 && (
              <span className="text-xs text-muted-foreground">
                +{alliance.members.length - 4} کلن دیگر
              </span>
            )}
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="flex items-center gap-1">
              <Gift className="w-3 h-3" />
              <span>بونوس تجاری: {alliance.benefits.tradeBonus}%</span>
            </div>
            <div className="flex items-center gap-1">
              <Shield className="w-3 h-3" />
              <span>پشتیبانی جنگ: {alliance.benefits.warSupport}%</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1"
              onClick={() => setSelectedAlliance(alliance)}
            >
              <Eye className="w-4 h-4 ml-2" />
              جزئیات
            </Button>
            {alliance.leader.id === clanId && (
              <Button size="sm" variant="secondary">
                <Crown className="w-4 h-4 ml-2" />
                مدیریت
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  const InvitationCard = ({ invitation }: { invitation: AllianceInvitation }) => {
    const typeInfo = getAllianceTypeInfo(invitation.allianceType);
    const TypeIcon = typeInfo.icon;

    return (
      <Card className="border-2 border-yellow-500/20">
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={invitation.from.logo} />
                <AvatarFallback>{invitation.from.name.slice(0, 2)}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-base">{invitation.from.name}</CardTitle>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Badge variant="outline" className={typeInfo.color}>
                    اتحاد {typeInfo.name}
                  </Badge>
                  <span>سطح {invitation.from.level}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              ۳ روز باقی‌مانده
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-3">
          <p className="text-sm">{invitation.message}</p>

          <div className="flex gap-2">
            <Button 
              size="sm" 
              className="flex-1 bg-green-600 hover:bg-green-700"
              onClick={() => handleInvitationResponse(invitation.id, 'accept')}
            >
              <CheckCircle className="w-4 h-4 ml-2" />
              پذیرش
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              className="flex-1 border-red-500 text-red-500 hover:bg-red-500/10"
              onClick={() => handleInvitationResponse(invitation.id, 'decline')}
            >
              <XCircle className="w-4 h-4 ml-2" />
              رد
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className={`space-y-6 ${className || ''}`} dir="rtl">
      {/* Header */}
      <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Handshake className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <CardTitle className="text-xl">سیستم اتحادها</CardTitle>
                <p className="text-muted-foreground text-sm">
                  تشکیل اتحاد با کلن‌های دیگر و تقویت قدرت مشترک
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 ml-2" />
                    ایجاد اتحاد
                  </Button>
                </DialogTrigger>
              </Dialog>
              
              <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Send className="w-4 h-4 ml-2" />
                    ارسال دعوت
                  </Button>
                </DialogTrigger>
              </Dialog>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="alliances" className="flex items-center gap-2">
            <Handshake className="w-4 h-4" />
            اتحادهای من ({alliances.length})
          </TabsTrigger>
          <TabsTrigger value="invitations" className="flex items-center gap-2">
            <Send className="w-4 h-4" />
            دعوت‌ها ({invitations.length})
            {invitations.length > 0 && (
              <Badge variant="destructive" className="text-xs h-5">
                {invitations.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="discover" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            کشف اتحادها
          </TabsTrigger>
        </TabsList>

        {/* My Alliances Tab */}
        <TabsContent value="alliances" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {alliances.map((alliance) => (
              <AllianceCard key={alliance.id} alliance={alliance} />
            ))}
          </div>

          {alliances.length === 0 && (
            <Card className="p-8 text-center">
              <div className="space-y-4">
                <Handshake className="w-16 h-16 text-muted-foreground/50 mx-auto" />
                <div>
                  <h3 className="text-lg font-semibold">هنوز عضو اتحادی نیستید</h3>
                  <p className="text-muted-foreground">
                    با تشکیل یا پیوستن به اتحاد، قدرت کلن خود را چندین برابر کنید
                  </p>
                </div>
                <Button onClick={() => setIsCreateDialogOpen(true)}>
                  <Plus className="w-4 h-4 ml-2" />
                  ایجاد اتحاد جدید
                </Button>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* Invitations Tab */}
        <TabsContent value="invitations" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {invitations.map((invitation) => (
              <InvitationCard key={invitation.id} invitation={invitation} />
            ))}
          </div>

          {invitations.length === 0 && (
            <Card className="p-8 text-center">
              <div className="space-y-4">
                <Send className="w-16 h-16 text-muted-foreground/50 mx-auto" />
                <div>
                  <h3 className="text-lg font-semibold">دعوتی دریافت نکرده‌اید</h3>
                  <p className="text-muted-foreground">
                    دعوت‌های اتحاد از کلن‌های دیگر در اینجا نمایش داده می‌شود
                  </p>
                </div>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* Discover Tab */}
        <TabsContent value="discover" className="space-y-4">
          <Card className="p-8 text-center">
            <div className="space-y-4">
              <Globe className="w-16 h-16 text-muted-foreground/50 mx-auto" />
              <div>
                <h3 className="text-lg font-semibold">کشف اتحادهای عمومی</h3>
                <p className="text-muted-foreground">
                  اتحادهای عمومی و باز برای پیوستن در اینجا نمایش داده می‌شود
                </p>
              </div>
              <Button variant="outline">
                جستجوی اتحادها
              </Button>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Create Alliance Dialog */}
      <DialogContent className="max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5" />
            ایجاد اتحاد جدید
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="alliance-name">نام اتحاد *</Label>
            <Input 
              id="alliance-name"
              value={newAllianceName}
              onChange={(e) => setNewAllianceName(e.target.value)}
              placeholder="مثلاً: اتحاد شرق آسیا"
            />
          </div>

          <div>
            <Label>نوع اتحاد *</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {(['offensive', 'defensive', 'trade', 'friendship'] as Alliance['type'][]).map((type) => {
                const typeInfo = getAllianceTypeInfo(type);
                const TypeIcon = typeInfo.icon;
                return (
                  <Button
                    key={type}
                    variant={newAllianceType === type ? 'default' : 'outline'}
                    size="sm"
                    className="justify-start"
                    onClick={() => setNewAllianceType(type)}
                  >
                    <TypeIcon className="w-4 h-4 ml-2" />
                    {typeInfo.name}
                  </Button>
                );
              })}
            </div>
          </div>

          <div>
            <Label htmlFor="alliance-description">توضیحات</Label>
            <Textarea
              id="alliance-description"
              value={newAllianceDescription}
              onChange={(e) => setNewAllianceDescription(e.target.value)}
              placeholder="اهداف و مزایای اتحاد را شرح دهید..."
              rows={3}
            />
          </div>

          <div className="flex gap-2">
            <Button className="flex-1" onClick={handleCreateAlliance}>
              <Plus className="w-4 h-4 ml-2" />
              ایجاد اتحاد
            </Button>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              انصراف
            </Button>
          </div>
        </div>
      </DialogContent>

      {/* Send Invite Dialog */}
      <DialogContent className="max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            ارسال دعوت اتحاد
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="clan-name">نام کلن مقصد *</Label>
            <Input 
              id="clan-name"
              value={inviteClanName}
              onChange={(e) => setInviteClanName(e.target.value)}
              placeholder="نام دقیق کلن مورد نظر"
            />
          </div>

          <div>
            <Label htmlFor="invite-message">پیام دعوت</Label>
            <Textarea
              id="invite-message"
              value={inviteMessage}
              onChange={(e) => setInviteMessage(e.target.value)}
              placeholder="پیام دوستانه برای کلن مقصد..."
              rows={3}
            />
          </div>

          <div className="flex gap-2">
            <Button className="flex-1" onClick={handleSendInvite}>
              <Send className="w-4 h-4 ml-2" />
              ارسال دعوت
            </Button>
            <Button variant="outline" onClick={() => setIsInviteDialogOpen(false)}>
              انصراف
            </Button>
          </div>
        </div>
      </DialogContent>

      {/* Alliance Details Dialog */}
      <Dialog open={!!selectedAlliance} onOpenChange={() => setSelectedAlliance(null)}>
        <DialogContent className="max-w-4xl" dir="rtl">
          {selectedAlliance && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Handshake className="w-5 h-5" />
                  {selectedAlliance.name}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Alliance Info */}
                <div className="grid grid-cols-2 gap-6">
                  <Card>
                    <CardContent className="p-4">
                      <h4 className="font-medium mb-3">اطلاعات اتحاد</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>نوع:</span>
                          <Badge className={getAllianceTypeInfo(selectedAlliance.type).color}>
                            {getAllianceTypeInfo(selectedAlliance.type).name}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>وضعیت:</span>
                          <span className={getStatusColor(selectedAlliance.status)}>
                            {getStatusText(selectedAlliance.status)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>اعضا:</span>
                          <span>{selectedAlliance.currentMembers}/{selectedAlliance.maxMembers}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>رهبر:</span>
                          <span>{selectedAlliance.leader.name}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <h4 className="font-medium mb-3">مزایا</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>بونوس تجاری:</span>
                          <span className="text-green-500">+{selectedAlliance.benefits.tradeBonus}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>پشتیبانی جنگ:</span>
                          <span className="text-blue-500">+{selectedAlliance.benefits.warSupport}%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>اشتراک منابع:</span>
                          <span className={selectedAlliance.benefits.resourceSharing ? 'text-green-500' : 'text-red-500'}>
                            {selectedAlliance.benefits.resourceSharing ? 'فعال' : 'غیرفعال'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span>رویدادهای مشترک:</span>
                          <span className={selectedAlliance.benefits.jointEvents ? 'text-green-500' : 'text-red-500'}>
                            {selectedAlliance.benefits.jointEvents ? 'فعال' : 'غیرفعال'}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Members */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">اعضای اتحاد</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {selectedAlliance.members.map((member) => (
                      <div key={member.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                        <div className="flex items-center gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={member.logo} />
                            <AvatarFallback>{member.name.slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{member.name}</p>
                            <div className="flex items-center gap-3 text-sm text-muted-foreground">
                              <span>سطح {member.level}</span>
                              <span>•</span>
                              <span>{member.members} عضو</span>
                              <span>•</span>
                              <span>{member.power.toLocaleString()} قدرت</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-500" />
                            <span className="font-medium">{member.contribution}%</span>
                          </div>
                          <p className="text-xs text-muted-foreground">مشارکت</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Description */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-2">توضیحات</h4>
                    <p className="text-sm text-muted-foreground">{selectedAlliance.description}</p>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default ClanAllianceSystem;