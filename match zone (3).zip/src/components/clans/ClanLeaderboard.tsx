import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Progress } from '../ui/progress';
import { Separator } from '../ui/separator';
import { 
  Trophy, Crown, Medal, Shield, Users, Target, TrendingUp, 
  Zap, Star, Award, ChevronUp, ChevronDown, Search, Filter,
  Flag, Globe, Calendar, BarChart3, Flame
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Clan } from './ClanCard';

export interface ClanLeaderboardEntry {
  id: string;
  name: string;
  tag: string;
  logo?: string;
  rank: number;
  previousRank?: number;
  level: number;
  totalTrophies: number;
  weeklyTrophies: number;
  members: { current: number; max: number };
  winRate: number;
  totalWins: number;
  region: string;
  xp: number;
  weeklyXp: number;
  achievements: string[];
  isRising: boolean;
  leader: {
    name: string;
    avatar?: string;
  };
  activities: {
    activeMembers: number;
    weeklyMatches: number;
    lastActive: string;
  };
}

export interface ClanLeaderboardStats {
  totalClans: number;
  activeClans: number;
  totalMembers: number;
  averageLevel: number;
  topRegions: { name: string; count: number; percentage: number }[];
  weeklyGrowth: number;
}

export interface ClanLeaderboardProps {
  clans: ClanLeaderboardEntry[];
  stats: ClanLeaderboardStats;
  userClanRank?: number;
  isGlobal?: boolean;
}

export function ClanLeaderboard({ 
  clans, 
  stats, 
  userClanRank,
  isGlobal = true 
}: ClanLeaderboardProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'rank' | 'trophies' | 'level' | 'members' | 'winRate'>('rank');
  const [filterBy, setFilterBy] = useState<'all' | 'rising' | 'elite' | 'active'>('all');
  const [regionFilter, setRegionFilter] = useState<string>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<'weekly' | 'monthly' | 'season' | 'alltime'>('weekly');

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-6 h-6 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-6 h-6 text-gray-400" />;
    if (rank === 3) return <Medal className="w-6 h-6 text-amber-600" />;
    if (rank <= 10) return <Star className="w-5 h-5 text-blue-500" />;
    return null;
  };

  const getRankChange = (clan: ClanLeaderboardEntry) => {
    if (!clan.previousRank) return null;
    const change = clan.previousRank - clan.rank;
    if (change > 0) return { direction: 'up', value: change, color: 'text-green-500' };
    if (change < 0) return { direction: 'down', value: Math.abs(change), color: 'text-red-500' };
    return { direction: 'same', value: 0, color: 'text-muted-foreground' };
  };

  const getLevelColor = (level: number) => {
    if (level >= 50) return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    if (level >= 30) return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
    if (level >= 15) return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    return 'bg-green-500/20 text-green-400 border-green-500/30';
  };

  const filteredAndSortedClans = clans
    .filter(clan => {
      if (!searchQuery) return true;
      return clan.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
             clan.tag.toLowerCase().includes(searchQuery.toLowerCase()) ||
             clan.leader.name.toLowerCase().includes(searchQuery.toLowerCase());
    })
    .filter(clan => {
      switch (filterBy) {
        case 'rising':
          return clan.isRising;
        case 'elite':
          return clan.rank <= 50;
        case 'active':
          return clan.activities.activeMembers >= clan.members.current * 0.7;
        default:
          return true;
      }
    })
    .filter(clan => {
      if (regionFilter === 'all') return true;
      return clan.region === regionFilter;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'trophies':
          return b.totalTrophies - a.totalTrophies;
        case 'level':
          return b.level - a.level;
        case 'members':
          return b.members.current - a.members.current;
        case 'winRate':
          return b.winRate - a.winRate;
        default:
          return a.rank - b.rank;
      }
    });

  const topClans = clans.slice(0, 3);
  const uniqueRegions = Array.from(new Set(clans.map(c => c.region)));

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <h2 className="font-bold text-xl flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-primary" />
            رنکینگ کلن‌ها {isGlobal ? 'جهانی' : 'منطقه‌ای'}
          </h2>
          <p className="text-muted-foreground">
            {stats.totalClans} کلن • {stats.totalMembers.toLocaleString()} عضو فعال
          </p>
        </div>
        
        {userClanRank && (
          <Card className="bg-gradient-to-r from-blue-500/10 to-green-500/10 border-blue-500/20">
            <CardContent className="p-3">
              <div className="text-center">
                <div className="font-bold text-lg text-blue-400">#{userClanRank}</div>
                <div className="text-xs text-muted-foreground">رنک کلن شما</div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-primary">{stats.totalClans}</div>
          <div className="text-sm text-muted-foreground">کلن فعال</div>
        </Card>
        
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-green-500">{stats.totalMembers.toLocaleString()}</div>
          <div className="text-sm text-muted-foreground">عضو</div>
        </Card>
        
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-blue-500">{stats.averageLevel}</div>
          <div className="text-sm text-muted-foreground">متوسط سطح</div>
        </Card>
        
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-purple-500">+{stats.weeklyGrowth}%</div>
          <div className="text-sm text-muted-foreground">رشد هفتگی</div>
        </Card>
      </div>

      {/* Top 3 Podium */}
      <Card className="bg-gradient-to-r from-yellow-500/5 to-orange-500/5 border-yellow-500/20">
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Trophy className="w-4 h-4 text-yellow-500" />
            برترین کلن‌ها
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            {topClans.map((clan, index) => (
              <motion.div
                key={clan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`text-center p-4 rounded-lg border ${
                  index === 0 ? 'bg-gradient-to-b from-yellow-500/20 to-yellow-600/10 border-yellow-500/30' :
                  index === 1 ? 'bg-gradient-to-b from-gray-400/20 to-gray-500/10 border-gray-400/30' :
                  'bg-gradient-to-b from-amber-600/20 to-amber-700/10 border-amber-600/30'
                } relative overflow-hidden`}
              >
                {/* Rank Position */}
                <div className="absolute top-2 left-2">
                  {getRankIcon(clan.rank)}
                </div>
                
                <div className="space-y-3">
                  <div className="relative">
                    <Avatar className={`w-16 h-16 mx-auto ${index === 0 ? 'ring-2 ring-yellow-500' : ''}`}>
                      <AvatarImage src={clan.logo} />
                      <AvatarFallback className="font-bold">{clan.tag}</AvatarFallback>
                    </Avatar>
                    <div className={`absolute -bottom-1 -right-1 px-2 py-1 rounded-full text-xs font-bold border ${getLevelColor(clan.level)}`}>
                      {clan.level}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-bold text-sm">[{clan.tag}] {clan.name}</h4>
                    <div className="text-xs text-muted-foreground mt-1">
                      <div>{clan.totalTrophies.toLocaleString()} جام</div>
                      <div>{clan.members.current} عضو</div>
                    </div>
                  </div>

                  <Badge variant="outline" className="text-xs">
                    رنک {clan.rank}
                  </Badge>
                </div>

                {/* Rising Indicator */}
                {clan.isRising && (
                  <div className="absolute top-2 right-2">
                    <div className="bg-green-500 rounded-full p-1">
                      <TrendingUp className="w-3 h-3 text-white" />
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Filters and Search */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="جستجو در کلن‌ها..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
                dir="rtl"
              />
            </div>

            {/* Filters */}
            <div className="flex gap-2">
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rank">رنک</SelectItem>
                  <SelectItem value="trophies">جام‌ها</SelectItem>
                  <SelectItem value="level">سطح</SelectItem>
                  <SelectItem value="members">اعضا</SelectItem>
                  <SelectItem value="winRate">درصد برد</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterBy} onValueChange={(value: any) => setFilterBy(value)}>
                <SelectTrigger className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  <SelectItem value="rising">صعودی</SelectItem>
                  <SelectItem value="elite">نخبه</SelectItem>
                  <SelectItem value="active">فعال</SelectItem>
                </SelectContent>
              </Select>

              <Select value={regionFilter} onValueChange={setRegionFilter}>
                <SelectTrigger className="w-28">
                  <SelectValue placeholder="منطقه" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه</SelectItem>
                  {uniqueRegions.map(region => (
                    <SelectItem key={region} value={region}>{region}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedPeriod} onValueChange={(value: any) => setSelectedPeriod(value)}>
                <SelectTrigger className="w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">هفتگی</SelectItem>
                  <SelectItem value="monthly">ماهانه</SelectItem>
                  <SelectItem value="season">فصلی</SelectItem>
                  <SelectItem value="alltime">همه‌وقت</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="leaderboard" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="leaderboard">رنکینگ کلن‌ها</TabsTrigger>
          <TabsTrigger value="regions">آمار مناطق</TabsTrigger>
          <TabsTrigger value="trends">روند تغییرات</TabsTrigger>
        </TabsList>

        <TabsContent value="leaderboard" className="space-y-4">
          {/* Leaderboard Table */}
          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {filteredAndSortedClans.map((clan, index) => {
                  const rankChange = getRankChange(clan);
                  
                  return (
                    <motion.div
                      key={clan.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.02 }}
                      className="p-4 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        {/* Left side - Stats */}
                        <div className="flex items-center gap-6 text-sm">
                          <div className="text-center min-w-[80px]">
                            <div className="font-bold text-yellow-600">{clan.totalTrophies.toLocaleString()}</div>
                            <div className="text-xs text-muted-foreground">جام</div>
                          </div>
                          
                          <div className="text-center min-w-[60px]">
                            <div className="font-medium">{clan.winRate}%</div>
                            <div className="text-xs text-muted-foreground">برد</div>
                          </div>
                          
                          <div className="text-center min-w-[50px]">
                            <div className="font-medium">{clan.members.current}/{clan.members.max}</div>
                            <div className="text-xs text-muted-foreground">عضو</div>
                          </div>

                          <div className="text-center min-w-[60px]">
                            <div className="font-medium text-green-600">+{clan.weeklyXp.toLocaleString()}</div>
                            <div className="text-xs text-muted-foreground">XP هفتگی</div>
                          </div>
                        </div>

                        {/* Center - Clan Info */}
                        <div className="flex-1 flex items-center gap-4 justify-end">
                          {/* Clan Details */}
                          <div className="text-right">
                            <div className="flex items-center gap-2 justify-end">
                              <span className="font-bold">[{clan.tag}] {clan.name}</span>
                              {clan.isRising && (
                                <div className="bg-green-500/20 rounded-full p-1">
                                  <Flame className="w-3 h-3 text-green-500" />
                                </div>
                              )}
                            </div>
                            
                            <div className="flex items-center gap-2 text-xs text-muted-foreground justify-end mt-1">
                              <span>رهبر: {clan.leader.name}</span>
                              <span>•</span>
                              <span>{clan.region}</span>
                              {clan.achievements.length > 0 && (
                                <div className="flex gap-1">
                                  {clan.achievements.slice(0, 2).map((achievement, i) => (
                                    <Award key={i} className="w-3 h-3 text-yellow-500" />
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Clan Avatar */}
                          <div className="relative">
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={clan.logo} />
                              <AvatarFallback className="font-bold">{clan.tag}</AvatarFallback>
                            </Avatar>
                            <div className={`absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full text-xs font-bold border ${getLevelColor(clan.level)}`}>
                              {clan.level}
                            </div>
                          </div>
                        </div>

                        {/* Right side - Rank */}
                        <div className="flex items-center gap-3 min-w-[120px]">
                          {/* Rank Change */}
                          <div className="flex flex-col items-center">
                            {rankChange && rankChange.direction !== 'same' && (
                              <div className={`flex items-center gap-1 text-xs ${rankChange.color}`}>
                                {rankChange.direction === 'up' ? 
                                  <ChevronUp className="w-3 h-3" /> : 
                                  <ChevronDown className="w-3 h-3" />
                                }
                                {rankChange.value}
                              </div>
                            )}
                          </div>

                          {/* Rank Number */}
                          <div className="flex items-center gap-2">
                            {getRankIcon(clan.rank)}
                            <span className={`font-bold text-xl ${
                              clan.rank <= 3 ? 'text-yellow-600' : 
                              clan.rank <= 10 ? 'text-blue-600' : ''
                            }`}>
                              #{clan.rank}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Additional Info for Top Clans */}
                      {clan.rank <= 10 && (
                        <div className="mt-3 pt-3 border-t border-muted">
                          <div className="grid grid-cols-4 gap-4 text-xs">
                            <div className="text-center">
                              <div className="font-medium">{clan.totalWins}</div>
                              <div className="text-muted-foreground">پیروزی</div>
                            </div>
                            <div className="text-center">
                              <div className="font-medium">{clan.activities.activeMembers}</div>
                              <div className="text-muted-foreground">فعال</div>
                            </div>
                            <div className="text-center">
                              <div className="font-medium">{clan.activities.weeklyMatches}</div>
                              <div className="text-muted-foreground">مسابقه هفتگی</div>
                            </div>
                            <div className="text-center">
                              <div className="font-medium">{clan.activities.lastActive}</div>
                              <div className="text-muted-foreground">آخرین فعالیت</div>
                            </div>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="regions" className="space-y-4">
          {/* Regional Statistics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">توزیع مناطق</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats.topRegions.map((region, index) => (
                    <div key={region.name} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">#{index + 1}</Badge>
                          <span className="font-medium">{region.name}</span>
                        </div>
                        <div className="text-sm font-medium">{region.count} کلن</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Progress value={region.percentage} className="flex-1 h-2" />
                        <span className="text-xs text-muted-foreground">{region.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">آمار کلی</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="space-y-1">
                    <div className="text-2xl font-bold text-primary">{stats.activeClans}</div>
                    <div className="text-xs text-muted-foreground">کلن فعال</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-2xl font-bold text-green-500">{Math.round(stats.totalMembers / stats.totalClans)}</div>
                    <div className="text-xs text-muted-foreground">متوسط اعضا</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-2xl font-bold text-blue-500">{stats.averageLevel}</div>
                    <div className="text-xs text-muted-foreground">متوسط سطح</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-2xl font-bold text-purple-500">+{stats.weeklyGrowth}%</div>
                    <div className="text-xs text-muted-foreground">رشد هفتگی</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card>
            <CardContent className="p-8 text-center">
              <BarChart3 className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="font-medium mb-2">نمودار روند تغییرات</h3>
              <p className="text-muted-foreground text-sm">
                نمودارهای تفصیلی روند تغییرات رنکینگ کلن‌ها بزودی اضافه خواهد شد
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}