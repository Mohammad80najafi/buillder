import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Separator } from '../ui/separator';
import { Textarea } from '../ui/textarea';
import { 
  Users, Crown, Shield, UserPlus, UserMinus, Settings, 
  MessageSquare, Award, Trash2, Edit, MoreHorizontal,
  Search, Filter, Calendar, Activity, Target, Trophy,
  Mail, Ban, CheckCircle, XCircle, Clock, Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner@2.0.3';

export interface ClanMember {
  id: string;
  name: string;
  avatar?: string;
  level: number;
  role: 'leader' | 'officer' | 'member';
  joinDate: string;
  lastActive: string;
  status: 'online' | 'offline' | 'away';
  stats: {
    trophies: number;
    wins: number;
    losses: number;
    weeklyActivity: number;
    donations: number;
  };
  permissions: string[];
  isOnline: boolean;
}

export interface ClanJoinRequest {
  id: string;
  player: {
    name: string;
    avatar?: string;
    level: number;
    trophies: number;
    winRate: number;
  };
  message: string;
  requestDate: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface ClanSettings {
  name: string;
  description: string;
  type: 'public' | 'private' | 'invite-only';
  requirements: {
    minLevel: number;
    minTrophies: number;
  };
  autoAccept: boolean;
  allowInvites: boolean;
  maxMembers: number;
}

export interface ClanManagementProps {
  members: ClanMember[];
  joinRequests: ClanJoinRequest[];
  settings: ClanSettings;
  userRole: 'leader' | 'officer' | 'member';
  onUpdateMember: (memberId: string, updates: Partial<ClanMember>) => void;
  onRemoveMember: (memberId: string) => void;
  onApproveRequest: (requestId: string) => void;
  onRejectRequest: (requestId: string) => void;
  onUpdateSettings: (settings: Partial<ClanSettings>) => void;
  onInvitePlayer: (playerName: string) => void;
}

export function ClanManagement({
  members,
  joinRequests,
  settings,
  userRole,
  onUpdateMember,
  onRemoveMember,
  onApproveRequest,
  onRejectRequest,
  onUpdateSettings,
  onInvitePlayer
}: ClanManagementProps) {
  const [activeTab, setActiveTab] = useState('members');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterBy, setFilterBy] = useState<'all' | 'online' | 'officers' | 'active'>('all');
  const [selectedMember, setSelectedMember] = useState<ClanMember | null>(null);
  const [editingSettings, setEditingSettings] = useState(false);
  const [invitePlayerName, setInvitePlayerName] = useState('');

  const canManageMembers = userRole === 'leader' || userRole === 'officer';
  const canManageSettings = userRole === 'leader';
  const canPromoteMembers = userRole === 'leader';

  const getRoleIcon = (role: ClanMember['role']) => {
    switch (role) {
      case 'leader': return <Crown className="w-4 h-4 text-yellow-500" />;
      case 'officer': return <Shield className="w-4 h-4 text-blue-500" />;
      default: return <Users className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getRoleText = (role: ClanMember['role']) => {
    switch (role) {
      case 'leader': return 'رهبر';
      case 'officer': return 'افسر';
      default: return 'عضو';
    }
  };

  const getStatusColor = (status: ClanMember['status']) => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const filteredMembers = members.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    switch (filterBy) {
      case 'online':
        return matchesSearch && member.status === 'online';
      case 'officers':
        return matchesSearch && (member.role === 'leader' || member.role === 'officer');
      case 'active':
        return matchesSearch && member.stats.weeklyActivity > 0;
      default:
        return matchesSearch;
    }
  });

  const handlePromoteMember = (memberId: string, newRole: ClanMember['role']) => {
    if (!canPromoteMembers) return;
    onUpdateMember(memberId, { role: newRole });
    toast.success('رتبه عضو تغییر کرد', {
      description: `عضو به ${getRoleText(newRole)} ارتقا یافت.`
    });
  };

  const handleRemoveMember = (memberId: string) => {
    if (!canManageMembers) return;
    onRemoveMember(memberId);
    toast.success('عضو از کلن حذف شد');
  };

  const handleInvitePlayer = () => {
    if (!invitePlayerName.trim()) return;
    onInvitePlayer(invitePlayerName);
    setInvitePlayerName('');
    toast.success('دعوت‌نامه ارسال شد', {
      description: `دعوت‌نامه به ${invitePlayerName} ارسال شد.`
    });
  };

  const pendingRequests = joinRequests.filter(req => req.status === 'pending');

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-bold text-xl flex items-center gap-2">
            <Settings className="w-6 h-6 text-primary" />
            مدیریت کلن
          </h2>
          <p className="text-muted-foreground">
            {members.length} عضو • {pendingRequests.length} درخواست در انتظار
          </p>
        </div>

        {canManageMembers && (
          <div className="flex gap-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <UserPlus className="w-4 h-4 ml-2" />
                  دعوت عضو
                </Button>
              </DialogTrigger>
              <DialogContent dir="rtl">
                <DialogHeader>
                  <DialogTitle>دعوت بازیکن جدید</DialogTitle>
                  <DialogDescription>
                    نام کاربری بازیکنی که می‌خواهید به کلن دعوت کنید را وارد کنید
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">نام کاربری بازیکن</label>
                    <Input
                      value={invitePlayerName}
                      onChange={(e) => setInvitePlayerName(e.target.value)}
                      placeholder="نام کاربری..."
                      dir="rtl"
                    />
                  </div>
                  <Button onClick={handleInvitePlayer} className="w-full">
                    ارسال دعوت‌نامه
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            {canManageSettings && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setEditingSettings(true)}
              >
                <Settings className="w-4 h-4 ml-2" />
                تنظیمات
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-blue-500">{members.length}</div>
          <div className="text-sm text-muted-foreground">کل اعضا</div>
        </Card>
        
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-green-500">
            {members.filter(m => m.status === 'online').length}
          </div>
          <div className="text-sm text-muted-foreground">آنلاین</div>
        </Card>
        
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-yellow-500">
            {members.filter(m => m.role === 'officer').length}
          </div>
          <div className="text-sm text-muted-foreground">افسر</div>
        </Card>
        
        <Card className="text-center p-4">
          <div className="text-2xl font-bold text-purple-500">{pendingRequests.length}</div>
          <div className="text-sm text-muted-foreground">درخواست</div>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="members">اعضا ({members.length})</TabsTrigger>
          <TabsTrigger value="requests">درخواست‌ها ({pendingRequests.length})</TabsTrigger>
          <TabsTrigger value="activity">فعالیت‌ها</TabsTrigger>
        </TabsList>

        <TabsContent value="members" className="space-y-4">
          {/* Members Filters */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="جستجو در اعضا..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pr-10"
                    dir="rtl"
                  />
                </div>
                
                <Select value={filterBy} onValueChange={(value: any) => setFilterBy(value)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">همه</SelectItem>
                    <SelectItem value="online">آنلاین</SelectItem>
                    <SelectItem value="officers">مدیران</SelectItem>
                    <SelectItem value="active">فعال</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Members List */}
          <Card>
            <CardContent className="p-0">
              <div className="divide-y">
                {filteredMembers.map((member) => (
                  <motion.div
                    key={member.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="p-4 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      {/* Member Stats */}
                      <div className="flex items-center gap-4 text-sm">
                        <div className="text-center min-w-[60px]">
                          <div className="font-bold text-yellow-600">{member.stats.trophies.toLocaleString()}</div>
                          <div className="text-xs text-muted-foreground">جام</div>
                        </div>
                        
                        <div className="text-center min-w-[50px]">
                          <div className="font-medium">
                            {Math.round((member.stats.wins / (member.stats.wins + member.stats.losses)) * 100)}%
                          </div>
                          <div className="text-xs text-muted-foreground">برد</div>
                        </div>
                        
                        <div className="text-center min-w-[50px]">
                          <div className="font-medium text-green-600">{member.stats.weeklyActivity}</div>
                          <div className="text-xs text-muted-foreground">فعالیت</div>
                        </div>
                      </div>

                      {/* Member Info */}
                      <div className="flex-1 flex items-center gap-3 justify-end">
                        <div className="text-right">
                          <div className="flex items-center gap-2 justify-end">
                            <span className="font-medium">{member.name}</span>
                            <div className="flex items-center gap-1">
                              {getRoleIcon(member.role)}
                              <span className="text-xs text-muted-foreground">{getRoleText(member.role)}</span>
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            <span>سطح {member.level}</span>
                            <span className="mx-2">•</span>
                            <span>پیوسته: {member.joinDate}</span>
                            <span className="mx-2">•</span>
                            <span>آخرین ورود: {member.lastActive}</span>
                          </div>
                        </div>

                        <div className="relative">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={member.avatar} />
                            <AvatarFallback>{member.name[0]}</AvatarFallback>
                          </Avatar>
                          <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-background ${getStatusColor(member.status)}`} />
                        </div>
                      </div>

                      {/* Actions */}
                      {canManageMembers && member.role !== 'leader' && (
                        <div className="flex items-center gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent dir="rtl">
                              <DialogHeader>
                                <DialogTitle>مدیریت عضو: {member.name}</DialogTitle>
                                <DialogDescription>
                                  تغییر نقش، ارسال پیام یا حذف این عضو از کلن
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                {canPromoteMembers && (
                                  <div className="space-y-2">
                                    <label className="text-sm font-medium">تغییر نقش</label>
                                    <Select
                                      value={member.role}
                                      onValueChange={(value: ClanMember['role']) => handlePromoteMember(member.id, value)}
                                    >
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="member">عضو عادی</SelectItem>
                                        <SelectItem value="officer">افسر</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>
                                )}
                                
                                <Separator />
                                
                                <div className="flex gap-2">
                                  <Button variant="outline" className="flex-1">
                                    <MessageSquare className="w-4 h-4 ml-2" />
                                    پیام خصوصی
                                  </Button>
                                  <Button 
                                    variant="destructive" 
                                    className="flex-1"
                                    onClick={() => handleRemoveMember(member.id)}
                                  >
                                    <UserMinus className="w-4 h-4 ml-2" />
                                    حذف از کلن
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="requests" className="space-y-4">
          {/* Join Requests */}
          {pendingRequests.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Mail className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="font-medium mb-2">درخواست جدیدی نیست</h3>
                <p className="text-muted-foreground">
                  هنوز درخواست عضویت جدیدی دریافت نشده است.
                </p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">درخواست‌های عضویت ({pendingRequests.length})</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {pendingRequests.map((request) => (
                  <motion.div
                    key={request.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 border rounded-lg space-y-4"
                  >
                    <div className="flex items-start gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={request.player.avatar} />
                        <AvatarFallback>{request.player.name[0]}</AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-medium">{request.player.name}</h4>
                          <Badge variant="outline">سطح {request.player.level}</Badge>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4 text-sm mb-3">
                          <div>
                            <span className="text-muted-foreground">جام‌ها:</span>
                            <span className="font-medium mr-2">{request.player.trophies.toLocaleString()}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">درصد برد:</span>
                            <span className="font-medium mr-2">{request.player.winRate}%</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground">درخواست:</span>
                            <span className="font-medium mr-2">{request.requestDate}</span>
                          </div>
                        </div>
                        
                        {request.message && (
                          <div className="bg-muted/50 p-3 rounded-lg mb-3">
                            <p className="text-sm">{request.message}</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {canManageMembers && (
                      <div className="flex gap-2">
                        <Button 
                          onClick={() => onApproveRequest(request.id)}
                          className="flex-1"
                        >
                          <CheckCircle className="w-4 h-4 ml-2" />
                          تایید
                        </Button>
                        <Button 
                          variant="outline"
                          onClick={() => onRejectRequest(request.id)}
                          className="flex-1"
                        >
                          <XCircle className="w-4 h-4 ml-2" />
                          رد
                        </Button>
                      </div>
                    )}
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">فعالیت‌های اخیر</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { type: 'join', user: 'محمد_گیمر', time: '2 ساعت پیش', icon: UserPlus },
                  { type: 'promote', user: 'سارا_پرو', time: '5 ساعت پیش', icon: Crown },
                  { type: 'win', user: 'علی_استریمر', time: '1 روز پیش', icon: Trophy },
                  { type: 'leave', user: 'احمد123', time: '2 روز پیش', icon: UserMinus }
                ].map((activity, index) => {
                  const Icon = activity.icon;
                  return (
                    <div key={index} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg">
                      <div className="p-2 bg-muted rounded-full">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <div className="text-sm">
                          {activity.type === 'join' && `${activity.user} به کلن پیوست`}
                          {activity.type === 'promote' && `${activity.user} به افسر ارتقا یافت`}
                          {activity.type === 'win' && `${activity.user} در تورنومنت برنده شد`}
                          {activity.type === 'leave' && `${activity.user} کلن را ترک کرد`}
                        </div>
                        <div className="text-xs text-muted-foreground">{activity.time}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Settings Dialog */}
      <Dialog open={editingSettings} onOpenChange={setEditingSettings}>
        <DialogContent className="max-w-2xl" dir="rtl">
          <DialogHeader>
            <DialogTitle>تنظیمات کلن</DialogTitle>
            <DialogDescription>
              تنظیمات عمومی کلن، شرایط عضویت و مجوزهای دسترسی
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* Basic Settings */}
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">نام کلن</label>
                <Input value={settings.name} dir="rtl" />
              </div>
              
              <div>
                <label className="text-sm font-medium">توضیحات</label>
                <Textarea value={settings.description} dir="rtl" rows={3} />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">نوع کلن</label>
                  <Select value={settings.type}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">عمومی</SelectItem>
                      <SelectItem value="private">خصوصی</SelectItem>
                      <SelectItem value="invite-only">فقط دعوت</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium">حداکثر اعضا</label>
                  <Input type="number" value={settings.maxMembers} />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">حداقل سطح</label>
                  <Input type="number" value={settings.requirements.minLevel} />
                </div>
                
                <div>
                  <label className="text-sm font-medium">حداقل جام</label>
                  <Input type="number" value={settings.requirements.minTrophies} />
                </div>
              </div>
            </div>
            
            <Separator />
            
            <div className="flex gap-2">
              <Button onClick={() => setEditingSettings(false)} className="flex-1">
                ذخیره تغییرات
              </Button>
              <Button variant="outline" onClick={() => setEditingSettings(false)} className="flex-1">
                انصراف
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}