/**
 * Lobby Invite Notifications System
 * سیستم اعلان‌های دعوتنامه لابی
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Avatar } from '../ui/avatar';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Bell, 
  Check, 
  X, 
  Clock, 
  Users, 
  MessageCircle,
  Calendar,
  ChevronRight,
  AlertCircle,
  CheckCircle,
  XCircle,
  Info
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { cn } from '../../lib/utils';
// Persian calendar utility removed

export interface LobbyInvitation {
  id: string;
  lobbyId: string;
  lobbyName: string;
  gameType: string;
  fromUserId: string;
  fromUsername: string;
  fromAvatar: string;
  toUserId: string;
  scheduledTime: Date;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
  createdAt: Date;
  expiresAt: Date;
  message?: string;
}

export interface ChatNotification {
  id: string;
  type: 'invite_accepted' | 'invite_declined' | 'lobby_reminder' | 'lobby_started';
  title: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
  metadata: {
    lobbyId?: string;
    userId?: string;
    username?: string;
  };
}

// Mock data
const MOCK_INVITATIONS: LobbyInvitation[] = [
  {
    id: 'inv_1',
    lobbyId: 'lobby_123',
    lobbyName: 'لابی فیفا شب',
    gameType: 'فیفا موبایل',
    fromUserId: 'user_1',
    fromUsername: 'علی حیدری',
    fromAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
    toUserId: 'current_user',
    scheduledTime: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
    status: 'pending',
    createdAt: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
    expiresAt: new Date(Date.now() + 22 * 60 * 60 * 1000), // 22 hours from now
    message: 'بیا برای یه بازی فیفا!'
  },
  {
    id: 'inv_2',
    lobbyId: 'lobby_456',
    lobbyName: 'تورنومنت پابجی',
    gameType: 'پابجی موبایل',
    fromUserId: 'user_2',
    fromUsername: 'سارا محمدی',
    fromAvatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b05b?w=40&h=40&fit=crop&crop=face',
    toUserId: 'current_user',
    scheduledTime: new Date(Date.now() + 4 * 60 * 60 * 1000), // 4 hours from now
    status: 'pending',
    createdAt: new Date(Date.now() - 15 * 60 * 1000), // 15 minutes ago
    expiresAt: new Date(Date.now() + 23 * 60 * 60 * 1000), // 23 hours from now
  }
];

const MOCK_CHAT_NOTIFICATIONS: ChatNotification[] = [
  {
    id: 'chat_1',
    type: 'invite_accepted',
    title: 'دعوتنامه پذیرفته شد',
    message: 'رضا کریمی دعوتنامه شما را برای "لابی کانتر" پذیرفت',
    timestamp: new Date(Date.now() - 10 * 60 * 1000),
    isRead: false,
    metadata: {
      lobbyId: 'lobby_789',
      userId: 'user_3',
      username: 'رضا کریمی'
    }
  },
  {
    id: 'chat_2',
    type: 'invite_declined',
    title: 'دعوتنامه رد شد',
    message: 'مینا رضایی دعوتنامه شما را برای "لابی فیفا" رد کرد',
    timestamp: new Date(Date.now() - 25 * 60 * 1000),
    isRead: false,
    metadata: {
      lobbyId: 'lobby_101',
      userId: 'user_4',
      username: 'مینا رضایی'
    }
  }
];

interface InvitationCardProps {
  invitation: LobbyInvitation;
  onAccept: (invitationId: string) => void;
  onDecline: (invitationId: string) => void;
  onViewDetails: (invitation: LobbyInvitation) => void;
}

const InvitationCard: React.FC<InvitationCardProps> = ({
  invitation,
  onAccept,
  onDecline,
  onViewDetails
}) => {
  const getTimeUntilStart = () => {
    const diffMs = invitation.scheduledTime.getTime() - Date.now();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffHours > 0) {
      return `${diffHours} ساعت و ${diffMinutes} دقیقه`;
    } else if (diffMinutes > 0) {
      return `${diffMinutes} دقیقه`;
    } else {
      return 'شروع شده';
    }
  };

  const getTimeUntilExpiry = () => {
    const diffMs = invitation.expiresAt.getTime() - Date.now();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours < 1) {
      const diffMinutes = Math.floor(diffMs / (1000 * 60));
      return `${diffMinutes} دقیقه`;
    }
    return `${diffHours} ساعت`;
  };

  const isExpiringSoon = (invitation.expiresAt.getTime() - Date.now()) < 2 * 60 * 60 * 1000; // 2 hours

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className={cn(
        "cursor-pointer transition-all",
        isExpiringSoon && "border-state-warning bg-state-warning-bg",
        invitation.status === 'accepted' && "border-state-success bg-state-success-bg",
        invitation.status === 'declined' && "border-state-danger bg-state-danger-bg"
      )}>
        <CardContent className="p-4">
          <div className="space-y-3">
            {/* Header */}
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <img src={invitation.fromAvatar} alt={invitation.fromUsername} />
              </Avatar>
              <div className="flex-1">
                <h4 className="font-medium">{invitation.lobbyName}</h4>
                <p className="text-sm text-text-secondary">
                  از {invitation.fromUsername} • {invitation.gameType}
                </p>
              </div>
              <Badge 
                variant={
                  invitation.status === 'pending' ? 'default' :
                  invitation.status === 'accepted' ? 'default' :
                  invitation.status === 'declined' ? 'destructive' : 'secondary'
                }
                className={cn(
                  invitation.status === 'accepted' && "bg-state-success text-white",
                  invitation.status === 'pending' && isExpiringSoon && "bg-state-warning text-black"
                )}
              >
                {invitation.status === 'pending' && 'در انتظار'}
                {invitation.status === 'accepted' && 'پذیرفته'}
                {invitation.status === 'declined' && 'رد شده'}
                {invitation.status === 'expired' && 'منقضی'}
              </Badge>
            </div>

            {/* Message */}
            {invitation.message && (
              <div className="bg-surface-secondary p-3 rounded-lg">
                <p className="text-sm">{invitation.message}</p>
              </div>
            )}

            {/* Time Info */}
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-text-tertiary" />
                <div>
                  <p className="text-text-tertiary">زمان شروع:</p>
                  <p>{getTimeUntilStart()} مانده</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-text-tertiary" />
                <div>
                  <p className="text-text-tertiary">انقضا:</p>
                  <p className={isExpiringSoon ? "text-state-warning" : ""}>
                    {getTimeUntilExpiry()} مانده
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            {invitation.status === 'pending' && (
              <motion.div 
                className="flex gap-2 pt-2"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDecline(invitation.id);
                  }}
                >
                  <X className="w-4 h-4 ml-1" />
                  رد کردن
                </Button>
                <Button
                  size="sm"
                  className="flex-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAccept(invitation.id);
                  }}
                >
                  <Check className="w-4 h-4 ml-1" />
                  پذیرفتن
                </Button>
              </motion.div>
            )}

            {/* View Details */}
            <Button
              variant="ghost"
              size="sm"
              className="w-full"
              onClick={() => onViewDetails(invitation)}
            >
              مشاهده جزئیات
              <ChevronRight className="w-4 h-4 mr-1" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

interface ChatNotificationCardProps {
  notification: ChatNotification;
  onMarkAsRead: (notificationId: string) => void;
}

const ChatNotificationCard: React.FC<ChatNotificationCardProps> = ({
  notification,
  onMarkAsRead
}) => {
  const getIcon = () => {
    switch (notification.type) {
      case 'invite_accepted':
        return <CheckCircle className="w-5 h-5 text-state-success" />;
      case 'invite_declined':
        return <XCircle className="w-5 h-5 text-state-danger" />;
      case 'lobby_reminder':
        return <Clock className="w-5 h-5 text-state-warning" />;
      case 'lobby_started':
        return <Info className="w-5 h-5 text-brand-primary" />;
      default:
        return <Bell className="w-5 h-5 text-text-secondary" />;
    }
  };

  const getTimeText = () => {
    const diffMs = Date.now() - notification.timestamp.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours > 0) return `${diffHours} ساعت پیش`;
    if (diffMinutes > 0) return `${diffMinutes} دقیقه پیش`;
    return 'همین الان';
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      whileHover={{ scale: 1.01 }}
      onClick={() => !notification.isRead && onMarkAsRead(notification.id)}
      className={cn(
        "p-3 rounded-lg border cursor-pointer transition-all",
        notification.isRead 
          ? "bg-surface-secondary border-border opacity-75" 
          : "bg-background border-brand-primary/20 shadow-sm"
      )}
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5">
          {getIcon()}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="font-medium text-sm">{notification.title}</h4>
            {!notification.isRead && (
              <div className="w-2 h-2 bg-brand-primary rounded-full" />
            )}
          </div>
          <p className="text-sm text-text-secondary mt-1 line-clamp-2">
            {notification.message}
          </p>
          <span className="text-xs text-text-tertiary">{getTimeText()}</span>
        </div>
      </div>
    </motion.div>
  );
};

// Main Component
interface LobbyInviteNotificationsProps {
  userId?: string;
  onInvitationResponse?: (invitationId: string, response: 'accept' | 'decline') => void;
  onNotificationRead?: (notificationId: string) => void;
}

export const LobbyInviteNotifications: React.FC<LobbyInviteNotificationsProps> = ({
  userId,
  onInvitationResponse,
  onNotificationRead
}) => {
  const [invitations, setInvitations] = useState(MOCK_INVITATIONS);
  const [chatNotifications, setChatNotifications] = useState(MOCK_CHAT_NOTIFICATIONS);
  const [selectedInvitation, setSelectedInvitation] = useState<LobbyInvitation | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  const pendingInvitations = invitations.filter(inv => inv.status === 'pending');
  const unreadNotifications = chatNotifications.filter(notif => !notif.isRead);

  const handleAcceptInvitation = (invitationId: string) => {
    setInvitations(prev => 
      prev.map(inv => 
        inv.id === invitationId 
          ? { ...inv, status: 'accepted' as const }
          : inv
      )
    );

    const invitation = invitations.find(inv => inv.id === invitationId);
    if (invitation) {
      // Add chat notification
      const newNotification: ChatNotification = {
        id: `chat_${Date.now()}`,
        type: 'invite_accepted',
        title: 'پذیرش دعوتنامه',
        message: `شما دعوتنامه "${invitation.lobbyName}" را پذیرفتید`,
        timestamp: new Date(),
        isRead: false,
        metadata: {
          lobbyId: invitation.lobbyId,
          userId: invitation.fromUserId,
          username: invitation.fromUsername
        }
      };
      
      setChatNotifications(prev => [newNotification, ...prev]);
      toast.success(`دعوتنامه "${invitation.lobbyName}" پذیرفته شد!`);
    }

    onInvitationResponse?.(invitationId, 'accept');
  };

  const handleDeclineInvitation = (invitationId: string) => {
    setInvitations(prev => 
      prev.map(inv => 
        inv.id === invitationId 
          ? { ...inv, status: 'declined' as const }
          : inv
      )
    );

    const invitation = invitations.find(inv => inv.id === invitationId);
    if (invitation) {
      // Add chat notification
      const newNotification: ChatNotification = {
        id: `chat_${Date.now()}`,
        type: 'invite_declined',
        title: 'رد دعوتنامه',
        message: `شما دعوتنامه "${invitation.lobbyName}" را رد کردید`,
        timestamp: new Date(),
        isRead: false,
        metadata: {
          lobbyId: invitation.lobbyId,
          userId: invitation.fromUserId,
          username: invitation.fromUsername
        }
      };
      
      setChatNotifications(prev => [newNotification, ...prev]);
      toast.error(`دعوتنامه "${invitation.lobbyName}" رد شد`);
    }

    onInvitationResponse?.(invitationId, 'decline');
  };

  const handleMarkAsRead = (notificationId: string) => {
    setChatNotifications(prev =>
      prev.map(notif =>
        notif.id === notificationId
          ? { ...notif, isRead: true }
          : notif
      )
    );
    onNotificationRead?.(notificationId);
  };

  const handleViewDetails = (invitation: LobbyInvitation) => {
    setSelectedInvitation(invitation);
    setIsDetailsOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Pending Invitations */}
      {pendingInvitations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-brand-primary" />
              دعوتنامه‌های جدید
              <Badge variant="destructive" className="mr-auto">
                {pendingInvitations.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <AnimatePresence>
                {pendingInvitations.map(invitation => (
                  <InvitationCard
                    key={invitation.id}
                    invitation={invitation}
                    onAccept={handleAcceptInvitation}
                    onDecline={handleDeclineInvitation}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </AnimatePresence>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Chat Notifications */}
      {unreadNotifications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-state-success" />
              اعلان‌های چت
              <Badge variant="secondary" className="mr-auto">
                {unreadNotifications.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-60">
              <div className="space-y-2">
                <AnimatePresence>
                  {chatNotifications.slice(0, 5).map(notification => (
                    <ChatNotificationCard
                      key={notification.id}
                      notification={notification}
                      onMarkAsRead={handleMarkAsRead}
                    />
                  ))}
                </AnimatePresence>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {pendingInvitations.length === 0 && unreadNotifications.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Bell className="w-12 h-12 mx-auto mb-4 text-text-tertiary opacity-50" />
            <h3 className="font-medium mb-2">هیچ اعلان جدیدی ندارید</h3>
            <p className="text-sm text-text-secondary">
              دعوتنامه‌ها و اعلان‌های جدید اینجا نمایش داده می‌شوند
            </p>
          </CardContent>
        </Card>
      )}

      {/* Invitation Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>جزئیات دعوتنامه</DialogTitle>
          </DialogHeader>
          {selectedInvitation && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Avatar className="w-12 h-12">
                  <ImageWithFallback src={selectedInvitation.fromAvatar} alt={selectedInvitation.fromUsername} />
                </Avatar>
                <div>
                  <h4 className="font-medium">{selectedInvitation.fromUsername}</h4>
                  <p className="text-sm text-text-secondary">@{selectedInvitation.fromUserId}</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-text-secondary">نام لابی</label>
                  <p>{selectedInvitation.lobbyName}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-text-secondary">نوع بازی</label>
                  <p>{selectedInvitation.gameType}</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-text-secondary">زمان شروع</label>
                  <p>{selectedInvitation.scheduledTime.toLocaleDateString('fa-IR')}</p>
                  <p className="text-sm text-text-secondary">
                    {selectedInvitation.scheduledTime.toLocaleTimeString('fa-IR')}
                  </p>
                </div>
                
                {selectedInvitation.message && (
                  <div>
                    <label className="text-sm font-medium text-text-secondary">پیام</label>
                    <div className="bg-surface-secondary p-3 rounded-lg mt-1">
                      <p>{selectedInvitation.message}</p>
                    </div>
                  </div>
                )}
              </div>
              
              {selectedInvitation.status === 'pending' && (
                <div className="flex gap-2 pt-4">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      handleDeclineInvitation(selectedInvitation.id);
                      setIsDetailsOpen(false);
                    }}
                  >
                    <X className="w-4 h-4 ml-1" />
                    رد کردن
                  </Button>
                  <Button
                    className="flex-1"
                    onClick={() => {
                      handleAcceptInvitation(selectedInvitation.id);
                      setIsDetailsOpen(false);
                    }}
                  >
                    <Check className="w-4 h-4 ml-1" />
                    پذیرفتن
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};