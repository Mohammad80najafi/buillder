import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Trophy, Users, Play, Clock, Star, Gamepad2, Zap, Target,
  TrendingUp, Calendar, MessageCircle, Coins, Award, Activity,
  Eye, Timer, Swords, Shield, Crosshair
} from 'lucide-react';
import { useMobile } from '../ui/use-mobile';
import { motion } from 'motion/react';

interface LiveStats {
  onlineUsers: number;
  activeLobbies: number;
  runningTournaments: number;
  totalMatches: number;
}

interface LiveMatch {
  id: string;
  game: string;
  players: string[];
  status: 'starting' | 'in-progress' | 'finishing';
  viewers: number;
  duration: string;
}

interface LeaderboardEntry {
  rank: number;
  username: string;
  points: number;
  gamesWon: number;
  winRate: number;
  avatar?: string;
}

export function RealTimeDashboard() {
  const isMobile = useMobile();
  const [liveStats, setLiveStats] = useState<LiveStats>({
    onlineUsers: 2847,
    activeLobbies: 156,
    runningTournaments: 12,
    totalMatches: 8934
  });

  const [liveMatches, setLiveMatches] = useState<LiveMatch[]>([
    {
      id: '1',
      game: 'کالاف دیوتی',
      players: ['علی_پرو', 'حسن_گیمر', 'سارا_وال', 'محمد_ایس'],
      status: 'in-progress',
      viewers: 234,
      duration: '12:34'
    },
    {
      id: '2',
      game: 'فیفا 24',
      players: ['احمد_کاپیتان', 'فاطمه_فیفا'],
      status: 'finishing',
      viewers: 89,
      duration: '23:45'
    },
    {
      id: '3',
      game: 'والورانت',
      players: ['رضا_شوت', 'مریم_کیل', 'امیر_کلاچ', 'نیلا_ایس', 'بهرام_پرو'],
      status: 'starting',
      viewers: 156,
      duration: '01:23'
    }
  ]);

  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([
    { rank: 1, username: 'علی_چمپیون', points: 15420, gamesWon: 234, winRate: 87.5 },
    { rank: 2, username: 'سارا_کیلر', points: 14890, gamesWon: 198, winRate: 85.2 },
    { rank: 3, username: 'محمد_استاد', points: 14120, gamesWon: 187, winRate: 82.8 },
    { rank: 4, username: 'فاطمه_پرو', points: 13650, gamesWon: 176, winRate: 81.4 },
    { rank: 5, username: 'احمد_ایس', points: 13200, gamesWon: 165, winRate: 79.9 }
  ]);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveStats(prev => ({
        ...prev,
        onlineUsers: prev.onlineUsers + Math.floor(Math.random() * 10) - 5,
        activeLobbies: prev.activeLobbies + Math.floor(Math.random() * 4) - 2,
        totalMatches: prev.totalMatches + Math.floor(Math.random() * 3)
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'starting': return 'bg-gradient-to-r from-yellow-500 to-orange-500';
      case 'in-progress': return 'bg-gradient-to-r from-green-500 to-emerald-500';
      case 'finishing': return 'bg-gradient-to-r from-red-500 to-pink-500';
      default: return 'bg-gradient-to-r from-gray-500 to-slate-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'starting': return 'شروع';
      case 'in-progress': return 'جریان';
      case 'finishing': return 'پایان';
      default: return 'نامعلوم';
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'from-yellow-500 to-orange-500';
      case 2: return 'from-gray-400 to-gray-500';
      case 3: return 'from-amber-600 to-amber-700';
      default: return 'from-muted to-muted-foreground';
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Trophy className="w-4 h-4" />;
      case 2: return <Award className="w-4 h-4" />;
      case 3: return <Star className="w-4 h-4" />;
      default: return <Target className="w-4 h-4" />;
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="space-y-6" 
      dir="rtl"
    >
      {/* Enhanced Live Stats Cards */}
      <div className={`grid ${isMobile ? 'grid-cols-2' : 'grid-cols-4'} gap-4`}>
        {[
          { 
            title: 'کاربران آنلاین', 
            value: liveStats.onlineUsers.toLocaleString('fa-IR'), 
            icon: Users, 
            color: 'from-green-500 to-emerald-500',
            bgColor: 'bg-green-500/10',
            borderColor: 'border-green-500/20'
          },
          { 
            title: 'لابی‌های فعال', 
            value: liveStats.activeLobbies, 
            icon: Play, 
            color: 'from-blue-500 to-cyan-500',
            bgColor: 'bg-blue-500/10',
            borderColor: 'border-blue-500/20'
          },
          { 
            title: 'تورنومنت‌ها', 
            value: liveStats.runningTournaments, 
            icon: Trophy, 
            color: 'from-yellow-500 to-orange-500',
            bgColor: 'bg-yellow-500/10',
            borderColor: 'border-yellow-500/20'
          },
          { 
            title: 'کل مسابقات', 
            value: liveStats.totalMatches.toLocaleString('fa-IR'), 
            icon: Target, 
            color: 'from-purple-500 to-pink-500',
            bgColor: 'bg-purple-500/10',
            borderColor: 'border-purple-500/20'
          }
        ].map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, duration: 0.5 }}
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <Card className={`relative overflow-hidden border-2 ${stat.borderColor} hover:border-primary/50 transition-all duration-300 group`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className={`text-2xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>
                      {stat.value}
                    </p>
                  </div>
                  <div className={`h-12 w-12 ${stat.bgColor} rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <stat.icon className={`h-6 w-6 bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`} />
                  </div>
                </div>
                
                {/* Animated pulse indicator */}
                <motion.div 
                  className={`absolute top-2 right-2 w-3 h-3 bg-gradient-to-r ${stat.color} rounded-full`}
                  animate={{ 
                    scale: [1, 1.5, 1],
                    opacity: [0.6, 1, 0.6]
                  }}
                  transition={{ 
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
                
                {/* Hover glow effect */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Main Dashboard Content */}
      <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-3'} gap-6`}>
        {/* Enhanced Live Matches */}
        <motion.div 
          className={isMobile ? 'col-span-1' : 'col-span-2'}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <Card className="border-2 border-primary/20 bg-gradient-to-br from-surface-primary via-surface-secondary to-surface-primary">
            <CardHeader>
              <CardTitle className="flex items-center">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Activity className="h-5 w-5 ml-2 text-green-500" />
                </motion.div>
                مسابقات زنده
                <Badge className="mr-2 bg-gradient-to-r from-red-500 to-pink-500 text-white border-0">
                  <motion.div
                    animate={{ opacity: [1, 0.5, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    ● زنده
                  </motion.div>
                </Badge>
              </CardTitle>
              <CardDescription>
                مسابقاتی که در حال حاضر در جریان هستند
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {liveMatches.map((match, index) => (
                <motion.div
                  key={match.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1, duration: 0.5 }}
                  whileHover={{ scale: 1.02 }}
                >
                  <Card className="border-l-4 border-l-primary bg-gradient-to-r from-surface-secondary/50 to-surface-tertiary/30 hover:from-surface-secondary/80 hover:to-surface-tertiary/50 transition-all duration-300">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <Button size="sm" variant="outline" className="hover:bg-primary/20">
                              <Eye className="h-3 w-3 ml-1" />
                              تماشا ({match.viewers})
                            </Button>
                            <Badge className={`${getStatusColor(match.status)} text-white border-0`}>
                              {getStatusText(match.status)}
                            </Badge>
                          </div>
                          <div className="text-right">
                            <h3 className="font-semibold flex items-center">
                              <Gamepad2 className="w-4 h-4 ml-1 text-primary" />
                              {match.game}
                            </h3>
                            <p className="text-sm text-muted-foreground flex items-center">
                              <Timer className="w-3 h-3 ml-1" />
                              مدت زمان: {match.duration}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap justify-end gap-2">
                          {match.players.map((player, index) => (
                            <motion.div 
                              key={index} 
                              className="flex items-center space-x-1 bg-surface-tertiary/50 rounded-lg px-2 py-1"
                              whileHover={{ scale: 1.05 }}
                            >
                              <span className="text-sm">{player}</span>
                              <Avatar className="h-6 w-6">
                                <AvatarFallback className="text-xs bg-gradient-to-br from-primary/20 to-secondary/20">
                                  {player[0]}
                                </AvatarFallback>
                              </Avatar>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        {/* Enhanced Sidebar */}
        <motion.div 
          className="space-y-6"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          {/* Enhanced Top Players Leaderboard */}
          <Card className="border-2 border-primary/20 bg-gradient-to-br from-surface-primary via-surface-secondary to-surface-primary">
            <CardHeader>
              <CardTitle className="flex items-center">
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                >
                  <Award className="h-5 w-5 ml-2 text-yellow-500" />
                </motion.div>
                جدول رتبه‌بندی
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {leaderboard.map((player, index) => (
                <motion.div 
                  key={player.rank} 
                  className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 bg-gradient-to-r from-surface-secondary/30 to-surface-tertiary/20 border border-border-secondary hover:border-primary/30 transition-all duration-300"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.1, duration: 0.5 }}
                  whileHover={{ scale: 1.02, x: 5 }}
                >
                  <div className="flex items-center space-x-3">
                    <div className="text-center">
                      <div className="text-xs text-muted-foreground">امتیاز</div>
                      <div className="text-sm font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                        {player.points.toLocaleString('fa-IR')}
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-muted-foreground">برد</div>
                      <div className="text-sm font-semibold">{player.gamesWon}</div>
                    </div>
                    <Progress 
                      value={player.winRate} 
                      className="w-16 h-2"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="text-right">
                      <div className="font-semibold text-sm">{player.username}</div>
                      <div className="text-xs text-muted-foreground">
                        نرخ برد: {player.winRate}%
                      </div>
                    </div>
                    <Avatar className="h-8 w-8 border-2 border-primary/30">
                      <AvatarFallback className="bg-gradient-to-br from-primary/20 to-secondary/20">
                        {player.username[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold bg-gradient-to-r ${getRankColor(player.rank)} text-white shadow-lg`}>
                      {getRankIcon(player.rank)}
                    </div>
                  </div>
                </motion.div>
              ))}
            </CardContent>
          </Card>

          {/* Enhanced Quick Actions */}
          <Card className="border-2 border-primary/20 bg-gradient-to-br from-surface-primary via-surface-secondary to-surface-primary">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="h-5 w-5 ml-2 text-blue-500" />
                اقدامات سریع
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { label: 'ایجاد لابی جدید', icon: Play, color: 'from-green-500 to-emerald-500' },
                { label: 'ثبت‌نام در تورنومنت', icon: Trophy, color: 'from-yellow-500 to-orange-500' },
                { label: 'مشاهده رتبه‌بندی', icon: TrendingUp, color: 'from-blue-500 to-cyan-500' },
                { label: 'پیام‌های جدید', icon: MessageCircle, color: 'from-purple-500 to-pink-500' }
              ].map((action, index) => (
                <motion.div
                  key={action.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + index * 0.1, duration: 0.4 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button className={`w-full justify-between bg-gradient-to-r ${action.color} hover:opacity-90 text-white border-0 shadow-lg hover:shadow-xl transition-all duration-300`}>
                    {action.label}
                    <action.icon className="h-4 w-4" />
                  </Button>
                </motion.div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
}