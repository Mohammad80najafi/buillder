import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardHeader } from '../ui/card';
import { GameButton } from '../ui/game-button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { 
  CheckCircle, 
  Clock, 
  Star, 
  Target, 
  Trophy,
  Coins,
  Gift,
  Zap
} from 'lucide-react';

export interface Mission {
  id: string;
  title: string;
  description: string;
  category: 'daily' | 'weekly' | 'achievement' | 'special';
  difficulty: 'easy' | 'medium' | 'hard' | 'legendary';
  progress: {
    current: number;
    target: number;
    unit?: string;
  };
  rewards: {
    xp: number;
    coins?: number;
    items?: {
      name: string;
      rarity: 'common' | 'rare' | 'epic' | 'legendary';
    }[];
  };
  deadline?: Date;
  isCompleted: boolean;
  isClaimed: boolean;
  isLocked?: boolean;
}

interface MissionCardProps {
  mission: Mission;
  onClaim?: () => void;
  onStart?: () => void;
  isClaiming?: boolean;
  className?: string;
}

const categoryConfig = {
  daily: { label: 'روزانه', color: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20', icon: Clock },
  weekly: { label: 'هفتگی', color: 'bg-green-100 text-green-800 dark:bg-green-900/20', icon: Target },
  achievement: { label: 'دستاورد', color: 'bg-purple-100 text-purple-800 dark:bg-purple-900/20', icon: Trophy },
  special: { label: 'ویژه', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20', icon: Star },
};

const difficultyConfig = {
  easy: { label: 'آسان', color: 'text-green-600', dots: 1 },
  medium: { label: 'متوسط', color: 'text-yellow-600', dots: 2 },
  hard: { label: 'سخت', color: 'text-red-600', dots: 3 },
  legendary: { label: 'افسانه‌ای', color: 'text-purple-600', dots: 4 },
};

const rarityColors = {
  common: 'text-gray-600',
  rare: 'text-blue-600',
  epic: 'text-purple-600',
  legendary: 'text-yellow-600',
};

export const MissionCard: React.FC<MissionCardProps> = ({
  mission,
  onClaim,
  onStart,
  isClaiming = false,
  className,
}) => {
  const categoryInfo = categoryConfig[mission.category];
  const difficultyInfo = difficultyConfig[mission.difficulty];
  const CategoryIcon = categoryInfo.icon;
  
  const progressPercentage = (mission.progress.current / mission.progress.target) * 100;
  const isCompleted = mission.isCompleted;
  const canClaim = isCompleted && !mission.isClaimed;

  const formatDeadline = (deadline: Date) => {
    const now = new Date();
    const timeLeft = deadline.getTime() - now.getTime();
    const hoursLeft = Math.floor(timeLeft / (1000 * 60 * 60));
    const daysLeft = Math.floor(hoursLeft / 24);
    
    if (daysLeft > 0) return `${daysLeft} روز باقی‌مانده`;
    if (hoursLeft > 0) return `${hoursLeft} ساعت باقی‌مانده`;
    return 'کمتر از یک ساعت';
  };

  return (
    <Card className={cn(
      'relative transition-all duration-200',
      isCompleted && 'border-green-200 bg-green-50/50 dark:bg-green-950/10',
      mission.isLocked && 'opacity-60',
      !mission.isLocked && 'hover:shadow-lg hover:scale-[1.02]',
      className
    )}>
      {isCompleted && !mission.isClaimed && (
        <div className="absolute -top-2 -right-2 z-10">
          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
            <CheckCircle className="w-4 h-4 text-white" />
          </div>
        </div>
      )}

      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <CategoryIcon className="w-4 h-4" />
            <Badge className={categoryInfo.color}>
              {categoryInfo.label}
            </Badge>
            {mission.category === 'special' && (
              <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white animate-pulse">
                <Zap className="w-3 h-3 mr-1" />
                محدود
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-1">
            {Array.from({ length: 4 }, (_, i) => (
              <div
                key={i}
                className={cn(
                  'w-2 h-2 rounded-full',
                  i < difficultyInfo.dots 
                    ? difficultyInfo.color.replace('text-', 'bg-')
                    : 'bg-gray-200 dark:bg-gray-700'
                )}
              />
            ))}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div>
          <h3 className="font-medium text-foreground mb-1">{mission.title}</h3>
          <p className="text-sm text-muted-foreground">{mission.description}</p>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>پیشرفت</span>
            <span className={isCompleted ? 'text-green-600 font-medium' : 'text-muted-foreground'}>
              {mission.progress.current} / {mission.progress.target}
              {mission.progress.unit && ` ${mission.progress.unit}`}
            </span>
          </div>
          <Progress 
            value={Math.min(progressPercentage, 100)} 
            className={cn('h-2', isCompleted && 'bg-green-100')}
          />
        </div>

        {/* Deadline */}
        {mission.deadline && !isCompleted && (
          <div className="flex items-center gap-2 text-sm text-orange-600">
            <Clock className="w-4 h-4" />
            <span>{formatDeadline(mission.deadline)}</span>
          </div>
        )}

        {/* Rewards */}
        <div className="p-3 bg-muted/50 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Gift className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium">جوایز:</span>
          </div>
          
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-1">
              <Zap className="w-3 h-3 text-blue-600" />
              <span>{mission.rewards.xp.toLocaleString('fa-IR')} XP</span>
            </div>
            
            {mission.rewards.coins && (
              <div className="flex items-center gap-1">
                <Coins className="w-3 h-3 text-yellow-600" />
                <span>{mission.rewards.coins.toLocaleString('fa-IR')} سکه</span>
              </div>
            )}
            
            {mission.rewards.items && mission.rewards.items.length > 0 && (
              <div className="flex items-center gap-1">
                <Trophy className="w-3 h-3 text-purple-600" />
                <span>
                  {mission.rewards.items.map((item, index) => (
                    <span key={index} className={rarityColors[item.rarity]}>
                      {item.name}
                      {index < mission.rewards.items!.length - 1 && ', '}
                    </span>
                  ))}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2">
          {mission.isLocked ? (
            <GameButton variant="secondary" disabled className="w-full">
              قفل شده
            </GameButton>
          ) : canClaim ? (
            <GameButton 
              onClick={onClaim}
              isLoading={isClaiming}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              <Gift className="w-4 h-4 mr-2" />
              دریافت جایزه
            </GameButton>
          ) : mission.isClaimed ? (
            <GameButton variant="secondary" disabled className="w-full">
              <CheckCircle className="w-4 h-4 mr-2" />
              دریافت شده
            </GameButton>
          ) : (
            <GameButton 
              onClick={onStart}
              variant="primary" 
              className="w-full"
            >
              شروع ماموریت
            </GameButton>
          )}
        </div>
      </CardContent>
    </Card>
  );
};