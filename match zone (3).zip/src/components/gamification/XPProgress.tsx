import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent } from '../ui/card';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { Star, Trophy, Zap } from 'lucide-react';

interface XPProgressProps {
  currentLevel: number;
  currentXP: number;
  xpToNextLevel: number;
  totalXPForCurrentLevel: number;
  levelName?: string;
  showDetails?: boolean;
  className?: string;
}

const getLevelColor = (level: number) => {
  if (level >= 50) return 'text-purple-600 bg-purple-100 dark:bg-purple-900/20';
  if (level >= 30) return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20';
  if (level >= 20) return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20';
  if (level >= 10) return 'text-green-600 bg-green-100 dark:bg-green-900/20';
  return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
};

const getLevelIcon = (level: number) => {
  if (level >= 50) return <Trophy className="w-4 h-4" />;
  if (level >= 20) return <Star className="w-4 h-4" />;
  return <Zap className="w-4 h-4" />;
};

const getDefaultLevelName = (level: number) => {
  if (level >= 50) return 'استاد';
  if (level >= 40) return 'متخصص';
  if (level >= 30) return 'پیشرفته';
  if (level >= 20) return 'ماهر';
  if (level >= 10) return 'تجربه‌کرده';
  if (level >= 5) return 'مبتدی پیشرفته';
  return 'تازه‌کار';
};

export const XPProgress: React.FC<XPProgressProps> = ({
  currentLevel,
  currentXP,
  xpToNextLevel,
  totalXPForCurrentLevel,
  levelName,
  showDetails = true,
  className,
}) => {
  const progressPercentage = totalXPForCurrentLevel > 0 
    ? ((currentXP / totalXPForCurrentLevel) * 100) 
    : 0;

  const xpNeeded = xpToNextLevel - currentXP;
  const displayLevelName = levelName || getDefaultLevelName(currentLevel);

  return (
    <Card className={className}>
      <CardContent className="p-4">
        <div className="space-y-4">
          {/* Level Badge and Name */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge className={cn('flex items-center gap-1', getLevelColor(currentLevel))}>
                {getLevelIcon(currentLevel)}
                سطح {currentLevel}
              </Badge>
              <span className="font-medium text-foreground">{displayLevelName}</span>
            </div>
            
            {showDetails && (
              <div className="text-sm text-muted-foreground">
                {currentXP.toLocaleString('fa-IR')} / {xpToNextLevel.toLocaleString('fa-IR')} XP
              </div>
            )}
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <Progress 
              value={progressPercentage} 
              className="h-3"
            />
            
            {showDetails && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  {xpNeeded.toLocaleString('fa-IR')} XP تا سطح {currentLevel + 1}
                </span>
                <span className="font-medium">
                  {progressPercentage.toFixed(1)}%
                </span>
              </div>
            )}
          </div>

          {/* Level Rewards Preview */}
          {showDetails && currentLevel % 5 === 4 && ( // Show when close to milestone levels
            <div className="p-3 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center gap-2 mb-1">
                <Trophy className="w-4 h-4 text-yellow-600" />
                <span className="text-sm font-medium text-yellow-700 dark:text-yellow-300">
                  جایزه سطح {currentLevel + 1}
                </span>
              </div>
              <p className="text-xs text-yellow-600 dark:text-yellow-400">
                ۵۰۰ سکه + نشان ویژه + دسترسی به ویژگی‌های جدید
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};