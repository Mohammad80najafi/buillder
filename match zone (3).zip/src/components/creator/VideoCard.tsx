import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent } from '../ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { PlayCircle, Eye, Clock, Heart, MessageCircle } from 'lucide-react';

export interface Video {
  id: string;
  title: string;
  thumbnail: string;
  creator: {
    id: string;
    name: string;
    avatar?: string;
    isVerified?: boolean;
  };
  duration: number;
  views: number;
  likes?: number;
  comments?: number;
  createdAt: Date;
  game?: string;
  isLive?: boolean;
  category: 'gameplay' | 'tutorial' | 'review' | 'stream' | 'highlights';
}

interface VideoCardProps {
  video: Video;
  onPlay?: () => void;
  onCreatorClick?: () => void;
  variant?: 'default' | 'compact';
  className?: string;
}

const categoryLabels = {
  gameplay: 'گیم‌پلی',
  tutorial: 'آموزش',
  review: 'بررسی',
  stream: 'استریم',
  highlights: 'هایلایت',
};

const categoryColors = {
  gameplay: 'bg-blue-100 text-blue-800 dark:bg-blue-900/20',
  tutorial: 'bg-green-100 text-green-800 dark:bg-green-900/20',
  review: 'bg-purple-100 text-purple-800 dark:bg-purple-900/20',
  stream: 'bg-red-100 text-red-800 dark:bg-red-900/20',
  highlights: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20',
};

export const VideoCard: React.FC<VideoCardProps> = ({
  video,
  onPlay,
  onCreatorClick,
  variant = 'default',
  className,
}) => {
  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const formatViews = (views: number) => {
    if (views >= 1000000) return `${(views / 1000000).toFixed(1)}M`;
    if (views >= 1000) return `${(views / 1000).toFixed(1)}K`;
    return views.toString();
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    const diffInDays = Math.floor(diffInHours / 24);
    
    if (diffInHours < 1) return 'کمتر از یک ساعت پیش';
    if (diffInHours < 24) return `${diffInHours} ساعت پیش`;
    if (diffInDays < 7) return `${diffInDays} روز پیش`;
    return date.toLocaleDateString('fa-IR');
  };

  return (
    <Card 
      className={cn('group cursor-pointer transition-all duration-200 hover:shadow-lg', className)}
      onClick={onPlay}
    >
      <CardContent className="p-0">
        <div className="relative">
          <div className={cn(
            'relative overflow-hidden rounded-t-lg',
            variant === 'compact' ? 'aspect-video' : 'aspect-video'
          )}>
            <img
              src={video.thumbnail}
              alt={video.title}
              className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
            />
            
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-200 flex items-center justify-center">
              <PlayCircle className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
            </div>

            {video.isLive && (
              <div className="absolute top-2 left-2">
                <Badge className="bg-red-500 text-white animate-pulse">
                  زنده
                </Badge>
              </div>
            )}

            <div className="absolute bottom-2 right-2">
              <Badge variant="secondary" className="text-xs bg-black/70 text-white">
                {formatDuration(video.duration)}
              </Badge>
            </div>

            <div className="absolute top-2 right-2">
              <Badge className={cn('text-xs', categoryColors[video.category])}>
                {categoryLabels[video.category]}
              </Badge>
            </div>
          </div>

          <div className="p-3">
            <div className="flex gap-3">
              <Avatar 
                className="w-10 h-10 flex-shrink-0 cursor-pointer" 
                onClick={(e) => {
                  e.stopPropagation();
                  onCreatorClick?.();
                }}
              >
                <AvatarImage src={video.creator.avatar} alt={video.creator.name} />
                <AvatarFallback>{video.creator.name.charAt(0)}</AvatarFallback>
              </Avatar>

              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-foreground line-clamp-2 mb-1 group-hover:text-primary transition-colors">
                  {video.title}
                </h3>
                
                <div className="flex items-center gap-2 mb-2">
                  <span 
                    className="text-sm text-muted-foreground hover:text-foreground cursor-pointer transition-colors"
                    onClick={(e) => {
                      e.stopPropagation();
                      onCreatorClick?.();
                    }}
                  >
                    {video.creator.name}
                  </span>
                  {video.creator.isVerified && (
                    <Badge className="bg-blue-500 text-white text-xs px-1">
                      ✓
                    </Badge>
                  )}
                  {video.game && (
                    <>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-sm text-muted-foreground">{video.game}</span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Eye className="w-4 h-4" />
                    <span>{formatViews(video.views)}</span>
                  </div>
                  
                  {video.likes && (
                    <div className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      <span>{formatViews(video.likes)}</span>
                    </div>
                  )}
                  
                  {video.comments && (
                    <div className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" />
                      <span>{formatViews(video.comments)}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>{formatTimeAgo(video.createdAt)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};