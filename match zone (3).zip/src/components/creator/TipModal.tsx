import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../ui/dialog';
import { GameButton } from '../ui/game-button';
import { GameInput } from '../ui/game-input';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Textarea } from '../ui/textarea';
import { Coins, Heart, Gift } from 'lucide-react';

interface Creator {
  id: string;
  name: string;
  avatar?: string;
}

interface TipModalProps {
  isOpen: boolean;
  onClose: () => void;
  creator: Creator;
  onSendTip: (amount: number, message?: string) => Promise<void>;
  userBalance: number;
}

const tipAmounts = [100, 500, 1000, 2500, 5000, 10000];

export const TipModal: React.FC<TipModalProps> = ({
  isOpen,
  onClose,
  creator,
  onSendTip,
  userBalance,
}) => {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const finalAmount = selectedAmount || parseInt(customAmount) || 0;
  const canSendTip = finalAmount > 0 && finalAmount <= userBalance;

  const handleSendTip = async () => {
    if (!canSendTip) return;

    setIsLoading(true);
    try {
      await onSendTip(finalAmount, message.trim() || undefined);
      setSelectedAmount(null);
      setCustomAmount('');
      setMessage('');
      onClose();
    } catch (error) {
      console.error('Failed to send tip:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount);
    setCustomAmount('');
  };

  const handleCustomAmountChange = (value: string) => {
    setCustomAmount(value);
    setSelectedAmount(null);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-right flex items-center gap-2">
            <Gift className="w-5 h-5 text-yellow-600" />
            ارسال انعام
          </DialogTitle>
          <DialogDescription className="text-right">
            به {creator.name} انعام بدهید
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Creator Info */}
          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
            <Avatar className="w-12 h-12">
              <AvatarImage src={creator.avatar} alt={creator.name} />
              <AvatarFallback>{creator.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium text-foreground">{creator.name}</h3>
              <p className="text-sm text-muted-foreground">کریتور</p>
            </div>
          </div>

          {/* User Balance */}
          <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-blue-600">موجودی شما</span>
            </div>
            <span className="font-medium text-blue-600">
              {userBalance.toLocaleString('fa-IR')} سکه
            </span>
          </div>

          {/* Quick Amount Selection */}
          <div className="space-y-3">
            <h4 className="font-medium text-right">انتخاب مبلغ</h4>
            <div className="grid grid-cols-3 gap-2">
              {tipAmounts.map((amount) => (
                <GameButton
                  key={amount}
                  variant={selectedAmount === amount ? 'primary' : 'secondary'}
                  size="sm"
                  onClick={() => handleAmountSelect(amount)}
                  disabled={amount > userBalance}
                  className="flex flex-col items-center py-3 h-auto"
                >
                  <Coins className="w-4 h-4 mb-1" />
                  <span className="text-xs">{amount.toLocaleString('fa-IR')}</span>
                </GameButton>
              ))}
            </div>
          </div>

          {/* Custom Amount */}
          <div className="space-y-2">
            <GameInput
              label="مبلغ دلخواه"
              placeholder="مبلغ سکه را وارد کنید"
              value={customAmount}
              onChange={(e) => handleCustomAmountChange(e.target.value)}
              type="number"
              min="1"
              max={userBalance}
            />
          </div>

          {/* Message */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              پیام (اختیاری)
            </label>
            <Textarea
              placeholder="پیام خود را بنویسید..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              maxLength={200}
              className="resize-none"
              rows={3}
            />
            <div className="text-xs text-muted-foreground text-left">
              {message.length}/200
            </div>
          </div>

          {/* Summary */}
          {finalAmount > 0 && (
            <div className="p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm">مبلغ انعام:</span>
                <span className="font-medium text-yellow-700">
                  {finalAmount.toLocaleString('fa-IR')} سکه
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">موجودی باقی‌مانده:</span>
                <span className="font-medium">
                  {(userBalance - finalAmount).toLocaleString('fa-IR')} سکه
                </span>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <GameButton
              variant="secondary"
              onClick={onClose}
              className="flex-1"
              disabled={isLoading}
            >
              انصراف
            </GameButton>
            <GameButton
              onClick={handleSendTip}
              disabled={!canSendTip || isLoading}
              isLoading={isLoading}
              className="flex-1 gap-2"
            >
              <Heart className="w-4 h-4" />
              ارسال انعام
            </GameButton>
          </div>

          {finalAmount > userBalance && (
            <p className="text-sm text-destructive text-center">
              موجودی شما کافی نیست
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};