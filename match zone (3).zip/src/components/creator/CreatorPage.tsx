import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { AspectRatio } from '../ui/aspect-ratio';
import { Play, Heart, Eye, Share, Gift, DollarSign, Clock, Users, Star, Zap } from 'lucide-react';
import { useMobile } from '../ui/use-mobile';

export function CreatorPage() {
  const [selectedVideo, setSelectedVideo] = useState<any>(null);
  const [tipAmount, setTipAmount] = useState('');
  const [isTipping, setIsTipping] = useState(false);
  const isMobile = useMobile();

  const videos = [
    {
      id: 1,
      title: '۱۰ نکته طلایی برای بهتر شدن در کالاف دیوتی',
      description: 'در این ویدیو بهترین تکنیک‌ها و راه‌های پیشرفت در کالاف دیوتی را یاد می‌گیرید',
      thumbnail: '/videos/cod-tips.jpg',
      duration: '12:34',
      views: 15420,
      likes: 1250,
      uploadDate: '۱۴۰۳/۰۸/۱۵',
      creator: {
        name: 'احمد_استریمر',
        avatar: '/avatars/ahmad.jpg',
        subscribers: 45000,
        verified: true
      },
      game: 'کالاف دیوتی',
      category: 'آموزش'
    },
    {
      id: 2,
      title: 'مسابقه لایو والورانت - گیم‌پلی کامل',
      description: 'تماشای کامل یک مسابقه تیمی والورانت با تحلیل و نکات حرفه‌ای',
      thumbnail: '/videos/valorant-gameplay.jpg',
      duration: '45:12',
      views: 28900,
      likes: 2100,
      uploadDate: '۱۴۰۳/۰۸/۱۴',
      creator: {
        name: 'سارا_پرو_گیمر',
        avatar: '/avatars/sara.jpg',
        subscribers: 67000,
        verified: true
      },
      game: 'والورانت',
      category: 'گیم‌پلی'
    },
    {
      id: 3,
      title: 'بررسی آپدیت جدید فیفا ۲۴',
      description: 'تمام تغییرات و ویژگی‌های جدید آپدیت اخیر فیفا ۲۴',
      thumbnail: '/videos/fifa-update.jpg',
      duration: '8:45',
      views: 12300,
      likes: 890,
      uploadDate: '۱۴۰۳/۰۸/۱۳',
      creator: {
        name: 'علی_فیفا_مستر',
        avatar: '/avatars/ali-fifa.jpg',
        subscribers: 23000,
        verified: false
      },
      game: 'فیفا ۲۴',
      category: 'بررسی'
    },
    {
      id: 4,
      title: 'چالش ۱۰۰ کیل در کالاف دیوتی!',
      description: 'تلاش برای رسیدن به ۱۰۰ کیل در یک روز کامل بازی',
      thumbnail: '/videos/100-kills-challenge.jpg',
      duration: '1:23:45',
      views: 45600,
      likes: 3400,
      uploadDate: '۱۴۰۳/۰۸/۱۲',
      creator: {
        name: 'محمد_چلنجر',
        avatar: '/avatars/mohammad-challenger.jpg',
        subscribers: 89000,
        verified: true
      },
      game: 'کالاف دیوتی',
      category: 'چالش'
    }
  ];

  const categories = ['همه', 'آموزش', 'گیم‌پلی', 'بررسی', 'چالش'];
  const [selectedCategory, setSelectedCategory] = useState('همه');

  const filteredVideos = selectedCategory === 'همه' 
    ? videos 
    : videos.filter(video => video.category === selectedCategory);

  const formatViews = (views: number) => {
    if (views >= 1000) {
      return (views / 1000).toFixed(1) + 'K';
    }
    return views.toString();
  };

  const formatDuration = (duration: string) => {
    return duration;
  };

  const tipAmounts = [5000, 10000, 25000, 50000];

  const handleTip = (video: any, amount: string) => {
    setIsTipping(true);
    console.log('Tipping', amount, 'to', video.creator.name);
    
    setTimeout(() => {
      setIsTipping(false);
      setSelectedVideo(null);
      setTipAmount('');
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="text-right" dir="rtl">
          <h1 className="text-2xl font-bold">کریتور</h1>
          <p className="text-muted-foreground">محتوای ویدیویی و استریم‌های زنده</p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(category)}
            className="whitespace-nowrap"
          >
            {category}
          </Button>
        ))}
      </div>

      {/* Videos Grid */}
      <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-2 xl:grid-cols-3'} gap-6`}>
        {filteredVideos.map((video) => (
          <Card key={video.id} className="overflow-hidden group hover:shadow-lg transition-shadow">
            {/* Video Thumbnail */}
            <div className="relative">
              <AspectRatio ratio={16 / 9}>
                <div className="w-full h-full bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                  <Play className="h-12 w-12 text-white/80" />
                </div>
              </AspectRatio>
              
              {/* Video Duration */}
              <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                {formatDuration(video.duration)}
              </div>

              {/* Play Overlay */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                <Button size="lg" className="rounded-full h-12 w-12 p-0">
                  <Play className="h-6 w-6" />
                </Button>
              </div>
            </div>

            <CardContent className="p-4">
              <div className="space-y-3">
                {/* Creator Info */}
                <div className="flex items-start space-x-3">
                  <div className="flex flex-col items-end space-y-1 flex-1">
                    <Badge variant="outline" className="text-xs">
                      {video.game}
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      {video.category}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center space-x-2" dir="rtl">
                    <div className="text-right">
                      <div className="flex items-center space-x-1">
                        {video.creator.verified && (
                          <div className="h-3 w-3 bg-blue-500 rounded-full"></div>
                        )}
                        <p className="text-sm font-medium">{video.creator.name}</p>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {formatViews(video.creator.subscribers)} دنبال‌کننده
                      </p>
                    </div>
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="text-xs">{video.creator.name[0]}</AvatarFallback>
                    </Avatar>
                  </div>
                </div>

                {/* Video Info */}
                <div className="text-right space-y-2" dir="rtl">
                  <h3 className="font-semibold line-clamp-2 leading-tight">{video.title}</h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">{video.description}</p>
                </div>

                {/* Stats */}
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>{video.uploadDate}</span>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <span>{formatViews(video.likes)}</span>
                      <Heart className="h-3 w-3" />
                    </div>
                    <div className="flex items-center space-x-1">
                      <span>{formatViews(video.views)}</span>
                      <Eye className="h-3 w-3" />
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex space-x-2 pt-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setSelectedVideo(video)}
                      >
                        <Gift className="h-3 w-3 ml-1" />
                        انعام
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle className="text-right" dir="rtl">انعام به کریتور</DialogTitle>
                        <DialogDescription className="text-right" dir="rtl">
                          مبلغ انعام خود را انتخاب کنید
                        </DialogDescription>
                      </DialogHeader>
                      
                      {selectedVideo && (
                        <div className="space-y-4">
                          {/* Creator Info */}
                          <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg" dir="rtl">
                            <div className="text-right">
                              <p className="font-medium">{selectedVideo.creator.name}</p>
                              <p className="text-sm text-muted-foreground">{selectedVideo.title}</p>
                            </div>
                            <Avatar>
                              <AvatarFallback>{selectedVideo.creator.name[0]}</AvatarFallback>
                            </Avatar>
                          </div>

                          {/* Quick Amounts */}
                          <div className="grid grid-cols-2 gap-2">
                            {tipAmounts.map((amount) => (
                              <Button
                                key={amount}
                                variant="outline"
                                onClick={() => setTipAmount(amount.toString())}
                                className={tipAmount === amount.toString() ? 'border-primary' : ''}
                              >
                                {new Intl.NumberFormat('fa-IR').format(amount)} تومان
                              </Button>
                            ))}
                          </div>

                          {/* Custom Amount */}
                          <div className="space-y-2">
                            <Label htmlFor="custom-tip" className="text-right" dir="rtl">مبلغ دلخواه</Label>
                            <Input
                              id="custom-tip"
                              placeholder="مثال: ۱۵۰۰۰"
                              value={tipAmount}
                              onChange={(e) => setTipAmount(e.target.value)}
                              className="text-right"
                              dir="rtl"
                            />
                          </div>

                          {/* Tip Button */}
                          <Button 
                            className="w-full"
                            onClick={() => handleTip(selectedVideo, tipAmount)}
                            disabled={!tipAmount || isTipping}
                          >
                            {isTipping ? (
                              <>
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                                در حال پردازش...
                              </>
                            ) : (
                              <>
                                <DollarSign className="h-4 w-4 ml-2" />
                                ارسال انعام
                              </>
                            )}
                          </Button>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>

                  <Button variant="outline" size="sm">
                    <Share className="h-3 w-3 ml-1" />
                    اشتراک
                  </Button>

                  <Button size="sm" className="flex-1">
                    <Play className="h-3 w-3 ml-1" />
                    تماشا
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Video Player Modal */}
      {selectedVideo && (
        <Dialog open={!!selectedVideo} onOpenChange={() => setSelectedVideo(null)}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle className="text-right" dir="rtl">{selectedVideo.title}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              {/* Video Player */}
              <AspectRatio ratio={16 / 9}>
                <div className="w-full h-full bg-black rounded-lg flex items-center justify-center">
                  <Button size="lg" className="rounded-full h-16 w-16 p-0">
                    <Play className="h-8 w-8" />
                  </Button>
                </div>
              </AspectRatio>

              {/* Video Details */}
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-4">
                    <Button variant="outline" size="sm">
                      <Share className="h-3 w-3 ml-1" />
                      اشتراک
                    </Button>
                    <Button variant="outline" size="sm">
                      <Heart className="h-3 w-3 ml-1" />
                      {formatViews(selectedVideo.likes)}
                    </Button>
                    <span className="text-sm text-muted-foreground">
                      {formatViews(selectedVideo.views)} بازدید
                    </span>
                  </div>
                  
                  <div className="text-right" dir="rtl">
                    <h2 className="text-lg font-bold">{selectedVideo.title}</h2>
                    <p className="text-sm text-muted-foreground">{selectedVideo.uploadDate}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4" dir="rtl">
                  <Button>
                    <Gift className="h-4 w-4 ml-2" />
                    انعام
                  </Button>
                  <Button variant="outline">
                    دنبال کردن
                  </Button>
                  <div className="flex items-center space-x-2">
                    <div className="text-right">
                      <p className="font-medium">{selectedVideo.creator.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {formatViews(selectedVideo.creator.subscribers)} دنبال‌کننده
                      </p>
                    </div>
                    <Avatar>
                      <AvatarFallback>{selectedVideo.creator.name[0]}</AvatarFallback>
                    </Avatar>
                  </div>
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm text-right" dir="rtl">{selectedVideo.description}</p>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {filteredVideos.length === 0 && (
        <Card className="p-12 text-center">
          <div className="space-y-4">
            <Play className="h-12 w-12 text-muted-foreground mx-auto" />
            <div>
              <h3 className="text-lg font-medium">ویدیویی یافت نشد</h3>
              <p className="text-muted-foreground">در این دسته‌بندی ویدیویی موجود نیست</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}