import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { TrustBadge, TrustLevel } from '../ui/trust-badge';
import { Trophy, Medal, Award, Crown } from 'lucide-react';

export interface LeaderboardEntry {
  id: string;
  rank: number;
  name: string;
  avatar?: string;
  score: number;
  change?: number; // Position change from last period
  trustLevel: TrustLevel;
  type: 'player' | 'clan' | 'party';
  metadata?: {
    level?: number;
    gamesPlayed?: number;
    winRate?: number;
    clanTag?: string;
    memberCount?: number;
  };
}

interface LeaderboardTableProps {
  entries: LeaderboardEntry[];
  title: string;
  scoreLabel: string;
  onEntryClick?: (entry: LeaderboardEntry) => void;
  className?: string;
}

const getRankIcon = (rank: number) => {
  switch (rank) {
    case 1:
      return <Crown className="w-5 h-5 text-yellow-500" />;
    case 2:
      return <Medal className="w-5 h-5 text-gray-400" />;
    case 3:
      return <Award className="w-5 h-5 text-amber-600" />;
    default:
      return null;
  }
};

const getRankBg = (rank: number) => {
  switch (rank) {
    case 1:
      return 'bg-gradient-to-r from-yellow-50 to-yellow-100 dark:from-yellow-950/20 dark:to-yellow-900/20 border-yellow-200';
    case 2:
      return 'bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-950/20 dark:to-gray-900/20 border-gray-200';
    case 3:
      return 'bg-gradient-to-r from-amber-50 to-amber-100 dark:from-amber-950/20 dark:to-amber-900/20 border-amber-200';
    default:
      return 'bg-card border-border hover:bg-accent/50';
  }
};

export const LeaderboardTable: React.FC<LeaderboardTableProps> = ({
  entries,
  title,
  scoreLabel,
  onEntryClick,
  className,
}) => {
  const formatScore = (score: number) => {
    if (score >= 1000000) return `${(score / 1000000).toFixed(1)}M`;
    if (score >= 1000) return `${(score / 1000).toFixed(1)}K`;
    return score.toLocaleString('fa-IR');
  };

  const formatChange = (change: number) => {
    if (change === 0) return null;
    const isPositive = change > 0;
    return (
      <span className={cn('text-xs', isPositive ? 'text-green-600' : 'text-red-600')}>
        {isPositive ? '↗' : '↘'} {Math.abs(change)}
      </span>
    );
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-right flex items-center gap-2">
          <Trophy className="w-5 h-5 text-yellow-600" />
          {title}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="space-y-1">
          {entries.map((entry, index) => (
            <div
              key={entry.id}
              className={cn(
                'flex items-center gap-4 p-4 border-b transition-all duration-200',
                getRankBg(entry.rank),
                onEntryClick && 'cursor-pointer hover:scale-[1.01]',
                index === entries.length - 1 && 'border-b-0'
              )}
              onClick={() => onEntryClick?.(entry)}
            >
              {/* Rank */}
              <div className="flex items-center justify-center w-8">
                {getRankIcon(entry.rank) || (
                  <span className="font-medium text-muted-foreground">
                    {entry.rank}
                  </span>
                )}
              </div>

              {/* Avatar & Info */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={entry.avatar} alt={entry.name} />
                  <AvatarFallback>
                    {entry.type === 'clan' ? entry.metadata?.clanTag?.charAt(0) : entry.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-foreground truncate">
                      {entry.name}
                    </h4>
                    {entry.metadata?.clanTag && (
                      <Badge variant="outline" className="text-xs">
                        [{entry.metadata.clanTag}]
                      </Badge>
                    )}
                    <TrustBadge level={entry.trustLevel} size="sm" showLabel={false} />
                  </div>
                  
                  <div className="flex items-center gap-3 text-sm text-muted-foreground">
                    {entry.metadata?.level && (
                      <span>سطح {entry.metadata.level}</span>
                    )}
                    {entry.metadata?.memberCount && (
                      <span>{entry.metadata.memberCount} عضو</span>
                    )}
                    {entry.metadata?.winRate && (
                      <span>{entry.metadata.winRate.toFixed(1)}% برد</span>
                    )}
                    {entry.metadata?.gamesPlayed && (
                      <span>{entry.metadata.gamesPlayed} بازی</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Score & Change */}
              <div className="text-right">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-lg">
                    {formatScore(entry.score)}
                  </span>
                  {entry.change !== undefined && formatChange(entry.change)}
                </div>
                <div className="text-xs text-muted-foreground">
                  {scoreLabel}
                </div>
              </div>
            </div>
          ))}
        </div>

        {entries.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>هنوز اطلاعاتی در جدول امتیازات وجود ندارد</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};