/**
 * Friend Invite System
 * سیستم دعوت دوستان برای لابی‌ها
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Input } from '../ui/input';
import { Avatar } from '../ui/avatar';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Checkbox } from '../ui/checkbox';
import { 
  Users, 
  UserPlus, 
  Search, 
  Send, 
  Check, 
  X, 
  Clock, 
  Star,
  MessageCircle,
  Bell,
  UserCheck,
  UserMinus
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { cn } from '../../lib/utils';

// Types
export interface Friend {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  isOnline: boolean;
  level: number;
  gamePreferences: string[];
  mutualFriends: number;
  lastSeen?: Date;
}

export interface LobbyInvitation {
  id: string;
  lobbyId: string;
  lobbyName: string;
  gameType: string;
  fromUserId: string;
  fromUsername: string;
  toUserId: string;
  scheduledTime: Date;
  status: 'pending' | 'accepted' | 'declined' | 'expired';
  createdAt: Date;
  expiresAt: Date;
  message?: string;
}

export interface InviteNotification {
  id: string;
  type: 'lobby_invite' | 'invite_accepted' | 'invite_declined' | 'lobby_reminder';
  title: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
  data: any;
}

// Mock data for friends
const MOCK_FRIENDS: Friend[] = [
  {
    id: '1',
    username: 'ali_gamer',
    displayName: 'علی حیدری',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face',
    isOnline: true,
    level: 25,
    gamePreferences: ['fifa-mobile', 'pubg-mobile'],
    mutualFriends: 5
  },
  {
    id: '2',
    username: 'sara_cs',
    displayName: 'سارا محمدی',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b05b?w=40&h=40&fit=crop&crop=face',
    isOnline: false,
    level: 18,
    gamePreferences: ['cs2', 'valorant'],
    mutualFriends: 3,
    lastSeen: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
  },
  {
    id: '3',
    username: 'reza_pro',
    displayName: 'رضا کریمی',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
    isOnline: true,
    level: 31,
    gamePreferences: ['cod-mobile', 'pubg-mobile'],
    mutualFriends: 8
  },
  {
    id: '4',
    username: 'mina_fifa',
    displayName: 'مینا رضایی',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face',
    isOnline: false,
    level: 22,
    gamePreferences: ['fifa-mobile'],
    mutualFriends: 2,
    lastSeen: new Date(Date.now() - 30 * 60 * 1000) // 30 minutes ago
  }
];

interface FriendCardProps {
  friend: Friend;
  isSelected: boolean;
  onSelect: (friend: Friend) => void;
  gameType?: string;
}

const FriendCard: React.FC<FriendCardProps> = ({ friend, isSelected, onSelect, gameType }) => {
  const isCompatible = gameType ? friend.gamePreferences.includes(gameType) : true;
  
  const getLastSeenText = () => {
    if (friend.isOnline) return 'آنلاین';
    if (!friend.lastSeen) return 'نامشخص';
    
    const diffMs = Date.now() - friend.lastSeen.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    
    if (diffHours > 0) return `${diffHours} ساعت پیش`;
    if (diffMinutes > 0) return `${diffMinutes} دقیقه پیش`;
    return 'همین الان';
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onSelect(friend)}
      className={cn(
        "p-3 rounded-xl border-2 cursor-pointer transition-all",
        isSelected 
          ? "border-brand-primary bg-brand-primary/10" 
          : "border-border hover:border-border-secondary",
        !isCompatible && "opacity-60"
      )}
    >
      <div className="flex items-center gap-3">
        <div className="relative">
          <Avatar className="w-10 h-10">
            <ImageWithFallback src={friend.avatar} alt={friend.displayName} className="w-full h-full object-cover" />
          </Avatar>
          <div className={cn(
            "absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-background",
            friend.isOnline ? "bg-state-success" : "bg-text-tertiary"
          )} />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="font-medium truncate">{friend.displayName}</h4>
            <Badge variant="secondary" className="text-xs">
              سطح {friend.level}
            </Badge>
          </div>
          <p className="text-sm text-text-secondary">@{friend.username}</p>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs text-text-tertiary">{getLastSeenText()}</span>
            {friend.mutualFriends > 0 && (
              <span className="text-xs text-brand-primary">
                {friend.mutualFriends} دوست مشترک
              </span>
            )}
          </div>
        </div>
        
        <div className="flex flex-col items-end gap-1">
          {isCompatible && gameType && (
            <Badge variant="outline" className="text-xs bg-state-success/10 text-state-success border-state-success/20">
              سازگار
            </Badge>
          )}
          {isSelected && (
            <Check className="w-5 h-5 text-brand-primary" />
          )}
        </div>
      </div>
    </motion.div>
  );
};

interface FriendInviteDialogProps {
  isOpen: boolean;
  onClose: () => void;
  lobbyName: string;
  gameType: string;
  scheduledTime: Date;
  onSendInvites: (friendIds: string[], message?: string) => void;
}

const FriendInviteDialog: React.FC<FriendInviteDialogProps> = ({
  isOpen,
  onClose,
  lobbyName,
  gameType,
  scheduledTime,
  onSendInvites
}) => {
  const [selectedFriends, setSelectedFriends] = useState<Friend[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [inviteMessage, setInviteMessage] = useState('');
  const [isSending, setIsSending] = useState(false);

  const filteredFriends = MOCK_FRIENDS.filter(friend =>
    friend.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    friend.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const compatibleFriends = filteredFriends.filter(friend =>
    friend.gamePreferences.includes(gameType)
  );

  const handleFriendSelect = (friend: Friend) => {
    setSelectedFriends(prev => {
      const isSelected = prev.some(f => f.id === friend.id);
      if (isSelected) {
        return prev.filter(f => f.id !== friend.id);
      } else {
        return [...prev, friend];
      }
    });
  };

  const handleSendInvites = async () => {
    if (selectedFriends.length === 0) return;
    
    setIsSending(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    onSendInvites(selectedFriends.map(f => f.id), inviteMessage);
    
    toast.success(`دعوتنامه برای ${selectedFriends.length} نفر ارسال شد!`);
    
    setSelectedFriends([]);
    setInviteMessage('');
    setSearchQuery('');
    setIsSending(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-brand-primary" />
            دعوت دوستان
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Lobby Info */}
          <Card className="bg-surface-secondary">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-brand-primary/10">
                  <Users className="w-5 h-5 text-brand-primary" />
                </div>
                <div>
                  <h4 className="font-medium">{lobbyName}</h4>
                  <p className="text-sm text-text-secondary">{gameType} • {scheduledTime.toLocaleString('fa-IR')}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Search */}
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-tertiary" />
            <Input
              placeholder="جستجو در دوستان..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
          </div>

          {/* Selected Friends */}
          {selectedFriends.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">انتخاب شده ({selectedFriends.length})</h4>
              <div className="flex flex-wrap gap-2">
                {selectedFriends.map(friend => (
                  <Badge 
                    key={friend.id} 
                    variant="secondary" 
                    className="flex items-center gap-2 p-2"
                  >
                    <Avatar className="w-4 h-4">
                      <ImageWithFallback src={friend.avatar} alt={friend.displayName} />
                    </Avatar>
                    {friend.displayName}
                    <X 
                      className="w-3 h-3 cursor-pointer hover:text-state-danger" 
                      onClick={() => handleFriendSelect(friend)}
                    />
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Friends List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium">دوستان</h4>
              <Badge variant="outline" className="text-xs">
                {compatibleFriends.length} نفر سازگار
              </Badge>
            </div>
            
            <ScrollArea className="h-60">
              <div className="space-y-2">
                {filteredFriends.length === 0 ? (
                  <div className="text-center py-8 text-text-secondary">
                    <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>دوستی یافت نشد</p>
                  </div>
                ) : (
                  filteredFriends.map(friend => (
                    <FriendCard
                      key={friend.id}
                      friend={friend}
                      isSelected={selectedFriends.some(f => f.id === friend.id)}
                      onSelect={handleFriendSelect}
                      gameType={gameType}
                    />
                  ))
                )}
              </div>
            </ScrollArea>
          </div>

          {/* Message */}
          <div>
            <label className="block text-sm font-medium mb-2">پیام دعوت (اختیاری)</label>
            <Input
              placeholder="پیامی برای دوستان خود بنویسید..."
              value={inviteMessage}
              onChange={(e) => setInviteMessage(e.target.value)}
              maxLength={100}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={onClose}
              disabled={isSending}
            >
              انصراف
            </Button>
            <Button 
              className="flex-1"
              onClick={handleSendInvites}
              disabled={selectedFriends.length === 0 || isSending}
            >
              {isSending ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  در حال ارسال...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Send className="w-4 h-4" />
                  ارسال دعوتنامه ({selectedFriends.length})
                </div>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

// Main Export Component
export interface FriendInviteSystemProps {
  lobbyId?: string;
  lobbyName: string;
  gameType: string;
  scheduledTime: Date;
  maxInvites?: number;
  onInvitesSent?: (invitations: LobbyInvitation[]) => void;
}

export const FriendInviteSystem: React.FC<FriendInviteSystemProps> = ({
  lobbyId,
  lobbyName,
  gameType,
  scheduledTime,
  maxInvites = 8,
  onInvitesSent
}) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [sentInvites, setSentInvites] = useState<LobbyInvitation[]>([]);

  const handleSendInvites = (friendIds: string[], message?: string) => {
    const newInvitations: LobbyInvitation[] = friendIds.map(friendId => {
      const friend = MOCK_FRIENDS.find(f => f.id === friendId);
      return {
        id: `invite_${Date.now()}_${friendId}`,
        lobbyId: lobbyId || 'temp_lobby',
        lobbyName,
        gameType,
        fromUserId: 'current_user',
        fromUsername: 'شما',
        toUserId: friendId,
        scheduledTime,
        status: 'pending' as const,
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
        message
      };
    });

    setSentInvites(prev => [...prev, ...newInvitations]);
    onInvitesSent?.(newInvitations);
  };

  const compatibleFriendsCount = MOCK_FRIENDS.filter(f => 
    f.gamePreferences.includes(gameType)
  ).length;

  return (
    <div className="space-y-4">
      {/* Invite Button */}
      <Button
        onClick={() => setIsDialogOpen(true)}
        className="w-full flex items-center gap-2"
        variant="outline"
      >
        <UserPlus className="w-4 h-4" />
        دعوت دوستان
        <Badge variant="secondary" className="mr-auto">
          {compatibleFriendsCount} نفر
        </Badge>
      </Button>

      {/* Sent Invites Summary */}
      {sentInvites.length > 0 && (
        <Card className="bg-surface-secondary">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium">دعوتنامه‌های ارسالی</h4>
              <Badge variant="outline">{sentInvites.length} نفر</Badge>
            </div>
            <div className="space-y-2">
              {sentInvites.slice(0, 3).map((invite) => {
                const friend = MOCK_FRIENDS.find(f => f.id === invite.toUserId);
                return (
                  <div key={invite.id} className="flex items-center gap-2 text-sm">
                    <Clock className="w-3 h-3 text-state-warning" />
                    <span>{friend?.displayName} - در انتظار پاسخ</span>
                  </div>
                );
              })}
              {sentInvites.length > 3 && (
                <p className="text-xs text-text-secondary">
                  و {sentInvites.length - 3} نفر دیگر...
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dialog */}
      <FriendInviteDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        lobbyName={lobbyName}
        gameType={gameType}
        scheduledTime={scheduledTime}
        onSendInvites={handleSendInvites}
      />
    </div>
  );
};