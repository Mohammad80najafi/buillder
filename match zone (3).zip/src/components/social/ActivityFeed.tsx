import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent } from '../ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';
import { GameButton } from '../ui/game-button';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Trophy, 
  Users, 
  GamepadIcon, 
  Crown, 
  Heart, 
  MessageCircle,
  Share2,
  MoreHorizontal 
} from 'lucide-react';

export interface ActivityItem {
  id: string;
  type: 'lobby_created' | 'tournament_won' | 'achievement_unlocked' | 'friend_joined' | 'post' | 'clan_joined';
  user: {
    id: string;
    name: string;
    avatar?: string;
  };
  timestamp: Date;
  content: string;
  metadata?: {
    game?: string;
    achievement?: string;
    lobbyId?: string;
    tournamentId?: string;
    clanName?: string;
    media?: string[];
  };
  interactions?: {
    likes: number;
    comments: number;
    shares: number;
    isLiked?: boolean;
  };
}

interface ActivityFeedProps {
  activities: ActivityItem[];
  onLike?: (activityId: string) => void;
  onComment?: (activityId: string) => void;
  onShare?: (activityId: string) => void;
  onUserClick?: (userId: string) => void;
  className?: string;
}

const activityIcons = {
  lobby_created: GamepadIcon,
  tournament_won: Trophy,
  achievement_unlocked: Crown,
  friend_joined: Users,
  post: MessageCircle,
  clan_joined: Users,
};

const activityColors = {
  lobby_created: 'text-blue-600',
  tournament_won: 'text-yellow-600',
  achievement_unlocked: 'text-purple-600',
  friend_joined: 'text-green-600',
  post: 'text-gray-600',
  clan_joined: 'text-indigo-600',
};

export const ActivityFeed: React.FC<ActivityFeedProps> = ({
  activities,
  onLike,
  onComment,
  onShare,
  onUserClick,
  className,
}) => {
  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'کمتر از یک ساعت پیش';
    if (diffInHours < 24) return `${diffInHours} ساعت پیش`;
    if (diffInHours < 24 * 7) return `${Math.floor(diffInHours / 24)} روز پیش`;
    return date.toLocaleDateString('fa-IR');
  };

  return (
    <div className={cn('space-y-4', className)}>
      {activities.map((activity) => {
        const Icon = activityIcons[activity.type];
        
        return (
          <Card key={activity.id} className="transition-all duration-200 hover:shadow-md">
            <CardContent className="p-4">
              <div className="flex gap-3">
                <div className="relative">
                  <Avatar className="w-10 h-10 cursor-pointer" onClick={() => onUserClick?.(activity.user.id)}>
                    <AvatarImage src={activity.user.avatar} alt={activity.user.name} />
                    <AvatarFallback>{activity.user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className={cn(
                    'absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-background border-2 border-background flex items-center justify-center',
                    activityColors[activity.type]
                  )}>
                    <Icon className="w-3 h-3" />
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span 
                          className="font-medium text-foreground cursor-pointer hover:underline"
                          onClick={() => onUserClick?.(activity.user.id)}
                        >
                          {activity.user.name}
                        </span>
                        {activity.metadata?.game && (
                          <Badge variant="secondary" className="text-xs">
                            {activity.metadata.game}
                          </Badge>
                        )}
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-2">
                        {activity.content}
                      </p>

                      {activity.metadata?.achievement && (
                        <div className="flex items-center gap-2 p-2 rounded-lg bg-muted/50 mb-2">
                          <Crown className="w-4 h-4 text-yellow-600" />
                          <span className="text-sm font-medium">
                            دستاورد: {activity.metadata.achievement}
                          </span>
                        </div>
                      )}

                      {activity.metadata?.media && activity.metadata.media.length > 0 && (
                        <div className="grid grid-cols-2 gap-2 mb-3">
                          {activity.metadata.media.slice(0, 4).map((media, index) => (
                            <div key={index} className="aspect-video rounded-lg overflow-hidden bg-muted">
                              <img
                                src={media}
                                alt="پست"
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">
                          {formatTimeAgo(activity.timestamp)}
                        </span>

                        {activity.interactions && (
                          <div className="flex items-center gap-4">
                            <button
                              onClick={() => onLike?.(activity.id)}
                              className={cn(
                                'flex items-center gap-1 text-sm transition-colors hover:text-red-600',
                                activity.interactions.isLiked ? 'text-red-600' : 'text-muted-foreground'
                              )}
                            >
                              <Heart className={cn('w-4 h-4', activity.interactions.isLiked && 'fill-current')} />
                              <span>{activity.interactions.likes}</span>
                            </button>

                            <button
                              onClick={() => onComment?.(activity.id)}
                              className="flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-blue-600"
                            >
                              <MessageCircle className="w-4 h-4" />
                              <span>{activity.interactions.comments}</span>
                            </button>

                            <button
                              onClick={() => onShare?.(activity.id)}
                              className="flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-green-600"
                            >
                              <Share2 className="w-4 h-4" />
                              <span>{activity.interactions.shares}</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    <button className="text-muted-foreground hover:text-foreground p-1">
                      <MoreHorizontal className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
      
      {activities.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <GamepadIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>هیچ فعالیتی یافت نشد</p>
          <p className="text-sm">وقتی دوستان شما فعالیت کنند، اینجا نمایش داده می‌شود</p>
        </div>
      )}
    </div>
  );
};