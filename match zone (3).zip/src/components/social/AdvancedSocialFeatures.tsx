/**
 * Advanced Social Features - Enhanced social interactions and community
 * مرحله 5: ویژگی‌های اجتماعی پیشرفته
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Textarea } from '../ui/textarea';
import { 
  Users,
  MessageSquare,
  Heart,
  Share2,
  Camera,
  Video,
  Mic,
  MicOff,
  VideoOff,
  MoreHorizontal,
  ThumbsUp,
  MessageCircle,
  Bookmark,
  Send,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Settings,
  UserPlus,
  UserCheck,
  Crown,
  Star,
  Trophy,
  Zap,
  Shield,
  Gift,
  Clock,
  MapPin,
  Eye,
  TrendingUp,
  Radio,
  PlusCircle
} from 'lucide-react';

interface Post {
  id: string;
  author: {
    id: string;
    username: string;
    displayName: string;
    avatar: string;
    isVerified: boolean;
    badge?: string;
  };
  content: {
    text?: string;
    media?: {
      type: 'image' | 'video' | 'gif';
      url: string;
      thumbnail?: string;
    }[];
    game?: {
      name: string;
      achievement?: string;
      score?: number;
    };
  };
  engagement: {
    likes: number;
    comments: number;
    shares: number;
    bookmarks: number;
    isLiked: boolean;
    isBookmarked: boolean;
  };
  timestamp: string;
  location?: string;
  isPromoted?: boolean;
}

interface LiveStream {
  id: string;
  streamer: {
    id: string;
    username: string;
    displayName: string;
    avatar: string;
    followers: number;
    isPartner: boolean;
  };
  title: string;
  game: string;
  viewers: number;
  duration: string;
  thumbnail: string;
  tags: string[];
  category: 'gaming' | 'tutorial' | 'casual' | 'tournament';
  isLive: boolean;
}

interface CommunityGroup {
  id: string;
  name: string;
  description: string;
  avatar: string;
  banner: string;
  members: number;
  category: string;
  isJoined: boolean;
  privacy: 'public' | 'private';
  recentActivity: number;
  moderators: string[];
  rules: string[];
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: string;
  progress?: number;
  maxProgress?: number;
}

const mockPosts: Post[] = [
  {
    id: '1',
    author: {
      id: '1',
      username: 'persian_legend',
      displayName: 'افسانه پارس',
      avatar: '/avatars/legend.png',
      isVerified: true,
      badge: 'چمپیون'
    },
    content: {
      text: 'تازه یه کلیپ فوق‌العاده از آخرین بازی‌م رو آپلود کردم! 🔥',
      media: [
        {
          type: 'video',
          url: '/videos/highlight1.mp4',
          thumbnail: '/thumbnails/highlight1.jpg'
        }
      ],
      game: {
        name: 'CS:GO',
        achievement: 'ACE',
        score: 5
      }
    },
    engagement: {
      likes: 1247,
      comments: 89,
      shares: 34,
      bookmarks: 156,
      isLiked: false,
      isBookmarked: true
    },
    timestamp: '2 ساعت پیش',
    location: 'تهران، ایران',
    isPromoted: false
  },
  {
    id: '2',
    author: {
      id: '2',
      username: 'shadow_master',
      displayName: 'استاد سایه',
      avatar: '/avatars/shadow.png',
      isVerified: false,
      badge: 'استاد'
    },
    content: {
      text: 'امشب استریم آموزشی دارم! کسایی که میخوان تاکتیک‌های جدید یاد بگیرن، حتماً بیان 📚',
      game: {
        name: 'Valorant'
      }
    },
    engagement: {
      likes: 567,
      comments: 43,
      shares: 21,
      bookmarks: 78,
      isLiked: true,
      isBookmarked: false
    },
    timestamp: '4 ساعت پیش'
  }
];

const mockStreams: LiveStream[] = [
  {
    id: '1',
    streamer: {
      id: '1',
      username: 'pro_gamer_ir',
      displayName: 'پرو گیمر ایران',
      avatar: '/streamers/pro1.jpg',
      followers: 25400,
      isPartner: true
    },
    title: 'رنکد پلی + آموزش تاکتیک جدید',
    game: 'CS:GO',
    viewers: 1247,
    duration: '2:34:12',
    thumbnail: '/streams/cs-stream.jpg',
    tags: ['رنکد', 'آموزشی', 'تاکتیک'],
    category: 'gaming',
    isLive: true
  },
  {
    id: '2',
    streamer: {
      id: '2',
      username: 'iranian_valorant',
      displayName: 'والورانت ایرانی',
      avatar: '/streamers/valorant.jpg',
      followers: 18900,
      isPartner: false
    },
    title: 'مسابقه با بینندگان - جوایز ویژه!',
    game: 'Valorant',
    viewers: 856,
    duration: '1:45:30',
    thumbnail: '/streams/valorant-stream.jpg',
    tags: ['مسابقه', 'جایزه', 'تعامل'],
    category: 'casual',
    isLive: true
  }
];

const mockCommunities: CommunityGroup[] = [
  {
    id: '1',
    name: 'گیمرهای ایرانی',
    description: 'بزرگ‌ترین انجمن گیمرهای ایران',
    avatar: '/communities/iranian-gamers.jpg',
    banner: '/communities/iranian-gamers-banner.jpg',
    members: 45670,
    category: 'عمومی',
    isJoined: true,
    privacy: 'public',
    recentActivity: 1247,
    moderators: ['admin1', 'admin2'],
    rules: ['احترام به دیگران', 'ممنوعیت اسپم', 'محتوای مناسب']
  },
  {
    id: '2',
    name: 'کلن‌های حرفه‌ای',
    description: 'انجمن تیم‌ها و کلن‌های حرفه‌ای',
    avatar: '/communities/pro-clans.jpg',
    banner: '/communities/pro-clans-banner.jpg',
    members: 12450,
    category: 'تخصصی',
    isJoined: false,
    privacy: 'private',
    recentActivity: 567,
    moderators: ['pro_admin'],
    rules: ['فقط کلن‌های تایید شده', 'محتوای حرفه‌ای', 'ممنوعیت تبلیغ']
  }
];

const mockAchievements: Achievement[] = [
  {
    id: '1',
    name: 'اولین برد',
    description: 'اولین پیروزی در بازی',
    icon: '/achievements/first-win.png',
    rarity: 'common',
    unlockedAt: '1403/05/12'
  },
  {
    id: '2',
    name: 'سری‌کیلر',
    description: '10 کشتن متوالی بدون مرگ',
    icon: '/achievements/killing-spree.png',
    rarity: 'rare',
    unlockedAt: '1403/05/28'
  },
  {
    id: '3',
    name: 'افسانه',
    description: 'رسیدن به رتبه افسانه‌ای',
    icon: '/achievements/legendary.png',
    rarity: 'legendary',
    progress: 85,
    maxProgress: 100
  }
];

const getRarityColor = (rarity: string) => {
  const colors = {
    common: 'text-gray-500 bg-gray-100 dark:bg-gray-900',
    rare: 'text-blue-500 bg-blue-100 dark:bg-blue-900',
    epic: 'text-purple-500 bg-purple-100 dark:bg-purple-900',
    legendary: 'text-orange-500 bg-orange-100 dark:bg-orange-900'
  };
  return colors[rarity as keyof typeof colors] || colors.common;
};

export function AdvancedSocialFeatures() {
  const [activeTab, setActiveTab] = useState('feed');
  const [isCommenting, setIsCommenting] = useState<string | null>(null);
  const [newComment, setNewComment] = useState('');

  const handleLike = (postId: string) => {
    console.log('Like post:', postId);
  };

  const handleComment = (postId: string) => {
    if (newComment.trim()) {
      console.log('Comment on post:', postId, newComment);
      setNewComment('');
      setIsCommenting(null);
    }
  };

  const handleJoinCommunity = (communityId: string) => {
    console.log('Join community:', communityId);
  };

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto" dir="rtl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        <div className="flex items-center justify-center gap-3">
          <Users className="w-8 h-8 text-purple-500" />
          <h1 className="text-3xl font-bold">اجتماع Matchzone</h1>
        </div>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          با گیمرهای ایرانی در ارتباط باشید، از آخرین رویدادها مطلع شوید و تجربیاتتان را به اشتراک بگذارید
        </p>
      </motion.div>

      {/* Main Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="feed">خبرخوان</TabsTrigger>
            <TabsTrigger value="streams">استریم‌ها</TabsTrigger>
            <TabsTrigger value="communities">انجمن‌ها</TabsTrigger>
            <TabsTrigger value="achievements">دستاوردها</TabsTrigger>
            <TabsTrigger value="events">رویدادها</TabsTrigger>
          </TabsList>

          {/* Feed */}
          <TabsContent value="feed" className="space-y-4">
            {/* Create Post */}
            <Card>
              <CardContent className="p-4">
                <div className="flex gap-3">
                  <Avatar>
                    <AvatarImage src="/current-user.jpg" />
                    <AvatarFallback>شما</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <Textarea 
                      placeholder="چه خبر؟ آخرین دستاوردتان را با دوستان به اشتراک بگذارید..."
                      className="mb-3 resize-none"
                      rows={3}
                    />
                    <div className="flex items-center justify-between">
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Camera className="w-4 h-4 ml-2" />
                          عکس
                        </Button>
                        <Button size="sm" variant="outline">
                          <Video className="w-4 h-4 ml-2" />
                          ویدیو
                        </Button>
                        <Button size="sm" variant="outline">
                          <Trophy className="w-4 h-4 ml-2" />
                          دستاورد
                        </Button>
                      </div>
                      <Button size="sm">
                        انتشار
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Posts */}
            <div className="space-y-4">
              {mockPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={post.author.avatar} alt={post.author.displayName} />
                            <AvatarFallback>{post.author.displayName.charAt(0)}</AvatarFallback>
                          </Avatar>
                          
                          <div>
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{post.author.displayName}</h3>
                              {post.author.isVerified && (
                                <Shield className="w-4 h-4 text-blue-500" />
                              )}
                              {post.author.badge && (
                                <Badge variant="secondary" className="text-xs">
                                  {post.author.badge}
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <span>@{post.author.username}</span>
                              <span>•</span>
                              <span>{post.timestamp}</span>
                              {post.location && (
                                <>
                                  <span>•</span>
                                  <div className="flex items-center gap-1">
                                    <MapPin className="w-3 h-3" />
                                    <span>{post.location}</span>
                                  </div>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <Button size="sm" variant="ghost">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      {post.content.text && (
                        <p>{post.content.text}</p>
                      )}

                      {post.content.game && (
                        <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                          <Gamepad2 className="w-5 h-5 text-blue-500" />
                          <div className="flex-1">
                            <p className="font-medium">{post.content.game.name}</p>
                            {post.content.game.achievement && (
                              <p className="text-sm text-muted-foreground">
                                {post.content.game.achievement}
                                {post.content.game.score && ` - ${post.content.game.score} کشتن`}
                              </p>
                            )}
                          </div>
                        </div>
                      )}

                      {post.content.media && post.content.media.length > 0 && (
                        <div className="rounded-lg overflow-hidden bg-muted aspect-video flex items-center justify-center">
                          <Play className="w-12 h-12 text-white/80" />
                        </div>
                      )}

                      {/* Engagement */}
                      <div className="flex items-center justify-between pt-2 border-t">
                        <div className="flex gap-6">
                          <Button
                            size="sm"
                            variant="ghost"
                            className={post.engagement.isLiked ? 'text-red-500' : ''}
                            onClick={() => handleLike(post.id)}
                          >
                            <Heart className={`w-4 h-4 ml-2 ${post.engagement.isLiked ? 'fill-current' : ''}`} />
                            {post.engagement.likes}
                          </Button>
                          
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setIsCommenting(post.id === isCommenting ? null : post.id)}
                          >
                            <MessageCircle className="w-4 h-4 ml-2" />
                            {post.engagement.comments}
                          </Button>
                          
                          <Button size="sm" variant="ghost">
                            <Share2 className="w-4 h-4 ml-2" />
                            {post.engagement.shares}
                          </Button>
                          
                          <Button
                            size="sm"
                            variant="ghost"
                            className={post.engagement.isBookmarked ? 'text-yellow-500' : ''}
                          >
                            <Bookmark className={`w-4 h-4 ${post.engagement.isBookmarked ? 'fill-current' : ''}`} />
                          </Button>
                        </div>
                      </div>

                      {/* Comment Section */}
                      <AnimatePresence>
                        {isCommenting === post.id && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="flex gap-3 pt-3 border-t"
                          >
                            <Avatar className="w-8 h-8">
                              <AvatarImage src="/current-user.jpg" />
                              <AvatarFallback>شما</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 flex gap-2">
                              <Textarea
                                placeholder="نظر شما..."
                                value={newComment}
                                onChange={(e) => setNewComment(e.target.value)}
                                className="resize-none"
                                rows={2}
                              />
                              <Button
                                size="sm"
                                onClick={() => handleComment(post.id)}
                                disabled={!newComment.trim()}
                              >
                                <Send className="w-4 h-4" />
                              </Button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Streams */}
          <TabsContent value="streams" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">استریم‌های زنده</h2>
              <Button variant="outline" size="sm">
                <Radio className="w-4 h-4 ml-2" />
                شروع استریم
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockStreams.map((stream, index) => (
                <motion.div
                  key={stream.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="overflow-hidden hover:shadow-lg transition-all">
                    <div className="relative aspect-video bg-gradient-to-br from-purple-500/20 to-blue-500/20">
                      <div className="absolute top-2 left-2">
                        <Badge variant="destructive" className="text-xs">
                          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse mr-1" />
                          زنده
                        </Badge>
                      </div>
                      <div className="absolute bottom-2 left-2">
                        <Badge variant="secondary" className="text-xs">
                          <Eye className="w-3 h-3 ml-1" />
                          {stream.viewers.toLocaleString()}
                        </Badge>
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Play className="w-12 h-12 text-white/80" />
                      </div>
                    </div>

                    <CardContent className="p-4">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="relative">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={stream.streamer.avatar} alt={stream.streamer.displayName} />
                            <AvatarFallback>{stream.streamer.displayName.charAt(0)}</AvatarFallback>
                          </Avatar>
                          {stream.streamer.isPartner && (
                            <Crown className="w-4 h-4 text-purple-500 absolute -top-1 -right-1" />
                          )}
                        </div>
                        
                        <div className="flex-1">
                          <h3 className="font-medium text-sm mb-1 line-clamp-2">
                            {stream.title}
                          </h3>
                          <p className="text-xs text-muted-foreground mb-1">
                            {stream.streamer.displayName}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {stream.game} • {stream.duration}
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1 mb-3">
                        {stream.tags.map((tag, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <Button size="sm" className="w-full">
                        مشاهده استریم
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Communities */}
          <TabsContent value="communities" className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold">انجمن‌های فعال</h2>
              <Button variant="outline" size="sm">
                <PlusCircle className="w-4 h-4 ml-2" />
                ایجاد انجمن
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mockCommunities.map((community, index) => (
                <motion.div
                  key={community.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="overflow-hidden hover:shadow-lg transition-all">
                    <div className="relative h-24 bg-gradient-to-r from-blue-500/20 to-purple-500/20">
                      <div className="absolute bottom-2 left-4">
                        <Avatar className="w-16 h-16 border-4 border-white dark:border-gray-800">
                          <AvatarImage src={community.avatar} alt={community.name} />
                          <AvatarFallback>{community.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                      </div>
                    </div>

                    <CardContent className="pt-8 pb-4">
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold">{community.name}</h3>
                          <Badge variant={community.privacy === 'private' ? 'secondary' : 'outline'}>
                            {community.privacy === 'private' ? 'خصوصی' : 'عمومی'}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">
                          {community.description}
                        </p>
                        
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            <span>{community.members.toLocaleString()} عضو</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <TrendingUp className="w-4 h-4" />
                            <span>{community.recentActivity} فعالیت</span>
                          </div>
                        </div>
                      </div>

                      <Button
                        size="sm"
                        className="w-full"
                        variant={community.isJoined ? 'secondary' : 'default'}
                        onClick={() => handleJoinCommunity(community.id)}
                      >
                        {community.isJoined ? (
                          <>
                            <UserCheck className="w-4 h-4 ml-2" />
                            عضو هستید
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-4 h-4 ml-2" />
                            پیوستن
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Achievements */}
          <TabsContent value="achievements" className="space-y-4">
            <div className="text-center mb-6">
              <h2 className="text-xl font-semibold mb-2">دستاوردهای شما</h2>
              <p className="text-muted-foreground">
                {mockAchievements.filter(a => a.unlockedAt).length} از {mockAchievements.length} دستاورد باز شده
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockAchievements.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className={`transition-all hover:shadow-lg ${
                    achievement.unlockedAt ? 'bg-gradient-to-br from-yellow-500/5 to-orange-500/5' : 'opacity-60'
                  }`}>
                    <CardContent className="p-6 text-center">
                      <div className={`w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center ${
                        getRarityColor(achievement.rarity)
                      }`}>
                        <Trophy className="w-8 h-8" />
                      </div>
                      
                      <h3 className="font-semibold mb-2">{achievement.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">
                        {achievement.description}
                      </p>
                      
                      <Badge className={getRarityColor(achievement.rarity)}>
                        {achievement.rarity === 'common' ? 'عادی' :
                         achievement.rarity === 'rare' ? 'نادر' :
                         achievement.rarity === 'epic' ? 'حماسی' : 'افسانه‌ای'}
                      </Badge>

                      {achievement.unlockedAt ? (
                        <p className="text-xs text-muted-foreground mt-2">
                          باز شده در {achievement.unlockedAt}
                        </p>
                      ) : achievement.progress !== undefined ? (
                        <div className="mt-3">
                          <div className="flex justify-between text-xs mb-1">
                            <span>پیشرفت</span>
                            <span>{achievement.progress}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-500 h-2 rounded-full transition-all"
                              style={{ width: `${achievement.progress}%` }}
                            />
                          </div>
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground mt-2">
                          هنوز باز نشده
                        </p>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Events */}
          <TabsContent value="events" className="space-y-4">
            <div className="text-center py-12">
              <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">رویدادهای آینده</h3>
              <p className="text-muted-foreground">
                به زودی رویدادهای هیجان‌انگیز در راه است!
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}