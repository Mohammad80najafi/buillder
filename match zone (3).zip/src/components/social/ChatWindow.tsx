import React, { useState, useRef, useEffect } from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { GameInput } from '../ui/game-input';
import { GameButton } from '../ui/game-button';
import { ScrollArea } from '../ui/scroll-area';
import { MessageBubble, Message } from './MessageBubble';
import { Send, Smile } from 'lucide-react';

interface ChatWindowProps {
  title?: string;
  messages: Message[];
  onSendMessage: (content: string) => void;
  currentUserId: string;
  isLoading?: boolean;
  placeholder?: string;
  className?: string;
  maxHeight?: string;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({
  title = 'چت',
  messages,
  onSendMessage,
  currentUserId,
  isLoading = false,
  placeholder = 'پیام خود را بنویسید...',
  className,
  maxHeight = 'h-96',
}) => {
  const [inputValue, setInputValue] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    if (!inputValue.trim() || isLoading) return;
    
    onSendMessage(inputValue.trim());
    setInputValue('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Card className={cn('flex flex-col', className)}>
      {title && (
        <CardHeader className="pb-3">
          <CardTitle className="text-right">{title}</CardTitle>
        </CardHeader>
      )}
      
      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className={cn('flex-1 px-4', maxHeight)} ref={scrollAreaRef}>
          <div className="space-y-3 py-4">
            {messages.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                هنوز پیامی ارسال نشده است
              </div>
            ) : (
              messages.map((message) => (
                <MessageBubble
                  key={message.id}
                  message={message}
                  isOwn={message.senderId === currentUserId}
                />
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        <div className="p-4 border-t border-border">
          <div className="flex gap-2">
            <div className="flex-1">
              <GameInput
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={placeholder}
                disabled={isLoading}
                className="resize-none"
              />
            </div>
            
            <div className="flex gap-1">
              <GameButton
                variant="ghost"
                size="sm"
                className="px-2"
                disabled={isLoading}
              >
                <Smile className="w-4 h-4" />
              </GameButton>
              
              <GameButton
                onClick={handleSend}
                disabled={!inputValue.trim() || isLoading}
                size="sm"
                className="px-2"
              >
                <Send className="w-4 h-4" />
              </GameButton>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};