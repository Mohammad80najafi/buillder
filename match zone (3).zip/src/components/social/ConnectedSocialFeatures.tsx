import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Heart, MessageCircle, UserPlus, UserCheck, Bell, BellOff } from 'lucide-react';
import { useSocialNotifications, useGamingNotifications, useSystemNotifications } from '../system/NotificationService';
import { motion } from 'motion/react';

interface User {
  id: string;
  username: string;
  avatar?: string;
  isFollowing: boolean;
  isOnline: boolean;
  lastActivity?: string;
}

export function ConnectedSocialFeatures() {
  const socialNotifications = useSocialNotifications();
  const gamingNotifications = useGamingNotifications();
  const systemNotifications = useSystemNotifications();
  
  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      username: 'گیمر_حرفه‌ای',
      avatar: 'https://images.unsplash.com/photo-1622349851524-890cc3641b87?w=150&h=150&fit=crop&crop=face',
      isFollowing: false,
      isOnline: true,
      lastActivity: 'پست جدید منتشر کرد'
    },
    {
      id: '2', 
      username: 'استریمر_ایرانی',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      isFollowing: true,
      isOnline: false,
      lastActivity: 'در تورنمنت CS:GO شرکت کرد'
    },
    {
      id: '3',
      username: 'پرو_پلیر',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face', 
      isFollowing: false,
      isOnline: true,
      lastActivity: 'دستاورد جدید کسب کرد'
    }
  ]);

  const [posts, setPosts] = useState([
    {
      id: '1',
      userId: '2',
      username: 'استریمر_ایرانی', 
      content: 'امشب استریم Valorant داریم! ساعت 20:00 📺',
      likes: 24,
      isLiked: false,
      timestamp: '2 ساعت پیش'
    },
    {
      id: '2',
      userId: '1',
      username: 'گیمر_حرفه‌ای',
      content: 'تازه CS:GO رو شروع کردم. کسی میاد تیم؟ 🎮',
      likes: 12,
      isLiked: true,
      timestamp: '5 ساعت پیش'
    }
  ]);

  const handleFollow = (userId: string, username: string) => {
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, isFollowing: !user.isFollowing }
          : user
      )
    );

    const user = users.find(u => u.id === userId);
    if (!user?.isFollowing) {
      // Simulate receiving a follow back notification
      setTimeout(() => {
        socialNotifications.notifyNewFollow(username);
      }, 2000);
    }
  };

  const handleLike = (postId: string, postUserId: string, username: string) => {
    setPosts(prev => 
      prev.map(post => 
        post.id === postId 
          ? { ...post, isLiked: !post.isLiked, likes: post.isLiked ? post.likes - 1 : post.likes + 1 }
          : post
      )
    );

    const post = posts.find(p => p.id === postId);
    if (!post?.isLiked) {
      // Simulate the other user liking our post back
      setTimeout(() => {
        socialNotifications.notifyLike(username);
      }, 1500);
    }
  };

  const simulateNewPost = (user: User) => {
    const newPost = {
      id: Date.now().toString(),
      userId: user.id,
      username: user.username,
      content: 'پست جدیدی منتشر شد! 🎮✨',
      likes: 0,
      isLiked: false,
      timestamp: 'الان'
    };
    
    setPosts(prev => [newPost, ...prev]);
    
    if (user.isFollowing) {
      socialNotifications.notifyNewPost(user.username, 'پست');
    }
  };

  const simulateMessage = (username: string) => {
    const messages = [
      'سلام! آماده بازی هستی؟',
      'بیا بریم یه گیم CS:GO',
      'دیدی که رنک جدیدم چیه؟',
      'همینو میخواستم بهت بگم!'
    ];
    
    const randomMessage = messages[Math.floor(Math.random() * messages.length)];
    socialNotifications.notifyNewMessage(username, randomMessage);
  };

  const simulateGamingEvents = () => {
    const events = [
      () => gamingNotifications.notifyMatchFound('Valorant Competitive'),
      () => gamingNotifications.notifyTournamentStart('جام ایران'),
      () => gamingNotifications.notifyInvitation('دوست_گیمر', 'CS:GO'),
      () => gamingNotifications.notifyAchievement('Headshot Master'),
    ];
    
    const randomEvent = events[Math.floor(Math.random() * events.length)];
    randomEvent();
  };

  const simulateSystemEvents = () => {
    const events = [
      () => systemNotifications.notifyUpdate('2.1.5'),
      () => systemNotifications.notifyMaintenance('02:00'),
      () => systemNotifications.notifyError('اتصال ناپایدار شبکه'),
    ];
    
    const randomEvent = events[Math.floor(Math.random() * events.length)];
    randomEvent();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>ویژگی‌های اجتماعی متصل</CardTitle>
          <p className="text-sm text-muted-foreground">
            تست اتصال سیستم اعلانات با عملکردهای اجتماعی
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Quick Test Buttons */}
          <div className="flex flex-wrap gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={simulateGamingEvents}
              className="bg-purple-500/10 border-purple-500/30 hover:bg-purple-500/20"
            >
              تست اعلان گیمینگ
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={simulateSystemEvents}
              className="bg-green-500/10 border-green-500/30 hover:bg-green-500/20"
            >
              تست اعلان سیستم
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => simulateMessage('کاربر_تست')}
              className="bg-blue-500/10 border-blue-500/30 hover:bg-blue-500/20"
            >
              تست پیام جدید
            </Button>
          </div>

          {/* Users List */}
          <div>
            <h3 className="font-semibold mb-3">کاربران پیشنهادی</h3>
            <div className="space-y-3">
              {users.map(user => (
                <motion.div
                  key={user.id}
                  layout
                  className="flex items-center justify-between p-4 bg-card rounded-lg border"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback>{user.username[0]}</AvatarFallback>
                      </Avatar>
                      {user.isOnline && (
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-background rounded-full" />
                      )}
                    </div>
                    
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{user.username}</span>
                        {user.isFollowing && (
                          <Badge variant="secondary" className="text-xs">
                            دنبال شده
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{user.lastActivity}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => simulateMessage(user.username)}
                    >
                      <MessageCircle className="h-4 w-4" />
                    </Button>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => simulateNewPost(user)}
                    >
                      پست جدید
                    </Button>

                    <Button
                      variant={user.isFollowing ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleFollow(user.id, user.username)}
                      className={user.isFollowing ? "bg-green-600 hover:bg-green-700" : ""}
                    >
                      {user.isFollowing ? (
                        <>
                          <UserCheck className="h-4 w-4 ml-1" />
                          دنبال شده
                        </>
                      ) : (
                        <>
                          <UserPlus className="h-4 w-4 ml-1" />
                          دنبال کردن
                        </>
                      )}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Posts Feed */}
          <div>
            <h3 className="font-semibold mb-3">فید اجتماعی</h3>
            <div className="space-y-4">
              {posts.map(post => (
                <motion.div
                  key={post.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-card rounded-lg border"
                >
                  <div className="flex items-start gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={users.find(u => u.id === post.userId)?.avatar} />
                      <AvatarFallback>{post.username[0]}</AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <span className="font-medium">{post.username}</span>
                          <span className="text-sm text-muted-foreground mr-2">{post.timestamp}</span>
                        </div>
                      </div>
                      
                      <p className="mb-3">{post.content}</p>
                      
                      <div className="flex items-center gap-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleLike(post.id, post.userId, post.username)}
                          className={post.isLiked ? "text-red-500 hover:text-red-600" : ""}
                        >
                          <Heart 
                            className={`h-4 w-4 ml-1 ${post.isLiked ? 'fill-current' : ''}`}
                          />
                          {post.likes}
                        </Button>
                        
                        <Button variant="ghost" size="sm">
                          <MessageCircle className="h-4 w-4 ml-1" />
                          نظر
                        </Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}