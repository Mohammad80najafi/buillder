import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../ui/utils';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';

const messageBubbleVariants = cva(
  [
    "rounded-lg p-3 max-w-sm transition-all duration-200"
  ],
  {
    variants: {
      kind: {
        text: "",
        image: "p-1",
        sticker: "p-2",
        system: "bg-surface-tertiary text-text-secondary text-center py-2 px-3 rounded-full text-sm max-w-none"
      },
      mine: {
        true: "bg-brand-primary text-white mr-auto",
        false: "bg-surface-secondary text-text-primary ml-auto"
      },
      compact: {
        true: "mb-1",
        false: "mb-3"
      }
    },
    defaultVariants: {
      kind: "text",
      mine: false,
      compact: false
    }
  }
);

interface UserInfo {
  id: string;
  username: string;
  avatar?: string;
  role?: 'owner' | 'admin' | 'member' | 'vip';
}

export interface MessageBubbleProps extends VariantProps<typeof messageBubbleVariants> {
  id: string;
  content: string;
  timestamp: string;
  user?: UserInfo;
  imageUrl?: string;
  stickerUrl?: string;
  reactions?: { emoji: string; count: number; userReacted: boolean }[];
  className?: string;
  onReact?: (emoji: string) => void;
  onReply?: () => void;
  isEdited?: boolean;
  isDeleted?: boolean;
}

const MessageBubble = React.forwardRef<HTMLDivElement, MessageBubbleProps>(
  ({
    id,
    content,
    timestamp,
    user,
    imageUrl,
    stickerUrl,
    reactions = [],
    kind,
    mine,
    compact,
    className,
    onReact,
    onReply,
    isEdited,
    isDeleted,
    ...props
  }, ref) => {
    const getRoleBadge = () => {
      if (!user?.role || user.role === 'member') return null;
      
      const roleConfig = {
        owner: { label: 'مالک', className: 'bg-state-warning text-white' },
        admin: { label: 'ادمین', className: 'bg-state-info text-white' },
        vip: { label: 'VIP', className: 'bg-state-success text-white' }
      };
      
      const config = roleConfig[user.role];
      return (
        <Badge variant="outline" className={cn('text-xs', config.className)}>
          {config.label}
        </Badge>
      );
    };

    // System message
    if (kind === 'system') {
      return (
        <div className="flex justify-center my-2" dir="rtl">
          <div className={cn(messageBubbleVariants({ kind, className }))}>
            {content}
          </div>
        </div>
      );
    }

    return (
      <div 
        ref={ref}
        className={cn(
          "flex gap-3",
          mine ? "flex-row-reverse" : "flex-row",
          compact && "mt-1",
          className
        )}
        dir="rtl"
        {...props}
      >
        {/* Avatar - only show if not compact or not mine */}
        {(!compact || !mine) && user && (
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarImage src={user.avatar} alt={user.username} />
            <AvatarFallback className="text-xs">{user.username[0]}</AvatarFallback>
          </Avatar>
        )}

        <div className={cn("flex flex-col", mine ? "items-end" : "items-start")}>
          {/* User info - only show if not compact */}
          {!compact && user && (
            <div className={cn(
              "flex items-center gap-2 mb-1",
              mine ? "flex-row-reverse" : "flex-row"
            )}>
              <span className="text-sm font-medium text-text-primary">
                {user.username}
              </span>
              {getRoleBadge()}
              <span className="text-xs text-text-tertiary">
                {timestamp}
              </span>
            </div>
          )}

          {/* Message content */}
          <div className={cn(messageBubbleVariants({ kind, mine, compact }))}>
            {isDeleted ? (
              <span className="italic text-text-tertiary">این پیام حذف شده است</span>
            ) : (
              <>
                {kind === 'text' && (
                  <div>
                    <p className="text-sm leading-relaxed">{content}</p>
                    {isEdited && (
                      <span className="text-xs opacity-70 block mt-1">ویرایش شده</span>
                    )}
                  </div>
                )}
                
                {kind === 'image' && imageUrl && (
                  <div className="rounded-md overflow-hidden max-w-xs">
                    <img 
                      src={imageUrl} 
                      alt="تصویر پیام" 
                      className="w-full h-auto"
                    />
                    {content && (
                      <div className="p-2 bg-surface-primary">
                        <p className="text-sm text-text-primary">{content}</p>
                      </div>
                    )}
                  </div>
                )}
                
                {kind === 'sticker' && stickerUrl && (
                  <div className="w-24 h-24">
                    <img 
                      src={stickerUrl} 
                      alt="استیکر" 
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}
              </>
            )}
          </div>

          {/* Reactions */}
          {reactions.length > 0 && !isDeleted && (
            <div className="flex flex-wrap gap-1 mt-1">
              {reactions.map((reaction, index) => (
                <button
                  key={index}
                  onClick={() => onReact?.(reaction.emoji)}
                  className={cn(
                    "flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-colors",
                    reaction.userReacted 
                      ? "bg-brand-primary/20 text-brand-primary border border-brand-primary/30" 
                      : "bg-surface-tertiary text-text-secondary hover:bg-surface-secondary"
                  )}
                >
                  <span>{reaction.emoji}</span>
                  <span>{reaction.count}</span>
                </button>
              ))}
            </div>
          )}

          {/* Timestamp for compact messages */}
          {compact && (
            <span className="text-xs text-text-tertiary mt-1">
              {timestamp}
            </span>
          )}
        </div>
      </div>
    );
  }
);

MessageBubble.displayName = "MessageBubble";

export { MessageBubble, messageBubbleVariants };