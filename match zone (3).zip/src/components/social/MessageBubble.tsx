import React from 'react';
import { cn } from '../ui/utils';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Badge } from '../ui/badge';

export interface Message {
  id: string;
  content: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  timestamp: Date;
  type: 'text' | 'image' | 'sticker' | 'system';
  edited?: boolean;
  reactions?: {
    emoji: string;
    count: number;
    userIds: string[];
  }[];
}

interface MessageBubbleProps {
  message: Message;
  isOwn: boolean;
  showAvatar?: boolean;
  className?: string;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isOwn,
  showAvatar = true,
  className,
}) => {
  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('fa-IR', {
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  if (message.type === 'system') {
    return (
      <div className={cn('flex justify-center my-2', className)}>
        <Badge variant="secondary" className="text-xs">
          {message.content}
        </Badge>
      </div>
    );
  }

  return (
    <div className={cn('flex gap-3', isOwn ? 'flex-row-reverse' : 'flex-row', className)}>
      {showAvatar && !isOwn && (
        <Avatar className="w-8 h-8 flex-shrink-0">
          <AvatarImage src={message.senderAvatar} alt={message.senderName} />
          <AvatarFallback className="text-xs">{message.senderName.charAt(0)}</AvatarFallback>
        </Avatar>
      )}

      <div className={cn('flex flex-col', isOwn ? 'items-end' : 'items-start', 'max-w-[70%]')}>
        {!isOwn && (
          <div className="text-xs text-muted-foreground mb-1 px-1">
            {message.senderName}
          </div>
        )}
        
        <div
          className={cn(
            'rounded-lg px-3 py-2 max-w-full break-words',
            isOwn
              ? 'bg-primary text-primary-foreground rounded-br-sm'
              : 'bg-muted text-muted-foreground rounded-bl-sm'
          )}
        >
          {message.type === 'text' && (
            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
          )}
          
          {message.type === 'image' && (
            <div>
              <img
                src={message.content}
                alt="پیام تصویری"
                className="rounded max-w-full h-auto"
              />
            </div>
          )}
          
          {message.type === 'sticker' && (
            <div className="text-2xl">{message.content}</div>
          )}
        </div>

        <div className={cn('flex items-center gap-2 mt-1', isOwn ? 'flex-row-reverse' : 'flex-row')}>
          <span className="text-xs text-muted-foreground">
            {formatTime(message.timestamp)}
          </span>
          
          {message.edited && (
            <span className="text-xs text-muted-foreground">ویرایش شده</span>
          )}
        </div>

        {message.reactions && message.reactions.length > 0 && (
          <div className="flex gap-1 mt-1 flex-wrap">
            {message.reactions.map((reaction, index) => (
              <div
                key={index}
                className="flex items-center gap-1 px-2 py-1 rounded-full bg-muted text-xs cursor-pointer hover:bg-muted/80 transition-colors"
              >
                <span>{reaction.emoji}</span>
                <span>{reaction.count}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};