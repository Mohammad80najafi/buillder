import React, { useState } from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { GameButton } from '../ui/game-button';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { CheckCircle, Clock, Users, BarChart3 } from 'lucide-react';

export interface PollOption {
  id: string;
  text: string;
  votes: number;
  voters: {
    id: string;
    name: string;
    avatar?: string;
  }[];
}

export interface ClanPoll {
  id: string;
  title: string;
  description?: string;
  options: PollOption[];
  creator: {
    id: string;
    name: string;
    avatar?: string;
    role: 'leader' | 'officer' | 'member';
  };
  totalVotes: number;
  deadline: Date;
  isActive: boolean;
  allowMultiple: boolean;
  userVote?: string[]; // Array of voted option IDs
}

interface ClanPollProps {
  poll: ClanPoll;
  onVote?: (optionIds: string[]) => void;
  canVote?: boolean;
  isVoting?: boolean;
  className?: string;
}

const roleLabels = {
  leader: 'رهبر',
  officer: 'افسر',
  member: 'عضو',
};

const roleColors = {
  leader: 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20',
  officer: 'text-purple-600 bg-purple-100 dark:bg-purple-900/20',
  member: 'text-blue-600 bg-blue-100 dark:bg-blue-900/20',
};

export const ClanPoll: React.FC<ClanPollProps> = ({
  poll,
  onVote,
  canVote = false,
  isVoting = false,
  className,
}) => {
  const [selectedOptions, setSelectedOptions] = useState<string[]>(poll.userVote || []);
  const [showResults, setShowResults] = useState(!canVote || !poll.isActive);

  const timeLeft = poll.deadline.getTime() - new Date().getTime();
  const isExpired = timeLeft <= 0;
  const hoursLeft = Math.max(0, Math.floor(timeLeft / (1000 * 60 * 60)));
  const daysLeft = Math.floor(hoursLeft / 24);

  const handleOptionToggle = (optionId: string) => {
    if (!canVote || !poll.isActive || isExpired) return;

    if (poll.allowMultiple) {
      setSelectedOptions(prev => 
        prev.includes(optionId) 
          ? prev.filter(id => id !== optionId)
          : [...prev, optionId]
      );
    } else {
      setSelectedOptions([optionId]);
    }
  };

  const handleVote = () => {
    if (selectedOptions.length === 0 || !onVote) return;
    onVote(selectedOptions);
  };

  const getOptionPercentage = (votes: number) => {
    return poll.totalVotes > 0 ? (votes / poll.totalVotes) * 100 : 0;
  };

  const hasVoted = poll.userVote && poll.userVote.length > 0;

  return (
    <Card className={cn('transition-all duration-200', className)}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-right mb-2">{poll.title}</CardTitle>
            {poll.description && (
              <p className="text-sm text-muted-foreground text-right">
                {poll.description}
              </p>
            )}
          </div>
          <Badge className={poll.isActive && !isExpired ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
            {poll.isActive && !isExpired ? 'فعال' : 'تمام شده'}
          </Badge>
        </div>

        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-2">
            <Avatar className="w-6 h-6">
              <AvatarImage src={poll.creator.avatar} alt={poll.creator.name} />
              <AvatarFallback className="text-xs">{poll.creator.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <span className="text-sm text-muted-foreground">{poll.creator.name}</span>
            <Badge className={cn('text-xs', roleColors[poll.creator.role])}>
              {roleLabels[poll.creator.role]}
            </Badge>
          </div>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              <span>{poll.totalVotes} رأی</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>
                {isExpired 
                  ? 'تمام شده' 
                  : daysLeft > 0 
                    ? `${daysLeft} روز باقی‌مانده`
                    : `${hoursLeft} ساعت باقی‌مانده`
                }
              </span>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-3">
          {poll.options.map((option) => {
            const percentage = getOptionPercentage(option.votes);
            const isSelected = selectedOptions.includes(option.id);
            const hasUserVoted = poll.userVote?.includes(option.id);

            return (
              <div key={option.id} className="space-y-2">
                <div
                  className={cn(
                    'p-3 rounded-lg border-2 transition-all duration-200 cursor-pointer',
                    showResults && hasUserVoted && 'border-primary bg-primary/5',
                    !showResults && isSelected && 'border-primary bg-primary/5',
                    !showResults && canVote && poll.isActive && !isExpired && 'hover:border-primary/50',
                    (!canVote || !poll.isActive || isExpired) && 'cursor-default'
                  )}
                  onClick={() => !showResults && handleOptionToggle(option.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {!showResults && canVote && poll.isActive && !isExpired && (
                        <div
                          className={cn(
                            'w-4 h-4 rounded border-2 transition-colors',
                            isSelected ? 'bg-primary border-primary' : 'border-muted-foreground'
                          )}
                        >
                          {isSelected && <CheckCircle className="w-4 h-4 text-primary-foreground" />}
                        </div>
                      )}
                      {showResults && hasUserVoted && (
                        <CheckCircle className="w-4 h-4 text-primary" />
                      )}
                      <span className="font-medium">{option.text}</span>
                    </div>
                    
                    {showResults && (
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {option.votes} رأی
                        </span>
                        <span className="text-sm font-medium">
                          {percentage.toFixed(1)}%
                        </span>
                      </div>
                    )}
                  </div>

                  {showResults && (
                    <div className="mt-2">
                      <Progress value={percentage} className="h-2" />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {!showResults && canVote && poll.isActive && !isExpired && (
          <div className="flex gap-2 pt-2">
            <GameButton
              onClick={handleVote}
              disabled={selectedOptions.length === 0 || isVoting}
              isLoading={isVoting}
              className="flex-1"
            >
              ثبت رأی
            </GameButton>
            
            <GameButton
              onClick={() => setShowResults(true)}
              variant="secondary"
              className="flex-1"
            >
              <BarChart3 className="w-4 h-4 ml-2" />
              مشاهده نتایج
            </GameButton>
          </div>
        )}

        {showResults && canVote && poll.isActive && !isExpired && !hasVoted && (
          <GameButton
            onClick={() => setShowResults(false)}
            variant="secondary"
            className="w-full"
          >
            بازگشت به رأی‌گیری
          </GameButton>
        )}

        {poll.allowMultiple && !showResults && (
          <p className="text-xs text-muted-foreground text-center">
            می‌توانید چند گزینه انتخاب کنید
          </p>
        )}
      </CardContent>
    </Card>
  );
};