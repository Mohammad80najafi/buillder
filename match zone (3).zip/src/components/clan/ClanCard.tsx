import React from 'react';
import { cn } from '../ui/utils';
import { Card, CardContent, CardFooter, CardHeader } from '../ui/card';
import { GameButton } from '../ui/game-button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { Users, Crown, Shield, Trophy, Target } from 'lucide-react';

export interface Clan {
  id: string;
  name: string;
  tag: string;
  description: string;
  logo?: string;
  leader: {
    id: string;
    name: string;
    avatar?: string;
  };
  memberCount: number;
  maxMembers: number;
  level: number;
  xp: number;
  xpToNextLevel: number;
  isPrivate: boolean;
  requiredLevel?: number;
  wins: number;
  losses: number;
  treasury: number;
  status: 'recruiting' | 'full' | 'closed';
  activeWars?: number;
}

interface ClanCardProps {
  clan: Clan;
  onJoin?: () => void;
  onView?: () => void;
  userLevel?: number;
  className?: string;
}

const statusConfig = {
  recruiting: { label: 'استخدام فعال', color: 'bg-green-100 text-green-800 dark:bg-green-900/20' },
  full: { label: 'تکمیل', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20' },
  closed: { label: 'بسته', color: 'bg-gray-100 text-gray-800 dark:bg-gray-900/20' },
};

export const ClanCard: React.FC<ClanCardProps> = ({
  clan,
  onJoin,
  onView,
  userLevel = 1,
  className,
}) => {
  const canJoin = 
    clan.status === 'recruiting' && 
    clan.memberCount < clan.maxMembers &&
    (!clan.requiredLevel || userLevel >= clan.requiredLevel);

  const winRate = clan.wins + clan.losses > 0 ? (clan.wins / (clan.wins + clan.losses)) * 100 : 0;
  const xpProgress = (clan.xp / clan.xpToNextLevel) * 100;

  return (
    <Card className={cn('transition-all duration-200 hover:shadow-lg', className)}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="w-12 h-12">
              <AvatarImage src={clan.logo} alt={clan.name} />
              <AvatarFallback className="bg-primary text-primary-foreground">
                {clan.tag}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-medium text-foreground">{clan.name}</h3>
                <Badge variant="outline" className="text-xs">
                  [{clan.tag}]
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Crown className="w-4 h-4" />
                <span>{clan.leader.name}</span>
              </div>
            </div>
          </div>
          <Badge className={statusConfig[clan.status].color}>
            {statusConfig[clan.status].label}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground line-clamp-2">
          {clan.description}
        </p>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <Users className="w-4 h-4 text-muted-foreground" />
              <span>
                {clan.memberCount}/{clan.maxMembers} عضو
              </span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Shield className="w-4 h-4 text-muted-foreground" />
              <span>سطح {clan.level}</span>
            </div>
            {clan.requiredLevel && (
              <div className="flex items-center gap-2 text-sm">
                <Target className="w-4 h-4 text-muted-foreground" />
                <span>حداقل سطح {clan.requiredLevel}</span>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <Trophy className="w-4 h-4 text-yellow-600" />
              <span>{clan.wins}W - {clan.losses}L</span>
            </div>
            <div className="text-sm">
              <span className="text-green-600">
                {winRate.toFixed(1)}% برد
              </span>
            </div>
            {clan.activeWars && clan.activeWars > 0 && (
              <div className="text-sm">
                <span className="text-red-600">
                  {clan.activeWars} جنگ فعال
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>پیشرفت تا سطح بعد</span>
            <span>{clan.xp.toLocaleString('fa-IR')} / {clan.xpToNextLevel.toLocaleString('fa-IR')} XP</span>
          </div>
          <Progress value={xpProgress} className="h-2" />
        </div>

        <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
          <span className="text-sm font-medium">خزانه کلن:</span>
          <span className="text-sm font-medium text-yellow-600">
            {clan.treasury.toLocaleString('fa-IR')} سکه
          </span>
        </div>

        {clan.isPrivate && (
          <Badge variant="secondary" className="w-full justify-center">
            کلن خصوصی - نیاز به دعوت
          </Badge>
        )}
      </CardContent>

      <CardFooter className="pt-0">
        <div className="flex gap-2 w-full">
          {canJoin && !clan.isPrivate && (
            <GameButton onClick={onJoin} className="flex-1" variant="primary">
              درخواست عضویت
            </GameButton>
          )}
          
          <GameButton onClick={onView} className="flex-1" variant="secondary">
            مشاهده جزئیات
          </GameButton>
        </div>
      </CardFooter>
    </Card>
  );
};