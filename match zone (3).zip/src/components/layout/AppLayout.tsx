/**
 * Matchzone App Layout
 * Main application layout with navigation and page rendering
 */

import React, { Suspense } from 'react';
import { NavigationProvider } from '../navigation/NavigationProvider';
import { FloatingActionButton } from './FloatingActionButton';
import { PageRenderer } from './PageRenderer';
import { useNavigation } from '../navigation/NavigationProvider';
import { ErrorBoundary } from '../ui/ErrorBoundary';
import { Card } from '../ui/card';
import { Loader2 } from 'lucide-react';

// Loading component
function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <Card className="p-8 text-center">
        <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
        <p className="text-muted-foreground">در حال بارگذاری...</p>
      </Card>
    </div>
  );
}

/**
 * App Layout Component
 * 
 * Features:
 * - Navigation management
 * - Floating Action Button navigation
 * - Page rendering with error boundaries
 * - Loading states
 * - Mobile-optimized layout
 * 
 * @returns {JSX.Element} The app layout
 */
function AppLayoutContent(): JSX.Element {
  const { 
    currentPage, 
    navigate, 
    navigateToLobby, 
    authenticate, 
    logout,
    currentLobbyId 
  } = useNavigation();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Main Content */}
      <main className="relative pb-safe">
        <ErrorBoundary>
          <Suspense fallback={<PageLoader />}>
            <PageRenderer
              page={currentPage}
              onNavigate={navigate}
              onNavigateToLobby={navigateToLobby}
              onAuth={authenticate}
              onLogout={logout}
              lobbyId={currentLobbyId}
            />
          </Suspense>
        </ErrorBoundary>
      </main>

      {/* Floating Action Button Navigation */}
      <ErrorBoundary fallback={null}>
        <FloatingActionButton
          currentPage={currentPage}
          onNavigate={navigate}
          unreadNotifications={3}
        />
      </ErrorBoundary>
    </div>
  );
}

/**
 * Main App Layout with Navigation Provider
 */
export function AppLayout(): JSX.Element {
  return (
    <ErrorBoundary>
      <NavigationProvider>
        <AppLayoutContent />
      </NavigationProvider>
    </ErrorBoundary>
  );
}

export default AppLayout;