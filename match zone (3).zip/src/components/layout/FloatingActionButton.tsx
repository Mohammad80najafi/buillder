/**
 * Ultra Creative Gaming Floating Action Button
 * Primary navigation with epic gaming visuals
 */

import React, { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, X, Home, Users, MessageCircle, User, 
  Bell, Settings, Trophy, ShoppingBag, 
  GraduationCap, Menu, Video, Gamepad2,
  Sparkles, Crown, Flame, Star, Zap
} from 'lucide-react';
import { useMobile } from '../ui/use-mobile';

interface FloatingActionButtonProps {
  currentPage: string;
  onNavigate?: (page: string) => void;
  unreadNotifications?: number;
}

export function FloatingActionButton({ 
  currentPage, 
  onNavigate, 
  unreadNotifications = 0 
}: FloatingActionButtonProps) {
  const isMobile = useMobile();
  const [isExpanded, setIsExpanded] = useState(false);
  const [dragY, setDragY] = useState(0);
  const [isCollapsing, setIsCollapsing] = useState(false);

  // آیتم‌های navigation با طراحی بهبودیافته
  const navigationItems = useMemo(() => [
    { 
      id: 'home', 
      icon: Home, 
      color: 'from-blue-500 via-blue-600 to-cyan-500', 
      label: 'خانه',
      glow: 'shadow-blue-500/30'
    },
    { 
      id: 'lobbies', 
      icon: Users, 
      color: 'from-green-500 via-emerald-600 to-teal-500', 
      label: 'لابی‌ها',
      glow: 'shadow-green-500/30'
    },
    { 
      id: 'videos', 
      icon: Video, 
      color: 'from-purple-500 via-indigo-600 to-violet-500', 
      label: 'ویدیوها',
      glow: 'shadow-purple-500/30'
    },
    { 
      id: 'tournaments', 
      icon: Trophy, 
      color: 'from-yellow-500 via-orange-500 to-amber-500', 
      label: 'مسابقات',
      glow: 'shadow-yellow-500/30'
    },
    { 
      id: 'notifications', 
      icon: Bell, 
      color: 'from-red-500 via-pink-600 to-rose-500', 
      label: 'اعلان‌ها',
      glow: 'shadow-red-500/30'
    },
    { 
      id: 'store', 
      icon: ShoppingBag, 
      color: 'from-pink-500 via-fuchsia-600 to-purple-500', 
      label: 'فروشگاه',
      glow: 'shadow-pink-500/30'
    },
    { 
      id: 'profile', 
      icon: User, 
      color: 'from-orange-500 via-red-600 to-pink-500', 
      label: 'پروفایل',
      glow: 'shadow-orange-500/30'
    },
    { 
      id: 'settings', 
      icon: Settings, 
      color: 'from-gray-500 via-slate-600 to-gray-500', 
      label: 'تنظیمات',
      glow: 'shadow-gray-500/30'
    }
  ], []);

  const handleItemClick = useCallback((id: string) => {
    setIsCollapsing(true);
    
    setTimeout(() => {
      onNavigate?.(id);
      setIsExpanded(false);
      setIsCollapsing(false);
    }, 200);
  }, [onNavigate]);

  const maxDragDistance = 100;
  
  const handleDragEnd = useCallback((event: any, info: any) => {
    if (isMobile) {
      const newY = Math.max(-maxDragDistance, Math.min(maxDragDistance, dragY + info.offset.y));
      setDragY(newY);
    }
  }, [isMobile, dragY]);

  const handleMainClick = useCallback(() => {
    setIsExpanded(!isExpanded);
  }, [isExpanded]);

  const getCenterPosition = useCallback(() => {
    if (typeof window === 'undefined') {
      return { centerX: 400, centerY: 300 };
    }
    return {
      centerX: window.innerWidth / 2,
      centerY: window.innerHeight / 2
    };
  }, []);

  return (
    <>
      {/* Enhanced Backdrop with Particle Effects */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            className="fixed inset-0 bg-black/60 backdrop-blur-md z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={() => setIsExpanded(false)}
          >
            {/* Floating Particles */}
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full"
                animate={{
                  x: [0, Math.random() * 200 - 100],
                  y: [0, Math.random() * 200 - 100],
                  scale: [1, 2, 1],
                  opacity: [0.3, 0.8, 0.3]
                }}
                transition={{
                  duration: 4 + Math.random() * 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`
                }}
              />
            ))}

            {/* Gaming Icons Background */}
            <motion.div
              className="absolute top-20 left-20 text-blue-300/20"
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Gamepad2 className="w-16 h-16" />
            </motion.div>
            
            <motion.div
              className="absolute bottom-20 right-20 text-purple-300/20"
              animate={{ 
                scale: [1, 1.3, 1],
                rotate: [0, 15, -15, 0]
              }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Crown className="w-12 h-12" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Container */}
      <div className="fixed inset-0 z-50 pointer-events-none">
        
        {/* Enhanced Navigation Items */}
        <AnimatePresence>
          {isExpanded && navigationItems.map((item, index) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            const angle = (index * 45) - 90;
            const radius = isMobile ? 140 : 160;
            
            const { centerX, centerY } = getCenterPosition();
            
            const x = centerX + Math.cos((angle * Math.PI) / 180) * radius;
            const y = centerY + Math.sin((angle * Math.PI) / 180) * radius;

            return (
              <motion.div
                key={item.id}
                className="absolute pointer-events-auto"
                style={{ 
                  left: x - (isMobile ? 36 : 44),
                  top: y - (isMobile ? 36 : 44),
                  zIndex: 55
                }}
                initial={{ 
                  opacity: 0, 
                  scale: 0,
                  left: centerX - (isMobile ? 36 : 44),
                  top: centerY - (isMobile ? 36 : 44)
                }}
                animate={isCollapsing ? {
                  opacity: 0,
                  scale: 0,
                  left: centerX - (isMobile ? 36 : 44),
                  top: centerY - (isMobile ? 36 : 44)
                } : { 
                  opacity: 1, 
                  scale: 1,
                  left: x - (isMobile ? 36 : 44),
                  top: y - (isMobile ? 36 : 44)
                }}
                exit={{ 
                  opacity: 0, 
                  scale: 0,
                  left: centerX - (isMobile ? 36 : 44),
                  top: centerY - (isMobile ? 36 : 44)
                }}
                transition={{
                  type: "spring",
                  stiffness: isCollapsing ? 500 : 400,
                  damping: isCollapsing ? 35 : 25,
                  delay: isCollapsing ? (9 - index) * 0.02 : index * 0.05
                }}
              >
                {/* Navigation Button with Enhanced Design */}
                <motion.button
                  className={`relative ${isMobile ? 'w-18 h-18' : 'w-22 h-22'} rounded-full flex items-center justify-center border-3 backdrop-blur-lg group overflow-hidden ${
                    isActive 
                      ? 'bg-white text-gray-900 border-white shadow-2xl shadow-white/50' 
                      : `bg-gradient-to-br ${item.color} text-white border-white/30 hover:border-white/60 shadow-2xl ${item.glow}`
                  }`}
                  onClick={() => handleItemClick(item.id)}
                  whileHover={{ scale: 1.15, rotate: 5 }}
                  whileTap={{ scale: 0.9 }}
                >
                  {/* Animated Background Glow */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-br ${item.color} opacity-0 group-hover:opacity-20 rounded-full`}
                    animate={{
                      scale: [1, 1.2, 1],
                      opacity: [0, 0.3, 0]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                  
                  {/* Sparkle Effect */}
                  <motion.div
                    className="absolute inset-0"
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                  >
                    {[...Array(3)].map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute w-1 h-1 bg-white rounded-full"
                        animate={{
                          x: [0, 20, -20, 0],
                          y: [0, -20, 20, 0],
                          opacity: [0, 1, 0]
                        }}
                        transition={{
                          duration: 1.5,
                          repeat: Infinity,
                          delay: i * 0.2
                        }}
                        style={{
                          left: `${30 + i * 20}%`,
                          top: `${30 + i * 20}%`
                        }}
                      />
                    ))}
                  </motion.div>
                  
                  <Icon className={`${isMobile ? 'w-7 h-7' : 'w-8 h-8'} relative z-10`} />
                  
                  {/* Enhanced Badge for notifications */}
                  {item.id === 'notifications' && unreadNotifications > 0 && (
                    <motion.span 
                      className="absolute -top-2 -right-2 w-7 h-7 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs rounded-full flex items-center justify-center border-3 border-white shadow-lg"
                      initial={{ scale: 0 }}
                      animate={{ 
                        scale: [1, 1.2, 1],
                        rotate: [0, 10, -10, 0]
                      }}
                      transition={{ 
                        scale: { duration: 2, repeat: Infinity },
                        rotate: { duration: 1, repeat: Infinity }
                      }}
                    >
                      {unreadNotifications > 9 ? '9+' : unreadNotifications}
                    </motion.span>
                  )}
                </motion.button>

                {/* Enhanced Label for desktop */}
                {!isMobile && (
                  <motion.div
                    className="absolute top-full mt-3 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none"
                    initial={{ opacity: 0, y: -10, scale: 0.8 }}
                    whileHover={{ opacity: 1, y: 0, scale: 1 }}
                  >
                    <div className="bg-gradient-to-r from-gray-900 to-black text-white px-4 py-2 rounded-xl text-sm whitespace-nowrap shadow-2xl border border-white/20 backdrop-blur-md">
                      <Sparkles className="w-3 h-3 inline ml-1" />
                      {item.label}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>

        {/* Enhanced Main FAB */}
        <motion.button
          className={`relative ${isMobile ? 'w-18 h-18' : 'w-20 h-20'} rounded-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 shadow-2xl flex items-center justify-center text-white border-3 border-white/40 pointer-events-auto overflow-hidden group`}
          onClick={handleMainClick}
          drag={isMobile && !isExpanded ? "y" : false}
          dragConstraints={isMobile ? { 
            top: -maxDragDistance, 
            bottom: maxDragDistance 
          } : undefined}
          dragElastic={0.1}
          onDragEnd={handleDragEnd}
          initial={isMobile ? { 
            bottom: 'calc(3rem + 10px)', 
            left: '1.5rem',
            y: 0
          } : {
            bottom: '2rem',
            right: '2rem',
            y: 0
          }}
          animate={isExpanded ? { 
            left: '50%',
            top: '50%',
            bottom: 'auto',
            right: 'auto',
            transform: 'translate(-50%, -50%)',
            y: 0
          } : isMobile ? { 
            bottom: 'calc(3rem + 10px)', 
            left: '1.5rem',
            top: 'auto',
            right: 'auto',
            transform: 'none',
            y: dragY
          } : {
            bottom: '2rem',
            right: '2rem',
            left: 'auto',
            top: 'auto',
            transform: 'none',
            y: 0
          }}
          transition={{
            type: "spring",
            stiffness: 400,
            damping: 30,
            duration: 0.25
          }}
          whileHover={{ scale: 1.1, rotate: 360 }}
          whileTap={{ scale: 0.9 }}
          style={{
            position: 'fixed',
            zIndex: 60
          }}
        >
          {/* Animated Background Pattern */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-yellow-400/20 via-pink-400/20 to-blue-400/20 rounded-full"
            animate={{
              rotate: [0, 360],
              scale: [1, 1.1, 1]
            }}
            transition={{
              rotate: { duration: 8, repeat: Infinity, ease: "linear" },
              scale: { duration: 2, repeat: Infinity, ease: "easeInOut" }
            }}
          />
          
          {/* Pulsing Ring */}
          <motion.div
            className="absolute inset-0 border-2 border-white/30 rounded-full"
            animate={{
              scale: [1, 1.3, 1],
              opacity: [1, 0, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />

          {/* Icon with Enhanced Animation */}
          <motion.div
            animate={{ 
              rotate: isExpanded ? 225 : 0,
              scale: isExpanded ? 1.1 : 1
            }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
            className="relative z-10"
          >
            {isExpanded ? (
              <X className={`${isMobile ? 'w-8 h-8' : 'w-9 h-9'}`} />
            ) : (
              <motion.div
                animate={{
                  scale: [1, 1.2, 1]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Plus className={`${isMobile ? 'w-8 h-8' : 'w-9 h-9'}`} />
              </motion.div>
            )}
          </motion.div>

          {/* Gaming Icon Overlay */}
          <motion.div
            className="absolute top-1 right-1 text-yellow-300/60"
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          >
            <Zap className="w-4 h-4" />
          </motion.div>
        </motion.button>

        {/* Enhanced Ripple Effect */}
        <AnimatePresence>
          {isExpanded && (
            <>
              {[...Array(3)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-4 h-4 rounded-full border-2 border-white/20 pointer-events-none"
                  style={{
                    left: '50%',
                    top: '50%',
                    transform: 'translate(-50%, -50%)'
                  }}
                  initial={{ scale: 0, opacity: 1 }}
                  animate={{ scale: 20 + i * 10, opacity: 0 }}
                  exit={{ scale: 0, opacity: 0 }}
                  transition={{
                    duration: 1.5,
                    delay: i * 0.2,
                    ease: "easeOut"
                  }}
                />
              ))}
            </>
          )}
        </AnimatePresence>

        {/* Enhanced Notification indicator */}
        {!isExpanded && unreadNotifications > 0 && (
          <motion.div
            className="absolute pointer-events-none"
            style={isMobile ? {
              bottom: '4.8rem',
              left: '3.2rem'
            } : {
              bottom: '4.8rem',
              right: '4.8rem'
            }}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <motion.div
              className="w-6 h-6 bg-gradient-to-r from-red-500 to-pink-500 rounded-full flex items-center justify-center border-2 border-white shadow-lg"
              animate={{
                scale: [1, 1.3, 1],
                boxShadow: [
                  "0 0 0 0 rgba(239, 68, 68, 0.7)",
                  "0 0 0 10px rgba(239, 68, 68, 0)",
                  "0 0 0 0 rgba(239, 68, 68, 0)"
                ]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <Flame className="w-3 h-3 text-white" />
            </motion.div>
          </motion.div>
        )}
      </div>
    </>
  );
}