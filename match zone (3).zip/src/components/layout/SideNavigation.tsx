import React from 'react';
import { Home, Users, Trophy, Shield, MessageCircle, User, Settings, LogOut, Store, Play, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../ui/tooltip';

interface SideNavigationProps {
  currentPage: string;
  onNavigate: (page: 'home' | 'lobbies' | 'tournaments' | 'clans' | 'social' | 'profile' | 'store' | 'settings') => void;
  collapsed?: boolean;
  onToggle?: () => void;
}

export function SideNavigation({ currentPage, onNavigate, collapsed = false, onToggle }: SideNavigationProps) {
  const mainNavItems = [
    { id: 'home', label: 'خانه / کشف', icon: Home },
    { id: 'lobbies', label: 'لابی‌ها', icon: Users },
    { id: 'tournaments', label: 'تورنومنت‌ها', icon: Trophy },
    { id: 'clans', label: 'کلن‌ها و تیم‌ها', icon: Shield },
    { id: 'social', label: 'اجتماعی', icon: MessageCircle, badge: 2 },
    { id: 'profile', label: 'پروفایل', icon: User },
  ];

  const secondaryNavItems = [
    { id: 'store', label: 'فروشگاه', icon: Store },
  ];

  const renderNavItem = (item: any) => {
    const Icon = item.icon;
    const isActive = currentPage === item.id;
    
    const buttonContent = (
      <Button
        key={item.id}
        variant={isActive ? 'secondary' : 'ghost'}
        className={`w-full ${collapsed ? 'justify-center px-2' : 'justify-start text-right'} h-10 ${
          isActive ? 'bg-secondary/80' : ''
        }`}
        onClick={() => onNavigate(item.id as any)}
        dir={collapsed ? 'ltr' : 'rtl'}
      >
        <Icon className={`h-4 w-4 ${!collapsed ? 'ml-3' : ''}`} />
        {!collapsed && (
          <>
            <span className="flex-1">{item.label}</span>
            {item.badge && (
              <Badge variant="destructive" className="h-4 w-4 p-0 text-xs">
                {item.badge}
              </Badge>
            )}
          </>
        )}
        {collapsed && item.badge && (
          <div className="absolute -top-1 -right-1 h-2 w-2 bg-destructive rounded-full" />
        )}
      </Button>
    );

    if (collapsed) {
      return (
        <TooltipProvider key={item.id}>
          <Tooltip>
            <TooltipTrigger asChild>
              {buttonContent}
            </TooltipTrigger>
            <TooltipContent side="left" className="mr-2">
              {item.label}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }

    return buttonContent;
  };

  if (collapsed) {
    return (
      <div className="fixed right-0 top-16 bottom-0 w-16 bg-background border-l z-40 transition-all duration-300">
        <div className="flex flex-col h-full p-2">
          {/* Toggle Button */}
          <div className="mb-4">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onToggle}
                    className="w-full h-10 px-0"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="left" className="mr-2">
                  باز کردن منو
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>

          {/* Main Navigation */}
          <nav className="space-y-2">
            {mainNavItems.map(renderNavItem)}
          </nav>

          <Separator className="my-4" />

          {/* Secondary Navigation */}
          <nav className="space-y-2">
            {secondaryNavItems.map(renderNavItem)}
          </nav>

          <Separator className="my-4" />

          {/* Account Actions */}
          <div className="mt-auto space-y-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    variant={currentPage === 'settings' ? 'secondary' : 'ghost'} 
                    className="w-full h-10 px-0"
                    onClick={() => onNavigate('settings')}
                  >
                    <Settings className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="left" className="mr-2">
                  تنظیمات
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" className="w-full h-10 px-0 text-destructive">
                    <LogOut className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="left" className="mr-2">
                  خروج
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed right-0 top-16 bottom-0 w-64 bg-background border-l z-40 transition-all duration-300">
      <div className="flex flex-col h-full p-4">
        {/* Toggle Button */}
        <div className="mb-4 flex justify-start">
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="h-8 w-8 p-0"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {/* Main Navigation */}
        <nav className="space-y-2">
          {mainNavItems.map(renderNavItem)}
        </nav>

        <Separator className="my-4" />

        {/* Secondary Navigation */}
        <nav className="space-y-2">
          {secondaryNavItems.map(renderNavItem)}
        </nav>

        <Separator className="my-4" />

        {/* Account Actions */}
        <div className="mt-auto space-y-2">
          <Button 
            variant={currentPage === 'settings' ? 'secondary' : 'ghost'} 
            className="w-full justify-start text-right h-10" 
            dir="rtl"
            onClick={() => onNavigate('settings')}
          >
            <Settings className="h-4 w-4 ml-3" />
            <span className="flex-1">تنظیمات</span>
          </Button>
          <Button variant="ghost" className="w-full justify-start text-right h-10 text-destructive" dir="rtl">
            <LogOut className="h-4 w-4 ml-3" />
            <span className="flex-1">خروج</span>
          </Button>
        </div>
      </div>
    </div>
  );
}