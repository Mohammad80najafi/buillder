import React, { useState } from 'react';
import { Search, Bell, Plus, User, Settings, X, Crown, Star, Gem, Users } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '../ui/dropdown-menu';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { useMobile } from '../ui/use-mobile';
import { NotificationCenter } from '../system/NotificationCenter';
import { useUser } from '../providers/UserProvider';

interface EnhancedAppHeaderProps {
  onToggleSidebar?: () => void;
  sidebarCollapsed?: boolean;
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
}

// User level icon mapping
const levelIcons = {
  player: Users,
  host: Crown,
  manager: Gem
};

export function EnhancedAppHeader({ onToggleSidebar, sidebarCollapsed, onNavigate, onLogout }: EnhancedAppHeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showMobileSearch, setShowMobileSearch] = useState(false);
  const isMobile = useMobile();
  const { user, currentLevelInfo } = useUser();
  
  const LevelIcon = levelIcons[user.level];
  
  // User display data
  const userData = {
    name: user.username,
    username: '@' + user.username.toLowerCase().replace(/\s+/g, '_'),
    role: currentLevelInfo.name,
    level: Math.floor(user.xp / 100),
    avatar: user.avatar,
    badge: user.level !== 'player' ? 'VIP' : undefined,
    coins: user.coins,
    isOnline: true,
    clan: user.clanName
  };
  
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className={`flex items-center justify-between transition-all duration-300 ${isMobile ? 'h-14' : 'h-16'}`}>
          {/* Right Section - Logo */}
          <div className="flex items-center">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">MZ</span>
              </div>
              {!isMobile && (
                <span className="font-bold text-lg bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  Matchzone
                </span>
              )}
            </div>
          </div>

          {/* Center Section - Search Bar (Desktop Only) */}
          {!isMobile && !showMobileSearch && (
            <div className="flex-1 max-w-md mx-16">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجوی بازی‌ها، کاربران..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10 text-right"
                  dir="rtl"
                />
              </div>
            </div>
          )}

          {/* Mobile Search Overlay */}
          {isMobile && showMobileSearch && (
            <div className="flex-1 mx-4">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجو..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10 text-right text-sm"
                  dir="rtl"
                  autoFocus
                />
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setShowMobileSearch(false)}
                  className="absolute left-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Left Section - Actions & User */}
          {!showMobileSearch && (
            <div className="flex items-center gap-6">
              {/* Mobile Actions */}
              {isMobile && (
                <>
                  {/* User Profile Button */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="flex items-center gap-2 px-3 py-2 bg-muted/30 rounded-lg border border-border/50 h-auto hover:bg-muted/50 transition-colors">
                        <div className="text-right text-xs" dir="rtl">
                          <div className="flex items-center gap-1 justify-end">
                            <p className="font-medium text-foreground">{userData.name.split(' ')[0]}</p>
                            <LevelIcon className={`h-3 w-3 ${currentLevelInfo.color}`} />
                          </div>
                          <div className="flex items-center gap-1 text-muted-foreground justify-end mt-0.5">
                            <span className="text-xs">سطح {userData.level}</span>
                            <div className={`h-1.5 w-1.5 rounded-full ${userData.isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />
                          </div>
                        </div>
                        <div className="relative">
                          <Avatar className="h-7 w-7 ring-1 ring-primary/20">
                            <AvatarImage src={userData.avatar} alt={userData.name} />
                            <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white text-xs">
                              {userData.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          {userData.isOnline && (
                            <div className="absolute top-0 right-0 h-2 w-2 bg-green-500 border-2 border-background rounded-full" />
                          )}
                        </div>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-64" dir="rtl">
                      {/* User Info Header */}
                      <div className="px-3 py-3 border-b">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10 ring-2 ring-primary/20">
                            <AvatarImage src={userData.avatar} alt={userData.name} />
                            <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white">
                              {userData.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 text-right">
                            <div className="flex items-center gap-2 justify-end">
                              <p className="font-semibold text-sm">{userData.name}</p>
                              <LevelIcon className={`h-4 w-4 ${currentLevelInfo.color}`} />
                            </div>
                            <p className="text-xs text-muted-foreground">{userData.role}</p>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1 justify-end">
                              <span>سطح {userData.level}</span>
                              <span>•</span>
                              <span>{userData.coins.toLocaleString()} سکه</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <DropdownMenuSeparator />
                      
                      {/* Menu Items */}
                      <DropdownMenuItem 
                        className="text-right flex-row-reverse cursor-pointer"
                        onClick={() => onNavigate?.('profile')}
                      >
                        <User className="ml-2 h-4 w-4" />
                        پروفایل
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-right flex-row-reverse cursor-pointer"
                        onClick={() => onNavigate?.('settings')}
                      >
                        <Settings className="ml-2 h-4 w-4" />
                        تنظیمات
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-right flex-row-reverse cursor-pointer"
                        onClick={() => onNavigate?.('store')}
                      >
                        <Star className="ml-2 h-4 w-4" />
                        فروشگاه
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                  
                  {/* Quick Actions */}
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setShowMobileSearch(true)}
                    className="p-2 h-8 w-8"
                  >
                    <Search className="h-4 w-4" />
                  </Button>

                  <Popover>
                    <PopoverTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="relative p-2"
                      >
                        <Bell className="h-4 w-4" />
                        <Badge variant="destructive" className="absolute -top-1 -right-1 h-4 w-4 p-0 text-xs">
                          3
                        </Badge>
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent 
                      className="w-80 p-0 notification-popover max-h-[500px] overflow-hidden" 
                      align="center" 
                      alignOffset={0}
                      side="bottom"
                      sideOffset={12}
                    >
                      <NotificationCenter />
                    </PopoverContent>
                  </Popover>
                </>
              )}

              {/* Desktop Actions */}
              {!isMobile && (
                <>
                  {/* Notifications */}
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="relative"
                      >
                        <Bell className="h-4 w-4" />
                        <Badge variant="destructive" className="absolute -top-1 -right-1 h-4 w-4 p-0 text-xs">
                          3
                        </Badge>
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent 
                      className="w-96 p-0 notification-popover max-h-[500px] overflow-hidden" 
                      align="end" 
                      alignOffset={-40}
                      side="bottom"
                      sideOffset={12}
                    >
                      <NotificationCenter />
                    </PopoverContent>
                  </Popover>

                  {/* User Menu - Desktop */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="flex items-center gap-4 px-4 py-2 bg-muted/30 rounded-lg border border-border/50 h-auto hover:bg-muted/50 transition-colors">
                        <div className="text-right text-sm" dir="rtl">
                          <div className="flex items-center gap-2 justify-end">
                            <p className="font-medium text-foreground">{userData.name}</p>
                            <LevelIcon className={`h-4 w-4 ${currentLevelInfo.color}`} />
                          </div>
                          <div className="flex items-center gap-1.5 text-muted-foreground justify-end mt-0.5">
                            <span className="text-xs">{userData.role}</span>
                            <span className="text-xs">•</span>
                            <span className="text-xs">سطح {userData.level}</span>
                            <div className={`h-1.5 w-1.5 rounded-full ${userData.isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />
                          </div>
                        </div>
                        <div className="relative">
                          <Avatar className="h-8 w-8 ring-1 ring-primary/20">
                            <AvatarImage src={userData.avatar} alt={userData.name} />
                            <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white text-sm">
                              {userData.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          {userData.isOnline && (
                            <div className="absolute bottom-0 right-0 h-2 w-2 bg-green-500 border-2 border-background rounded-full" />
                          )}
                        </div>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-64" dir="rtl">
                      {/* User Info Header */}
                      <div className="px-3 py-3 border-b">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10 ring-2 ring-primary/20">
                            <AvatarImage src={userData.avatar} alt={userData.name} />
                            <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white">
                              {userData.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 text-right">
                            <div className="flex items-center gap-2 justify-end">
                              <p className="font-semibold text-sm">{userData.name}</p>
                              <Badge variant="secondary" className={`h-4 px-1.5 text-xs ${currentLevelInfo.bgColor} ${currentLevelInfo.color} border-0`}>
                                <LevelIcon className="h-2.5 w-2.5 ml-1" />
                                {userData.role}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">{userData.username}</p>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1 justify-end">
                              <span>سطح {userData.level}</span>
                              <span>•</span>
                              <div className="flex items-center gap-1">
                                <Star className="h-3 w-3 text-yellow-500" />
                                <span>{userData.coins.toLocaleString()} سکه</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <DropdownMenuSeparator />
                      
                      {/* Menu Items */}
                      <DropdownMenuItem 
                        className="text-right flex-row-reverse cursor-pointer"
                        onClick={() => onNavigate?.('profile')}
                      >
                        <User className="ml-2 h-4 w-4" />
                        پروفایل
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-right flex-row-reverse cursor-pointer"
                        onClick={() => onNavigate?.('settings')}
                      >
                        <Settings className="ml-2 h-4 w-4" />
                        تنظیمات
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-right flex-row-reverse cursor-pointer"
                        onClick={() => onNavigate?.('store')}
                      >
                        <Star className="ml-2 h-4 w-4" />
                        فروشگاه
                      </DropdownMenuItem>
                      
                      <DropdownMenuSeparator />
                      
                      <DropdownMenuItem 
                        className="text-right flex-row-reverse cursor-pointer text-destructive"
                        onClick={onLogout}
                      >
                        <Settings className="ml-2 h-4 w-4" />
                        خروج
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}