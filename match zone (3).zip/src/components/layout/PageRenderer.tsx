/**
 * Matchzone Page Renderer
 * Dynamic page component rendering with mobile/desktop optimization
 */

import React from 'react';
import { NavigationPage } from '../../types/navigation';
import { useMobile } from '../ui/use-mobile';

// Import all page components
import { HomePage } from '../pages/HomePage';
import { LobbiesPageAdvanced } from '../pages/LobbiesPageAdvanced';
import { EnhancedLobbiesPage } from '../pages/EnhancedLobbiesPage';
import { LobbyDetailDemo } from '../pages/LobbyDetailDemo';
import { TournamentsPage } from '../pages/TournamentsPage';
import { ClansPage } from '../pages/ClansPage';
import { SocialPage } from '../pages/SocialPage';
import { ModernSocialPageFixed } from '../pages/ModernSocialPageFixed';
import { ProfilePage } from '../pages/ProfilePage';
import { AuthPage } from '../pages/AuthPage';
import { SettingsPage } from '../pages/SettingsPage';
import { StorePage } from '../store/StorePage';
import { MentorshipSystem } from '../coaching/MentorshipSystem';
import { PlatformAnalyticsDashboard } from '../analytics/PlatformAnalyticsDashboard';
import { ComponentShowcase } from '../pages/ComponentShowcase';
import { HomeDiscoverPage } from '../pages/mz-home-discover';
import { CreativeMobileHome } from '../pages/CreativeMobileHome';
import { CreatorPlatformHome } from '../pages/CreatorPlatformHome';
import { ScrollbarShowcase } from '../pages/ScrollbarShowcase';
import { ComponentShowcaseRefactored } from '../pages/ComponentShowcaseRefactored';
import { CreateLobbyPage } from '../gaming/CreateLobbyPage';
import { ComponentTestPage } from '../pages/ComponentTestPage';
import { FinalShowcase } from '../pages/FinalShowcase';
import { LobbyDetailPageWithTimer } from '../gaming/LobbyDetailPageWithTimer';
import { MembershipTestPage } from '../pages/MembershipTestPage';
import { CountdownTimerDemo } from '../pages/CountdownTimerDemo';
import { LobbyChatDemo } from '../pages/LobbyChatDemo';
import { ClanChatDemo } from '../pages/ClanChatDemo';
import { SocialPageComparison } from '../pages/SocialPageComparison';
import Stage4ShowcasePage from '../pages/Stage4ShowcasePage';
import { Stage5ShowcasePage } from '../pages/Stage5ShowcasePage';
import { ChatTestPage } from '../pages/ChatTestPage';
import { ChatListPage } from '../pages/ChatListPage';
import { VideoDetailPage } from '../pages/VideoDetailPage';
import { VideoTestPage } from '../pages/VideoTestPage';
import { NotificationsPage } from '../pages/NotificationsPage';
import { UltraMobileChatPage } from '../pages/UltraMobileChatPage';
import { ResponsiveDesktopChatPage } from '../pages/ResponsiveDesktopChatPage';
import { VideosPage } from '../pages/VideosPage';

interface PageConfig {
  component: React.ComponentType<any>;
  mobileComponent?: React.ComponentType<any>;
  props?: Record<string, any>;
}

interface PageRendererProps {
  page: NavigationPage;
  onNavigate: (page: NavigationPage) => void;
  onNavigateToLobby: (lobbyId: string) => void;
  onAuth: (success: boolean) => void;
  onLogout: () => void;
  lobbyId?: string;
}

export function PageRenderer({ page, onNavigate, onNavigateToLobby, onAuth, onLogout, lobbyId }: PageRendererProps) {
  const isMobile = useMobile();

  const pageConfig: Record<NavigationPage, PageConfig> = {
    home: {
      component: CreatorPlatformHome,
      mobileComponent: CreatorPlatformHome,
      props: { 
        onNavigate, 
        onLogout, 
        onLobbyClick: (id: string) => onNavigateToLobby(id),
        onVideoClick: (videoId: string) => {
          onNavigateToLobby(videoId);
          onNavigate('video-detail');
        }
      }
    },
    lobbies: {
      component: EnhancedLobbiesPage,
      props: { onLobbyClick: (id: string) => onNavigateToLobby(id) }
    },
    'lobby-detail': {
      component: LobbyDetailPageWithTimer,
      props: { onBack: () => onNavigate('home'), lobbyId: lobbyId || 'default' }
    },
    'create-lobby': {
      component: CreateLobbyPage,
      props: { onNavigateToLobbies: () => onNavigate('lobbies') }
    },
    tournaments: {
      component: TournamentsPage
    },
    clans: {
      component: ClansPage
    },
    social: {
      component: SocialPage
    },
    profile: {
      component: ProfilePage
    },
    store: {
      component: StorePage
    },
    settings: {
      component: SettingsPage
    },
    coaching: {
      component: MentorshipSystem
    },
    analytics: {
      component: PlatformAnalyticsDashboard
    },
    auth: {
      component: AuthPage,
      props: { onAuth }
    },
    showcase: {
      component: ComponentShowcaseRefactored
    },
    scrollbar: {
      component: ScrollbarShowcase
    },
    docs: {
      component: ComponentShowcaseRefactored
    },

    'component-test': {
      component: ComponentTestPage
    },
    'final-showcase': {
      component: FinalShowcase,
      props: { onNavigate }
    },
    'membership-test': {
      component: MembershipTestPage,
      props: { onBack: () => onNavigate('home') }
    },
    'countdown-timer-demo': {
      component: CountdownTimerDemo,
      props: {}
    },
    'lobby-chat-demo': {
      component: LobbyChatDemo,
      props: {}
    },
    'clan-chat-demo': {
      component: ClanChatDemo,
      props: {}
    },
    'social-comparison': {
      component: SocialPageComparison,
      props: {}
    },
    'stage4-showcase': {
      component: Stage4ShowcasePage,
      props: {}
    },
    'stage5-showcase': {
      component: Stage5ShowcasePage,
      props: {}
    },
    'chat-test': {
      component: ChatTestPage,
      props: {}
    },
    'chat-list': {
      component: ChatListPage,
      props: {
        onChatSelect: (chatId: string) => {
          onNavigateToLobby(chatId);
          onNavigate('chat-detail');
        },
        onNewChat: () => console.log('New chat clicked')
      }
    },
    'chat-detail': {
      component: ResponsiveDesktopChatPage,
      props: {}
    },
    'chat-mobile': {
      component: UltraMobileChatPage,
      props: {}
    },
    'video-detail': {
      component: VideoDetailPage,
      props: { videoId: lobbyId || 'v123' }
    },
    'video-test': {
      component: VideoTestPage,
      props: { onBack: () => onNavigate('home') }
    },
    'notifications': {
      component: NotificationsPage,
      props: {}
    },
    'videos': {
      component: VideosPage,
      props: { 
        onNavigateToSeries: (seriesId: string) => {
          onNavigateToLobby(seriesId);
          onNavigate('video-detail');
        },
        onNavigateToEpisode: (episodeId: string) => {
          onNavigateToLobby(episodeId);
          onNavigate('video-detail');
        },
        onNavigateToVideo: (videoId: string) => {
          onNavigateToLobby(videoId);
          onNavigate('video-detail');
        }
      }
    }
  };

  const config = pageConfig[page];
  if (!config) {
    console.warn(`Page "${page}" not found, rendering home page`);
    return <HomeDiscoverPage />;
  }

  // Choose mobile or desktop component
  const Component = (isMobile && config.mobileComponent) 
    ? config.mobileComponent 
    : config.component;

  // Render with props
  return <Component {...(config.props || {})} />;
}

// Export page metadata for navigation components
export const pageMetadata: Record<NavigationPage, {
  title: string;
  icon?: string;
  requiresAuth?: boolean;
  mobileOptimized?: boolean;
}> = {
  home: {
    title: 'خانه',
    icon: 'Home',
    mobileOptimized: true
  },
  lobbies: {
    title: 'لابی‌ها',
    icon: 'Users',
    requiresAuth: true
  },
  'lobby-detail': {
    title: 'جزئیات لابی',
    icon: 'Eye',
    requiresAuth: true
  },
  'create-lobby': {
    title: 'ایجاد لابی',
    icon: 'Plus',
    requiresAuth: true
  },
  tournaments: {
    title: 'مسابقات',
    icon: 'Trophy',
    requiresAuth: true
  },
  clans: {
    title: 'کلن‌ها و تیم‌ها',
    icon: 'Shield',
    requiresAuth: true
  },
  social: {
    title: 'اجتماعی',
    icon: 'MessageCircle',
    requiresAuth: true,
    mobileOptimized: true
  },
  profile: {
    title: 'پروفایل',
    icon: 'User',
    requiresAuth: true
  },
  store: {
    title: 'فروشگاه',
    icon: 'ShoppingBag',
    requiresAuth: true
  },
  settings: {
    title: 'تنظیمات',
    icon: 'Settings',
    requiresAuth: true
  },
  auth: {
    title: 'ورود',
    icon: 'LogIn'
  },
  showcase: {
    title: 'نمایش کامپوننت‌ها',
    icon: 'Grid'
  },
  scrollbar: {
    title: 'نمایش اسکرول‌بار',
    icon: 'Scroll'
  },
  docs: {
    title: 'مستندات',
    icon: 'FileText'
  },

  'component-test': {
    title: 'تست کامپوننت‌ها',
    icon: 'TestTube',
    requiresAuth: false,
    mobileOptimized: true
  },
  'final-showcase': {
    title: 'نمایش نهایی پلتفرم',
    icon: 'Crown',
    requiresAuth: false,
    mobileOptimized: true
  },
  'membership-test': {
    title: 'تست سیستم عضویت',
    icon: 'UserCheck',
    requiresAuth: false,
    mobileOptimized: true
  },
  'countdown-timer-demo': {
    title: 'نمایش تایمر لابی',
    icon: 'Timer',
    requiresAuth: false,
    mobileOptimized: true
  },
  'lobby-chat-demo': {
    title: 'نمایش چت لابی',
    icon: 'MessageCircle',
    requiresAuth: false,
    mobileOptimized: true
  },
  'clan-chat-demo': {
    title: 'نمایش چت کلن',
    icon: 'Shield',
    requiresAuth: false,
    mobileOptimized: true
  },
  'social-comparison': {
    title: 'مقایسه طراحی صفحه اج��ماعی',
    icon: 'Sparkles',
    requiresAuth: false,
    mobileOptimized: true
  },
  'stage5-showcase': {
    title: 'مرحله 5: ویژگی‌های پیشرفته',
    icon: 'Star',
    requiresAuth: false,
    mobileOptimized: true
  },
  'chat-test': {
    title: 'تست صفحه چت ریسپانسیو',
    icon: 'MessageCircle',
    requiresAuth: false,
    mobileOptimized: true
  },
  'video-detail': {
    title: 'جزئیات ویدیو',
    icon: 'Play',
    requiresAuth: false,
    mobileOptimized: true
  },
  'video-test': {
    title: 'تست صفحه ویدیو',
    icon: 'Play',
    requiresAuth: false,
    mobileOptimized: true
  },
  'notifications': {
    title: 'اعلان‌ها',
    icon: 'Bell',
    requiresAuth: true,
    mobileOptimized: true
  },
  'chat-list': {
    title: 'لیست چت‌ها',
    icon: 'MessageCircle',
    requiresAuth: true,
    mobileOptimized: true
  },
  'videos': {
    title: 'ویدیوها',
    icon: 'Video',
    requiresAuth: false,
    mobileOptimized: true
  }
};