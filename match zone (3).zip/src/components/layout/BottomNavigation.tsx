import React, { useState } from 'react';
import { 
  Home, 
  Users, 
  MessageCircle, 
  User, 
  Menu, 
  X, 
  Trophy, 
  Shield, 
  Settings, 
  Store, 
  BarChart3, 
  BookOpen, 
  Headphones,
  Crown,
  Star,
  Gem,
  Wallet,
  HelpCircle,
  Play,
  LogOut,
  Video,
  Camera,
  Upload,
  Mic
} from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { motion, AnimatePresence } from 'motion/react';
import { useUser } from '../providers/UserProvider';

interface BottomNavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout?: () => void;
}

export function BottomNavigation({ currentPage, onNavigate, onLogout }: BottomNavigationProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, currentLevelInfo } = useUser();

  // User level icon mapping
  const levelIcons = {
    player: Users,
    host: Crown,
    manager: Gem
  };

  const LevelIcon = levelIcons[user.level];
  
  // User data for display
  const userData = {
    name: user.username,
    username: '@' + user.username.toLowerCase().replace(/\s+/g, '_'),
    role: currentLevelInfo.name,
    level: Math.floor(user.xp / 100),
    avatar: user.avatar,
    badge: user.level !== 'player' ? 'VIP' : undefined,
    coins: user.coins,
    isOnline: true,
    clan: user.clanName,
    xp: user.xp
  };

  // آیتم‌های navigation اصلی
  const mainNavItems = [
    { 
      id: 'lobbies', 
      icon: Users, 
      badge: null
    },
    { 
      id: 'home', 
      icon: Home, 
      badge: null
    },
    { 
      id: 'social', 
      icon: MessageCircle, 
      badge: 3
    },
    { 
      id: 'profile', 
      icon: User, 
      badge: null
    }
  ];

  // آیتم‌های منوی جانبی
  const menuItems = [
    { id: 'home', icon: Home, title: 'خانه', desc: 'صفحه اصلی پلتفرم', section: 'main' },
    { id: 'lobbies', icon: Users, title: 'لابی‌ها', desc: 'لابی‌های بازی', section: 'main' },
    { id: 'tournaments', icon: Trophy, title: 'تورنومنت‌ها', desc: 'مسابقات رسمی', section: 'main' },
    { id: 'clans', icon: Shield, title: 'کلن‌ها', desc: 'گروه‌های بازیکنان', section: 'main' },
    { id: 'social', icon: MessageCircle, title: 'چت‌ها', desc: 'پیام‌های شما', section: 'main' },
    { id: 'profile', icon: User, title: 'پروفایل من', desc: 'حساب کاربری', section: 'user' },
    { id: 'store', icon: Wallet, title: 'کیف پول', desc: 'سکه‌ها و خرید', section: 'user' },
    { id: 'analytics', icon: BarChart3, title: 'آمار من', desc: 'عملکرد و پیشرفت', section: 'user' },
    { id: 'video-test', icon: Play, title: 'تست ویدیو', desc: 'صفحه جزئیات ویدیو', section: 'user' },
    { id: 'settings', icon: Settings, title: 'تنظیمات', desc: 'تنظیمات برنامه', section: 'user' },
    { id: 'help', icon: HelpCircle, title: 'راهنما و پشتیبانی', desc: 'کمک و آموزش', section: 'user' }
  ];

  const handleNavigate = (page: string) => {
    onNavigate(page);
    setIsMenuOpen(false);
  };

  const handleMenuToggle = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <>
      {/* Overlay برای منو - فقط وقتی باز است */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[90]"
            onClick={() => setIsMenuOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Side Menu - Custom Implementation */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ x: 320 }}
            animate={{ x: 0 }}
            exit={{ x: 320 }}
            transition={{ type: "spring", damping: 25, stiffness: 400 }}
            className="fixed top-0 right-0 bottom-0 w-80 bg-background border-l border-border/30 z-[95] shadow-2xl"
            dir="rtl"
          >
            {/* Header with User Info */}
            <div className="p-6 pb-4 border-b border-border/30 bg-gradient-to-br from-muted/50 to-muted/30">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-right font-semibold">منوی اصلی</h2>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setIsMenuOpen(false)}
                  className="hover:bg-destructive/10 hover:text-destructive rounded-lg h-8 w-8 p-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              {/* User Profile Section */}
              <div className="flex items-center gap-3 p-3 bg-background/50 rounded-xl border border-border/50">
                <div className="relative">
                  <Avatar className="h-10 w-10 ring-2 ring-primary/30 shadow-lg">
                    <AvatarImage src={userData.avatar} alt={userData.name} />
                    <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white">
                      {userData.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  {userData.isOnline && (
                    <div className="absolute bottom-0 right-0 h-2.5 w-2.5 bg-green-500 border-2 border-background rounded-full" />
                  )}
                </div>
                <div className="flex-1 text-right">
                  <div className="flex items-center gap-2 justify-end">
                    <p className="font-medium text-sm">{userData.name}</p>
                    {userData.badge === 'VIP' && (
                      <Crown className="h-3.5 w-3.5 text-yellow-500" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{userData.username}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1 justify-end">
                    <span>{userData.role}</span>
                    <span>•</span>
                    <div className="flex items-center gap-1">
                      <Star className="h-3 w-3 text-yellow-500" />
                      <span>سطح {userData.level}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-2 mt-3">
                <div className="p-2 bg-background/30 rounded-lg text-center">
                  <div className="flex items-center justify-center gap-1 font-semibold text-yellow-600 text-sm">
                    <span>{userData.coins.toLocaleString('fa-IR')}</span>
                    <div className="h-2.5 w-2.5 bg-yellow-500 rounded-full" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">سکه</p>
                </div>
                <div className="p-2 bg-background/30 rounded-lg text-center">
                  <div className="flex items-center justify-center gap-1 font-semibold text-primary text-sm">
                    <span>{userData.xp.toLocaleString('fa-IR')}</span>
                    <Star className="h-2.5 w-2.5" />
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">امتیاز</p>
                </div>
              </div>
            </div>

            {/* Menu Items */}
            <div className="overflow-y-auto max-h-[calc(100vh-300px)]">
              {/* Main Navigation */}
              <div className="p-4 space-y-2">
                <h3 className="text-xs font-medium text-muted-foreground text-right mb-3 px-2">
                  دسترسی سریع
                </h3>
                <AnimatePresence>
                  {menuItems.filter(item => item.section === 'main').map((item, index) => {
                    const Icon = item.icon;
                    const isActive = currentPage === item.id;
                    
                    return (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ 
                          duration: 0.2, 
                          delay: index * 0.03,
                          ease: "easeOut"
                        }}
                      >
                        <Button
                          variant="ghost"
                          className={`w-full justify-start text-right p-3 h-auto transition-all duration-200 rounded-xl ${
                            isActive 
                              ? 'bg-primary/10 text-primary border border-primary/20' 
                              : 'hover:bg-surface-secondary/80 hover:text-primary'
                          }`}
                          onClick={() => handleNavigate(item.id)}
                        >
                          <div className="flex items-center space-x-3 rtl:space-x-reverse w-full">
                            <div className={`p-2 rounded-lg transition-all duration-200 ${
                              isActive 
                                ? 'bg-primary/20 text-primary' 
                                : 'bg-surface-tertiary/60 text-muted-foreground'
                            }`}>
                              <Icon className="h-4 w-4" />
                            </div>
                            <div className="flex-1 text-right">
                              <div className={`font-medium text-sm transition-colors duration-200 ${
                                isActive ? 'text-primary' : 'text-foreground'
                              }`}>
                                {item.title}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {item.desc}
                              </div>
                            </div>
                            {isActive && (
                              <motion.div 
                                layoutId="activeIndicator"
                                className="w-1 h-6 bg-primary rounded-full"
                                transition={{ type: "spring", stiffness: 400, damping: 30 }}
                              />
                            )}
                          </div>
                        </Button>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>

              {/* User Section */}
              <div className="p-4 pt-2 space-y-2 border-t border-border/30">
                <h3 className="text-xs font-medium text-muted-foreground text-right mb-3 px-2">
                  حساب کاربری
                </h3>
                <AnimatePresence>
                  {menuItems.filter(item => item.section === 'user').map((item, index) => {
                    const Icon = item.icon;
                    const isActive = currentPage === item.id;
                    
                    return (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ 
                          duration: 0.2, 
                          delay: (index + 7) * 0.03,
                          ease: "easeOut"
                        }}
                      >
                        <Button
                          variant="ghost"
                          className={`w-full justify-start text-right p-3 h-auto transition-all duration-200 rounded-xl ${
                            isActive 
                              ? 'bg-primary/10 text-primary border border-primary/20' 
                              : 'hover:bg-surface-secondary/80 hover:text-primary'
                          }`}
                          onClick={() => handleNavigate(item.id)}
                        >
                          <div className="flex items-center space-x-3 rtl:space-x-reverse w-full">
                            <div className={`p-2 rounded-lg transition-all duration-200 ${
                              isActive 
                                ? 'bg-primary/20 text-primary' 
                                : 'bg-surface-tertiary/60 text-muted-foreground'
                            }`}>
                              <Icon className="h-4 w-4" />
                            </div>
                            <div className="flex-1 text-right">
                              <div className={`font-medium text-sm transition-colors duration-200 ${
                                isActive ? 'text-primary' : 'text-foreground'
                              }`}>
                                {item.title}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {item.desc}
                              </div>
                            </div>
                            {isActive && (
                              <motion.div 
                                layoutId="activeIndicatorUser"
                                className="w-1 h-6 bg-primary rounded-full"
                                transition={{ type: "spring", stiffness: 400, damping: 30 }}
                              />
                            )}
                          </div>
                        </Button>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
                
                {/* Logout Button */}
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ 
                    duration: 0.2, 
                    delay: 0.4,
                    ease: "easeOut"
                  }}
                  className="pt-2 mt-2 border-t border-border/30"
                >
                  <Button
                    variant="ghost"
                    className="w-full justify-start text-right p-3 h-auto transition-all duration-200 rounded-xl hover:bg-destructive/10 hover:text-destructive text-muted-foreground"
                    onClick={() => {
                      onLogout?.();
                      setIsMenuOpen(false);
                    }}
                  >
                    <div className="flex items-center space-x-3 rtl:space-x-reverse w-full">
                      <div className="p-2 rounded-lg bg-surface-tertiary/60 text-muted-foreground transition-all duration-200 group-hover:bg-destructive/20 group-hover:text-destructive">
                        <LogOut className="h-4 w-4" />
                      </div>
                      <div className="flex-1 text-right">
                        <div className="font-medium text-sm">
                          خروج از حساب
                        </div>
                        <div className="text-xs text-muted-foreground">
                          بازگشت به صفحه ورود
                        </div>
                      </div>
                    </div>
                  </Button>
                </motion.div>
              </div>

              {/* Footer */}
              <div className="p-4 pt-2 border-t border-border/30">
                <div className="text-center space-y-1">
                  <div className="text-xs text-muted-foreground">
                    Matchzone Gaming Platform
                  </div>
                  <div className="text-xs text-muted-foreground/60">
                    نسخه 2.1.0 • {userData.isOnline ? 'آنلاین' : 'آفلاین'}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom Navigation Container */}
      <div className="fixed bottom-0 left-0 right-0 z-[100]">
        {/* Gradient Background with Blur Effect */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/95 to-transparent backdrop-blur-xl" />
        
        {/* Border Line */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border/50 to-transparent" />
        
        {/* Navigation Content */}
        <div className="relative px-6 py-3 pb-safe">
          <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse max-w-md mx-auto">
            
            {/* Menu Button */}
            <motion.div
              whileTap={{ scale: 0.95 }}
              className="relative"
            >
              <Button
                variant="ghost"
                size="sm"
                className={`relative h-12 w-12 rounded-2xl transition-all duration-300 p-0 ${
                  isMenuOpen 
                    ? 'bg-primary/15 border border-primary/30 text-primary' 
                    : 'bg-surface-secondary/50 hover:bg-surface-secondary text-muted-foreground'
                }`}
                onClick={handleMenuToggle}
              >
                <motion.div
                  animate={{ rotate: isMenuOpen ? 90 : 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                >
                  {isMenuOpen ? (
                    <X className="h-5 w-5" />
                  ) : (
                    <Menu className="h-5 w-5" />
                  )}
                </motion.div>
              </Button>
            </motion.div>

            {/* Creator Actions Circle - Only show on home page */}
            {currentPage === 'home' && (
              <motion.div 
                className="relative flex-1 max-w-48"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              >
                {/* Central Hub */}
                <div className="relative w-24 h-12 mx-auto">
                  {/* Circular Action Buttons */}
                  {[
                    { icon: Video, label: 'ضبط', color: 'from-red-500 to-pink-600', angle: -45 },
                    { icon: Upload, label: 'آپلود', color: 'from-orange-500 to-yellow-500', angle: -15 },
                    { icon: Camera, label: 'لایو', color: 'from-purple-500 to-blue-500', angle: 15 },
                    { icon: Mic, label: 'پادکست', color: 'from-green-500 to-teal-500', angle: 45 }
                  ].map((action, index) => {
                    const Icon = action.icon;
                    const radius = 35;
                    const angleRad = (action.angle * Math.PI) / 180;
                    const x = Math.cos(angleRad) * radius;
                    const y = Math.sin(angleRad) * radius;
                    
                    return (
                      <motion.button
                        key={index}
                        className={`absolute w-8 h-8 rounded-full bg-gradient-to-r ${action.color} shadow-lg flex items-center justify-center backdrop-blur-sm border border-white/20`}
                        style={{
                          left: `50%`,
                          top: `50%`,
                          transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`
                        }}
                        whileHover={{ 
                          scale: 1.2,
                          rotate: 360,
                          boxShadow: '0 8px 25px rgba(0,0,0,0.3)'
                        }}
                        whileTap={{ scale: 0.9 }}
                        initial={{ 
                          opacity: 0, 
                          scale: 0,
                          rotate: -180
                        }}
                        animate={{ 
                          opacity: 1, 
                          scale: 1,
                          rotate: 0
                        }}
                        transition={{ 
                          delay: index * 0.1,
                          duration: 0.6,
                          type: "spring",
                          stiffness: 300,
                          damping: 25
                        }}
                        onClick={() => console.log(`${action.label} clicked`)}
                      >
                        <Icon className="w-4 h-4 text-white drop-shadow-sm" />
                        
                        {/* Ripple Effect */}
                        <motion.div
                          className="absolute inset-0 rounded-full bg-white/30"
                          initial={{ scale: 0, opacity: 0.8 }}
                          animate={{ scale: [0, 1.5, 0], opacity: [0.8, 0, 0] }}
                          transition={{ 
                            duration: 2,
                            repeat: Infinity,
                            ease: "easeOut",
                            delay: index * 0.5
                          }}
                        />
                        
                        {/* Floating Label */}
                        <motion.div
                          className="absolute -top-8 left-1/2 transform -translate-x-1/2 px-2 py-1 bg-black/80 text-white text-xs rounded-full opacity-0 pointer-events-none"
                          whileHover={{ opacity: 1, y: -2 }}
                          transition={{ duration: 0.2 }}
                        >
                          {action.label}
                        </motion.div>
                      </motion.button>
                    );
                  })}
                  
                  {/* Central Glow */}
                  <motion.div
                    className="absolute inset-0 rounded-full bg-gradient-to-r from-red-500/20 via-orange-500/20 via-purple-500/20 to-green-500/20 blur-lg"
                    animate={{ 
                      rotate: 360,
                      scale: [1, 1.1, 1]
                    }}
                    transition={{ 
                      rotate: { duration: 8, repeat: Infinity, ease: "linear" },
                      scale: { duration: 3, repeat: Infinity, ease: "easeInOut" }
                    }}
                  />
                </div>
              </motion.div>
            )}

            {/* Regular Navigation Items for other pages */}
            {currentPage !== 'home' && mainNavItems.map((item, index) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              const isHome = item.id === 'home';
              
              return (
                <motion.div
                  key={item.id}
                  whileTap={{ scale: 0.95 }}
                  className="relative"
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`relative h-12 w-12 rounded-2xl transition-all duration-300 p-0 ${
                      isHome && isActive
                        ? 'bg-gradient-to-br from-primary to-primary/80 shadow-lg shadow-primary/25'
                        : isActive
                          ? 'bg-primary/15 border border-primary/30'
                          : 'bg-surface-secondary/50 hover:bg-surface-secondary'
                    }`}
                    onClick={() => handleNavigate(item.id)}
                  >
                    <Icon className={`h-5 w-5 transition-all duration-300 ${
                      isHome && isActive
                        ? 'text-white drop-shadow-sm'
                        : isActive
                          ? 'text-primary'
                          : 'text-muted-foreground'
                    }`} />
                    
                    {/* Badge */}
                    {item.badge && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-1 -right-1"
                      >
                        <Badge 
                          variant="destructive" 
                          className="h-5 w-5 text-xs p-0 flex items-center justify-center rounded-full border-2 border-background"
                        >
                          {item.badge}
                        </Badge>
                      </motion.div>
                    )}
                    
                    {/* Active Indicator */}
                    {isActive && !isHome && (
                      <motion.div
                        layoutId="bottomNavIndicator"
                        className="absolute -top-0.5 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-primary rounded-full"
                        transition={{ type: "spring", stiffness: 400, damping: 30 }}
                      />
                    )}
                  </Button>
                </motion.div>
              );
            })}

            {/* Home Navigation Item - Always show */}
            {mainNavItems.filter(item => item.id === 'home').map((item, index) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <motion.div
                  key={item.id}
                  whileTap={{ scale: 0.95 }}
                  className="relative"
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`relative h-12 w-12 rounded-2xl transition-all duration-300 p-0 ${
                      isActive
                        ? 'bg-gradient-to-br from-red-500 via-orange-500 to-yellow-400 shadow-lg shadow-orange-500/25'
                        : 'bg-surface-secondary/50 hover:bg-surface-secondary'
                    }`}
                    onClick={() => handleNavigate(item.id)}
                  >
                    <Icon className={`h-5 w-5 transition-all duration-300 ${
                      isActive
                        ? 'text-white drop-shadow-sm'
                        : 'text-muted-foreground'
                    }`} />
                    
                    {/* Badge */}
                    {item.badge && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-1 -right-1"
                      >
                        <Badge 
                          variant="destructive" 
                          className="h-5 w-5 text-xs p-0 flex items-center justify-center rounded-full border-2 border-background"
                        >
                          {item.badge}
                        </Badge>
                      </motion.div>
                    )}
                  </Button>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}