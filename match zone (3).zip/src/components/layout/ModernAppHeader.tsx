import React, { useState } from 'react';
import { 
  Search, 
  Bell, 
  X
} from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { useMobile } from '../ui/use-mobile';
import { NotificationCenter } from '../system/NotificationCenter';
import { motion, AnimatePresence } from 'motion/react';

interface ModernAppHeaderProps {
  onToggleSidebar?: () => void;
  sidebarCollapsed?: boolean;
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
}

export function ModernAppHeader({ onToggleSidebar, sidebarCollapsed, onNavigate, onLogout }: ModernAppHeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showMobileSearch, setShowMobileSearch] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const isMobile = useMobile();

  return (
    <>
      {/* Modern Header */}
      <motion.header 
        className="sticky top-0 z-50 w-full backdrop-blur-xl bg-background/80 border-b border-border/50"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      >
        <div className="container mx-auto px-4 lg:px-6">
          <div className={`flex items-center justify-between transition-all duration-300 ${isMobile ? 'h-16' : 'h-18'}`}>
            
            {/* Right Section - Logo & Brand */}
            <motion.div 
              className="flex items-center gap-4"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              {/* Logo */}
              <div className="relative">
                <motion.div 
                  className="h-10 w-10 bg-gradient-to-br from-primary via-primary/90 to-accent rounded-2xl flex items-center justify-center shadow-xl shadow-primary/20"
                  whileHover={{ rotate: 5, scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="text-white font-bold text-lg drop-shadow-sm">MZ</span>
                </motion.div>
                <div className="absolute -top-1 -right-1 h-3 w-3 bg-green-500 border-2 border-background rounded-full animate-pulse" />
              </div>

              {/* Brand Info */}
              {!isMobile && (
                <div className="flex flex-col">
                  <h1 className="font-bold text-xl bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent leading-tight">
                    Matchzone
                  </h1>
                  <p className="text-xs text-muted-foreground -mt-1">
                    پلتفرم گیمینگ اجتماعی ایران
                  </p>
                </div>
              )}
            </motion.div>

            {/* Center Section - Search (Desktop) */}
            {!isMobile && !showMobileSearch && (
              <div className="flex-1 max-w-2xl mx-8">
                <motion.div 
                  className={`relative transition-all duration-300 ${isSearchFocused ? 'scale-105' : 'scale-100'}`}
                  whileFocus={{ scale: 1.02 }}
                >
                  <div className="absolute right-4 top-1/2 transform -translate-y-1/2 z-10">
                    <Search className={`h-5 w-5 transition-colors duration-200 ${isSearchFocused ? 'text-primary' : 'text-muted-foreground'}`} />
                  </div>
                  <Input
                    placeholder="جستجو در Matchzone - بازی‌ها، کاربران، کلن‌ها، تورنومنت‌ها..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onFocus={() => setIsSearchFocused(true)}
                    onBlur={() => setIsSearchFocused(false)}
                    className={`pr-12 pl-4 h-12 text-right bg-muted/50 border-2 transition-all duration-300 rounded-2xl ${
                      isSearchFocused 
                        ? 'border-primary/50 bg-background/80 shadow-lg shadow-primary/10' 
                        : 'border-border/30 hover:border-border/50'
                    }`}
                    dir="rtl"
                  />
                  {searchQuery && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="absolute left-4 top-1/2 transform -translate-y-1/2"
                    >
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setSearchQuery('')}
                        className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground rounded-full"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </motion.div>
                  )}
                </motion.div>
              </div>
            )}

            {/* Mobile Search Overlay */}
            <AnimatePresence>
              {isMobile && showMobileSearch && (
                <motion.div 
                  className="absolute inset-x-0 top-0 h-16 bg-background/95 backdrop-blur-xl border-b border-border/50 flex items-center px-4 gap-3"
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="flex-1 relative">
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="جستجو در Matchzone..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pr-10 pl-10 text-right bg-muted/50 border-border/30 rounded-xl h-10"
                      dir="rtl"
                      autoFocus
                    />
                    {searchQuery && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setSearchQuery('')}
                        className="absolute left-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setShowMobileSearch(false)}
                    className="h-10 w-10 p-0 rounded-xl"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Left Section - Notifications Only */}
            {!showMobileSearch && (
              <div className="flex items-center gap-3">
                
                {/* Mobile Actions */}
                {isMobile && (
                  <>
                    <motion.div whileTap={{ scale: 0.95 }}>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setShowMobileSearch(true)}
                        className="h-10 w-10 p-0 rounded-xl bg-muted/30 hover:bg-muted/50 border border-border/30"
                      >
                        <Search className="h-4 w-4" />
                      </Button>
                    </motion.div>
                    
                    {/* Mobile Notifications */}
                    <Popover>
                      <PopoverTrigger asChild>
                        <motion.div whileTap={{ scale: 0.95 }}>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="relative h-10 w-10 p-0 rounded-xl bg-muted/30 hover:bg-muted/50 border border-border/30"
                          >
                            <Bell className="h-4 w-4" />
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="absolute -top-1 -right-1"
                            >
                              <Badge variant="destructive" className="h-5 w-5 p-0 text-xs rounded-full flex items-center justify-center">
                                3
                              </Badge>
                            </motion.div>
                          </Button>
                        </motion.div>
                      </PopoverTrigger>
                      <PopoverContent 
                        className="w-80 p-0 max-h-[500px] overflow-hidden" 
                        align="center" 
                        side="bottom"
                        sideOffset={12}
                      >
                        <NotificationCenter />
                      </PopoverContent>
                    </Popover>
                  </>
                )}

                {/* Desktop Notifications */}
                {!isMobile && (
                  <Popover>
                    <PopoverTrigger asChild>
                      <motion.div whileTap={{ scale: 0.95 }}>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="relative h-11 w-11 p-0 rounded-xl bg-muted/30 hover:bg-muted/50 border border-border/30 transition-all duration-200"
                        >
                          <Bell className="h-5 w-5" />
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute -top-1 -right-1"
                          >
                            <Badge variant="destructive" className="h-5 w-5 p-0 text-xs rounded-full flex items-center justify-center">
                              3
                            </Badge>
                          </motion.div>
                        </Button>
                      </motion.div>
                    </PopoverTrigger>
                    <PopoverContent 
                      className="w-96 p-0 max-h-[500px] overflow-hidden" 
                      align="end" 
                      side="bottom"
                      sideOffset={12}
                    >
                      <NotificationCenter />
                    </PopoverContent>
                  </Popover>
                )}
              </div>
            )}
          </div>
        </div>
      </motion.header>
    </>
  );
}