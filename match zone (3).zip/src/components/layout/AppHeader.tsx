import React, { useState } from 'react';
import { Search, Bell, Plus, User, Settings, Menu, X, Crown, Star, Gem, Users, LogOut, Wallet, HelpCircle } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '../ui/dropdown-menu';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { useMobile } from '../ui/use-mobile';
import { NotificationCenter } from '../system/NotificationCenter';
import { useUser } from '../providers/UserProvider';
import { motion } from 'motion/react';

interface AppHeaderProps {
  onToggleSidebar?: () => void;
  sidebarCollapsed?: boolean;
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
}

// User level icon mapping
const levelIcons = {
  player: Users,
  host: Crown,
  manager: Gem
};

export function AppHeader({ onToggleSidebar, sidebarCollapsed, onNavigate, onLogout }: AppHeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showMobileSearch, setShowMobileSearch] = useState(false);
  const isMobile = useMobile();
  const { user, currentLevelInfo } = useUser();
  
  const LevelIcon = levelIcons[user.level];
  
  // Mock additional data - در پروژه واقعی این اطلاعات از user context یا API می‌آید
  const userData = {
    name: user.username,
    username: '@' + user.username.toLowerCase().replace(/\s+/g, '_'),
    role: currentLevelInfo.name,
    level: Math.floor(user.xp / 100), // Calculate level from XP
    avatar: user.avatar,
    badge: user.level !== 'player' ? 'VIP' : undefined,
    coins: user.coins,
    isOnline: true,
    clan: user.clanName
  };
  
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className={`flex items-center justify-between transition-all duration-300 ${isMobile ? 'h-14' : 'h-16'}`}>
          
          {/* Logo Section */}
          <div className="flex items-center">
            <motion.div 
              className="flex items-center gap-3"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              <div className="h-8 w-8 bg-gradient-to-br from-primary via-primary/90 to-accent rounded-xl flex items-center justify-center shadow-lg shadow-primary/25">
                <span className="text-white font-bold text-sm drop-shadow-sm">MZ</span>
              </div>
              {!isMobile && (
                <div className="flex flex-col">
                  <span className="font-bold text-lg bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    Matchzone
                  </span>
                  <span className="text-xs text-muted-foreground -mt-1">
                    پلتفرم گیمینگ اجتماعی
                  </span>
                </div>
              )}
            </motion.div>
          </div>

          {/* Center Section - Search Bar (Desktop Only) */}
          {!isMobile && !showMobileSearch && (
            <div className="flex-1 max-w-lg mx-12">
              <motion.div 
                className="relative"
                whileFocus={{ scale: 1.02 }}
                transition={{ duration: 0.2 }}
              >
                <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجوی بازی‌ها، کاربران، لابی‌ها..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-12 pl-4 text-right bg-muted/50 border-border/50 hover:border-border transition-colors rounded-xl h-10"
                  dir="rtl"
                />
                {searchQuery && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSearchQuery('')}
                    className="absolute left-2 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0 text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                )}
              </motion.div>
            </div>
          )}

          {/* Mobile Search Overlay */}
          {isMobile && showMobileSearch && (
            <motion.div 
              className="flex-1 mx-4"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="جستجو در Matchzone..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pr-10 pl-10 text-right text-sm bg-muted/50 border-border/50 rounded-xl"
                  dir="rtl"
                  autoFocus
                />
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setShowMobileSearch(false)}
                  className="absolute left-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Actions Section */}
          {!showMobileSearch && (
            <div className="flex items-center gap-3">
              
              {/* Mobile Actions */}
              {isMobile && (
                <>
                  <motion.div whileTap={{ scale: 0.95 }}>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setShowMobileSearch(true)}
                      className="p-2 h-9 w-9 rounded-xl bg-muted/30 hover:bg-muted/50 border border-border/30"
                    >
                      <Search className="h-4 w-4" />
                    </Button>
                  </motion.div>
                  
                  <Popover>
                    <PopoverTrigger asChild>
                      <motion.div whileTap={{ scale: 0.95 }}>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="relative p-2 h-9 w-9 rounded-xl bg-muted/30 hover:bg-muted/50 border border-border/30"
                        >
                          <Bell className="h-4 w-4" />
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute -top-1 -right-1"
                          >
                            <Badge variant="destructive" className="h-4 w-4 p-0 text-xs rounded-full">
                              3
                            </Badge>
                          </motion.div>
                        </Button>
                      </motion.div>
                    </PopoverTrigger>
                    <PopoverContent 
                      className="w-80 p-0 notification-popover max-h-[500px] overflow-hidden" 
                      align="center" 
                      side="bottom"
                      sideOffset={12}
                    >
                      <NotificationCenter />
                    </PopoverContent>
                  </Popover>
                </>
              )}

              {/* Desktop Actions */}
              {!isMobile && (
                <>
                  {/* Create Button */}
                  <motion.div whileTap={{ scale: 0.95 }}>
                    <Button 
                      variant="default"
                      size="sm"
                      onClick={() => onNavigate?.('create-lobby')}
                      className="bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary/80 text-white border-0 shadow-lg shadow-primary/25 rounded-xl px-4"
                    >
                      <Plus className="h-4 w-4 ml-2" />
                      ایجاد لابی
                    </Button>
                  </motion.div>
                  
                  {/* Notifications */}
                  <Popover>
                    <PopoverTrigger asChild>
                      <motion.div whileTap={{ scale: 0.95 }}>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="relative p-2 h-10 w-10 rounded-xl bg-muted/30 hover:bg-muted/50 border border-border/30"
                        >
                          <Bell className="h-4 w-4" />
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute -top-1 -right-1"
                          >
                            <Badge variant="destructive" className="h-4 w-4 p-0 text-xs rounded-full">
                              3
                            </Badge>
                          </motion.div>
                        </Button>
                      </motion.div>
                    </PopoverTrigger>
                    <PopoverContent 
                      className="w-96 p-0 notification-popover max-h-[500px] overflow-hidden" 
                      align="end" 
                      side="bottom"
                      sideOffset={12}
                    >
                      <NotificationCenter />
                    </PopoverContent>
                  </Popover>

                  {/* User Profile Button */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <motion.div whileTap={{ scale: 0.95 }}>
                        <Button 
                          variant="ghost" 
                          className="flex items-center gap-3 px-3 py-2 bg-muted/30 rounded-xl border border-border/30 h-auto hover:bg-muted/50 transition-all duration-200"
                        >
                          <div className="text-right text-sm" dir="rtl">
                            <div className="flex items-center gap-2 justify-end">
                              <p className="font-medium text-foreground">{userData.name}</p>
                              {userData.badge === 'VIP' && (
                                <Crown className="h-3.5 w-3.5 text-yellow-500" />
                              )}
                            </div>
                            <div className="flex items-center gap-1.5 text-muted-foreground justify-end mt-0.5">
                              <span className="text-xs">{userData.role}</span>
                              <div className={`h-1.5 w-1.5 rounded-full ${userData.isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />
                            </div>
                          </div>
                          <div className="relative">
                            <Avatar className="h-8 w-8 ring-2 ring-primary/20 shadow-sm">
                              <AvatarImage src={userData.avatar} alt={userData.name} />
                              <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white text-sm">
                                {userData.name.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            {userData.isOnline && (
                              <div className="absolute bottom-0 right-0 h-2.5 w-2.5 bg-green-500 border-2 border-background rounded-full" />
                            )}
                          </div>
                        </Button>
                      </motion.div>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-72 p-0" dir="rtl">
                      {/* User Profile Header */}
                      <div className="p-4 border-b bg-gradient-to-br from-muted/50 to-muted/30">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-12 w-12 ring-2 ring-primary/30 shadow-lg">
                            <AvatarImage src={userData.avatar} alt={userData.name} />
                            <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white">
                              {userData.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 text-right">
                            <div className="flex items-center gap-2 justify-end">
                              <p className="font-semibold">{userData.name}</p>
                              {userData.badge === 'VIP' && (
                                <Badge variant="secondary" className="h-5 px-2 text-xs bg-gradient-to-r from-yellow-500 to-amber-500 text-white border-0">
                                  <Crown className="h-3 w-3 ml-1" />
                                  VIP
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">{userData.username}</p>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1 justify-end">
                              <span>{userData.role}</span>
                              <span>•</span>
                              <div className="flex items-center gap-1">
                                <Star className="h-3 w-3 text-yellow-500" />
                                <span>سطح {userData.level}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Stats Section */}
                      <div className="p-3 bg-muted/20 border-b">
                        <div className="grid grid-cols-2 gap-3 text-center">
                          <div className="p-2 bg-background/50 rounded-lg">
                            <div className="flex items-center justify-center gap-1 font-semibold text-yellow-600">
                              <span>{userData.coins.toLocaleString('fa-IR')}</span>
                              <div className="h-3 w-3 bg-yellow-500 rounded-full" />
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">سکه</p>
                          </div>
                          <div className="p-2 bg-background/50 rounded-lg">
                            <div className="flex items-center justify-center gap-1 font-semibold text-primary">
                              <span>{user.xp.toLocaleString('fa-IR')}</span>
                              <Star className="h-3 w-3" />
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">امتیاز</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Menu Items */}
                      <div className="p-1">
                        <DropdownMenuItem 
                          className="text-right flex-row-reverse cursor-pointer rounded-lg mx-1"
                          onClick={() => onNavigate?.('profile')}
                        >
                          <User className="ml-2 h-4 w-4" />
                          پروفایل من
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="text-right flex-row-reverse cursor-pointer rounded-lg mx-1"
                          onClick={() => onNavigate?.('store')}
                        >
                          <Wallet className="ml-2 h-4 w-4" />
                          کیف پول
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="text-right flex-row-reverse cursor-pointer rounded-lg mx-1"
                          onClick={() => onNavigate?.('settings')}
                        >
                          <Settings className="ml-2 h-4 w-4" />
                          تنظیمات
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="text-right flex-row-reverse cursor-pointer rounded-lg mx-1"
                          onClick={() => onNavigate?.('help')}
                        >
                          <HelpCircle className="ml-2 h-4 w-4" />
                          راهنما و پشتیبانی
                        </DropdownMenuItem>
                        
                        <DropdownMenuSeparator className="mx-2" />
                        
                        <DropdownMenuItem 
                          className="text-right flex-row-reverse cursor-pointer rounded-lg mx-1 text-destructive focus:text-destructive"
                          onClick={onLogout}
                        >
                          <LogOut className="ml-2 h-4 w-4" />
                          خروج از حساب
                        </DropdownMenuItem>
                      </div>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}