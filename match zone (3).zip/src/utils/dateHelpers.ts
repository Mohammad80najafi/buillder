/**
 * Matchzone Gaming Platform
 * Date Helper Utilities - کمک‌کننده‌های تاریخ و زمان فارسی
 */

import { format } from 'date-fns';

// Persian day names mapping (Gregorian)
const persianDays: { [key: string]: string } = {
  'Monday': 'دوشنبه',
  'Tuesday': 'سه‌شنبه', 
  'Wednesday': 'چهارشنبه',
  'Thursday': 'پنج‌شنبه',
  'Friday': 'جمعه',
  'Saturday': 'شنبه',
  'Sunday': 'یکشنبه'
};

// Persian month names mapping (Gregorian)
const persianMonths: { [key: string]: string } = {
  'January': 'ژانویه',
  'February': 'فوریه',
  'March': 'مارس',
  'April': 'آوریل',
  'May': 'مه',
  'June': 'ژوئن',
  'July': 'ژوئیه',
  'August': 'اوت',
  'September': 'سپتامبر',
  'October': 'اکتبر',
  'November': 'نوامبر',
  'December': 'دسامبر'
};

/**
 * Format time in Persian style
 */
export const formatPersianTime = (date: Date): string => {
  return format(date, 'HH:mm');
};

/**
 * Format date in Persian style (simple fallback)
 */
export const formatPersianDate = (date: Date): string => {
  return date.toLocaleDateString('fa-IR');
};

/**
 * Format date with month name in Persian style (simple fallback)
 */
export const formatPersianDateLong = (date: Date): string => {
  return date.toLocaleDateString('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

/**
 * Format date with month name in Persian style (Gregorian fallback)
 */
export const formatPersianDateWithMonth = (date: Date): string => {
  let formatted = format(date, 'EEEE، dd MMMM');
  
  // Replace English day names with Persian
  Object.entries(persianDays).forEach(([english, persian]) => {
    formatted = formatted.replace(english, persian);
  });
  
  // Replace English month names with Persian
  Object.entries(persianMonths).forEach(([english, persian]) => {
    formatted = formatted.replace(english, persian);
  });
  
  return formatted;
};

/**
 * Get relative time in Persian
 */
export const getRelativeTimePersian = (date: Date): string => {
  const now = new Date();
  const diffMs = date.getTime() - now.getTime();
  
  if (diffMs <= 0) return 'شروع شده';
  
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);
  
  if (diffDays > 0) return `${diffDays} روز`;
  if (diffHours > 0) return `${diffHours} ساعت`;
  return `${diffMinutes} دقیقه`;
};

/**
 * Check if date is today
 */
export const isPersianToday = (date: Date): boolean => {
  const today = new Date();
  return date.toDateString() === today.toDateString();
};

/**
 * Check if date is tomorrow
 */
export const isPersianTomorrow = (date: Date): boolean => {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  return date.toDateString() === tomorrow.toDateString();
};

/**
 * Get display text for date in Persian
 */
export const getPersianDateDisplayText = (date: Date): string => {
  if (isPersianToday(date)) return 'امروز';
  if (isPersianTomorrow(date)) return 'فردا';
  return formatPersianDate(date);
};

/**
 * Check if two dates are the same day
 */
export const isSameDay = (date1: Date, date2: Date): boolean => {
  return date1.toDateString() === date2.toDateString();
};

/**
 * Check if date is today
 */
export const isToday = (date: Date): boolean => {
  return isPersianToday(date);
};

/**
 * Check if date is tomorrow
 */
export const isTomorrow = (date: Date): boolean => {
  return isPersianTomorrow(date);
};

/**
 * Format numbers in Persian style with K/M abbreviations
 */
export const formatNumber = (num: number): string => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toLocaleString('fa-IR');
};

/**
 * Format currency in Persian style (Toman)
 */
export const formatCurrency = (amount: number): string => {
  return amount.toLocaleString('fa-IR') + ' تومان';
};