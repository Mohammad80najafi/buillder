/**
 * Safe Clipboard Utilities
 * Cross-browser compatible clipboard operations with graceful error handling
 */

export interface ClipboardResult {
  success: boolean;
  method?: 'clipboard-api' | 'execCommand' | 'selection-api' | 'manual';
  error?: string;
}

/**
 * Safe clipboard copy with multiple fallback strategies
 */
export async function safeCopy(text: string): Promise<ClipboardResult> {
  // Strategy 1: Modern Clipboard API
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text);
      return { success: true, method: 'clipboard-api' };
    } catch (error: any) {
      // Permission denied or other clipboard API error - continue to fallbacks
      console.log('Clipboard API failed:', error.message);
    }
  }

  // Strategy 2: Legacy execCommand
  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    
    // Make it invisible but accessible
    Object.assign(textarea.style, {
      position: 'fixed',
      left: '-999999px',
      top: '-999999px',
      opacity: '0',
      pointerEvents: 'none'
    });
    
    textarea.setAttribute('readonly', '');
    textarea.setAttribute('contenteditable', 'true');
    
    document.body.appendChild(textarea);
    
    // Mobile-friendly selection
    if (/ipad|iphone|android/i.test(navigator.userAgent)) {
      textarea.contentEditable = 'true';
      textarea.readOnly = false;
      const range = document.createRange();
      range.selectNodeContents(textarea);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
      textarea.setSelectionRange(0, 999999);
    } else {
      textarea.focus();
      textarea.select();
    }
    
    const successful = document.execCommand('copy');
    document.body.removeChild(textarea);
    
    if (successful) {
      return { success: true, method: 'execCommand' };
    }
  } catch (error: any) {
    console.log('execCommand failed:', error.message);
  }

  // Strategy 3: Selection API
  try {
    const div = document.createElement('div');
    div.textContent = text;
    div.style.position = 'absolute';
    div.style.left = '-9999px';
    div.setAttribute('contenteditable', 'true');
    
    document.body.appendChild(div);
    
    const range = document.createRange();
    range.selectNodeContents(div);
    const selection = window.getSelection();
    selection?.removeAllRanges();
    selection?.addRange(range);
    
    const successful = document.execCommand('copy');
    document.body.removeChild(div);
    
    if (successful) {
      return { success: true, method: 'selection-api' };
    }
  } catch (error: any) {
    console.log('Selection API failed:', error.message);
  }

  // All strategies failed
  return {
    success: false,
    method: 'manual',
    error: 'خودکار کپی کردن امکان‌پذیر نیست. لطفاً به صورت دستی کپی کنید.'
  };
}

/**
 * Simple copy function that doesn't throw errors
 * Good for fire-and-forget scenarios
 */
export function silentCopy(text: string): void {
  safeCopy(text).catch(() => {
    // Silently fail - useful for non-critical copy operations
  });
}

/**
 * Copy with user feedback
 */
export async function copyWithFeedback(
  text: string, 
  onSuccess?: (method: string) => void,
  onFailure?: (error: string) => void
): Promise<void> {
  const result = await safeCopy(text);
  
  if (result.success) {
    onSuccess?.(result.method || 'unknown');
  } else {
    onFailure?.(result.error || 'Copy failed');
  }
}

/**
 * Check if clipboard API is available
 */
export function isClipboardSupported(): boolean {
  return !!(navigator.clipboard && window.isSecureContext);
}

/**
 * Check if any copy method is likely to work
 */
export function canCopy(): boolean {
  return !!(
    (navigator.clipboard && window.isSecureContext) ||
    document.queryCommandSupported?.('copy') ||
    document.execCommand
  );
}