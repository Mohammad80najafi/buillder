/**
 * Matchzone Game Launcher Utility
 * Comprehensive game launching system for all supported platforms
 */

// Platform detection
export function detectPlatform(): 'pc' | 'android' | 'ios' | 'unknown' {
  if (typeof window === 'undefined') return 'unknown';
  
  const userAgent = navigator.userAgent.toLowerCase();
  if (/android/.test(userAgent)) return 'android';
  if (/iphone|ipad|ipod/.test(userAgent)) return 'ios';
  if (/windows|mac|linux/.test(userAgent)) return 'pc';
  return 'unknown';
}

// Check if app is installed (for mobile)
export async function isAppInstalled(packageName: string): Promise<boolean> {
  const platform = detectPlatform();
  
  if (platform === 'android') {
    try {
      // Try to launch the app with a quick timeout
      const intent = `intent://launch/#Intent;package=${packageName};end`;
      window.location.href = intent;
      
      // If we're still here after 2 seconds, app is probably not installed
      return new Promise((resolve) => {
        const timer = setTimeout(() => resolve(false), 2000);
        
        // Listen for visibility change (app opening)
        const handleVisibilityChange = () => {
          if (document.hidden) {
            clearTimeout(timer);
            resolve(true);
            document.removeEventListener('visibilitychange', handleVisibilityChange);
          }
        };
        
        document.addEventListener('visibilitychange', handleVisibilityChange);
      });
    } catch {
      return false;
    }
  }
  
  return false; // Can't detect on other platforms
}

// Steam connection helper
export function createSteamConnection(
  appId: string, 
  serverIp?: string, 
  serverPort?: number, 
  password?: string
): string {
  let steamUrl = `steam://run/${appId}`;
  
  if (serverIp && serverPort) {
    steamUrl += `// +connect ${serverIp}:${serverPort}`;
    if (password) {
      steamUrl += ` +password ${password}`;
    }
  }
  
  return steamUrl;
}

// Copy to clipboard with fallback
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    } else {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'absolute';
      textArea.style.left = '-999999px';
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      return true;
    }
  } catch {
    return false;
  }
}

// Launch result types
export interface LaunchResult {
  success: boolean;
  method: 'direct' | 'store_redirect' | 'manual_copy' | 'failed';
  message: string;
  data?: {
    roomCode?: string;
    password?: string;
    serverInfo?: string;
  };
}

// Enhanced game launcher
export async function launchGame(
  gameConfig: any,
  lobbyData?: any,
  options: {
    showFallback?: boolean;
    copyToClipboard?: boolean;
    showInstructions?: boolean;
  } = {}
): Promise<LaunchResult> {
  const platform = detectPlatform();
  const launchMethod = gameConfig.launchMethods[platform];
  
  if (!launchMethod) {
    return {
      success: false,
      method: 'failed',
      message: `این بازی روی پلتفرم ${platform} پشتیبانی نمی‌شود`
    };
  }

  try {
    switch (platform) {
      case 'pc':
        return await launchPCGame(gameConfig, lobbyData, launchMethod);
      
      case 'android':
        return await launchAndroidGame(gameConfig, lobbyData, launchMethod, options);
      
      case 'ios':
        return await launchiOSGame(gameConfig, lobbyData, launchMethod, options);
      
      default:
        return {
          success: false,
          method: 'failed',
          message: 'پلتفرم پشتیبانی نمی‌شود'
        };
    }
  } catch (error) {
    return {
      success: false,
      method: 'failed',
      message: `خطا در راه‌اندازی: ${error}`
    };
  }
}

// PC game launcher
async function launchPCGame(
  gameConfig: any,
  lobbyData: any,
  launchMethod: any
): Promise<LaunchResult> {
  try {
    if (launchMethod.steam) {
      let steamUrl = launchMethod.steam;
      
      // Add server connection for games that support it
      if (lobbyData?.server && gameConfig.joinMethod === 'direct') {
        steamUrl = createSteamConnection(
          gameConfig.id === 'cs2' ? '730' : gameConfig.id === 'dota2' ? '570' : '945360',
          lobbyData.server.ip,
          lobbyData.server.port,
          lobbyData.server.password
        );
      }
      
      window.location.href = steamUrl;
      
      return {
        success: true,
        method: 'direct',
        message: 'Steam لانچ شد. اگر بازی باز نشد، Steam را راه‌اندازی کنید.',
        data: lobbyData?.server ? {
          serverInfo: `${lobbyData.server.ip}:${lobbyData.server.port}`
        } : undefined
      };
    }
    
    if (launchMethod.battlenet) {
      window.location.href = launchMethod.battlenet;
      return {
        success: true,
        method: 'direct',
        message: 'Battle.net لانچ شد'
      };
    }
    
    return {
      success: false,
      method: 'failed',
      message: 'هیچ روش لانچ معتبری یافت نشد'
    };
  } catch (error) {
    return {
      success: false,
      method: 'failed',
      message: `خطا در لانچ PC: ${error}`
    };
  }
}

// Android game launcher
async function launchAndroidGame(
  gameConfig: any,
  lobbyData: any,
  launchMethod: any,
  options: any
): Promise<LaunchResult> {
  try {
    if (launchMethod.intent) {
      // Try to launch the app
      window.location.href = launchMethod.intent;
      
      // Set up fallback to Play Store
      const fallbackTimer = setTimeout(() => {
        window.open(`https://play.google.com/store/apps/details?id=${launchMethod.packageName}`);
      }, 2500);
      
      // Listen for app launch (visibility change)
      const handleVisibilityChange = () => {
        if (document.hidden) {
          clearTimeout(fallbackTimer);
          document.removeEventListener('visibilitychange', handleVisibilityChange);
        }
      };
      
      document.addEventListener('visibilitychange', handleVisibilityChange);
      
      // Prepare room code for copying if needed
      if (lobbyData?.room?.id && options.copyToClipboard) {
        await copyToClipboard(lobbyData.room.id);
      }
      
      return {
        success: true,
        method: lobbyData?.room?.id ? 'manual_copy' : 'direct',
        message: lobbyData?.room?.id 
          ? `بازی لانچ شد. کد روم کپی شد: ${lobbyData.room.id}`
          : 'بازی لانچ شد',
        data: lobbyData?.room ? {
          roomCode: lobbyData.room.id,
          password: lobbyData.room.password
        } : undefined
      };
    }
    
    return {
      success: false,
      method: 'failed',
      message: 'روش لانچ اندروید یافت نشد'
    };
  } catch (error) {
    return {
      success: false,
      method: 'failed',
      message: `خطا در لانچ اندروید: ${error}`
    };
  }
}

// iOS game launcher
async function launchiOSGame(
  gameConfig: any,
  lobbyData: any,
  launchMethod: any,
  options: any
): Promise<LaunchResult> {
  try {
    // iOS has limited deep linking, so we mainly copy room codes
    if (lobbyData?.room?.id) {
      const copySuccess = await copyToClipboard(lobbyData.room.id);
      
      if (copySuccess) {
        return {
          success: true,
          method: 'manual_copy',
          message: `کد روم کپی شد: ${lobbyData.room.id}\nبازی را دستی باز کرده و کد را وارد کنید`,
          data: {
            roomCode: lobbyData.room.id,
            password: lobbyData.room.password
          }
        };
      }
    }
    
    // Try URL scheme if available
    if (launchMethod.scheme) {
      window.location.href = launchMethod.scheme;
      return {
        success: true,
        method: 'direct',
        message: 'تلاش برای باز کردن بازی'
      };
    }
    
    return {
      success: false,
      method: 'failed',
      message: 'iOS پشتیبانی محدودی دارد. لطفاً بازی را دستی باز کنید'
    };
  } catch (error) {
    return {
      success: false,
      method: 'failed',
      message: `خطا در لانچ iOS: ${error}`
    };
  }
}

// Generate shareable lobby link
export function generateLobbyLink(lobbyId: string, gameId: string): string {
  const baseUrl = window.location.origin;
  return `${baseUrl}/lobby/${lobbyId}?game=${gameId}`;
}

// Parse lobby link
export function parseLobbyLink(url: string): { lobbyId?: string; gameId?: string } | null {
  try {
    const urlObj = new URL(url);
    const pathParts = urlObj.pathname.split('/');
    const lobbyId = pathParts[pathParts.indexOf('lobby') + 1];
    const gameId = urlObj.searchParams.get('game');
    
    if (lobbyId) {
      return { lobbyId, gameId: gameId || undefined };
    }
    
    return null;
  } catch {
    return null;
  }
}

// Show launch instructions modal (to be used with UI components)
export interface LaunchInstructions {
  title: string;
  steps: string[];
  roomCode?: string;
  password?: string;
  serverInfo?: string;
  platformSpecific: boolean;
}

export function generateLaunchInstructions(
  gameConfig: any,
  lobbyData: any,
  platform: string
): LaunchInstructions {
  const instructions: LaunchInstructions = {
    title: `نحوه پیوستن به ${gameConfig.displayName}`,
    steps: [],
    platformSpecific: true
  };

  switch (gameConfig.joinMethod) {
    case 'direct':
      if (platform === 'pc') {
        instructions.steps = [
          'روی دکمه "ورود مستقیم" کلیک کنید',
          'Steam یا launcher مربوطه باز می‌شود',
          'بازی به صورت خودکار به سرور متصل می‌شود'
        ];
        if (lobbyData?.server) {
          instructions.serverInfo = `${lobbyData.server.ip}:${lobbyData.server.port}`;
        }
      }
      break;

    case 'room_code':
      instructions.steps = [
        'بازی را باز کنید',
        'به بخش Custom Room یا Private Match بروید',
        'کد روم را وارد کنید'
      ];
      
      if (lobbyData?.room?.password) {
        instructions.steps.push('رمز عبور را وارد کنید');
        instructions.password = lobbyData.room.password;
      }
      
      if (lobbyData?.room?.id) {
        instructions.roomCode = lobbyData.room.id;
      }
      break;

    case 'invite':
      instructions.steps = [
        'بازی را باز کنید',
        'منتظر دعوتنامه از میزبان باشید',
        'دعوتنامه را قبول کنید'
      ];
      break;

    default:
      instructions.steps = [
        'بازی را باز کنید',
        'با میزبان تماس بگیرید',
        'دستورالعمل‌های ویژه را دنبال کنید'
      ];
  }

  return instructions;
}

export default {
  detectPlatform,
  isAppInstalled,
  launchGame,
  copyToClipboard,
  generateLobbyLink,
  parseLobbyLink,
  generateLaunchInstructions,
  createSteamConnection
};