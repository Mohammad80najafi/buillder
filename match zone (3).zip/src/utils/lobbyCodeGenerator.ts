/**
 * Lobby Code Generator Utility
 * Generates unique, shareable lobby codes for Matchzone gaming platform
 */

// Generate a random lobby code (6 characters: letters + numbers)
export function generateLobbyCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// Generate lobby code from lobby ID (deterministic)
export function getLobbyCodeFromId(lobbyId: string): string {
  // In real app, this would be a hash or database lookup
  // For demo, we'll create a deterministic code
  const hash = lobbyId.split('').reduce((a, b) => {
    a = ((a << 5) - a) + b.charCodeAt(0);
    return a & a;
  }, 0);
  
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  let num = Math.abs(hash);
  
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(num % chars.length);
    num = Math.floor(num / chars.length);
  }
  
  return result.padStart(6, 'A');
}

// Generate lobby URL for sharing
export function generateLobbyUrl(lobbyId: string): string {
  const lobbyCode = getLobbyCodeFromId(lobbyId);
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://matchzone.ir';
  return `${baseUrl}/lobby/${lobbyCode}`;
}

// Generate share text for different platforms
export function generateShareText(lobbyName: string, lobbyCode: string, gameTitle: string): string {
  return `🎮 بیا توی لابی "${lobbyName}" بپیون!
🎯 بازی: ${gameTitle}
🔑 کد لابی: ${lobbyCode}
📱 Matchzone - بهترین پلتفرم گیمینگ ایران`;
}

import { safeCopy, ClipboardResult } from './clipboardUtils';

// Copy text to clipboard with multiple fallback methods
export async function copyToClipboard(text: string): Promise<ClipboardResult> {
  return safeCopy(text);
}

// Share via Web Share API (mobile)
export async function shareViaWebAPI(data: ShareData): Promise<boolean> {
  try {
    if (navigator.share) {
      await navigator.share(data);
      return true;
    }
    return false;
  } catch (error) {
    console.error('Error sharing: ', error);
    return false;
  }
}