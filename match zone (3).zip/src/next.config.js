/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    // Enable React 18 features
    appDir: true,
    // TypeScript strict mode
    typedRoutes: true,
  },
  
  // TypeScript configuration
  typescript: {
    // Enable TypeScript errors to fail the build
    ignoreBuildErrors: false,
  },

  // ESLint configuration
  eslint: {
    ignoreDuringBuilds: false,
  },

  // Performance optimizations
  swcMinify: true,
  
  // Image optimization
  images: {
    domains: ['images.unsplash.com', 'source.unsplash.com'],
    formats: ['image/webp', 'image/avif'],
  },

  // PWA support for mobile experience
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
        ],
      },
    ];
  },

  // RTL support
  i18n: {
    locales: ['fa', 'en'],
    defaultLocale: 'fa',
    localeDetection: false,
  },

  // Runtime config for environment variables
  publicRuntimeConfig: {
    NODE_ENV: process.env.NODE_ENV,
  },

  // Webpack configuration for custom optimizations
  webpack: (config, { isServer }) => {
    // Custom webpack rules can go here
    if (!isServer) {
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
      };
    }
    
    return config;
  },
};

module.exports = nextConfig;