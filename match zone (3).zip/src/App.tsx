/**
 * Matchzone Gaming Platform
 * Main application entry point - Component-oriented architecture
 */

import React from 'react';
import { AppProviders } from './components/providers/AppProviders';
import { AuthGuard } from './components/auth/AuthGuard';
import { AppLayout } from './components/layout/AppLayout';
import { Toaster } from './components/ui/sonner';

/**
 * Main App Component
 * 
 * Features:
 * - Component-based architecture
 * - Centralized state management
 * - Responsive design (mobile/desktop)
 * - RTL support
 * - Theme system (dark/light)
 * - Authentication flow
 * - Navigation routing
 * - Friend invitation system
 * - Notification system
 * 
 * @returns {JSX.Element} The main application
 */
function App(): JSX.Element {
  return (
    <AppProviders>
      <AuthGuard>
        <AppLayout />
        <Toaster 
          position="top-center"
          dir="rtl"
          richColors
          closeButton
          theme="dark"
        />
      </AuthGuard>
    </AppProviders>
  );
}

export default App;