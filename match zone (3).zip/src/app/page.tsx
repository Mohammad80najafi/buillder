'use client';

import React, { useState } from 'react';
import { NotificationProvider } from '../components/system/NotificationService';
import { AppHeader } from '../components/layout/AppHeader';
import { BottomNavigation } from '../components/layout/BottomNavigation';
import { SideNavigation } from '../components/layout/SideNavigation';
import { HomePage } from '../components/pages/HomePage';
import { LobbiesPage } from '../components/pages/LobbiesPage';
import { TournamentsPage } from '../components/pages/TournamentsPage';
import { SocialPage } from '../components/pages/SocialPage';
import { ProfilePage } from '../components/pages/ProfilePage';
import { AuthPage } from '../components/pages/AuthPage';
import { SettingsPage } from '../components/pages/SettingsPage';
import { StorePage } from '../components/store/StorePage';
import { MediaPage } from '../components/media/MediaPage';
import { ComponentShowcase } from '../components/pages/ComponentShowcase';
import { HomeDiscoverPage } from '../components/pages/mz-home-discover';
import { MobileHomePage } from '../components/pages/MobileHomePage';
import { CreativeMobileHome } from '../components/pages/CreativeMobileHome';
import { ScrollbarShowcase } from '../components/pages/ScrollbarShowcase';
import { PropsNotesPage } from '../components/docs/99_Props_Notes_Fixed';

import { useMobile } from '../components/ui/use-mobile';

// Strict TypeScript types
type Page = 'home' | 'lobbies' | 'tournaments' | 'social' | 'profile' | 'store' | 'media' | 'settings' | 'showcase' | 'scrollbar' | 'docs' | 'auth';

interface AppState {
  currentPage: Page;
  isAuthenticated: boolean;
  sidebarCollapsed: boolean;
}

export default function MatchzonePage(): JSX.Element {
  const [appState, setAppState] = useState<AppState>({
    currentPage: 'home',
    isAuthenticated: true,
    sidebarCollapsed: false,
  });
  
  const isMobile = useMobile();

  const handleNavigation = (page: Page): void => {
    setAppState(prev => ({ ...prev, currentPage: page }));
  };

  const handleAuth = (success: boolean): void => {
    setAppState(prev => ({
      ...prev,
      isAuthenticated: success,
      currentPage: success ? 'home' : 'auth'
    }));
  };

  const toggleSidebar = (): void => {
    setAppState(prev => ({ ...prev, sidebarCollapsed: !prev.sidebarCollapsed }));
  };

  if (!appState.isAuthenticated) {
    return <AuthPage onAuth={handleAuth} />;
  }

  // Show showcase pages for demonstration (outside provider for specific demos)
  if (appState.currentPage === 'showcase') {
    return <ComponentShowcase />;
  }
  
  if (appState.currentPage === 'scrollbar') {
    return <ScrollbarShowcase />;
  }

  const renderPage = (): JSX.Element => {
    switch (appState.currentPage) {
      case 'home':
        return isMobile ? <CreativeMobileHome /> : <HomeDiscoverPage />;
      case 'lobbies':
        return <LobbiesPage />;
      case 'tournaments':
        return <TournamentsPage />;
      case 'social':
        return <SocialPage />;
      case 'profile':
        return <ProfilePage />;
      case 'store':
        return <StorePage />;
      case 'media':
        return <MediaPage />;
      case 'settings':
        return <SettingsPage />;
      case 'showcase':
        return <ComponentShowcase />;
      case 'scrollbar':
        return <ScrollbarShowcase />;
      case 'docs':
        return <PropsNotesPage />;
      default:
        return isMobile ? <CreativeMobileHome /> : <HomeDiscoverPage />;
    }
  };

  return (
    <NotificationProvider>
      <div className="min-h-screen bg-background dark gaming-scroll">
        {!(isMobile && appState.currentPage === 'home') && (
          <AppHeader 
            onToggleSidebar={!isMobile ? toggleSidebar : undefined} 
            sidebarCollapsed={appState.sidebarCollapsed}
          />
        )}
        
        <div className="flex">
          <main className={`flex-1 ${!isMobile ? (appState.sidebarCollapsed ? 'pr-16' : 'pr-64') : ''} ${isMobile ? 'pb-16' : ''} transition-all duration-300`}>
            {isMobile && appState.currentPage === 'home' ? (
              <div className="gaming-scroll">
                {renderPage()}
              </div>
            ) : (
              <div className={`container mx-auto px-4 py-6 ${isMobile ? 'max-w-full' : 'max-w-7xl'} gaming-scroll`}>
                {renderPage()}
              </div>
            )}
          </main>
          
          {!isMobile && (
            <SideNavigation 
              currentPage={appState.currentPage} 
              onNavigate={handleNavigation}
              collapsed={appState.sidebarCollapsed}
              onToggle={toggleSidebar}
            />
          )}
        </div>

        {isMobile && (
          <BottomNavigation currentPage={appState.currentPage} onNavigate={handleNavigation} />
        )}
      </div>
    </NotificationProvider>
  );
}