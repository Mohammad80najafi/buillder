import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import '../styles/globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' })

export const metadata: Metadata = {
  title: {
    default: 'Matchzone - پلتفرم گیمینگ اجتماعی ایرانی',
    template: '%s | Matchzone'
  },
  description: 'بهترین پلتفرم گیمینگ اجتماعی ایرانی برای بازی‌های آنلاین، تورنومنت‌ها و تعامل با گیمرها',
  keywords: ['گیمینگ', 'بازی آنلاین', 'تورنومنت', 'ایرانی', 'اجتماعی'],
  authors: [{ name: 'Matchzone Team' }],
  creator: 'Matchzone',
  publisher: 'Matchzone',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  manifest: '/site.webmanifest',
  openGraph: {
    type: 'website',
    locale: 'fa_IR',
    url: 'https://matchzone.ir',
    siteName: 'Matchzone',
    title: 'Matchzone - پلتفرم گیمینگ اجتماعی ایرانی',
    description: 'بهترین پلتفرم گیمینگ اجتماعی ایرانی برای بازی‌های آنلاین، تورنومنت‌ها و تعامل با گیمرها',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Matchzone Social Gaming Platform',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Matchzone - پلتفرم گیمینگ اجتماعی ایرانی',
    description: 'بهترین پلتفرم گیمینگ اجتماعی ایرانی برای بازی‌های آنلاین، تورنومنت‌ها و تعامل با گیمرها',
    images: ['/og-image.png'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-verification-code',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fa" dir="rtl" className={inter.variable}>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, viewport-fit=cover" />
        <meta name="theme-color" content="#0F1115" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="Matchzone" />
        <link rel="preconnect" href="https://images.unsplash.com" />
        <link rel="dns-prefetch" href="https://images.unsplash.com" />
      </head>
      <body className={`${inter.className} min-h-screen bg-background text-foreground antialiased`}>
        <div id="root">
          {children}
        </div>
      </body>
    </html>
  )
}