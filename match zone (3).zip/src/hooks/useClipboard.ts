/**
 * useClipboard Hook
 * Easy-to-use clipboard functionality with multiple fallback strategies
 */

import { useState, useCallback } from 'react';
import { safeCopy } from '../utils/clipboardUtils';

export interface UseClipboardOptions {
  timeout?: number;
  onSuccess?: (method: string) => void;
  onError?: (error: string) => void;
}

export interface UseClipboardReturn {
  copy: (text: string) => Promise<boolean>;
  copied: boolean;
  error: string | null;
  isSupported: boolean;
}

export function useClipboard(options: UseClipboardOptions = {}): UseClipboardReturn {
  const { timeout = 2000, onSuccess, onError } = options;
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const copy = useCallback(async (text: string): Promise<boolean> => {
    if (!text) {
      const errorMsg = 'متن برای کپی کردن موجود نیست';
      setError(errorMsg);
      onError?.(errorMsg);
      return false;
    }

    try {
      const result = await safeCopy(text);
      
      if (result.success) {
        setCopied(true);
        setError(null);
        onSuccess?.(result.method || 'unknown');
        
        // Reset copied state after timeout
        setTimeout(() => {
          setCopied(false);
        }, timeout);
        
        return true;
      } else {
        const errorMsg = result.error || 'خطا در کپی کردن';
        setError(errorMsg);
        onError?.(errorMsg);
        return false;
      }
    } catch (err) {
      const errorMsg = 'خطای غیرمنتظره در کپی کردن';
      setError(errorMsg);
      onError?.(errorMsg);
      return false;
    }
  }, [timeout, onSuccess, onError]);

  const isSupported = !!(navigator.clipboard || document.execCommand);

  return {
    copy,
    copied,
    error,
    isSupported
  };
}

/**
 * Hook مخصوص کپی کردن با toast notification
 */
export function useClipboardWithToast(options: UseClipboardOptions = {}) {
  return useClipboard({
    ...options,
    onSuccess: (method) => {
      // This will be handled by the component using the hook
      options.onSuccess?.(method);
    },
    onError: (error) => {
      // This will be handled by the component using the hook
      options.onError?.(error);
    }
  });
}