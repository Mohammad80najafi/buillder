/**
 * Friends Hook
 * Manages friend list, online status, and social sharing
 */

import { useState, useEffect } from 'react';
import { Friend, FriendInviteStatus } from '../types/friends';

// Mock data for demonstration
const mockFriends: Friend[] = [
  {
    id: '1',
    username: 'gaming_pro',
    displayName: 'علی رضایی',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop&crop=face',
    isOnline: true,
    status: 'online',
    currentGame: 'CS2',
    platform: 'matchzone',
    mutualFriends: 12
  },
  {
    id: '2',
    username: 'sara_gamer',
    displayName: 'سارا احمدی',
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b1e3?w=64&h=64&fit=crop&crop=face',
    isOnline: true,
    status: 'busy',
    currentGame: 'Valorant',
    platform: 'matchzone',
    mutualFriends: 8
  },
  {
    id: '3',
    username: 'reza_esports',
    displayName: 'رضا محمدی',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop&crop=face',
    isOnline: true,
    status: 'away',
    lastSeen: new Date(Date.now() - 5 * 60 * 1000), // 5 minutes ago
    platform: 'matchzone',
    mutualFriends: 15
  },
  {
    id: '4',
    username: 'mina_stream',
    displayName: 'مینا کریمی',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop&crop=face',
    isOnline: false,
    status: 'offline',
    lastSeen: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    platform: 'discord',
    socialHandle: 'mina_stream#1234',
    mutualFriends: 6
  },
  {
    id: '5',
    username: 'hassan_fps',
    displayName: 'حسن علوی',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=64&h=64&fit=crop&crop=face',
    isOnline: false,
    status: 'offline',
    lastSeen: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
    platform: 'telegram',
    socialHandle: '@hassan_fps',
    mutualFriends: 10
  },
  {
    id: '6',
    username: 'negar_competitive',
    displayName: 'نگار صادقی',
    avatar: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=64&h=64&fit=crop&crop=face',
    isOnline: true,
    status: 'online',
    currentGame: 'Fortnite',
    platform: 'instagram',
    socialHandle: '@negar_competitive',
    mutualFriends: 4
  }
];

export function useFriends() {
  const [friends, setFriends] = useState<Friend[]>([]);
  const [inviteStatuses, setInviteStatuses] = useState<Map<string, FriendInviteStatus>>(new Map());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setFriends(mockFriends);
      setLoading(false);
    }, 500);
  }, []);

  // Sort friends: online first, then by last seen
  const sortedFriends = friends.sort((a, b) => {
    // Online friends first
    if (a.isOnline && !b.isOnline) return -1;
    if (!a.isOnline && b.isOnline) return 1;
    
    // If both online, sort by status priority
    if (a.isOnline && b.isOnline) {
      const statusPriority = { online: 0, away: 1, busy: 2, offline: 3 };
      const aPriority = statusPriority[a.status || 'offline'];
      const bPriority = statusPriority[b.status || 'offline'];
      if (aPriority !== bPriority) return aPriority - bPriority;
    }
    
    // If both offline, sort by last seen (most recent first)
    if (!a.isOnline && !b.isOnline) {
      const aTime = a.lastSeen?.getTime() || 0;
      const bTime = b.lastSeen?.getTime() || 0;
      return bTime - aTime;
    }
    
    return 0;
  });

  const sendLobbyInvite = async (friendId: string, lobbyData: any) => {
    const friend = friends.find(f => f.id === friendId);
    if (!friend) return;

    const inviteStatus: FriendInviteStatus = {
      friendId,
      status: 'sent',
      sentAt: new Date()
    };

    setInviteStatuses(prev => new Map(prev).set(friendId, inviteStatus));

    // Simulate network delay and status updates
    setTimeout(() => {
      setInviteStatuses(prev => {
        const newMap = new Map(prev);
        const current = newMap.get(friendId);
        if (current) {
          newMap.set(friendId, { ...current, status: 'delivered' });
        }
        return newMap;
      });
    }, 1000);

    // Simulate friend seeing the invite
    setTimeout(() => {
      setInviteStatuses(prev => {
        const newMap = new Map(prev);
        const current = newMap.get(friendId);
        if (current) {
          newMap.set(friendId, { ...current, status: 'seen', seenAt: new Date() });
        }
        return newMap;
      });
    }, 3000);
  };

  const getOnlineFriends = () => sortedFriends.filter(f => f.isOnline);
  const getOfflineFriends = () => sortedFriends.filter(f => !f.isOnline);

  return {
    friends: sortedFriends,
    onlineFriends: getOnlineFriends(),
    offlineFriends: getOfflineFriends(),
    inviteStatuses,
    loading,
    sendLobbyInvite
  };
}