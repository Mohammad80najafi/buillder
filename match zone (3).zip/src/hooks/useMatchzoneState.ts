/**
 * Matchzone Global State Hook
 * Centralized state management for gaming platform
 */

import { useState, useCallback, useContext, createContext, useEffect } from 'react';
import { UserSummary, LobbyData, TournamentData, MessageData } from '../components/ui/interfaces';

interface MatchzoneState {
  // User state
  user: UserSummary | null;
  isAuthenticated: boolean;
  
  // Gaming state  
  activeLobbies: LobbyData[];
  activeTournaments: TournamentData[];
  recentMessages: MessageData[];
  
  // UI state
  notifications: Notification[];
  isLoading: boolean;
  error: string | null;
  
  // Settings
  theme: 'light' | 'dark' | 'system';
  language: 'fa' | 'en';
  soundEnabled: boolean;
}

interface MatchzoneActions {
  // User actions
  setUser: (user: UserSummary | null) => void;
  authenticate: (success: boolean) => void;
  logout: () => void;
  
  // Gaming actions
  joinLobby: (lobbyId: string) => Promise<void>;
  leaveLobby: (lobbyId: string) => Promise<void>;
  createLobby: (data: Partial<LobbyData>) => Promise<LobbyData>;
  joinTournament: (tournamentId: string) => Promise<void>;
  
  // Message actions
  sendMessage: (content: string, targetId: string) => Promise<void>;
  
  // UI actions
  addNotification: (notification: Notification) => void;
  removeNotification: (id: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  
  // Settings actions
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  setLanguage: (language: 'fa' | 'en') => void;
  toggleSound: () => void;
}

interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  actionUrl?: string;
}

const initialState: MatchzoneState = {
  user: null,
  isAuthenticated: false,
  activeLobbies: [],
  activeTournaments: [],
  recentMessages: [],
  notifications: [],
  isLoading: false,
  error: null,
  theme: 'dark',
  language: 'fa',
  soundEnabled: true
};

export function useMatchzoneState() {
  const [state, setState] = useState<MatchzoneState>(initialState);

  // User actions
  const setUser = useCallback((user: UserSummary | null) => {
    setState(prev => ({ ...prev, user }));
  }, []);

  const authenticate = useCallback((success: boolean) => {
    setState(prev => ({ 
      ...prev, 
      isAuthenticated: success,
      user: success ? prev.user : null
    }));
  }, []);

  const logout = useCallback(() => {
    setState(prev => ({ 
      ...prev, 
      isAuthenticated: false,
      user: null,
      activeLobbies: [],
      activeTournaments: [],
      recentMessages: []
    }));
  }, []);

  // Gaming actions
  const joinLobby = useCallback(async (lobbyId: string) => {
    setState(prev => ({ ...prev, isLoading: true }));
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Add lobby to active lobbies
      const mockLobby: LobbyData = {
        id: lobbyId,
        title: 'مسابقه تیمی',
        game: 'Call of Duty',
        status: 'open',
        currentPlayers: 3,
        maxPlayers: 4,
        owner: {
          id: 'owner-1',
          username: 'محمد',
          trustLevel: 'high'
        },
        visibility: 'public',
        createdAt: new Date().toISOString()
      };
      
      setState(prev => ({
        ...prev,
        activeLobbies: [...prev.activeLobbies, mockLobby],
        isLoading: false
      }));
      
      addNotification({
        id: Date.now().toString(),
        type: 'success',
        title: 'موفقیت',
        message: 'با موفقیت به لابی پیوستید',
        timestamp: new Date(),
        read: false
      });
    } catch (error) {
      setState(prev => ({ 
        ...prev, 
        isLoading: false,
        error: 'خطا در پیوستن به لابی'
      }));
    }
  }, []);

  const leaveLobby = useCallback(async (lobbyId: string) => {
    setState(prev => ({
      ...prev,
      activeLobbies: prev.activeLobbies.filter(lobby => lobby.id !== lobbyId)
    }));
  }, []);

  const createLobby = useCallback(async (data: Partial<LobbyData>): Promise<LobbyData> => {
    setState(prev => ({ ...prev, isLoading: true }));
    
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const newLobby: LobbyData = {
        id: Date.now().toString(),
        title: data.title || 'لابی جدید',
        game: data.game || 'بازی انتخابی',
        status: 'open',
        currentPlayers: 1,
        maxPlayers: data.maxPlayers || 4,
        owner: state.user!,
        visibility: data.visibility || 'public',
        createdAt: new Date().toISOString()
      };
      
      setState(prev => ({
        ...prev,
        activeLobbies: [...prev.activeLobbies, newLobby],
        isLoading: false
      }));
      
      return newLobby;
    } catch (error) {
      setState(prev => ({ 
        ...prev, 
        isLoading: false,
        error: 'خطا در ایجاد لابی'
      }));
      throw error;
    }
  }, [state.user]);

  // Notification actions
  const addNotification = useCallback((notification: Notification) => {
    setState(prev => ({
      ...prev,
      notifications: [notification, ...prev.notifications]
    }));
  }, []);

  const removeNotification = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      notifications: prev.notifications.filter(n => n.id !== id)
    }));
  }, []);

  // UI actions
  const setLoading = useCallback((loading: boolean) => {
    setState(prev => ({ ...prev, isLoading: loading }));
  }, []);

  const setError = useCallback((error: string | null) => {
    setState(prev => ({ ...prev, error }));
  }, []);

  // Settings actions
  const setTheme = useCallback((theme: 'light' | 'dark' | 'system') => {
    setState(prev => ({ ...prev, theme }));
    
    // Apply theme to document
    document.documentElement.className = theme === 'system' 
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : theme;
  }, []);

  const setLanguage = useCallback((language: 'fa' | 'en') => {
    setState(prev => ({ ...prev, language }));
    document.documentElement.dir = language === 'fa' ? 'rtl' : 'ltr';
  }, []);

  const toggleSound = useCallback(() => {
    setState(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }));
  }, []);

  // Mock data initialization
  useEffect(() => {
    const initializeMockData = () => {
      const mockUser: UserSummary = {
        id: 'user-1',
        username: 'محمد',
        isVerified: true,
        trustLevel: 'high',
        followerCount: 150
      };

      setState(prev => ({
        ...prev,
        user: mockUser,
        isAuthenticated: true
      }));
    };

    initializeMockData();
  }, []);

  const actions: MatchzoneActions = {
    setUser,
    authenticate,
    logout,
    joinLobby,
    leaveLobby,
    createLobby,
    joinTournament: async () => {}, // Mock
    sendMessage: async () => {}, // Mock
    addNotification,
    removeNotification,
    setLoading,
    setError,
    setTheme,
    setLanguage,
    toggleSound
  };

  return {
    state,
    actions
  };
}

// Context for global state sharing
const MatchzoneStateContext = createContext<{
  state: MatchzoneState;
  actions: MatchzoneActions;
} | null>(null);

export function useMatchzoneContext() {
  const context = useContext(MatchzoneStateContext);
  if (!context) {
    throw new Error('useMatchzoneContext must be used within MatchzoneStateProvider');
  }
  return context;
}

export { MatchzoneStateContext };