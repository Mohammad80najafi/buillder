// Global type definitions for Matchzone

export {};

declare global {
  // Environment variables
  namespace NodeJS {
    interface ProcessEnv {
      readonly NODE_ENV: 'development' | 'production' | 'test';
      readonly NEXT_PUBLIC_APP_URL: string;
      readonly NEXT_PUBLIC_SUPABASE_URL?: string;
      readonly NEXT_PUBLIC_SUPABASE_ANON_KEY?: string;
    }
  }

  // Custom CSS properties
  interface CSSStyleDeclaration {
    [key: `--${string}`]: string;
  }

  // Figma asset imports
  declare module 'figma:asset/*' {
    const value: string;
    export default value;
  }
}

// Utility types for strict TypeScript
export type StrictOmit<T, K extends keyof T> = Omit<T, K>;
export type StrictPick<T, K extends keyof T> = Pick<T, K>;

// Component prop types
export interface BaseComponentProps {
  readonly className?: string;
  readonly children?: React.ReactNode;
}

// Navigation types
export type NavigationPage = 
  | 'home' 
  | 'lobbies' 
  | 'tournaments' 
  | 'social' 
  | 'profile' 
  | 'store' 
  | 'media' 
  | 'settings' 
  | 'showcase' 
  | 'scrollbar' 
  | 'docs' 
  | 'auth';

// Gaming types
export interface GameLobby {
  readonly id: string;
  readonly title: string;
  readonly game: string;
  readonly players: number;
  readonly maxPlayers: number;
  readonly status: 'waiting' | 'playing' | 'finished';
  readonly createdAt: Date;
}

export interface Tournament {
  readonly id: string;
  readonly title: string;
  readonly game: string;
  readonly participants: number;
  readonly maxParticipants: number;
  readonly prizePool: number;
  readonly startDate: Date;
  readonly status: 'upcoming' | 'live' | 'finished';
}

// User types
export interface User {
  readonly id: string;
  readonly username: string;
  readonly displayName: string;
  readonly avatar?: string;
  readonly level: number;
  readonly xp: number;
  readonly isOnline: boolean;
  readonly lastSeen: Date;
}

// Notification types
export type NotificationType = 
  | 'tournament'
  | 'lobby' 
  | 'social'
  | 'system'
  | 'promotion'
  | 'achievement';

export interface Notification {
  readonly id: string;
  readonly type: NotificationType;
  readonly title: string;
  readonly message: string;
  readonly data?: Record<string, unknown>;
  readonly read: boolean;
  readonly createdAt: Date;
}

// API response types
export interface ApiResponse<T = unknown> {
  readonly success: boolean;
  readonly data?: T;
  readonly error?: string;
  readonly message?: string;
}

// Form types
export interface FormField {
  readonly name: string;
  readonly value: string | number | boolean;
  readonly error?: string;
  readonly required?: boolean;
}

// Theme types
export type ThemeMode = 'light' | 'dark';

export interface ThemeConfig {
  readonly mode: ThemeMode;
  readonly primaryColor: string;
  readonly accentColor: string;
}

// Mobile detection
export interface MobileBreakpoints {
  readonly sm: number;
  readonly md: number;
  readonly lg: number;
  readonly xl: number;
}