/**
 * Matchzone Navigation Types
 * Comprehensive type definitions for routing and navigation
 */

export type NavigationPage = 
  | 'home' 
  | 'lobbies' 
  | 'lobby-detail'
  | 'create-lobby'
  | 'tournaments'
  | 'clans'
  | 'social' 
  | 'profile' 
  | 'store' 
  | 'coaching'
  | 'analytics'
  | 'settings' 
  | 'showcase' 
  | 'scrollbar' 
  | 'docs' 
  | 'component-test'
  | 'final-showcase'
  | 'membership-test'
  | 'countdown-timer-demo'
  | 'lobby-chat-demo'
  | 'clan-chat-demo'
  | 'social-comparison'
  | 'stage4-showcase'
  | 'stage5-showcase'
  | 'chat-test'
  | 'chat-list'
  | 'videos'
  | 'video-detail'
  | 'video-test'
  | 'notifications'
  | 'auth';

export interface NavigationState {
  currentPage: NavigationPage;
  isAuthenticated: boolean;
  currentLobbyId?: string;
}

export interface NavigationActions {
  navigate: (page: NavigationPage) => void;
  navigateToLobby: (lobbyId: string) => void;
  authenticate: (success: boolean) => void;
  logout: () => void;
}

export interface NavigationConfig {
  requiresAuth: NavigationPage[];
  mobilePages: NavigationPage[];
  desktopPages: NavigationPage[];
  showcasePages: NavigationPage[];
}

export interface PageComponent {
  page: NavigationPage;
  component: React.ComponentType<any>;
  mobile?: React.ComponentType<any>;
  desktop?: React.ComponentType<any>;
  requiresAuth?: boolean;
  showHeader?: boolean;
  showNavigation?: boolean;
}