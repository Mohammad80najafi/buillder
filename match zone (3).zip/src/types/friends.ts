/**
 * Friends System Types
 * Type definitions for friend management and social features
 */

export interface Friend {
  id: string;
  username: string;
  avatar?: string;
  displayName: string;
  isOnline: boolean;
  lastSeen?: Date;
  status?: 'online' | 'away' | 'busy' | 'offline';
  currentGame?: string;
  mutualFriends?: number;
  platform?: 'matchzone' | 'discord' | 'telegram' | 'instagram';
  socialHandle?: string;
}

export interface FriendInviteStatus {
  friendId: string;
  status: 'pending' | 'sent' | 'delivered' | 'seen' | 'joined' | 'declined';
  sentAt: Date;
  seenAt?: Date;
  joinedAt?: Date;
}

export interface SocialShare {
  platform: 'whatsapp' | 'telegram' | 'instagram' | 'discord';
  friendId?: string;
  username?: string;
  displayName?: string;
}