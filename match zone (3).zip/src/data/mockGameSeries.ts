/**
 * Mock Data for Game Series
 * داده‌های نمونه برای سری بازی‌ها
 */

import { GameSeries } from '../components/gaming/GameSeriesCard';

export const mockGameSeries: GameSeries[] = [
  {
    id: 'last-survivor-series',
    title: 'آخرین بازمانده',
    description: 'سری هیجان‌انگیز بقا در جزیره مرموز با چالش‌های سخت و مهیج',
    coverImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&h=400&fit=crop',
    totalEpisodes: 12,
    completedEpisodes: 3,
    category: 'بقا و تاکتیک',
    rating: 4.8,
    isPremium: true,
    creator: {
      name: 'استودیو گیم ایران',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
      verified: true
    },
    stats: {
      totalViews: 1250000,
      totalParticipants: 89420,
      averageRating: 4.8
    },
    episodes: [
      {
        id: 'ep1',
        title: 'ورود به جزیره',
        description: 'اولین قدم در جزیره مرموز و آشنایی با محیط',
        thumbnail: 'https://images.unsplash.com/photo-1551103782-8ab07afd45c1?w=400&h=250&fit=crop',
        duration: '45:32',
        releaseDate: '1403/01/15',
        isNew: false,
        isWatched: true,
        isLocked: false,
        views: 340000,
        likes: 28400,
        difficulty: 'آسان',
        participants: 15200
      },
      {
        id: 'ep2',
        title: 'اولین چالش',
        description: 'جستجو برای منابع و ساخت پناهگاه اولیه',
        thumbnail: 'https://images.unsplash.com/photo-1504681869696-d977211a5f4c?w=400&h=250&fit=crop',
        duration: '52:18',
        releaseDate: '1403/01/22',
        isNew: false,
        isWatched: true,
        isLocked: false,
        views: 298000,
        likes: 25100,
        difficulty: 'متوسط',
        participants: 12800
      },
      {
        id: 'ep3',
        title: 'شکار یا شکارچی',
        description: 'رویارویی با حیوانات وحشی و تاکتیک‌های شکار',
        thumbnail: 'https://images.unsplash.com/photo-1574263867128-5fdecc80a02e?w=400&h=250&fit=crop',
        duration: '48:45',
        releaseDate: '1403/01/29',
        isNew: false,
        isWatched: true,
        isLocked: false,
        views: 275000,
        likes: 23600,
        difficulty: 'سخت',
        participants: 10900
      },
      {
        id: 'ep4',
        title: 'اتحاد یا خیانت',
        description: 'تشکیل تیم و تصمیمات سرنوشت‌ساز',
        thumbnail: 'https://images.unsplash.com/photo-1595273670150-bd0c3c392e46?w=400&h=250&fit=crop',
        duration: '55:20',
        releaseDate: '1403/02/05',
        isNew: true,
        isWatched: false,
        isLocked: false,
        views: 0,
        likes: 0,
        difficulty: 'سخت',
        participants: 0
      },
      {
        id: 'ep5',
        title: 'راز غار مخفی',
        description: 'کشف رازهای پنهان جزیره در اعماق غار',
        thumbnail: 'https://images.unsplash.com/photo-1547036967-23d11aacaee0?w=400&h=250&fit=crop',
        duration: '50:15',
        releaseDate: '1403/02/12',
        isNew: false,
        isWatched: false,
        isLocked: true,
        views: 0,
        likes: 0,
        difficulty: 'خیلی سخت'
      }
    ]
  },
  {
    id: 'urban-warrior',
    title: 'جنگجوی شهری',
    description: 'مبارزات خیابانی و تاکتیک‌های شهری در محیط آپوکالیپتیک',
    coverImage: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=800&h=400&fit=crop',
    totalEpisodes: 8,
    completedEpisodes: 0,
    category: 'اکشن و مبارزه',
    rating: 4.6,
    isPremium: false,
    creator: {
      name: 'تیم گیمینگ تهران',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
      verified: true
    },
    stats: {
      totalViews: 850000,
      totalParticipants: 45600,
      averageRating: 4.6
    },
    episodes: [
      {
        id: 'uw1',
        title: 'نابودی آغاز شد',
        description: 'روز اول آپوکالیپس و بقای اولیه',
        thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=250&fit=crop',
        duration: '42:30',
        releaseDate: '1403/01/10',
        isNew: false,
        isWatched: false,
        isLocked: false,
        views: 180000,
        likes: 15200,
        difficulty: 'متوسط',
        participants: 8500
      },
      {
        id: 'uw2',
        title: 'جنگ خیابان‌ها',
        description: 'تاکتیک‌های مبارزه در فضای شهری',
        thumbnail: 'https://images.unsplash.com/photo-1574263867128-5fdecc80a02e?w=400&h=250&fit=crop',
        duration: '38:45',
        releaseDate: '1403/01/17',
        isNew: false,
        isWatched: false,
        isLocked: false,
        views: 165000,
        likes: 14100,
        difficulty: 'سخت',
        participants: 7200
      }
    ]
  },
  {
    id: 'racing-legends',
    title: 'افسانه‌های سرعت',
    description: 'مسابقات اتومبیل‌رانی در مسیرهای خطرناک جهان',
    coverImage: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=800&h=400&fit=crop',
    totalEpisodes: 10,
    completedEpisodes: 6,
    category: 'ورزشی و مسابقه‌ای',
    rating: 4.7,
    isPremium: true,
    creator: {
      name: 'استودیو سرعت',
      avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop&crop=face',
      verified: true
    },
    stats: {
      totalViews: 2100000,
      totalParticipants: 156000,
      averageRating: 4.7
    },
    episodes: [
      {
        id: 'rl1',
        title: 'مسیر کوهستان',
        description: 'رانندگی در جاده‌های پرپیچ و خم کوهستان',
        thumbnail: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=400&h=250&fit=crop',
        duration: '35:20',
        releaseDate: '1402/12/01',
        isNew: false,
        isWatched: true,
        isLocked: false,
        views: 290000,
        likes: 24500,
        difficulty: 'متوسط',
        participants: 18900
      },
      {
        id: 'rl2',
        title: 'شب نئون',
        description: 'مسابقه شبانه در خیابان‌های شهر',
        thumbnail: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=250&fit=crop',
        duration: '40:15',
        releaseDate: '1402/12/08',
        isNew: false,
        isWatched: true,
        isLocked: false,
        views: 275000,
        likes: 23100,
        difficulty: 'سخت',
        participants: 16800
      }
    ]
  },
  {
    id: 'mystic-puzzle',
    title: 'معماهای رمزآلود',
    description: 'حل پازل‌های پیچیده و رازهای باستانی',
    coverImage: 'https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?w=800&h=400&fit=crop',
    totalEpisodes: 15,
    completedEpisodes: 2,
    category: 'پازل و فکری',
    rating: 4.5,
    isPremium: false,
    creator: {
      name: 'گروه بازی‌های فکری',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b602?w=100&h=100&fit=crop&crop=face',
      verified: false
    },
    stats: {
      totalViews: 650000,
      totalParticipants: 28500,
      averageRating: 4.5
    },
    episodes: [
      {
        id: 'mp1',
        title: 'آغاز راز',
        description: 'ورود به دنیای معماها و اولین چالش',
        thumbnail: 'https://images.unsplash.com/photo-1567095761054-7a02e69e5c43?w=400&h=250&fit=crop',
        duration: '28:40',
        releaseDate: '1403/01/20',
        isNew: false,
        isWatched: true,
        isLocked: false,
        views: 95000,
        likes: 8200,
        difficulty: 'آسان',
        participants: 4500
      }
    ]
  },
  {
    id: 'space-adventure',
    title: 'ماجراجویی فضایی',
    description: 'سفر به کهکشان‌های ناشناخته و مبارزه با بیگانگان',
    coverImage: 'https://images.unsplash.com/photo-1446776877081-d282a0f896e2?w=800&h=400&fit=crop',
    totalEpisodes: 20,
    completedEpisodes: 0,
    category: 'علمی تخیلی',
    rating: 4.9,
    isPremium: true,
    creator: {
      name: 'استودیو آینده',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop&crop=face',
      verified: true
    },
    stats: {
      totalViews: 3200000,
      totalParticipants: 298000,
      averageRating: 4.9
    },
    episodes: [
      {
        id: 'sa1',
        title: 'پرتاب به فضا',
        description: 'آغاز ماموریت و سفر به مریخ',
        thumbnail: 'https://images.unsplash.com/photo-1516849841032-87cbac4d88f7?w=400&h=250&fit=crop',
        duration: '50:00',
        releaseDate: '1403/02/01',
        isNew: true,
        isWatched: false,
        isLocked: false,
        views: 0,
        likes: 0,
        difficulty: 'متوسط',
        participants: 0
      }
    ]
  }
];

export const getGameSeriesById = (id: string): GameSeries | undefined => {
  return mockGameSeries.find(series => series.id === id);
};

export const getGameSeriesByCategory = (category: string): GameSeries[] => {
  if (category === 'همه') return mockGameSeries;
  return mockGameSeries.filter(series => series.category === category);
};

export const getFeaturedGameSeries = (): GameSeries[] => {
  return mockGameSeries.filter(series => series.rating >= 4.7);
};

export const getPopularGameSeries = (): GameSeries[] => {
  return [...mockGameSeries]
    .sort((a, b) => b.stats.totalViews - a.stats.totalViews)
    .slice(0, 6);
};

export const getNewGameSeries = (): GameSeries[] => {
  return mockGameSeries.filter(series => 
    series.episodes.some(episode => episode.isNew)
  );
};